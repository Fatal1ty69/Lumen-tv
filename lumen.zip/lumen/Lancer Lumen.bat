@echo off
chcp 65001 >nul
setlocal EnableExtensions
title Lumen
cd /d "%~dp0"

rem Lancement quotidien : utilise l'interface deja construite dans dist.
rem Les composants Electron restent hors du dossier du code.
set "RT=%LOCALAPPDATA%\Lumen\runtime"

if not exist "%~dp0runtime-package.json" (
  echo.
  echo  Fichier runtime-package.json introuvable.
  echo  Replace ce fichier a la racine de Lumen puis relance.
  echo.
  pause
  exit /b 1
)

rem Installe ou met a jour le runtime uniquement si necessaire.
fc /b "%~dp0runtime-package.json" "%RT%\package.json" >nul 2>nul
if errorlevel 1 goto install_runtime
if not exist "%RT%\node_modules\electron\dist\electron.exe" goto install_runtime
goto check_dist

:install_runtime
call :check_node
if errorlevel 1 exit /b 1
echo.
echo  Preparation des composants de Lumen...
echo  Cette etape ne se fera de nouveau que si le runtime change.
echo.
if not exist "%RT%" mkdir "%RT%"
copy /y "%~dp0runtime-package.json" "%RT%\package.json" >nul
pushd "%RT%"
call npm install --no-audit --no-fund --loglevel=error
set "ERR=%errorlevel%"
popd
if not "%ERR%"=="0" (
  del "%RT%\package.json" >nul 2>nul
  echo.
  echo  L'installation du runtime a echoue.
  echo  Verifie ta connexion internet puis relance ce fichier.
  echo.
  pause
  exit /b 1
)
if not exist "%RT%\node_modules\electron\dist\electron.exe" (
  echo.
  echo  Electron n'a pas ete installe correctement.
  echo.
  pause
  exit /b 1
)

:check_dist
if exist "%~dp0dist\index.html" goto run
echo.
echo  L'interface construite est absente.
echo  Reconstruction automatique en cours...
echo.
call "%~dp0Mettre a jour Lumen.bat" --no-launch
if errorlevel 1 exit /b 1
if not exist "%~dp0dist\index.html" (
  echo.
  echo  La reconstruction n'a pas cree dist\index.html.
  echo.
  pause
  exit /b 1
)

:run
set "LUMEN_RUNTIME=%RT%"
set "NODE_PATH=%RT%\node_modules"
start "" "%RT%\node_modules\electron\dist\electron.exe" "%~dp0."
exit /b 0

:check_node
where node >nul 2>nul
if not errorlevel 1 exit /b 0
echo.
echo  Node.js n'est pas installe sur ce PC.
echo  Installe la version LTS depuis la page qui va s'ouvrir, puis relance.
echo.
start "" https://nodejs.org/fr/download
pause
exit /b 1
