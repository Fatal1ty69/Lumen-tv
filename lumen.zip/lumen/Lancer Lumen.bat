@echo off
chcp 65001 >nul
title Lumen
cd /d "%~dp0"

rem Les composants (Electron) sont installés une seule fois ici, hors du dossier du code :
rem remplacer le dossier lumen lors d'une mise à jour ne les efface plus.
set "RT=%LOCALAPPDATA%\Lumen\runtime"

rem Installation (ou mise à jour) des composants seulement si leur liste a changé
fc /b "%~dp0runtime-package.json" "%RT%\package.json" >nul 2>nul
if errorlevel 1 goto install
if not exist "%RT%\node_modules\electron\dist\electron.exe" goto install
goto build

:install
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js n'est pas installé sur ce PC.
  echo  Installe la version LTS depuis la page qui va s'ouvrir, puis relance ce fichier.
  echo.
  start https://nodejs.org/fr/download
  pause
  exit /b 1
)
echo.
echo  Installation des composants de Lumen (une seule fois, quelques minutes)...
echo.
if not exist "%RT%" mkdir "%RT%"
copy /y "%~dp0runtime-package.json" "%RT%\package.json" >nul
pushd "%RT%"
call npm install --no-audit --no-fund --loglevel=error
set "ERR=%errorlevel%"
popd
if not "%ERR%"=="0" (
  del "%RT%\package.json" >nul 2>nul
  echo.
  echo  L'installation a échoué. Vérifie ta connexion internet et relance ce fichier.
  pause
  exit /b 1
)

:build
rem L'interface est livrée déjà construite. On ne la reconstruit que si elle manque.
if exist "%~dp0dist\index.html" goto run
echo  Préparation de l'interface (une seule fois)...
call npm install --no-audit --no-fund --loglevel=error
call npm run build --silent
if errorlevel 1 (
  echo  La préparation a échoué.
  pause
  exit /b 1
)

:run
set "LUMEN_RUNTIME=%RT%"
set "NODE_PATH=%RT%\node_modules"
start "" "%RT%\node_modules\electron\dist\electron.exe" "%~dp0."
exit /b 0
