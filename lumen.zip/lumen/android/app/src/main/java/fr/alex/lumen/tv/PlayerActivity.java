package fr.alex.lumen.tv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.OptIn;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Lecteur plein écran de Lumen TV (Media3 / ExoPlayer).
 *
 * Films et séries (mode "vod") : items = [{ url, alt, title, sub, key, kind, introEnd, tmdbId, parentTmdbId, season, episode }]
 *   OK pause · gauche -10 s · droite +30 s · bas : commandes · appui long sur OK (ou Menu) : menu Lumen
 * Direct (mode "live") : chaînes et groupes envoyés une fois (LumenTvPlugin.liveData)
 *   haut : chaîne suivante · bas : chaîne précédente · gauche : liste des chaînes du groupe
 *   droite : dernière chaîne regardée · OK : menu (programme, pistes, image)
 */
@OptIn(markerClass = UnstableApi.class)
public class PlayerActivity extends Activity {

    /** Options de lecture (trop volumineuses pour un Intent) */
    static volatile String pendingOptions = null;
    /** Lecteur affiché (pour les rappels envoyés par Lumen pendant la lecture) */
    static volatile PlayerActivity current = null;

    private ExoPlayer player;
    private PlayerView view;
    private TextView banner, nextHint, introHint, toast;
    private LinearLayout infoBar;
    private ImageView infoLogo;
    private TextView infoTitle, infoNow, infoNext;
    private ProgressBar infoProgress, spinner;
    private ListPanel channelPanel, menuPanel;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private JSONObject opts = new JSONObject();
    private boolean live;
    private boolean finished = false;
    private String error = null;
    private boolean triedAlt = false;

    // Films et séries
    private JSONArray items = new JSONArray();
    private boolean autoNext = true, autoSkipIntro = false;
    private int credits = 40;
    private int index = 0;
    private final List<long[]> seen = new ArrayList<>(); // index, pos ms, dur ms, ended
    private final JSONObject learnedIntro = new JSONObject();
    private boolean introDone = false;

    // Direct
    private JSONArray channels = new JSONArray();
    private JSONArray groups = new JSONArray();
    private JSONArray bases = new JSONArray();
    private JSONArray epgBases = new JSONArray();
    private int group = 0;      // groupe en cours
    private int pos = 0;        // place dans le groupe
    private int channel = -1;   // chaîne en cours (index global)
    private int prevChannel = -1;
    private String liveExt = "ts";
    private int panelGroup = 0;
    private boolean panelOkDown = false, panelOkLong = false;
    private final java.util.Map<String, Boolean> favChanges = new java.util.HashMap<>();
    private boolean altWorked = false;

    // Langues
    private boolean langChanged = false;
    private String audioLang = "fr", subLang = "fr";
    private boolean subOn = false;
    private int resize = 0;

    // Appui long sur OK
    private boolean okDown = false, okLong = false;

    // Rappels (programme qui commence, nouvel épisode)
    private TextView reminder;
    private String reminderKey = null;
    private final Runnable hideReminder = () -> { reminder.setVisibility(View.GONE); reminderKey = null; };
    // Temps passé sur chaque chaîne (récap « Ton année »)
    private final java.util.Map<String, Long> liveTime = new java.util.HashMap<>();
    private int liveTimed = -1;
    private long liveSince = 0;
    private String gotoKey = null;

    private final Runnable hideBanner = () -> banner.setVisibility(View.GONE);
    private final Runnable hideToast = () -> toast.setVisibility(View.GONE);
    private final Runnable hideInfo = () -> infoBar.setVisibility(View.GONE);
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            track();
            updateHints();
            ui.postDelayed(this, 1000);
        }
    };

    // ---------- Démarrage ----------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);

        String raw = pendingOptions;
        pendingOptions = null;
        if (raw == null) raw = getIntent().getStringExtra("options");
        try { opts = new JSONObject(raw != null ? raw : "{}"); } catch (Exception e) { opts = new JSONObject(); }

        live = "live".equals(opts.optString("mode"));
        audioLang = opts.optString("audioLang", "fr");
        subLang = opts.optString("subLang", "fr");
        subOn = opts.optBoolean("subOn", false);
        resize = opts.optInt("resize", 0);

        buildUi();
        buildPlayer();

        if (live) startLive();
        else startVod();

        ui.postDelayed(tick, 1000);
    }

    private boolean reused = false;
    private Player.Listener listener;

    private void buildPlayer() {
        String ua = opts.optString("userAgent", LumenTvPlugin.IPTV_UA);
        // Direct lancé depuis la miniature : on reprend le même lecteur, sans nouvelle connexion
        ExoPlayer fromPreview = live && opts.optBoolean("reuse", false) ? LivePreview.take(opts.optString("startKey", "")) : null;
        reused = fromPreview != null;
        player = reused ? fromPreview : Players.create(this, live, ua);
        applyLangs();
        view.setPlayer(player);
        applyResize();

        listener = new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                spinner.setVisibility(state == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                if (state == Player.STATE_READY && live && triedAlt) altWorked = true;
                if (state == Player.STATE_ENDED && !live) {
                    markEnded(player.getCurrentMediaItemIndex());
                    finishWithResult();
                }
            }

            @Override
            public void onMediaItemTransition(MediaItem item, int reason) {
                if (live) return;
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) markEnded(index);
                index = player.getCurrentMediaItemIndex();
                triedAlt = false;
                introDone = false;
                showBanner();
            }

            @Override
            public void onPlayerError(PlaybackException e) {
                if (!triedAlt) {
                    String alt = live ? liveUrl(channel, "ts".equals(liveExt) ? "m3u8" : "ts") : currentItem() != null ? currentItem().optString("alt", "") : "";
                    if (alt != null && !alt.isEmpty()) {
                        triedAlt = true;
                        if (live) {
                            player.setMediaItem(liveItem(channel, alt));
                        } else {
                            long p = Math.max(0, player.getCurrentPosition());
                            int i = player.getCurrentMediaItemIndex();
                            player.replaceMediaItem(i, vodItem(currentItem(), alt));
                            player.seekTo(i, p);
                        }
                        player.prepare();
                        player.play();
                        return;
                    }
                }
                if (live && e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                if (live) {
                    // En direct on reste dans le lecteur : on prévient et on laisse zapper
                    showToast(describe(e), 4000);
                    return;
                }
                error = describe(e);
                finishWithResult();
            }
        };
        player.addListener(listener);
        spinner.setVisibility(player.getPlaybackState() == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
    }

    private void startVod() {
        items = opts.optJSONArray("items");
        if (items == null) items = new JSONArray();
        autoNext = opts.optBoolean("autoNext", true);
        autoSkipIntro = opts.optBoolean("autoSkipIntro", false);
        credits = opts.optInt("credits", 40);
        index = Math.max(0, Math.min(opts.optInt("index", 0), Math.max(0, items.length() - 1)));
        long startMs = (long) (opts.optDouble("startAt", 0) * 1000);
        List<MediaItem> list = new ArrayList<>();
        for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it != null) list.add(vodItem(it, it.optString("url")));
        }
        player.setMediaItems(list, index, startMs > 0 ? startMs : C.TIME_UNSET);
        player.setPauseAtEndOfMediaItems(!autoNext);
        player.prepare();
        player.play();
        showBanner();
    }

    private void startLive() {
        JSONObject data = LumenTvPlugin.liveData;
        if (data == null) data = new JSONObject();
        channels = data.optJSONArray("channels");
        groups = data.optJSONArray("groups");
        bases = data.optJSONArray("bases");
        epgBases = data.optJSONArray("epg");
        if (channels == null) channels = new JSONArray();
        if (groups == null) groups = new JSONArray();
        if (bases == null) bases = new JSONArray();
        if (epgBases == null) epgBases = new JSONArray();
        liveExt = opts.optString("liveExt", "ts");
        group = Math.max(0, Math.min(opts.optInt("group", 0), Math.max(0, groups.length() - 1)));
        pos = Math.max(0, opts.optInt("pos", 0));
        prevChannel = findChannel(opts.optString("prevKey", ""));
        int start = channelAt(group, pos);
        if (start < 0 && channels.length() > 0) start = 0;
        JSONObject sc = channels.optJSONObject(start);
        if (reused && sc != null && sc.optString("key").equals(opts.optString("startKey", ""))) {
            channel = start;
            markLive();
            player.play();
            showInfo();
            return;
        }
        playChannel(start, false);
    }

    // ---------- Médias ----------

    private MediaItem vodItem(JSONObject it, String url) {
        MediaMetadata meta = new MediaMetadata.Builder()
                .setTitle(it.optString("title", ""))
                .setSubtitle(it.optString("sub", ""))
                .build();
        return new MediaItem.Builder()
                .setUri(Uri.parse(url))
                .setMediaId(it.optString("key", url))
                .setMediaMetadata(meta)
                .build();
    }

    private String liveUrl(int ch, String ext) {
        JSONObject c = channels.optJSONObject(ch);
        if (c == null) return null;
        // Playlist M3U : la chaîne porte déjà son adresse complète
        String direct = c.optString("url", "");
        if (!direct.isEmpty()) return direct;
        String base = bases.optString(c.optInt("a", 0), "");
        return base + c.optString("id") + "." + ext;
    }

    private String epgUrl(int ch) {
        JSONObject c = channels.optJSONObject(ch);
        if (c == null) return null;
        String base = epgBases.optString(c.optInt("a", 0), "");
        return base.isEmpty() ? null : base + c.optString("id");
    }

    private MediaItem liveItem(int ch, String url) {
        JSONObject c = channels.optJSONObject(ch);
        return new MediaItem.Builder()
                .setUri(Uri.parse(url))
                .setMediaId(c != null ? c.optString("key", url) : url)
                .build();
    }

    private int channelAt(int g, int p) {
        JSONObject gr = groups.optJSONObject(g);
        if (gr == null) return -1;
        JSONArray ch = gr.optJSONArray("ch");
        if (ch == null || ch.length() == 0) return -1;
        return ch.optInt(Math.max(0, Math.min(p, ch.length() - 1)), -1);
    }

    private int groupSize(int g) {
        JSONObject gr = groups.optJSONObject(g);
        JSONArray ch = gr != null ? gr.optJSONArray("ch") : null;
        return ch == null ? 0 : ch.length();
    }

    private int findChannel(String key) {
        if (key == null || key.isEmpty()) return -1;
        for (int i = 0; i < channels.length(); i++) {
            JSONObject c = channels.optJSONObject(i);
            if (c != null && key.equals(c.optString("key"))) return i;
        }
        return -1;
    }

    /** Place de la chaîne dans un groupe (ou -1) */
    private int indexInGroup(int g, int ch) {
        JSONObject gr = groups.optJSONObject(g);
        JSONArray l = gr != null ? gr.optJSONArray("ch") : null;
        if (l == null) return -1;
        for (int i = 0; i < l.length(); i++) if (l.optInt(i) == ch) return i;
        return -1;
    }

    private void playChannel(int ch, boolean remember) {
        if (ch < 0 || ch >= channels.length()) return;
        if (remember && channel >= 0 && channel != ch) prevChannel = channel;
        channel = ch;
        markLive();
        triedAlt = false;
        String url = liveUrl(ch, liveExt);
        player.setMediaItem(liveItem(ch, url));
        player.prepare();
        player.play();
        showInfo();
    }

    private int zapTarget = -1;
    private final Runnable commitZap = () -> {
        int t = zapTarget;
        zapTarget = -1;
        if (t >= 0 && t != channel) playChannel(t, true);
    };

    private void zap(int dir) {
        int n = groupSize(group);
        if (n < 2) return;
        pos = (pos + dir + n) % n;
        zapTarget = channelAt(group, pos);
        showInfo(zapTarget);
        ui.removeCallbacks(commitZap);
        ui.postDelayed(commitZap, 450);
    }

    private JSONObject currentItem() {
        int i = player != null ? player.getCurrentMediaItemIndex() : index;
        return items.optJSONObject(i);
    }

    // ---------- Langues et image ----------

    private void applyLangs() {
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon()
                .setPreferredAudioLanguage(audioLang)
                .setSelectUndeterminedTextLanguage(false);
        if (subOn) b.setPreferredTextLanguage(subLang).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false);
        else b.setPreferredTextLanguage(null);
        player.setTrackSelectionParameters(b.build());
    }

    private static final String[] RESIZE_NAMES = {"Ajustée", "Zoom (remplit l'écran)", "Étirée"};

    private void applyResize() {
        int[] modes = {AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL};
        view.setResizeMode(modes[Math.max(0, Math.min(resize, 2))]);
    }

    // ---------- Interface ----------

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable box(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(12));
        return bg;
    }

    private TextView label(float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setBackground(box(0xD9141418));
        t.setPadding(dp(20), dp(12), dp(20), dp(12));
        t.setVisibility(View.GONE);
        return t;
    }

    private TextView text(float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        view = new PlayerView(this);
        view.setKeepScreenOn(true);
        view.setShowSubtitleButton(true);
        view.setControllerShowTimeoutMs(4000);
        view.setControllerAutoShow(false);
        view.setShowShuffleButton(false);
        view.setUseController(!live);
        root.addView(view, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        spinner = new ProgressBar(this);
        spinner.setVisibility(View.GONE);
        root.addView(spinner, new FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER));

        banner = label(20, true);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        bp.setMargins(dp(40), dp(32), dp(40), 0);
        root.addView(banner, bp);

        nextHint = label(18, true);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
        np.setMargins(0, 0, dp(48), dp(110));
        root.addView(nextHint, np);

        introHint = label(18, true);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
        ip.setMargins(0, 0, dp(48), dp(110));
        root.addView(introHint, ip);

        reminder = label(19, true);
        reminder.setBackground(box(0xF01C1C22));
        reminder.setPadding(dp(24), dp(16), dp(24), dp(16));
        reminder.setMaxWidth(dp(520));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        rp.setMargins(0, dp(32), dp(40), 0);
        root.addView(reminder, rp);

        toast = label(18, true);
        root.addView(toast, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        // Bandeau du direct : logo, chaîne, programme en cours et suivant
        infoBar = new LinearLayout(this);
        infoBar.setOrientation(LinearLayout.HORIZONTAL);
        infoBar.setGravity(Gravity.CENTER_VERTICAL);
        infoBar.setBackground(box(0xE60B0B0E));
        infoBar.setPadding(dp(24), dp(18), dp(28), dp(18));
        infoLogo = new ImageView(this);
        infoLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(120), dp(72));
        lp.setMargins(0, 0, dp(22), 0);
        infoBar.addView(infoLogo, lp);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        infoTitle = text(24, Color.WHITE, true);
        infoNow = text(17, 0xFFE4E4EA, false);
        infoProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        infoProgress.setMax(1000);
        infoNext = text(15, 0xFFA8A8B3, false);
        col.addView(infoTitle);
        col.addView(infoNow);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8));
        pp.setMargins(0, dp(8), 0, dp(8));
        col.addView(infoProgress, pp);
        col.addView(infoNext);
        infoBar.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        FrameLayout.LayoutParams ib = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        ib.setMargins(dp(40), 0, dp(40), dp(36));
        infoBar.setVisibility(View.GONE);
        root.addView(infoBar, ib);

        channelPanel = new ListPanel(this, true);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(560), FrameLayout.LayoutParams.MATCH_PARENT, Gravity.START);
        root.addView(channelPanel, cp);

        menuPanel = new ListPanel(this, false);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(520), FrameLayout.LayoutParams.MATCH_PARENT, Gravity.END);
        root.addView(menuPanel, mp);

        setContentView(root);
        view.requestFocus();
    }

    private void showBanner() {
        JSONObject it = currentItem();
        if (it == null) return;
        String title = it.optString("title", "");
        String sub = it.optString("sub", "");
        banner.setText(sub.isEmpty() ? title : title + "\n" + sub);
        banner.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBanner);
        ui.postDelayed(hideBanner, 3000);
    }

    /** Appelé par Lumen : affiche un rappel par-dessus la vidéo. channelKey : chaîne à ouvrir avec OK */
    static boolean remind(final String title, final String text, final String channelKey) {
        final PlayerActivity a = current;
        if (a == null || a.finished) return false;
        a.runOnUiThread(() -> a.showReminder(title, text, channelKey));
        return true;
    }

    private void showReminder(String title, String text, String channelKey) {
        if (reminder == null) return;
        boolean canGo = channelKey != null && !channelKey.isEmpty() && (!live || findChannel(channelKey) != channel);
        reminderKey = canGo ? channelKey : null;
        String body = title + (text == null || text.isEmpty() ? "" : "\n" + text);
        if (canGo) body += "\nOK pour y aller";
        reminder.setText(body);
        reminder.setVisibility(View.VISIBLE);
        reminder.bringToFront();
        ui.removeCallbacks(hideReminder);
        ui.postDelayed(hideReminder, 15000);
    }

    /** OK pendant un rappel : on change de chaîne (direct) ou on rend la main à Lumen pour l'ouvrir */
    private boolean goReminder() {
        if (reminderKey == null || reminder.getVisibility() != View.VISIBLE) return false;
        String key = reminderKey;
        hideReminder.run();
        ui.removeCallbacks(hideReminder);
        if (live) {
            int ch = findChannel(key);
            if (ch >= 0) {
                int inGroup = indexInGroup(group, ch);
                if (inGroup < 0) {
                    for (int g = 0; g < groups.length(); g++) {
                        int i = indexInGroup(g, ch);
                        if (i >= 0) { group = g; inGroup = i; break; }
                    }
                }
                if (inGroup >= 0) pos = inGroup;
                playChannel(ch, true);
                return true;
            }
        }
        gotoKey = key;
        finishWithResult();
        return true;
    }

    private void markLive() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (liveTimed >= 0 && liveSince > 0) {
            JSONObject c = channels.optJSONObject(liveTimed);
            if (c != null) {
                String k = c.optString("key");
                Long had = liveTime.get(k);
                liveTime.put(k, (had == null ? 0L : had) + (now - liveSince));
            }
        }
        liveTimed = channel;
        liveSince = now;
    }

    private void showToast(String t, int ms) {
        toast.setText(t);
        toast.setVisibility(View.VISIBLE);
        toast.bringToFront();
        ui.removeCallbacks(hideToast);
        ui.postDelayed(hideToast, ms);
    }

    private static String hhmm(long t) {
        return new SimpleDateFormat("HH:mm", Locale.FRANCE).format(new Date(t));
    }

    private void showInfo() { showInfo(channel); }

    private int infoChannel = -1;

    private void showInfo(final int ch) {
        infoChannel = ch;
        JSONObject c = channels.optJSONObject(ch);
        if (c == null) return;
        String num = c.optString("num", "");
        infoTitle.setText((num.isEmpty() || num.equals("0") ? "" : num + "   ") + c.optString("n", ""));
        ImageLoader.load(c.optString("logo", ""), infoLogo);
        fillInfo(Epg.cached(epgUrl(ch)));
        infoBar.setVisibility(View.VISIBLE);
        infoBar.bringToFront();
        ui.removeCallbacks(hideInfo);
        ui.postDelayed(hideInfo, 3000);
        String url = epgUrl(ch);
        if (url != null && Epg.cached(url) == null) Epg.load(url, progs -> { if (infoChannel == ch) fillInfo(progs); });
    }

    private void fillInfo(List<Epg.Prog> progs) {
        Epg.Prog now = Epg.now(progs);
        Epg.Prog next = Epg.next(progs);
        if (now != null) {
            infoNow.setText(hhmm(now.start) + " - " + hhmm(now.end) + "   " + now.title);
            long span = Math.max(1, now.end - now.start);
            infoProgress.setProgress((int) (1000 * (System.currentTimeMillis() - now.start) / span));
            infoProgress.setVisibility(View.VISIBLE);
        } else {
            infoNow.setText(progs == null ? "Chargement du programme…" : "Pas de programme annoncé");
            infoProgress.setVisibility(View.GONE);
        }
        infoNext.setText(next != null ? "Ensuite à " + hhmm(next.start) + " : " + next.title : "");
        infoNext.setVisibility(next != null ? View.VISIBLE : View.GONE);
    }

    // ---------- Liste des chaînes ----------

    private void openChannels() {
        panelGroup = group;
        int at = indexInGroup(panelGroup, channel);
        fillChannels(at >= 0 ? at : 0);
        channelPanel.show();
        infoBar.setVisibility(View.GONE);
    }

    private void fillChannels(int selected) {
        JSONObject gr = groups.optJSONObject(panelGroup);
        JSONArray l = gr != null ? gr.optJSONArray("ch") : null;
        List<ListPanel.Row> rows = new ArrayList<>();
        if (l != null) {
            for (int i = 0; i < l.length(); i++) {
                int ci = l.optInt(i);
                JSONObject c = channels.optJSONObject(ci);
                if (c == null) continue;
                ListPanel.Row r = new ListPanel.Row();
                r.num = c.optString("num", "");
                if ("0".equals(r.num)) r.num = "";
                if (isFav(ci)) r.num = "★";
                r.title = c.optString("n", "");
                r.logo = c.optString("logo", "");
                r.live = ci == channel;
                Epg.Prog now = Epg.now(Epg.cached(epgUrl(ci)));
                r.sub = now != null ? now.title : "";
                r.data = ci;
                rows.add(r);
            }
        }
        String name = gr != null ? gr.optString("name", "") : "";
        String title = (groups.length() > 1 ? "‹  " : "") + name + (groups.length() > 1 ? "  ›" : "");
        channelPanel.setRows(title, rows, selected, rows.size() + " chaînes · ‹ › groupe · OK regarder · appui long : favori");
        loadPanelEpg();
    }

    // Programme des chaînes autour de la sélection
    private void loadPanelEpg() {
        final int g = panelGroup;
        List<ListPanel.Row> rows = channelPanel.rows();
        int s = channelPanel.selected();
        for (int i = Math.max(0, s - 4); i < Math.min(rows.size(), s + 6); i++) {
            final ListPanel.Row r = rows.get(i);
            String url = epgUrl((Integer) r.data);
            if (url == null || Epg.cached(url) != null) continue;
            Epg.load(url, progs -> {
                if (panelGroup != g) return;
                r.sub = rowEpg(progs, r == channelPanel.selectedRow());
                channelPanel.refresh();
            });
        }
        // La ligne sélectionnée montre aussi le programme suivant
        for (ListPanel.Row r : rows) {
            List<Epg.Prog> pr = Epg.cached(epgUrl((Integer) r.data));
            if (pr != null) r.sub = rowEpg(pr, r == channelPanel.selectedRow());
        }
        channelPanel.refresh();
    }

    private String rowEpg(List<Epg.Prog> progs, boolean full) {
        Epg.Prog now = Epg.now(progs);
        Epg.Prog next = Epg.next(progs);
        String a = now != null ? hhmm(now.start) + "  " + now.title : "";
        if (!full || next == null) return a;
        return a + (a.isEmpty() ? "" : "   ·   ") + "Ensuite " + hhmm(next.start) + "  " + next.title;
    }

    private boolean isFav(int ci) {
        JSONObject g0 = groups.optJSONObject(0);
        if (g0 == null || !"__fav".equals(g0.optString("id"))) return false;
        JSONArray l = g0.optJSONArray("ch");
        for (int i = 0; l != null && i < l.length(); i++) if (l.optInt(i) == ci) return true;
        return false;
    }

    private void toggleFav(int ci) {
        JSONObject c = channels.optJSONObject(ci);
        if (c == null) return;
        try {
            JSONObject g0 = groups.optJSONObject(0);
            if (g0 == null || !"__fav".equals(g0.optString("id"))) {
                // Premier favori : on crée le groupe Favoris en tête
                JSONArray ng = new JSONArray();
                g0 = new JSONObject();
                g0.put("name", "Favoris");
                g0.put("id", "__fav");
                g0.put("ch", new JSONArray());
                ng.put(g0);
                for (int i = 0; i < groups.length(); i++) ng.put(groups.get(i));
                groups = ng;
                group++;
                panelGroup++;
            }
            JSONArray l = g0.getJSONArray("ch");
            boolean was = false;
            JSONArray nl = new JSONArray();
            for (int i = 0; i < l.length(); i++) {
                if (l.optInt(i) == ci) was = true;
                else nl.put(l.optInt(i));
            }
            if (!was) nl.put(ci);
            g0.put("ch", nl);
            String key = c.optString("key");
            favChanges.put(key, !was);
            showToast(was ? "Retirée des favoris" : "Ajoutée aux favoris", 1500);
        } catch (Exception ignored) { }
    }

    private boolean channelKeys(KeyEvent e) {
        if (isOk(e.getKeyCode())) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                if (e.getRepeatCount() == 0) { panelOkDown = true; panelOkLong = false; }
                else if (!panelOkLong) {
                    panelOkLong = true;
                    ListPanel.Row r = channelPanel.selectedRow();
                    if (r != null) {
                        int ci = (Integer) r.data;
                        toggleFav(ci);
                        JSONObject c = channels.optJSONObject(ci);
                        String num = c != null ? c.optString("num", "") : "";
                        r.num = isFav(ci) ? "★" : ("0".equals(num) ? "" : num);
                        channelPanel.refresh();
                    }
                }
            } else if (panelOkDown && !panelOkLong) {
                panelOkDown = false;
                ListPanel.Row r = channelPanel.selectedRow();
                if (r != null) {
                    group = panelGroup;
                    pos = channelPanel.selected();
                    channelPanel.hide();
                    playChannel((Integer) r.data, true);
                }
            } else {
                panelOkDown = false;
            }
            return true;
        }
        if (e.getAction() != KeyEvent.ACTION_DOWN) return true;
        switch (e.getKeyCode()) {
            case KeyEvent.KEYCODE_DPAD_UP: channelPanel.move(-1); loadPanelEpg(); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN: channelPanel.move(1); loadPanelEpg(); return true;
            case KeyEvent.KEYCODE_PAGE_UP: case KeyEvent.KEYCODE_CHANNEL_UP: channelPanel.move(-8); loadPanelEpg(); return true;
            case KeyEvent.KEYCODE_PAGE_DOWN: case KeyEvent.KEYCODE_CHANNEL_DOWN: channelPanel.move(8); loadPanelEpg(); return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (groups.length() < 2) return true;
                panelGroup = (panelGroup + (e.getKeyCode() == KeyEvent.KEYCODE_DPAD_RIGHT ? 1 : -1) + groups.length()) % groups.length();
                int at = indexInGroup(panelGroup, channel);
                fillChannels(at >= 0 ? at : 0);
                return true;
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE:
                channelPanel.hide();
                return true;
            default:
                return true;
        }
    }

    // ---------- Menu Lumen (pistes, sous-titres, image) ----------

    private static final int M_AUDIO = 1, M_SUBS = 2, M_ONLINE = 3, M_RESIZE = 4, M_CHANNELS = 5, M_INFO = 6, M_STARTOVER = 7, M_REPLAYS = 8;
    private String action = null;
    private int menuLevel = 0; // 0 : principal, 1 : audio, 2 : sous-titres, 3 : sous-titres en ligne

    private static String langName(String code) {
        if (code == null || code.isEmpty() || code.equals("und")) return "";
        String n = new Locale(code).getDisplayLanguage(Locale.FRENCH);
        return n.isEmpty() ? code : Character.toUpperCase(n.charAt(0)) + n.substring(1);
    }

    private static String codec(Format f) {
        String m = f.sampleMimeType != null ? f.sampleMimeType : "";
        if (m.contains("eac3")) return "Dolby Digital+";
        if (m.contains("ac3")) return "Dolby Digital";
        if (m.contains("dts")) return "DTS";
        if (m.contains("truehd")) return "TrueHD";
        if (m.contains("mp4a")) return "AAC";
        if (m.contains("mpeg")) return "MP3";
        if (m.contains("opus")) return "Opus";
        if (m.contains("subrip")) return "SRT";
        if (m.contains("ass") || m.contains("ssa")) return "ASS";
        if (m.contains("pgs")) return "image";
        return "";
    }

    private String trackLabel(Format f, int n) {
        List<String> parts = new ArrayList<>();
        String l = langName(f.language);
        if (!l.isEmpty()) parts.add(l);
        if (f.label != null && !f.label.isEmpty() && !f.label.equalsIgnoreCase(l)) parts.add(f.label);
        String c = codec(f);
        if (!c.isEmpty()) parts.add(c);
        if (f.channelCount == 6) parts.add("5.1");
        else if (f.channelCount == 8) parts.add("7.1");
        else if (f.channelCount == 2) parts.add("stéréo");
        if (parts.isEmpty()) parts.add("Piste " + n);
        return TextUtils.join(" · ", parts);
    }

    private ListPanel.Row row(String title, String sub, Object data, boolean checked) {
        ListPanel.Row r = new ListPanel.Row();
        r.title = title;
        r.sub = sub;
        r.data = data;
        r.checked = checked;
        return r;
    }

    private String currentTrack(int type) {
        for (Tracks.Group g : player.getCurrentTracks().getGroups()) {
            if (g.getType() != type) continue;
            for (int i = 0; i < g.length; i++) if (g.isTrackSelected(i)) return trackLabel(g.getTrackFormat(i), i + 1);
        }
        return type == C.TRACK_TYPE_TEXT ? "Désactivés" : "Automatique";
    }

    private void openMenu() {
        menuLevel = 0;
        List<ListPanel.Row> rows = new ArrayList<>();
        rows.add(row("Audio", currentTrack(C.TRACK_TYPE_AUDIO), M_AUDIO, false));
        rows.add(row("Sous-titres", currentTrack(C.TRACK_TYPE_TEXT), M_SUBS, false));
        if (!live && opts.optJSONObject("os") != null && !opts.optJSONObject("os").optString("key", "").isEmpty()) {
            rows.add(row("Chercher des sous-titres en ligne", "OpenSubtitles", M_ONLINE, false));
        }
        rows.add(row("Format d'image", RESIZE_NAMES[resize], M_RESIZE, false));
        if (live) {
            rows.add(0, row("Programme en cours", "", M_INFO, false));
            rows.add(1, row("Liste des chaînes", "Touche gauche", M_CHANNELS, false));
            JSONObject c = channels.optJSONObject(channel);
            if (c != null && c.optBoolean("arch", false)) {
                Epg.Prog now = Epg.now(Epg.cached(epgUrl(channel)));
                rows.add(2, row("Reprendre depuis le début", now != null ? now.title + " · depuis " + hhmm(now.start) : "Programme en cours", M_STARTOVER, false));
                rows.add(3, row("Programmes passés", "Revoir un programme de cette chaîne", M_REPLAYS, false));
            }
        }
        menuPanel.setRows("Lecture", rows, 0, "OK pour choisir · Retour pour fermer");
        menuPanel.show();
        infoBar.setVisibility(View.GONE);
        view.hideController();
    }

    private void openTracks(int type) {
        menuLevel = type == C.TRACK_TYPE_AUDIO ? 1 : 2;
        List<ListPanel.Row> rows = new ArrayList<>();
        boolean anyText = false;
        if (type == C.TRACK_TYPE_TEXT) {
            boolean off = player.getTrackSelectionParameters().disabledTrackTypes.contains(C.TRACK_TYPE_TEXT);
            rows.add(row("Désactivés", "", null, false));
            anyText = !off;
        }
        int sel = 0;
        for (Tracks.Group g : player.getCurrentTracks().getGroups()) {
            if (g.getType() != type) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                boolean on = g.isTrackSelected(i);
                rows.add(row(trackLabel(g.getTrackFormat(i), rows.size() + 1), "", new Object[]{g, i}, on));
                if (on) sel = rows.size() - 1;
            }
        }
        if (type == C.TRACK_TYPE_TEXT && !anyText) rows.get(0).checked = true;
        if (type == C.TRACK_TYPE_TEXT && sel == 0 && rows.size() == 1) rows.get(0).sub = "Aucun sous-titre dans ce fichier";
        if (type == C.TRACK_TYPE_AUDIO && rows.isEmpty()) rows.add(row("Piste unique", "", null, true));
        menuPanel.setRows(type == C.TRACK_TYPE_AUDIO ? "Audio" : "Sous-titres", rows, sel, "OK pour choisir · Retour");
    }

    private void pickTrack(ListPanel.Row r) {
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        if (menuLevel == 2 && r.data == null) {
            b.clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
            subOn = false;
            langChanged = true;
            player.setTrackSelectionParameters(b.build());
            showToast("Sous-titres désactivés", 1500);
        } else if (r.data instanceof Object[]) {
            Object[] d = (Object[]) r.data;
            Tracks.Group g = (Tracks.Group) d[0];
            int i = (Integer) d[1];
            b.setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), i));
            if (g.getType() == C.TRACK_TYPE_TEXT) {
                b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false);
                subOn = true;
                String l = g.getTrackFormat(i).language;
                if (l != null && !l.isEmpty() && !l.equals("und")) subLang = l;
            } else {
                String l = g.getTrackFormat(i).language;
                if (l != null && !l.isEmpty() && !l.equals("und")) audioLang = l;
            }
            langChanged = true;
            player.setTrackSelectionParameters(b.build());
            showToast(r.title, 1500);
        }
        menuPanel.hide();
    }

    private void searchOnline() {
        menuLevel = 3;
        List<ListPanel.Row> wait = new ArrayList<>();
        wait.add(row("Recherche…", "", null, false));
        menuPanel.setRows("Sous-titres en ligne", wait, 0, null);
        final JSONObject it = currentItem();
        final JSONObject os = opts.optJSONObject("os");
        final String langs = "en".equals(subLang) ? "en,fr" : "fr,en";
        if (it == null || os == null) return;
        Net.POOL.execute(() -> {
            List<ListPanel.Row> rows = new ArrayList<>();
            String err = null;
            try {
                for (OpenSubs.Sub s : OpenSubs.search(os, it, langs)) {
                    rows.add(row(langName(s.lang) + " · " + s.name, s.downloads + " téléchargements", s, false));
                }
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fe = err;
            ui.post(() -> {
                if (menuLevel != 3 || !menuPanel.shown()) return;
                if (rows.isEmpty()) rows.add(row(fe != null ? fe : "Aucun sous-titre trouvé", "", null, false));
                menuPanel.setRows("Sous-titres en ligne", rows, 0, "OK pour charger · Retour");
            });
        });
    }

    private void loadOnline(final OpenSubs.Sub s) {
        menuPanel.hide();
        showToast("Téléchargement du sous-titre…", 3000);
        final JSONObject os = opts.optJSONObject("os");
        final File dir = getCacheDir();
        Net.POOL.execute(() -> {
            try {
                final File f = OpenSubs.download(os, s.fileId, dir);
                ui.post(() -> {
                    if (player == null) return;
                    int i = player.getCurrentMediaItemIndex();
                    long p = Math.max(0, player.getCurrentPosition());
                    MediaItem cur = player.getCurrentMediaItem();
                    if (cur == null) return;
                    MediaItem.SubtitleConfiguration sub = new MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                            .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                            .setLanguage(s.lang)
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                            .build();
                    player.replaceMediaItem(i, cur.buildUpon().setSubtitleConfigurations(Collections.singletonList(sub)).build());
                    player.seekTo(i, p);
                    subOn = true;
                    subLang = s.lang;
                    langChanged = true;
                    applyLangs();
                    showToast("Sous-titres chargés", 1500);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                ui.post(() -> showToast(m != null ? m : "Sous-titre indisponible", 3000));
            }
        });
    }

    private boolean menuKeys(KeyEvent e) {
        if (e.getAction() != KeyEvent.ACTION_DOWN) return true;
        if (isOk(e.getKeyCode()) && e.getRepeatCount() > 0) return true;
        switch (e.getKeyCode()) {
            case KeyEvent.KEYCODE_DPAD_UP: menuPanel.move(-1); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN: menuPanel.move(1); return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_DPAD_RIGHT: {
                ListPanel.Row r = menuPanel.selectedRow();
                if (r == null) return true;
                if (menuLevel == 0) {
                    int what = r.data instanceof Integer ? (Integer) r.data : 0;
                    if (what == M_AUDIO) openTracks(C.TRACK_TYPE_AUDIO);
                    else if (what == M_SUBS) openTracks(C.TRACK_TYPE_TEXT);
                    else if (what == M_ONLINE) searchOnline();
                    else if (what == M_RESIZE) {
                        resize = (resize + 1) % 3;
                        applyResize();
                        r.sub = RESIZE_NAMES[resize];
                        menuPanel.refresh();
                    } else if (what == M_CHANNELS) {
                        menuPanel.hide();
                        openChannels();
                    } else if (what == M_INFO) {
                        menuPanel.hide();
                        showInfo();
                    } else if (what == M_STARTOVER || what == M_REPLAYS) {
                        // Lumen prend le relais : replay du programme en cours, ou liste des programmes passés
                        action = what == M_STARTOVER ? "startover" : "replays";
                        menuPanel.hide();
                        finishWithResult();
                    }
                } else if (menuLevel == 3) {
                    if (r.data instanceof OpenSubs.Sub) loadOnline((OpenSubs.Sub) r.data);
                } else if (e.getKeyCode() != KeyEvent.KEYCODE_DPAD_RIGHT) {
                    pickTrack(r);
                }
                return true;
            }
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE:
                if (menuLevel == 0) menuPanel.hide();
                else openMenu();
                return true;
            default:
                return true;
        }
    }

    // ---------- Indications (intro, épisode suivant) ----------

    private boolean nextAvailable() {
        return !live && player != null && player.hasNextMediaItem();
    }

    private void updateHints() {
        if (player == null || live) return;
        long dur = player.getDuration();
        long p = player.getCurrentPosition();
        // Épisode suivant pendant le générique
        boolean showNext = nextAvailable() && dur > 0 && dur != C.TIME_UNSET && dur - p <= credits * 1000L && dur - p > 500;
        if (showNext) {
            JSONObject n = items.optJSONObject(player.getCurrentMediaItemIndex() + 1);
            String what = n != null ? n.optString("sub", "") : "";
            nextHint.setText("Épisode suivant" + (what.isEmpty() ? "" : " : " + what) + "\nOK pour lancer");
        }
        nextHint.setVisibility(showNext ? View.VISIBLE : View.GONE);
        // Passer l'intro
        JSONObject it = currentItem();
        boolean episode = it != null && "episode".equals(it.optString("kind"));
        long introEnd = it != null ? (long) (it.optDouble("introEnd", 0) * 1000) : 0;
        boolean showIntro = episode && !introDone && p > 3000 && (introEnd > 0 ? p < introEnd - 1000 : p < 300000);
        if (showIntro && autoSkipIntro && introEnd > 0) {
            introDone = true;
            player.seekTo(introEnd);
            showToast("Intro passée", 1500);
            showIntro = false;
        }
        if (showIntro) introHint.setText("Passer l'intro\nOK");
        introHint.setVisibility(showIntro && !showNext ? View.VISIBLE : View.GONE);
    }

    private void skipIntro() {
        JSONObject it = currentItem();
        long introEnd = it != null ? (long) (it.optDouble("introEnd", 0) * 1000) : 0;
        long p = player.getCurrentPosition();
        long target = introEnd > p ? introEnd : p + 85000;
        player.seekTo(target);
        introDone = true;
        introHint.setVisibility(View.GONE);
        if (introEnd <= 0) {
            try { learnedIntro.put(String.valueOf(player.getCurrentMediaItemIndex()), target / 1000.0); } catch (Exception ignored) { }
        }
    }

    // ---------- Suivi de la progression ----------

    private void track() {
        if (player == null || live) return;
        int i = player.getCurrentMediaItemIndex();
        long dur = player.getDuration();
        long p = player.getCurrentPosition();
        if (dur == C.TIME_UNSET || dur <= 0) return;
        for (long[] s : seen) {
            if (s[0] == i) { s[1] = p; s[2] = dur; return; }
        }
        seen.add(new long[]{i, p, dur, 0});
    }

    private void markEnded(int i) {
        track();
        for (long[] s : seen) {
            if (s[0] == i) { s[3] = 1; s[1] = s[2]; return; }
        }
    }

    // ---------- Télécommande ----------

    private boolean isOk(int k) {
        return k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER;
    }

    private void shortOk() {
        if (goReminder()) return;
        if (live) { openMenu(); return; }
        if (introHint.getVisibility() == View.VISIBLE) { skipIntro(); return; }
        if (nextHint.getVisibility() == View.VISIBLE && nextAvailable()) { player.seekToNextMediaItem(); return; }
        if (player.isPlaying()) { player.pause(); showToast("Pause", 1000); } else player.play();
        view.showController();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int k = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;

        if (menuPanel.shown()) return menuKeys(event);
        if (channelPanel.shown()) return channelKeys(event);

        boolean controls = !live && view.isControllerFullyVisible();

        if (k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_INFO || k == KeyEvent.KEYCODE_CAPTIONS) {
            if (down) openMenu();
            return true;
        }
        if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE) {
            if (!down) return true;
            if (controls) { view.hideController(); return true; }
            if (!live && infoBar.getVisibility() == View.VISIBLE) { infoBar.setVisibility(View.GONE); return true; }
            finishWithResult();
            return true;
        }
        // OK : appui court ou appui long (menu)
        if (isOk(k) && !controls) {
            if (down) {
                if (event.getRepeatCount() == 0) { okDown = true; okLong = false; }
                else if (!okLong) { okLong = true; openMenu(); }
            } else {
                if (okDown && !okLong) shortOk();
                okDown = false;
            }
            return true;
        }
        if (live && down) {
            // Haut : chaîne suivante · bas : chaîne précédente (touche maintenue : défilement du bandeau)
            if (k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_CHANNEL_UP) { zap(1); return true; }
            if (k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_CHANNEL_DOWN) { zap(-1); return true; }
            if (k == KeyEvent.KEYCODE_DPAD_LEFT) { if (event.getRepeatCount() == 0) openChannels(); return true; }
            if (k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_MEDIA_PREVIOUS || k == KeyEvent.KEYCODE_LAST_CHANNEL) {
                if (event.getRepeatCount() > 0) return true;
                if (prevChannel >= 0) {
                    int target = prevChannel;
                    int at = indexInGroup(group, target);
                    if (at >= 0) pos = at;
                    else {
                        for (int g = 0; g < groups.length(); g++) {
                            int a2 = indexInGroup(g, target);
                            if (a2 >= 0) { group = g; pos = a2; break; }
                        }
                    }
                    ui.removeCallbacks(commitZap);
                    zapTarget = -1;
                    playChannel(target, true);
                } else showToast("Pas encore de chaîne précédente", 1500);
                return true;
            }
        }
        if (live) return super.dispatchKeyEvent(event);

        if (down && !controls) {
            if (k == KeyEvent.KEYCODE_DPAD_LEFT) {
                player.seekTo(Math.max(0, player.getCurrentPosition() - 10000));
                showToast("- 10 s", 800);
                return true;
            }
            if (k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                long d = player.getDuration();
                long target = player.getCurrentPosition() + 30000;
                player.seekTo(d > 0 && d != C.TIME_UNSET ? Math.min(target, d - 1000) : target);
                showToast("+ 30 s", 800);
                return true;
            }
            if (k == KeyEvent.KEYCODE_MEDIA_NEXT && nextAvailable()) { player.seekToNextMediaItem(); return true; }
        }
        return view.dispatchKeyEvent(event) || super.dispatchKeyEvent(event);
    }

    // ---------- Fin ----------

    private String describe(PlaybackException e) {
        int c = e.errorCode;
        if (c == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) return "Le serveur refuse ce flux (connexion déjà utilisée ou contenu retiré).";
        if (c == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED || c == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) return "Le serveur ne répond pas.";
        if (c == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED || c == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED || c == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED || c == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES) return "Format vidéo ou audio non pris en charge par le lecteur intégré.";
        if (c == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED || c == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED) return "Fichier illisible par le lecteur intégré.";
        return "Le flux ne peut pas être lu (" + e.getErrorCodeName().toLowerCase(Locale.ROOT) + ").";
    }

    private void finishWithResult() {
        if (finished) return;
        finished = true;
        ui.removeCallbacksAndMessages(null);
        JSONObject r = new JSONObject();
        try {
            track();
            if (live) {
                JSONObject c = channels.optJSONObject(channel);
                if (c != null) r.put("channelKey", c.optString("key"));
                JSONObject pc = channels.optJSONObject(prevChannel);
                if (pc != null) r.put("prevKey", pc.optString("key"));
                r.put("group", group);
                JSONArray add = new JSONArray(), rem = new JSONArray();
                for (java.util.Map.Entry<String, Boolean> f : favChanges.entrySet()) (f.getValue() ? add : rem).put(f.getKey());
                if (add.length() > 0) r.put("favAdd", add);
                if (rem.length() > 0) r.put("favRemove", rem);
                if (altWorked) r.put("liveExt", "ts".equals(liveExt) ? "m3u8" : "ts");
                if (action != null) r.put("action", action);
                markLive();
                JSONObject secs = new JSONObject();
                for (java.util.Map.Entry<String, Long> t : liveTime.entrySet()) if (t.getValue() >= 1000) secs.put(t.getKey(), t.getValue() / 1000);
                if (secs.length() > 0) r.put("liveSeconds", secs);
            } else if (player != null) {
                r.put("index", player.getCurrentMediaItemIndex());
                r.put("pos", Math.max(0, player.getCurrentPosition()) / 1000.0);
                long d = player.getDuration();
                r.put("dur", d > 0 && d != C.TIME_UNSET ? d / 1000.0 : 0);
            }
            JSONArray arr = new JSONArray();
            for (long[] s : seen) {
                JSONObject x = new JSONObject();
                x.put("index", s[0]);
                x.put("pos", s[1] / 1000.0);
                x.put("dur", s[2] / 1000.0);
                x.put("ended", s[3] == 1);
                arr.put(x);
            }
            r.put("items", arr);
            if (gotoKey != null) r.put("gotoKey", gotoKey);
            if (learnedIntro.length() > 0) r.put("intro", learnedIntro);
            if (langChanged) {
                r.put("audioLang", audioLang);
                r.put("subLang", subLang);
                r.put("subOn", subOn);
            }
            r.put("resize", resize);
            if (error != null) r.put("error", error);
        } catch (Exception ignored) { }
        Intent data = new Intent();
        data.putExtra("result", r.toString());
        setResult(RESULT_OK, data);
        if (player != null) {
            if (live && action == null && opts.optBoolean("keepPreview", false)) {
                // Retour à l'écran Direct : la miniature continue la chaîne regardée
                ui.removeCallbacks(commitZap);
                player.removeListener(listener);
                view.setPlayer(null);
                JSONObject c = channels.optJSONObject(channel);
                LivePreview.giveBack(player, c != null ? c.optString("key") : null);
            } else {
                player.release();
            }
            player = null;
        }
        finish();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Touche Accueil : on garde la position, on rend la main à Lumen et on coupe le son
        if (!isChangingConfigurations() && !finished) {
            finishWithResult();
            LivePreview.stop();
        }
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        ui.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
