package fr.alex.lumen.tv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.OptIn;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Lecteur plein écran (Media3 / ExoPlayer).
 * Options reçues en JSON :
 *  items     : [{ url, alt, title, sub, key }]  (épisodes à enchaîner ou chaînes à zapper)
 *  index     : élément de départ
 *  startAt   : position de départ en secondes (premier élément)
 *  live      : true pour le direct (haut/bas changent de chaîne)
 *  autoNext  : enchaîner les épisodes
 *  credits   : secondes avant la fin où proposer l'épisode suivant
 *  audioLang, subLang : langues préférées
 * Résultat : { index, pos, dur, items: [{ index, pos, dur, ended }], error }
 */
@OptIn(markerClass = UnstableApi.class)
public class PlayerActivity extends Activity {

    private ExoPlayer player;
    private PlayerView view;
    private TextView banner, nextHint, toast;
    private ProgressBar spinner;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private JSONArray items;
    private boolean live;
    private boolean autoNext;
    private int credits = 40;
    private int index = 0;
    private int liveIndex = 0;
    private final List<long[]> seen = new ArrayList<>(); // index, pos ms, dur ms, ended
    private final boolean[] triedAlt = new boolean[1];
    private String userAgent = LumenTvPlugin.IPTV_UA;
    private boolean finished = false;
    private String error = null;

    private final Runnable hideBanner = () -> banner.setVisibility(View.GONE);
    private final Runnable hideToast = () -> toast.setVisibility(View.GONE);
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            track();
            updateNextHint();
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);

        JSONObject o;
        try {
            o = new JSONObject(getIntent().getStringExtra("options"));
        } catch (Exception e) {
            o = new JSONObject();
        }
        items = o.optJSONArray("items");
        if (items == null) items = new JSONArray();
        live = o.optBoolean("live", false);
        autoNext = o.optBoolean("autoNext", true);
        credits = o.optInt("credits", 40);
        index = Math.max(0, Math.min(o.optInt("index", 0), Math.max(0, items.length() - 1)));
        liveIndex = index;
        if (o.has("userAgent")) userAgent = o.optString("userAgent", userAgent);
        long startMs = (long) (o.optDouble("startAt", 0) * 1000);

        buildUi();

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(userAgent)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(30000);
        DefaultExtractorsFactory extractors = new DefaultExtractorsFactory()
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
                .setConstantBitrateSeekingEnabled(true);
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this)
                .setEnableDecoderFallback(true)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON);

        player = new ExoPlayer.Builder(this, renderers)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(http, extractors))
                .build();
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setPreferredAudioLanguage(o.optString("audioLang", "fr"))
                .setPreferredTextLanguage(o.optString("subLang", "fr"))
                .build());
        view.setPlayer(player);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                spinner.setVisibility(state == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                if (state == Player.STATE_ENDED && !live) {
                    markEnded(player.getCurrentMediaItemIndex());
                    finishWithResult();
                }
            }

            @Override
            public void onMediaItemTransition(MediaItem item, int reason) {
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && index >= 0) markEnded(index);
                index = player.getCurrentMediaItemIndex();
                triedAlt[0] = false;
                showBanner();
            }

            @Override
            public void onPlayerError(PlaybackException e) {
                // Direct : on retente une fois avec l'autre format (.m3u8 / .ts)
                JSONObject it = currentItem();
                String alt = it != null ? it.optString("alt", "") : "";
                if (!triedAlt[0] && !alt.isEmpty()) {
                    triedAlt[0] = true;
                    long pos = live ? C.TIME_UNSET : Math.max(0, player.getCurrentPosition());
                    MediaItem m = toMediaItem(it, alt);
                    if (live) {
                        player.setMediaItem(m);
                    } else {
                        player.replaceMediaItem(player.getCurrentMediaItemIndex(), m);
                        player.seekTo(player.getCurrentMediaItemIndex(), pos);
                    }
                    player.prepare();
                    player.play();
                    return;
                }
                if (live && e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                error = describe(e);
                finishWithResult();
            }
        });

        if (live) {
            // Une seule chaîne chargée à la fois : le zapping recharge le flux
            JSONObject it = items.optJSONObject(liveIndex);
            if (it != null) player.setMediaItem(toMediaItem(it, it.optString("url")));
        } else {
            List<MediaItem> list = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.optJSONObject(i);
                if (it != null) list.add(toMediaItem(it, it.optString("url")));
            }
            player.setMediaItems(list, index, startMs > 0 ? startMs : C.TIME_UNSET);
            player.setPauseAtEndOfMediaItems(!autoNext);
        }
        player.prepare();
        player.play();
        showBanner();
        ui.postDelayed(tick, 1000);
    }

    private MediaItem toMediaItem(JSONObject it, String url) {
        MediaMetadata meta = new MediaMetadata.Builder()
                .setTitle(it.optString("title", ""))
                .setSubtitle(it.optString("sub", ""))
                .build();
        return new MediaItem.Builder()
                .setUri(Uri.parse(url))
                .setMediaId(it.optString("key", url))
                .setMediaMetadata(meta)
                .build();
    }

    private JSONObject currentItem() {
        int i = live ? liveIndex : (player != null ? player.getCurrentMediaItemIndex() : index);
        return items.optJSONObject(i);
    }

    // ---------- Interface ----------

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView label(float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xD9141418);
        bg.setCornerRadius(dp(10));
        t.setBackground(bg);
        t.setPadding(dp(20), dp(12), dp(20), dp(12));
        t.setVisibility(View.GONE);
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        view = new PlayerView(this);
        view.setKeepScreenOn(true);
        view.setShowSubtitleButton(true);
        view.setControllerShowTimeoutMs(4000);
        view.setControllerAutoShow(false);
        view.setShowShuffleButton(false);
        root.addView(view, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        spinner = new ProgressBar(this);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER);
        root.addView(spinner, sp);

        banner = label(20, true);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        bp.setMargins(dp(40), dp(32), dp(40), 0);
        root.addView(banner, bp);

        nextHint = label(18, true);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
        np.setMargins(0, 0, dp(48), dp(110));
        root.addView(nextHint, np);

        toast = label(18, true);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(toast, tp);

        setContentView(root);
        view.requestFocus();
    }

    private void showBanner() {
        JSONObject it = currentItem();
        if (it == null) return;
        String title = it.optString("title", "");
        String sub = it.optString("sub", "");
        banner.setText(sub.isEmpty() ? title : title + "\n" + sub);
        banner.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBanner);
        ui.postDelayed(hideBanner, 4000);
    }

    private void showToast(String text) {
        toast.setText(text);
        toast.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideToast);
        ui.postDelayed(hideToast, 1200);
    }

    private boolean nextAvailable() {
        return !live && player != null && player.hasNextMediaItem();
    }

    private void updateNextHint() {
        if (!nextAvailable()) { nextHint.setVisibility(View.GONE); return; }
        long dur = player.getDuration();
        long pos = player.getCurrentPosition();
        boolean show = dur > 0 && dur != C.TIME_UNSET && dur - pos <= credits * 1000L && dur - pos > 500;
        if (show) {
            JSONObject n = items.optJSONObject(player.getCurrentMediaItemIndex() + 1);
            String what = n != null ? n.optString("sub", "") : "";
            nextHint.setText("Épisode suivant" + (what.isEmpty() ? "" : " : " + what) + "\nOK pour lancer");
        }
        nextHint.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    // ---------- Suivi de la progression ----------

    private void track() {
        if (player == null || live) return;
        int i = player.getCurrentMediaItemIndex();
        long dur = player.getDuration();
        long pos = player.getCurrentPosition();
        if (dur == C.TIME_UNSET || dur <= 0) return;
        for (long[] s : seen) {
            if (s[0] == i) { s[1] = pos; s[2] = dur; return; }
        }
        seen.add(new long[]{i, pos, dur, 0});
    }

    private void markEnded(int i) {
        track();
        for (long[] s : seen) {
            if (s[0] == i) { s[3] = 1; s[1] = s[2]; return; }
        }
    }

    // ---------- Télécommande ----------

    private void zap(int dir) {
        if (items.length() < 2) return;
        liveIndex = (liveIndex + dir + items.length()) % items.length();
        triedAlt[0] = false;
        JSONObject it = items.optJSONObject(liveIndex);
        if (it == null) return;
        player.setMediaItem(toMediaItem(it, it.optString("url")));
        player.prepare();
        player.play();
        showBanner();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int k = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        boolean controls = view.isControllerFullyVisible();

        if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE) {
            if (!down) return true;
            if (controls) { view.hideController(); return true; }
            finishWithResult();
            return true;
        }
        if (live && down) {
            if (k == KeyEvent.KEYCODE_CHANNEL_UP || (!controls && k == KeyEvent.KEYCODE_DPAD_UP)) { zap(-1); return true; }
            if (k == KeyEvent.KEYCODE_CHANNEL_DOWN || (!controls && k == KeyEvent.KEYCODE_DPAD_DOWN)) { zap(1); return true; }
            if (!controls && (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER)) { showBanner(); view.showController(); return true; }
        }
        if (!live && down && !controls) {
            if (k == KeyEvent.KEYCODE_DPAD_LEFT) {
                player.seekTo(Math.max(0, player.getCurrentPosition() - 10000));
                showToast("− 10 s");
                return true;
            }
            if (k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                long d = player.getDuration();
                long target = player.getCurrentPosition() + 30000;
                player.seekTo(d > 0 && d != C.TIME_UNSET ? Math.min(target, d - 1000) : target);
                showToast("+ 30 s");
                return true;
            }
            if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) {
                if (nextHint.getVisibility() == View.VISIBLE && nextAvailable()) {
                    player.seekToNextMediaItem();
                    return true;
                }
                if (player.isPlaying()) { player.pause(); showToast("Pause"); } else player.play();
                view.showController();
                return true;
            }
            if (k == KeyEvent.KEYCODE_MEDIA_NEXT && nextAvailable()) { player.seekToNextMediaItem(); return true; }
        }
        return view.dispatchKeyEvent(event) || super.dispatchKeyEvent(event);
    }

    // ---------- Fin ----------

    private String describe(PlaybackException e) {
        int c = e.errorCode;
        if (c == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) return "Le serveur refuse ce flux (connexion déjà utilisée ou contenu retiré).";
        if (c == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED || c == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) return "Le serveur ne répond pas.";
        if (c == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED || c == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED || c == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED || c == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES) return "Format vidéo ou audio non pris en charge par le lecteur intégré.";
        if (c == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED || c == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED) return "Fichier illisible par le lecteur intégré.";
        return "Le flux ne peut pas être lu (" + e.getErrorCodeName().toLowerCase(Locale.ROOT) + ").";
    }

    private void finishWithResult() {
        if (finished) return;
        finished = true;
        ui.removeCallbacksAndMessages(null);
        JSONObject r = new JSONObject();
        try {
            track();
            if (player != null && !live) {
                r.put("index", player.getCurrentMediaItemIndex());
                r.put("pos", Math.max(0, player.getCurrentPosition()) / 1000.0);
                long d = player.getDuration();
                r.put("dur", d > 0 && d != C.TIME_UNSET ? d / 1000.0 : 0);
            } else {
                r.put("index", liveIndex);
            }
            JSONArray arr = new JSONArray();
            for (long[] s : seen) {
                JSONObject x = new JSONObject();
                x.put("index", s[0]);
                x.put("pos", s[1] / 1000.0);
                x.put("dur", s[2] / 1000.0);
                x.put("ended", s[3] == 1);
                arr.put(x);
            }
            r.put("items", arr);
            if (error != null) r.put("error", error);
        } catch (Exception ignored) { }
        Intent data = new Intent();
        data.putExtra("result", r.toString());
        setResult(RESULT_OK, data);
        if (player != null) {
            player.release();
            player = null;
        }
        finish();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Touche Accueil : on garde la position et on rend la main à Lumen
        if (!isChangingConfigurations()) finishWithResult();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
