package fr.alex.lumen.tv;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Outline;
import android.net.Uri;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;

/**
 * Miniature du direct : un petit lecteur posé par-dessus l'écran Direct de Lumen.
 * En plein écran, le lecteur plein écran récupère ce même lecteur (pas de nouvelle connexion),
 * puis le rend à la miniature au retour.
 */
@OptIn(markerClass = UnstableApi.class)
final class LivePreview {
    private static ExoPlayer player;
    private static String key = null;      // chaîne en cours dans la miniature
    private static String url = null, alt = null;
    private static boolean taken = false;  // le plein écran l'utilise
    private static boolean triedAlt = false;
    private static FrameLayout box;
    private static TextureView texture;

    private LivePreview() { }

    private static final Player.Listener LISTENER = new Player.Listener() {
        @Override
        public void onPlayerError(PlaybackException e) {
            if (taken || player == null) return;
            if (!triedAlt && alt != null && !alt.isEmpty()) {
                triedAlt = true;
                player.setMediaItem(new MediaItem.Builder().setUri(Uri.parse(alt)).setMediaId(key).build());
                player.prepare();
                player.play();
                return;
            }
            if (box != null) box.setVisibility(View.GONE);
        }

        @Override
        public void onPlaybackStateChanged(int state) {
            if (!taken && box != null && state == Player.STATE_READY) box.setAlpha(1f);
        }
    };

    private static void ensureBox(Activity a) {
        if (box != null && box.getParent() != null) return;
        box = new FrameLayout(a);
        box.setBackgroundColor(Color.BLACK);
        box.setClipToOutline(true);
        final float r = 12 * a.getResources().getDisplayMetrics().density;
        box.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), r); }
        });
        texture = new TextureView(a);
        box.addView(texture, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        box.setFocusable(false);
        box.setVisibility(View.GONE);
        ViewGroup root = a.findViewById(android.R.id.content);
        root.addView(box, new FrameLayout.LayoutParams(1, 1));
    }

    /** Position en pixels CSS de la page (largeur de page vw) */
    private static void place(Activity a, double x, double y, double w, double h, double vw) {
        View web = a.findViewById(android.R.id.content);
        double scale = vw > 0 ? web.getWidth() / vw : 1;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) Math.round(w * scale), (int) Math.round(h * scale));
        lp.leftMargin = (int) Math.round(x * scale);
        lp.topMargin = (int) Math.round(y * scale);
        box.setLayoutParams(lp);
    }

    static void start(Activity a, String newKey, String newUrl, String newAlt, double x, double y, double w, double h, double vw, String ua) {
        ensureBox(a);
        place(a, x, y, w, h, vw);
        if (player == null) {
            player = Players.create(a, true, ua);
            player.addListener(LISTENER);
        }
        if (!taken) player.setVideoTextureView(texture);
        if (newKey != null && !newKey.equals(key)) {
            key = newKey;
            url = newUrl;
            alt = newAlt;
            triedAlt = false;
            box.setAlpha(0f);
            player.setMediaItem(new MediaItem.Builder().setUri(Uri.parse(newUrl)).setMediaId(newKey).build());
            player.prepare();
        }
        player.play();
        box.setVisibility(View.VISIBLE);
        box.bringToFront();
    }

    static void move(Activity a, double x, double y, double w, double h, double vw) {
        if (box == null) return;
        place(a, x, y, w, h, vw);
    }

    static void hide() {
        if (box != null) box.setVisibility(View.GONE);
    }

    static void stop() {
        if (box != null) box.setVisibility(View.GONE);
        if (player != null && !taken) {
            player.removeListener(LISTENER);
            player.release();
            player = null;
            key = null;
        }
    }

    /** Le plein écran prend le lecteur s'il joue déjà cette chaîne */
    static ExoPlayer take(String wantedKey) {
        if (player == null || taken || wantedKey == null || !wantedKey.equals(key)) return null;
        taken = true;
        player.removeListener(LISTENER);
        player.clearVideoTextureView(texture);
        if (box != null) box.setVisibility(View.GONE);
        return player;
    }

    /** Retour du plein écran : la miniature reprend le lecteur (et la chaîne choisie entre-temps) */
    static void giveBack(ExoPlayer p, String currentKey) {
        if (p == null) return;
        player = p;
        key = currentKey;
        taken = false;
        triedAlt = false;
        player.addListener(LISTENER);
        if (texture != null) player.setVideoTextureView(texture);
        // Sécurité : si l'écran Direct ne réaffiche pas la miniature, on coupe
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            if (!taken && player != null && (box == null || box.getVisibility() != View.VISIBLE)) stop();
        }, 4000);
    }

    static boolean isTaken() { return taken; }
}
