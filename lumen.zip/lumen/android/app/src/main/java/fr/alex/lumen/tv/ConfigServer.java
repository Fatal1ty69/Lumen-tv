package fr.alex.lumen.tv;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Mini serveur web sur le réseau local.
 * GET /        : page pour saisir son serveur Xtream depuis un téléphone
 * GET /ping    : permet au PC de vérifier qu'il parle bien à Lumen TV
 * POST /config : reçoit les réglages (avec le code affiché sur la TV)
 * POST /sync   : échange les profils (progression, Ma liste...) avec Lumen PC
 */
class ConfigServer extends Thread {

    interface Listener {
        void onConfig(String json);
        /** Synchro avec le PC : renvoie la réponse JSON (attend l'interface), ou null si elle ne répond pas */
        String onSync(String json);
    }

    private static final int FIRST_PORT = 47820;
    private static final int MAX_BODY = 20 * 1024 * 1024;

    private final String code;
    private final String html;
    private final Listener listener;
    private volatile boolean running = true;
    private volatile int port = 0;
    private ServerSocket socket;

    ConfigServer(String code, String html, Listener listener) {
        this.code = code;
        this.html = html;
        this.listener = listener;
        setDaemon(true);
    }

    int getPort() { return port; }

    boolean isRunning() { return running && socket != null && !socket.isClosed(); }

    void shutdown() {
        running = false;
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
    }

    @Override
    public void run() {
        for (int p = FIRST_PORT; p < FIRST_PORT + 6 && socket == null; p++) {
            try {
                socket = new ServerSocket(p, 16);
                port = p;
            } catch (Exception ignored) { }
        }
        if (socket == null) { running = false; return; }
        while (running) {
            try {
                final Socket s = socket.accept();
                new Thread(() -> handle(s)).start();
            } catch (Exception e) {
                if (!running) break;
            }
        }
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(20000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            // En-têtes : jusqu'à la ligne vide
            ByteArrayOutputStream head = new ByteArrayOutputStream();
            int b, last4 = 0;
            while ((b = in.read()) != -1) {
                head.write(b);
                last4 = (last4 << 8) | b;
                if (last4 == 0x0D0A0D0A) break;
                if (head.size() > 65536) break;
            }
            String[] lines = head.toString("UTF-8").split("\r\n");
            if (lines.length == 0 || lines[0].isEmpty()) { s.close(); return; }
            String[] first = lines[0].split(" ");
            String method = first[0].toUpperCase(Locale.ROOT);
            String path = first.length > 1 ? first[1] : "/";
            int length = 0;
            for (String l : lines) {
                int i = l.indexOf(':');
                if (i > 0 && l.substring(0, i).trim().equalsIgnoreCase("Content-Length")) {
                    try { length = Integer.parseInt(l.substring(i + 1).trim()); } catch (NumberFormatException ignored) { }
                }
            }
            if (length > MAX_BODY) { reply(s, 413, "application/json", "{\"ok\":false,\"error\":\"Trop volumineux\"}"); return; }
            byte[] body = new byte[Math.max(0, length)];
            int read = 0;
            while (read < length) {
                int n = in.read(body, read, length - read);
                if (n == -1) break;
                read += n;
            }

            if (method.equals("OPTIONS")) { reply(s, 204, "text/plain", ""); return; }
            if (method.equals("GET") && (path.equals("/") || path.startsWith("/?"))) { reply(s, 200, "text/html; charset=utf-8", html); return; }
            if (method.equals("GET") && path.startsWith("/ping")) { reply(s, 200, "application/json", "{\"ok\":true,\"app\":\"Lumen TV\"}"); return; }
            if (method.equals("POST") && path.startsWith("/sync")) {
                String json = new String(body, 0, read, StandardCharsets.UTF_8);
                JSONObject o;
                try { o = new JSONObject(json); } catch (Exception e) {
                    reply(s, 400, "application/json", "{\"ok\":false,\"error\":\"Données illisibles\"}");
                    return;
                }
                if (!code.equals(o.optString("code"))) {
                    reply(s, 403, "application/json", "{\"ok\":false,\"error\":\"Code incorrect\"}");
                    return;
                }
                String res = listener.onSync(json);
                if (res == null) reply(s, 503, "application/json", "{\"ok\":false,\"error\":\"Lumen TV est occupée, nouvel essai bientôt\"}");
                else reply(s, 200, "application/json", res);
                return;
            }
            if (method.equals("POST") && path.startsWith("/config")) {
                String json = new String(body, 0, read, StandardCharsets.UTF_8);
                JSONObject o;
                try { o = new JSONObject(json); } catch (Exception e) {
                    reply(s, 400, "application/json", "{\"ok\":false,\"error\":\"Données illisibles\"}");
                    return;
                }
                if (!code.equals(o.optString("code"))) {
                    reply(s, 403, "application/json", "{\"ok\":false,\"error\":\"Code incorrect : recopie le code affiché sur la TV.\"}");
                    return;
                }
                listener.onConfig(json);
                reply(s, 200, "application/json", "{\"ok\":true}");
                return;
            }
            reply(s, 404, "text/plain", "Introuvable");
        } catch (Exception e) {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    private void reply(Socket s, int status, String type, String text) {
        try {
            byte[] data = text.getBytes(StandardCharsets.UTF_8);
            String reason = status == 200 ? "OK" : status == 204 ? "No Content" : status == 403 ? "Forbidden" : status == 404 ? "Not Found" : status == 503 ? "Service Unavailable" : "Error";
            String h = "HTTP/1.1 " + status + " " + reason + "\r\n"
                    + "Content-Type: " + type + "\r\n"
                    + "Content-Length: " + data.length + "\r\n"
                    + "Access-Control-Allow-Origin: *\r\n"
                    + "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
                    + "Access-Control-Allow-Headers: Content-Type\r\n"
                    + "Cache-Control: no-store\r\n"
                    + "Connection: close\r\n\r\n";
            OutputStream out = s.getOutputStream();
            out.write(h.getBytes(StandardCharsets.UTF_8));
            out.write(data);
            out.flush();
            s.close();
        } catch (Exception ignored) { }
    }
}
