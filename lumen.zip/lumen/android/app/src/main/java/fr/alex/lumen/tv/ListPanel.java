package fr.alex.lumen.tv;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Panneau de liste piloté à la télécommande (liste des chaînes, menu du lecteur).
 * La sélection est gérée à la main : haut/bas déplacent, OK valide.
 */
final class ListPanel extends LinearLayout {

    static final class Row {
        String num = "";
        String title = "";
        String sub = "";
        String logo = null;
        boolean checked = false;
        boolean live = false;  // chaîne en cours de lecture
        Object data;
    }

    private final TextView header;
    private final TextView footer;
    private final ListView list;
    private final Adapter adapter = new Adapter();
    private List<Row> rows = new ArrayList<>();
    private int sel = 0;
    private final boolean logos;
    private final int accent = 0xFFF2A93B;

    ListPanel(Context ctx, boolean withLogos) {
        super(ctx);
        logos = withLogos;
        setOrientation(VERTICAL);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xF20B0B0E, 0xE60B0B0E});
        setBackground(bg);
        setPadding(dp(28), dp(26), dp(20), dp(20));

        header = new TextView(ctx);
        header.setTextColor(Color.WHITE);
        header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setSingleLine(true);
        header.setEllipsize(TextUtils.TruncateAt.END);
        header.setPadding(dp(6), 0, dp(6), dp(14));
        addView(header, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        list = new ListView(ctx);
        list.setDivider(null);
        list.setFocusable(false);
        list.setFocusableInTouchMode(false);
        list.setSelector(android.R.color.transparent);
        list.setVerticalScrollBarEnabled(false);
        list.setAdapter(adapter);
        addView(list, new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));

        footer = new TextView(ctx);
        footer.setTextColor(0xFFA8A8B3);
        footer.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        footer.setPadding(dp(6), dp(12), dp(6), 0);
        addView(footer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        setVisibility(GONE);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    void setRows(String title, List<Row> r, int selected, String hint) {
        header.setText(title);
        footer.setText(hint == null ? "" : hint);
        footer.setVisibility(hint == null || hint.isEmpty() ? GONE : VISIBLE);
        rows = r;
        sel = Math.max(0, Math.min(selected, Math.max(0, r.size() - 1)));
        adapter.notifyDataSetChanged();
        center();
    }

    void setHeader(String title) { header.setText(title); }

    void refresh() { adapter.notifyDataSetChanged(); }

    int selected() { return sel; }

    Row selectedRow() { return sel >= 0 && sel < rows.size() ? rows.get(sel) : null; }

    List<Row> rows() { return rows; }

    void move(int d) {
        if (rows.isEmpty()) return;
        sel = (sel + d + rows.size()) % rows.size();
        adapter.notifyDataSetChanged();
        center();
    }

    private void center() {
        list.post(() -> {
            int h = list.getHeight();
            int rowH = dp(logos ? 66 : 58);
            list.setSelectionFromTop(sel, Math.max(0, h / 2 - rowH / 2));
        });
    }

    boolean shown() { return getVisibility() == VISIBLE; }

    void show() { setVisibility(VISIBLE); bringToFront(); center(); }

    void hide() { setVisibility(GONE); }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int p) { return rows.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int p, View convert, ViewGroup parent) {
            Holder h;
            if (convert == null) {
                h = new Holder();
                LinearLayout row = new LinearLayout(getContext());
                row.setOrientation(HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(8), dp(12), dp(8));
                row.setMinimumHeight(dp(logos ? 66 : 58));

                h.num = new TextView(getContext());
                h.num.setTextColor(0xFF8A8A95);
                h.num.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                h.num.setGravity(Gravity.END);
                row.addView(h.num, new LayoutParams(dp(logos ? 44 : 28), LayoutParams.WRAP_CONTENT));

                if (logos) {
                    h.logo = new ImageView(getContext());
                    h.logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    LayoutParams lp = new LayoutParams(dp(72), dp(44));
                    lp.setMargins(dp(12), 0, dp(12), 0);
                    row.addView(h.logo, lp);
                } else {
                    View gap = new View(getContext());
                    row.addView(gap, new LayoutParams(dp(10), 1));
                }

                LinearLayout col = new LinearLayout(getContext());
                col.setOrientation(VERTICAL);
                h.title = new TextView(getContext());
                h.title.setTextColor(Color.WHITE);
                h.title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                h.title.setTypeface(Typeface.DEFAULT_BOLD);
                h.title.setSingleLine(true);
                h.title.setEllipsize(TextUtils.TruncateAt.END);
                h.sub = new TextView(getContext());
                h.sub.setTextColor(0xFFA8A8B3);
                h.sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                h.sub.setSingleLine(true);
                h.sub.setEllipsize(TextUtils.TruncateAt.END);
                col.addView(h.title);
                col.addView(h.sub);
                row.addView(col, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
                row.setTag(h);
                convert = row;
            } else {
                h = (Holder) convert.getTag();
            }
            Row r = rows.get(p);
            h.num.setText(r.checked ? "✓" : r.num);
            h.num.setTextColor(r.checked ? accent : 0xFF8A8A95);
            h.title.setText(r.title);
            h.title.setTextColor(r.live ? accent : Color.WHITE);
            h.sub.setText(r.sub == null ? "" : r.sub);
            h.sub.setVisibility(r.sub == null || r.sub.isEmpty() ? GONE : VISIBLE);
            if (h.logo != null) ImageLoader.load(r.logo, h.logo);
            if (p == sel) {
                GradientDrawable d = new GradientDrawable();
                d.setColor(0x33F2A93B);
                d.setStroke(dp(2), accent);
                d.setCornerRadius(dp(10));
                convert.setBackground(d);
            } else {
                convert.setBackground(null);
            }
            return convert;
        }
    }

    private static final class Holder {
        TextView num, title, sub;
        ImageView logo;
    }
}
