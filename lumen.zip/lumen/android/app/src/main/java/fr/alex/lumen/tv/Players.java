package fr.alex.lumen.tv;

import android.content.Context;

import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;

/** Fabrique commune des lecteurs (plein écran et miniature du direct). */
@OptIn(markerClass = UnstableApi.class)
final class Players {
    private Players() { }

    static ExoPlayer create(Context ctx, boolean live, String ua) {
        Context app = ctx.getApplicationContext();
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(ua != null ? ua : LumenTvPlugin.IPTV_UA)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(10000)
                .setReadTimeoutMs(20000);
        DefaultExtractorsFactory extractors = new DefaultExtractorsFactory()
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
                .setConstantBitrateSeekingEnabled(true);
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(app)
                .setEnableDecoderFallback(true)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON);
        // Direct : démarrage dès 0,6 s de vidéo reçue. Films : 1 s, puis réserve plus large.
        DefaultLoadControl load = live
                ? new DefaultLoadControl.Builder().setBufferDurationsMs(2500, 20000, 600, 1500).build()
                : new DefaultLoadControl.Builder().setBufferDurationsMs(15000, 50000, 1000, 2500).build();
        return new ExoPlayer.Builder(app, renderers)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(http, extractors))
                .setLoadControl(load)
                .build();
    }
}
