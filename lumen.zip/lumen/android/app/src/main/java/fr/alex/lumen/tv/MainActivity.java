package fr.alex.lumen.tv;

import android.os.Bundle;
import android.webkit.WebSettings;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(LumenTvPlugin.class);
        super.onCreate(savedInstanceState);
        // Respecte la largeur demandée par la page (1280 px) pour une mise en page « écran de TV »
        if (getBridge() != null && getBridge().getWebView() != null) {
            WebSettings s = getBridge().getWebView().getSettings();
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
            s.setMediaPlaybackRequiresUserGesture(false);
            getBridge().getWebView().setBackgroundColor(0xFF0B0B0E);
        }
    }
}
