package fr.alex.lumen.tv;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Recherche et téléchargement de sous-titres sur OpenSubtitles (même compte que Lumen PC). */
final class OpenSubs {
    private static final String API = "https://api.opensubtitles.com/api/v1";
    private static final String UA = "Lumen v0.3";
    private static String token = null;

    static final class Sub {
        String fileId, lang, name;
        int downloads;
    }

    private OpenSubs() { }

    private static Map<String, String> headers(String key) {
        Map<String, String> h = new HashMap<>();
        h.put("Api-Key", key);
        h.put("User-Agent", UA);
        h.put("Accept", "application/json");
        h.put("Content-Type", "application/json");
        return h;
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }

    /** q : tmdbId (film) ou parentTmdbId + season + episode (épisode), sinon query */
    static List<Sub> search(JSONObject os, JSONObject item, String langs) throws Exception {
        String key = os.optString("key", "");
        StringBuilder u = new StringBuilder(API + "/subtitles?languages=" + enc(langs));
        long parent = item.optLong("parentTmdbId", 0);
        long tmdb = item.optLong("tmdbId", 0);
        if (parent > 0) u.append("&parent_tmdb_id=").append(parent).append("&season_number=").append(item.optInt("season")).append("&episode_number=").append(item.optInt("episode"));
        else if (tmdb > 0) u.append("&tmdb_id=").append(tmdb);
        else u.append("&query=").append(enc(item.optString("query", item.optString("title", ""))));
        Net.Response r = Net.request(u.toString(), "GET", headers(key), null, 15000);
        if (r.status == 401 || r.status == 403) throw new Exception("Clé OpenSubtitles refusée");
        JSONArray data = new JSONObject(r.text()).optJSONArray("data");
        List<Sub> out = new ArrayList<>();
        if (data == null) return out;
        for (int i = 0; i < data.length() && out.size() < 25; i++) {
            JSONObject a = data.optJSONObject(i) != null ? data.optJSONObject(i).optJSONObject("attributes") : null;
            if (a == null) continue;
            JSONArray files = a.optJSONArray("files");
            if (files == null || files.length() == 0) continue;
            Sub s = new Sub();
            s.fileId = String.valueOf(files.optJSONObject(0).optLong("file_id"));
            s.lang = a.optString("language", "");
            s.name = a.optString("release", files.optJSONObject(0).optString("file_name", "Sous-titre"));
            s.downloads = a.optInt("download_count", 0);
            out.add(s);
        }
        return out;
    }

    static File download(JSONObject os, String fileId, File dir) throws Exception {
        String key = os.optString("key", "");
        Map<String, String> h = headers(key);
        String user = os.optString("user", "");
        String pass = os.optString("pass", "");
        if (token == null && !user.isEmpty() && !pass.isEmpty()) {
            try {
                JSONObject b = new JSONObject();
                b.put("username", user);
                b.put("password", pass);
                Net.Response lr = Net.request(API + "/login", "POST", h, b.toString(), 15000);
                token = new JSONObject(lr.text()).optString("token", null);
            } catch (Exception ignored) { }
        }
        if (token != null) h.put("Authorization", "Bearer " + token);
        JSONObject body = new JSONObject();
        body.put("file_id", Long.parseLong(fileId));
        Net.Response r = Net.request(API + "/download", "POST", h, body.toString(), 15000);
        JSONObject d = new JSONObject(r.text());
        String link = d.optString("link", "");
        if (link.isEmpty()) throw new Exception(d.optString("message", "Téléchargement refusé (quota atteint ?)"));
        Map<String, String> h2 = new HashMap<>();
        h2.put("User-Agent", UA);
        Net.Response f = Net.request(link, "GET", h2, null, 20000);
        File out = new File(dir, "sub-" + fileId + ".srt");
        FileOutputStream fo = new FileOutputStream(out);
        fo.write(f.body);
        fo.close();
        return out;
    }
}
