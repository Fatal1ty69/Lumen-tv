package fr.alex.lumen.tv;

import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Petites requêtes HTTP en arrière-plan pour le lecteur (guide TV, logos, sous-titres). */
final class Net {
    static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    static final Handler UI = new Handler(Looper.getMainLooper());

    private Net() { }

    static final class Response {
        int status;
        byte[] body = new byte[0];
        String text() { return new String(body, StandardCharsets.UTF_8); }
    }

    /** Requête bloquante (à appeler hors du fil principal). Suit les redirections, y compris http vers https. */
    static Response request(String url, String method, Map<String, String> headers, String body, int timeoutMs) throws Exception {
        Response r = new Response();
        String m = method == null ? "GET" : method;
        String b = body;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs);
            c.setRequestMethod(m);
            boolean ua = false;
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    c.setRequestProperty(e.getKey(), e.getValue());
                    if (e.getKey().equalsIgnoreCase("User-Agent")) ua = true;
                }
            }
            if (!ua) c.setRequestProperty("User-Agent", LumenTvPlugin.IPTV_UA);
            if (b != null && !m.equals("GET")) {
                byte[] bytes = b.getBytes(StandardCharsets.UTF_8);
                c.setDoOutput(true);
                c.setFixedLengthStreamingMode(bytes.length);
                OutputStream os = c.getOutputStream();
                os.write(bytes);
                os.close();
            }
            int code = c.getResponseCode();
            String loc = c.getHeaderField("Location");
            if (code >= 300 && code < 400 && loc != null) {
                url = new URL(new URL(url), loc).toString();
                c.disconnect();
                if (code != 307 && code != 308) { m = "GET"; b = null; }
                continue;
            }
            r.status = code;
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[32768];
                int n;
                while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
                in.close();
                r.body = buf.toByteArray();
            }
            c.disconnect();
            return r;
        }
        throw new Exception("Trop de redirections");
    }
}
