package fr.alex.lumen.tv;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Guide des programmes court (en cours, ensuite) via l'API Xtream get_short_epg. */
final class Epg {

    static final class Prog {
        String title;
        long start, end;
    }

    interface Callback { void done(List<Prog> progs); }

    private static final long TTL = 10 * 60 * 1000L;
    private static final Map<String, List<Prog>> CACHE = Collections.synchronizedMap(new HashMap<>());
    private static final Map<String, Long> TIME = Collections.synchronizedMap(new HashMap<>());
    private static final Set<String> LOADING = Collections.synchronizedSet(new HashSet<>());

    private Epg() { }

    static List<Prog> cached(String url) {
        Long t = TIME.get(url);
        if (t == null || System.currentTimeMillis() - t > TTL) return null;
        return CACHE.get(url);
    }

    /** Programme en cours (ou null) */
    static Prog now(List<Prog> l) {
        if (l == null) return null;
        long n = System.currentTimeMillis();
        for (Prog p : l) if (p.start <= n && p.end > n) return p;
        return null;
    }

    static Prog next(List<Prog> l) {
        if (l == null) return null;
        long n = System.currentTimeMillis();
        for (Prog p : l) if (p.start > n) return p;
        return null;
    }

    private static String text(String s) {
        if (s == null) return "";
        try {
            return new String(Base64.decode(s, Base64.DEFAULT), StandardCharsets.UTF_8).trim();
        } catch (IllegalArgumentException e) {
            return s.trim();
        }
    }

    static void load(final String url, final Callback cb) {
        List<Prog> hit = cached(url);
        if (hit != null) { cb.done(hit); return; }
        if (url == null || url.isEmpty() || !LOADING.add(url)) return;
        Net.POOL.execute(() -> {
            List<Prog> out = new ArrayList<>();
            try {
                Net.Response r = Net.request(url, "GET", null, null, 8000);
                JSONObject o = new JSONObject(r.text());
                JSONArray a = o.optJSONArray("epg_listings");
                long n = System.currentTimeMillis();
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject p = a.optJSONObject(i);
                        if (p == null) continue;
                        Prog g = new Prog();
                        g.title = text(p.optString("title"));
                        g.start = p.optLong("start_timestamp", 0) * 1000L;
                        g.end = p.optLong("stop_timestamp", 0) * 1000L;
                        if (g.end > n - 60000 && g.end > g.start) out.add(g);
                    }
                }
            } catch (Exception ignored) { }
            CACHE.put(url, out);
            TIME.put(url, System.currentTimeMillis());
            LOADING.remove(url);
            final List<Prog> done = out;
            Net.UI.post(() -> cb.done(done));
        });
    }
}
