package fr.alex.lumen.tv;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.speech.RecognizerIntent;

import androidx.core.content.FileProvider;
import androidx.tvprovider.media.tv.TvContractCompat;
import androidx.tvprovider.media.tv.WatchNextProgram;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.core.content.pm.PackageInfoCompat;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;

import javax.net.ssl.SSLException;

/**
 * Pont entre l'interface Lumen (web) et Android :
 * requêtes HTTP sans restriction CORS, lecteur vidéo natif, ouverture d'une autre appli,
 * petit serveur local pour recevoir les réglages envoyés depuis le PC ou le téléphone.
 */
@CapacitorPlugin(name = "LumenTv")
public class LumenTvPlugin extends Plugin {

    static final String IPTV_UA = "VLC/3.0.20 LibVLC/3.0.20";
    /** Chaînes et groupes du direct, envoyés une seule fois par catalogue */
    static volatile JSObject liveData = null;
    static volatile String liveVersion = "";
    private ConfigServer server;

    // ---------- Lecture ----------

    @PluginMethod
    public void play(PluginCall call) {
        Intent intent = new Intent(getContext(), PlayerActivity.class);
        PlayerActivity.pendingOptions = call.getData().toString();
        startActivityForResult(call, intent, "onPlayResult");
    }

    @PluginMethod
    public void setLiveData(PluginCall call) {
        liveData = call.getData();
        liveVersion = call.getString("version", "");
        call.resolve();
    }

    @PluginMethod
    public void getLiveVersion(PluginCall call) {
        JSObject r = new JSObject();
        r.put("version", liveData != null ? liveVersion : "");
        call.resolve(r);
    }

    // ---------- « Continuer à regarder » sur l'écran d'accueil de la Shield ----------

    @PluginMethod
    public void syncWatchNext(PluginCall call) {
        final JSArray list = call.getArray("items", new JSArray());
        new Thread(() -> {
            SharedPreferences p = getContext().getSharedPreferences("lumen", Context.MODE_PRIVATE);
            android.content.ContentResolver cr = getContext().getContentResolver();
            int added = 0;
            try {
                // On retire les programmes ajoutés la fois précédente, puis on remet la liste à jour
                JSONArray old = new JSONArray(p.getString("watchNextIds", "[]"));
                for (int i = 0; i < old.length(); i++) {
                    try { cr.delete(TvContractCompat.buildWatchNextProgramUri(old.getLong(i)), null, null); } catch (Exception ignored) { }
                }
                JSONArray ids = new JSONArray();
                for (int i = 0; i < list.length(); i++) {
                    JSONObject it = list.getJSONObject(i);
                    WatchNextProgram.Builder b = new WatchNextProgram.Builder();
                    boolean episode = "episode".equals(it.optString("kind"));
                    b.setType(episode ? TvContractCompat.WatchNextPrograms.TYPE_TV_EPISODE : TvContractCompat.WatchNextPrograms.TYPE_MOVIE)
                            .setWatchNextType(it.optBoolean("next") ? TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_NEXT : TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE)
                            .setLastEngagementTimeUtcMillis(it.optLong("t", System.currentTimeMillis()))
                            .setTitle(it.optString("title"))
                            .setInternalProviderId(it.optString("key"))
                            .setIntentUri(Uri.parse("lumen://play?key=" + Uri.encode(it.optString("key"))))
                            .setLastPlaybackPositionMillis((int) Math.min(Integer.MAX_VALUE, it.optLong("pos") * 1000L))
                            .setDurationMillis((int) Math.min(Integer.MAX_VALUE, it.optLong("dur") * 1000L));
                    if (episode) b.setEpisodeTitle(it.optString("sub"));
                    String img = it.optString("image", "");
                    if (!img.isEmpty()) {
                        b.setPosterArtUri(Uri.parse(img));
                        b.setPosterArtAspectRatio(TvContractCompat.WatchNextPrograms.ASPECT_RATIO_16_9);
                    }
                    Uri u = cr.insert(TvContractCompat.WatchNextPrograms.CONTENT_URI, b.build().toContentValues());
                    if (u != null) { ids.put(android.content.ContentUris.parseId(u)); added++; }
                }
                p.edit().putString("watchNextIds", ids.toString()).apply();
            } catch (Exception ignored) { }
            JSObject r = new JSObject();
            r.put("added", added);
            call.resolve(r);
        }).start();
    }

    // ---------- Miniature du direct ----------

    private void onUi(Runnable r) { if (getActivity() != null) getActivity().runOnUiThread(r); }

    @PluginMethod
    public void previewStart(PluginCall call) {
        final String key = call.getString("key");
        final String url = call.getString("url");
        final String alt = call.getString("alt", "");
        final double x = call.getDouble("x", 0.0), y = call.getDouble("y", 0.0), w = call.getDouble("w", 0.0), h = call.getDouble("h", 0.0), vw = call.getDouble("vw", 0.0);
        onUi(() -> {
            try { LivePreview.start(getActivity(), key, url, alt, x, y, w, h, vw, IPTV_UA); } catch (Exception ignored) { }
            call.resolve();
        });
    }

    @PluginMethod
    public void previewMove(PluginCall call) {
        final double x = call.getDouble("x", 0.0), y = call.getDouble("y", 0.0), w = call.getDouble("w", 0.0), h = call.getDouble("h", 0.0), vw = call.getDouble("vw", 0.0);
        onUi(() -> { LivePreview.move(getActivity(), x, y, w, h, vw); call.resolve(); });
    }

    @PluginMethod
    public void previewHide(PluginCall call) {
        onUi(() -> { LivePreview.hide(); call.resolve(); });
    }

    @PluginMethod
    public void previewStop(PluginCall call) {
        onUi(() -> { LivePreview.stop(); call.resolve(); });
    }

    @Override
    protected void handleOnStop() {
        // Lumen passe en arrière-plan (et pas vers le plein écran) : on coupe la miniature
        if (!LivePreview.isTaken()) onUi(LivePreview::stop);
        super.handleOnStop();
    }

    // ---------- Recherche vocale ----------

    @PluginMethod
    public void voice(PluginCall call) {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Que veux-tu regarder ?");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        try {
            startActivityForResult(call, i, "onVoiceResult");
        } catch (Exception e) {
            call.reject("La recherche vocale n'est pas disponible sur cet appareil");
        }
    }

    @ActivityCallback
    private void onVoiceResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject r = new JSObject();
        Intent d = result.getData();
        ArrayList<String> words = d != null ? d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) : null;
        r.put("text", words != null && !words.isEmpty() ? words.get(0) : "");
        call.resolve(r);
    }

    // ---------- Mise à jour de l'appli ----------

    @PluginMethod
    public void appInfo(PluginCall call) {
        JSObject r = new JSObject();
        try {
            android.content.pm.PackageInfo pi = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
            r.put("versionCode", PackageInfoCompat.getLongVersionCode(pi));
            r.put("versionName", pi.versionName);
        } catch (Exception e) {
            r.put("versionCode", 0);
        }
        call.resolve(r);
    }

    @PluginMethod
    public void installUpdate(PluginCall call) {
        final String url = call.getString("url");
        if (url == null) { call.reject("Adresse manquante"); return; }
        // Android 8+ : l'appli doit être autorisée à installer des applis
        if (Build.VERSION.SDK_INT >= 26 && !getContext().getPackageManager().canRequestPackageInstalls()) {
            try {
                Intent s = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
                s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(s);
            } catch (Exception ignored) { }
            JSObject r = new JSObject();
            r.put("needPermission", true);
            call.resolve(r);
            return;
        }
        new Thread(() -> {
            try {
                java.net.HttpURLConnection c = null;
                String u = url;
                for (int hop = 0; hop < 6; hop++) {
                    c = (java.net.HttpURLConnection) new URL(u).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(30000);
                    int code = c.getResponseCode();
                    String loc = c.getHeaderField("Location");
                    if (code >= 300 && code < 400 && loc != null) { u = new URL(new URL(u), loc).toString(); c.disconnect(); continue; }
                    break;
                }
                if (c.getResponseCode() >= 400) throw new Exception("Téléchargement refusé (" + c.getResponseCode() + ")");
                long total = c.getContentLengthLong();
                File f = new File(getContext().getCacheDir(), "lumen-update.apk");
                InputStream in = c.getInputStream();
                FileOutputStream out = new FileOutputStream(f);
                byte[] chunk = new byte[65536];
                long done = 0;
                int n, last = -1;
                while ((n = in.read(chunk)) != -1) {
                    out.write(chunk, 0, n);
                    done += n;
                    int pct = total > 0 ? (int) (done * 100 / total) : -1;
                    if (pct != last) {
                        last = pct;
                        JSObject ev = new JSObject();
                        ev.put("percent", pct);
                        notifyListeners("updateProgress", ev);
                    }
                }
                out.close();
                in.close();
                c.disconnect();
                Uri apk = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(apk, "application/vnd.android.package-archive");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
                call.resolve(new JSObject());
            } catch (Exception e) {
                call.reject(e.getMessage() != null ? e.getMessage() : "Téléchargement impossible");
            }
        }).start();
    }

    @ActivityCallback
    private void onPlayResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        Intent data = result.getData();
        String json = data != null ? data.getStringExtra("result") : null;
        if (json != null) {
            try {
                ret = new JSObject(json);
            } catch (JSONException e) {
                ret.put("error", "Réponse du lecteur illisible");
            }
        } else {
            ret.put("closed", true);
        }
        call.resolve(ret);
    }

    // Ouvre un flux dans une autre appli (VLC, Just Player, MX Player…)
    @PluginMethod
    public void openExternal(PluginCall call) {
        String url = call.getString("url");
        if (url == null) { call.reject("Adresse manquante"); return; }
        try {
            Intent view = new Intent(Intent.ACTION_VIEW);
            if (call.getBoolean("video", false)) view.setDataAndType(Uri.parse(url), "video/*");
            else view.setData(Uri.parse(url));
            String title = call.getString("title");
            if (title != null) view.putExtra("title", title);
            Intent chooser = Intent.createChooser(view, "Ouvrir avec");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("Aucune appli ne sait ouvrir ce lien");
        }
    }

    // ---------- Réseau ----------

    @PluginMethod
    public void http(PluginCall call) {
        new Thread(() -> {
            JSObject ret = new JSObject();
            try {
                String url = call.getString("url");
                String method = call.getString("method", "GET");
                String body = call.getString("body");
                int timeout = call.getInt("timeout", 30000);
                JSObject headers = call.getObject("headers", new JSObject());
                HttpURLConnection c = null;
                for (int hop = 0; hop < 6; hop++) {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(timeout);
                    c.setReadTimeout(timeout);
                    c.setRequestMethod(method);
                    boolean ua = false;
                    Iterator<String> keys = headers.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        c.setRequestProperty(k, headers.getString(k));
                        if (k.equalsIgnoreCase("User-Agent")) ua = true;
                    }
                    if (!ua) c.setRequestProperty("User-Agent", IPTV_UA);
                    if (body != null && !method.equals("GET")) {
                        c.setDoOutput(true);
                        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                        c.setFixedLengthStreamingMode(bytes.length);
                        OutputStream os = c.getOutputStream();
                        os.write(bytes);
                        os.close();
                    }
                    int code = c.getResponseCode();
                    // Redirections, y compris de http vers https (que Java ne suit pas tout seul)
                    if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                        url = new URL(new URL(url), c.getHeaderField("Location")).toString();
                        c.disconnect();
                        if (code != 307 && code != 308) { method = "GET"; body = null; }
                        continue;
                    }
                    break;
                }
                int status = c.getResponseCode();
                InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                String text = "";
                if (in != null) {
                    ByteArrayOutputStream buf = new ByteArrayOutputStream();
                    byte[] chunk = new byte[65536];
                    int n;
                    while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
                    in.close();
                    text = buf.toString("UTF-8");
                }
                ret.put("ok", true);
                ret.put("status", status);
                ret.put("text", text);
                String pages = c.getHeaderField("X-Pagination-Page-Count");
                if (pages != null) {
                    try { ret.put("pageCount", Integer.parseInt(pages.trim())); } catch (NumberFormatException ignored) { }
                }
                c.disconnect();
            } catch (UnknownHostException e) {
                ret.put("ok", false);
                ret.put("error", "Adresse introuvable : vérifie l'adresse du serveur et la connexion de la TV.");
            } catch (SocketTimeoutException e) {
                ret.put("ok", false);
                ret.put("error", "Le serveur ne répond pas (délai dépassé).");
            } catch (ConnectException e) {
                ret.put("ok", false);
                ret.put("error", "Connexion refusée : vérifie l'adresse et le port du serveur.");
            } catch (SSLException e) {
                ret.put("ok", false);
                ret.put("error", "Certificat de sécurité invalide : essaie avec http:// au lieu de https://.");
            } catch (Exception e) {
                ret.put("ok", false);
                ret.put("error", e.getMessage() != null ? e.getMessage() : e.toString());
            }
            call.resolve(ret);
        }).start();
    }

    // ---------- Réception des réglages ----------

    private String pairCode() {
        SharedPreferences p = getContext().getSharedPreferences("lumen", Context.MODE_PRIVATE);
        String code = p.getString("pairCode", null);
        if (code == null) {
            code = String.valueOf(1000 + new Random().nextInt(9000));
            p.edit().putString("pairCode", code).apply();
        }
        return code;
    }

    static String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress() && a.isSiteLocalAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    @PluginMethod
    public void startServer(PluginCall call) {
        if (server == null || !server.isRunning()) {
            String html = "<p>Lumen TV</p>";
            try {
                InputStream in = getContext().getAssets().open("lumen-config.html");
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int n;
                while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
                in.close();
                html = buf.toString("UTF-8");
            } catch (Exception ignored) { }
            server = new ConfigServer(pairCode(), html, new ConfigServer.Listener() {
                @Override
                public void onConfig(String json) {
                    try {
                        final JSObject data = new JSObject(json);
                        if (getActivity() != null) getActivity().runOnUiThread(() -> notifyListeners("config", data));
                    } catch (JSONException ignored) { }
                }

                @Override
                public String onSync(String json) { return relaySync(json); }
            });
            server.start();
            // Laisse au serveur le temps d'ouvrir son port
            for (int i = 0; i < 20 && server.getPort() == 0; i++) {
                try { Thread.sleep(50); } catch (InterruptedException ignored) { }
            }
        }
        JSObject ret = new JSObject();
        ret.put("ip", localIp());
        ret.put("port", server.getPort());
        ret.put("code", pairCode());
        call.resolve(ret);
    }

    // ---------- Rappels pendant la lecture ----------

    @PluginMethod
    public void remind(PluginCall call) {
        boolean shown = PlayerActivity.remind(call.getString("title", ""), call.getString("text", ""), call.getString("channelKey", null));
        JSObject ret = new JSObject();
        ret.put("shown", shown);
        call.resolve(ret);
    }

    // ---------- Synchro avec Lumen PC ----------
    // Le serveur reçoit la demande, l'interface fusionne les données et répond via syncReply

    private static final java.util.concurrent.ConcurrentHashMap<String, String[]> syncWaits = new java.util.concurrent.ConcurrentHashMap<>();
    private static final java.util.concurrent.atomic.AtomicInteger syncSeq = new java.util.concurrent.atomic.AtomicInteger();

    String relaySync(String json) {
        if (getActivity() == null) return null;
        final String id = "s" + syncSeq.incrementAndGet();
        final String[] box = new String[1];
        final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
        syncWaits.put(id, box);
        syncLatches.put(id, latch);
        try {
            final JSObject ev = new JSObject();
            ev.put("id", id);
            ev.put("body", json);
            getActivity().runOnUiThread(() -> notifyListeners("syncRequest", ev));
            latch.await(15, java.util.concurrent.TimeUnit.SECONDS);
            return box[0];
        } catch (Exception e) {
            return null;
        } finally {
            syncWaits.remove(id);
            syncLatches.remove(id);
        }
    }

    private static final java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.CountDownLatch> syncLatches = new java.util.concurrent.ConcurrentHashMap<>();

    @PluginMethod
    public void syncReply(PluginCall call) {
        String id = call.getString("id", "");
        String[] box = syncWaits.get(id);
        java.util.concurrent.CountDownLatch latch = syncLatches.get(id);
        if (box != null) box[0] = call.getString("body", "{\"ok\":false}");
        if (latch != null) latch.countDown();
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        if (server != null) server.shutdown();
        super.handleOnDestroy();
    }
}
