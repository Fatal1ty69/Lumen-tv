package fr.alex.lumen.tv;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;

import javax.net.ssl.SSLException;

/**
 * Pont entre l'interface Lumen (web) et Android :
 * requêtes HTTP sans restriction CORS, lecteur vidéo natif, ouverture d'une autre appli,
 * petit serveur local pour recevoir les réglages envoyés depuis le PC ou le téléphone.
 */
@CapacitorPlugin(name = "LumenTv")
public class LumenTvPlugin extends Plugin {

    static final String IPTV_UA = "VLC/3.0.20 LibVLC/3.0.20";
    private ConfigServer server;

    // ---------- Lecture ----------

    @PluginMethod
    public void play(PluginCall call) {
        Intent intent = new Intent(getContext(), PlayerActivity.class);
        intent.putExtra("options", call.getData().toString());
        startActivityForResult(call, intent, "onPlayResult");
    }

    @ActivityCallback
    private void onPlayResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        Intent data = result.getData();
        String json = data != null ? data.getStringExtra("result") : null;
        if (json != null) {
            try {
                ret = new JSObject(json);
            } catch (JSONException e) {
                ret.put("error", "Réponse du lecteur illisible");
            }
        } else {
            ret.put("closed", true);
        }
        call.resolve(ret);
    }

    // Ouvre un flux dans une autre appli (VLC, Just Player, MX Player…)
    @PluginMethod
    public void openExternal(PluginCall call) {
        String url = call.getString("url");
        if (url == null) { call.reject("Adresse manquante"); return; }
        try {
            Intent view = new Intent(Intent.ACTION_VIEW);
            if (call.getBoolean("video", false)) view.setDataAndType(Uri.parse(url), "video/*");
            else view.setData(Uri.parse(url));
            String title = call.getString("title");
            if (title != null) view.putExtra("title", title);
            Intent chooser = Intent.createChooser(view, "Ouvrir avec");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("Aucune appli ne sait ouvrir ce lien");
        }
    }

    // ---------- Réseau ----------

    @PluginMethod
    public void http(PluginCall call) {
        new Thread(() -> {
            JSObject ret = new JSObject();
            try {
                String url = call.getString("url");
                String method = call.getString("method", "GET");
                String body = call.getString("body");
                int timeout = call.getInt("timeout", 30000);
                JSObject headers = call.getObject("headers", new JSObject());
                HttpURLConnection c = null;
                for (int hop = 0; hop < 6; hop++) {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(timeout);
                    c.setReadTimeout(timeout);
                    c.setRequestMethod(method);
                    boolean ua = false;
                    Iterator<String> keys = headers.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        c.setRequestProperty(k, headers.getString(k));
                        if (k.equalsIgnoreCase("User-Agent")) ua = true;
                    }
                    if (!ua) c.setRequestProperty("User-Agent", IPTV_UA);
                    if (body != null && !method.equals("GET")) {
                        c.setDoOutput(true);
                        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                        c.setFixedLengthStreamingMode(bytes.length);
                        OutputStream os = c.getOutputStream();
                        os.write(bytes);
                        os.close();
                    }
                    int code = c.getResponseCode();
                    // Redirections, y compris de http vers https (que Java ne suit pas tout seul)
                    if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                        url = new URL(new URL(url), c.getHeaderField("Location")).toString();
                        c.disconnect();
                        if (code != 307 && code != 308) { method = "GET"; body = null; }
                        continue;
                    }
                    break;
                }
                int status = c.getResponseCode();
                InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                String text = "";
                if (in != null) {
                    ByteArrayOutputStream buf = new ByteArrayOutputStream();
                    byte[] chunk = new byte[65536];
                    int n;
                    while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
                    in.close();
                    text = buf.toString("UTF-8");
                }
                ret.put("ok", true);
                ret.put("status", status);
                ret.put("text", text);
                String pages = c.getHeaderField("X-Pagination-Page-Count");
                if (pages != null) {
                    try { ret.put("pageCount", Integer.parseInt(pages.trim())); } catch (NumberFormatException ignored) { }
                }
                c.disconnect();
            } catch (UnknownHostException e) {
                ret.put("ok", false);
                ret.put("error", "Adresse introuvable : vérifie l'adresse du serveur et la connexion de la TV.");
            } catch (SocketTimeoutException e) {
                ret.put("ok", false);
                ret.put("error", "Le serveur ne répond pas (délai dépassé).");
            } catch (ConnectException e) {
                ret.put("ok", false);
                ret.put("error", "Connexion refusée : vérifie l'adresse et le port du serveur.");
            } catch (SSLException e) {
                ret.put("ok", false);
                ret.put("error", "Certificat de sécurité invalide : essaie avec http:// au lieu de https://.");
            } catch (Exception e) {
                ret.put("ok", false);
                ret.put("error", e.getMessage() != null ? e.getMessage() : e.toString());
            }
            call.resolve(ret);
        }).start();
    }

    // ---------- Réception des réglages ----------

    private String pairCode() {
        SharedPreferences p = getContext().getSharedPreferences("lumen", Context.MODE_PRIVATE);
        String code = p.getString("pairCode", null);
        if (code == null) {
            code = String.valueOf(1000 + new Random().nextInt(9000));
            p.edit().putString("pairCode", code).apply();
        }
        return code;
    }

    static String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress() && a.isSiteLocalAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    @PluginMethod
    public void startServer(PluginCall call) {
        if (server == null || !server.isRunning()) {
            String html = "<p>Lumen TV</p>";
            try {
                InputStream in = getContext().getAssets().open("lumen-config.html");
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int n;
                while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
                in.close();
                html = buf.toString("UTF-8");
            } catch (Exception ignored) { }
            server = new ConfigServer(pairCode(), html, json -> {
                try {
                    final JSObject data = new JSObject(json);
                    if (getActivity() != null) getActivity().runOnUiThread(() -> notifyListeners("config", data));
                } catch (JSONException ignored) { }
            });
            server.start();
            // Laisse au serveur le temps d'ouvrir son port
            for (int i = 0; i < 20 && server.getPort() == 0; i++) {
                try { Thread.sleep(50); } catch (InterruptedException ignored) { }
            }
        }
        JSObject ret = new JSObject();
        ret.put("ip", localIp());
        ret.put("port", server.getPort());
        ret.put("code", pairCode());
        call.resolve(ret);
    }

    @Override
    protected void handleOnDestroy() {
        if (server != null) server.shutdown();
        super.handleOnDestroy();
    }
}
