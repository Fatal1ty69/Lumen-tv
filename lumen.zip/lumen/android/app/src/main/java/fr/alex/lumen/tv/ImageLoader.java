package fr.alex.lumen.tv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Logos des chaînes : chargés en arrière-plan, réduits et gardés en mémoire. */
final class ImageLoader {
    private static final LruCache<String, Bitmap> CACHE = new LruCache<>(400);
    private static final Set<String> FAILED = Collections.synchronizedSet(new HashSet<>());
    private static final int MAX = 220;

    private ImageLoader() { }

    static void load(final String url, final ImageView view) {
        view.setTag(url);
        if (url == null || url.isEmpty() || FAILED.contains(url)) { view.setImageDrawable(null); return; }
        Bitmap hit = CACHE.get(url);
        if (hit != null) { view.setImageBitmap(hit); return; }
        view.setImageDrawable(null);
        Net.POOL.execute(() -> {
            Bitmap bm = null;
            try {
                Net.Response r = Net.request(url, "GET", null, null, 8000);
                if (r.status < 400 && r.body.length > 0) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(r.body, 0, r.body.length, o);
                    int s = 1;
                    while (o.outWidth / (s * 2) >= MAX || o.outHeight / (s * 2) >= MAX) s *= 2;
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = s;
                    bm = BitmapFactory.decodeByteArray(r.body, 0, r.body.length, o2);
                }
            } catch (Exception ignored) { }
            if (bm == null) { FAILED.add(url); return; }
            CACHE.put(url, bm);
            final Bitmap done = bm;
            Net.UI.post(() -> { if (url.equals(view.getTag())) view.setImageBitmap(done); });
        });
    }
}
