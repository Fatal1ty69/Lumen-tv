# Lumen TV sur la Nvidia Shield

## 1. Créer le dépôt GitHub (une seule fois)
1. Crée un compte gratuit sur github.com.
2. En haut à droite, « + » puis « New repository ». Nom : `lumen-tv`. Choisis **Public** (la Shield pourra télécharger l'APK sans mot de passe ; le dépôt ne contient aucun identifiant IPTV). Clique « Create repository ».
3. Sur la page du dépôt, clique « uploading an existing file ».
4. Dézippe `lumen-tv-github.zip` sur ton PC, puis glisse dans la page **le dossier `.github` et le fichier `lumen.zip`** (les deux en même temps). Clique « Commit changes ».
5. Onglet « Actions » : la compilation démarre toute seule (environ 6 à 8 minutes). Une coche verte = l'APK est prêt.

## 2. Installer sur la Shield (une seule fois)
1. Sur la Shield, installe l'appli **Downloader** (Play Store).
2. Paramètres de la Shield, Préférences de l'appareil, Sécurité et restrictions, Sources inconnues : autorise **Downloader**.
3. Ouvre Downloader et tape l'adresse :
   `https://github.com/TON-PSEUDO/lumen-tv/releases/latest/download/lumen-tv.apk`
4. Installe, puis ouvre Lumen (il apparaît dans la rangée des applis).

## 3. Configurer
Lumen TV affiche un QR code, une adresse et un code à 4 chiffres.
- Depuis le PC : Lumen PC, Réglages, carte « Envoyer vers ma TV » : adresse et code, puis « Envoyer ». Tout est recopié (serveurs, clés TMDB et OMDb, Trakt, Ma liste, progression).
- Ou depuis le téléphone : scanne le QR code et remplis le formulaire.

## 4. Mettre à jour
Quand je t'envoie une nouvelle version : sur GitHub, « Add file », « Upload files », glisse le nouveau `lumen.zip`, « Commit changes ». Après la coche verte, refais l'étape 2.3 dans Downloader : la nouvelle version s'installe par-dessus en gardant tes réglages.

## Si la compilation échoue (croix rouge)
Onglet Actions, clique sur la compilation en rouge, puis sur l'étape en rouge : fais une capture de la fin du texte et envoie-la-moi.
