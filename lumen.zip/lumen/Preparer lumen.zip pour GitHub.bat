@echo off
chcp 65001 >nul
setlocal
title Lumen - Preparer lumen.zip pour GitHub
cd /d "%~dp0"
if not exist "%~dp0package.json" (
  echo.
  echo  Place ce fichier a la racine de Lumen, a cote de package.json, puis relance.
  echo.
  pause
  exit /b 1
)
set "OUT=%~dp0..\lumen.zip"
set "TMPD=%TEMP%\lumen-zip-%RANDOM%"
if exist "%OUT%" del "%OUT%"
echo.
echo  Copie des sources (sans node_modules, dist ni sauvegardes)...
robocopy "%~dp0." "%TMPD%\lumen" /E /NFL /NDL /NJH /NJS /NP /XD node_modules dist dist.previous .lumen-backups release build .gradle "Lumen-v*" /XF *.bat >nul
if errorlevel 8 (
  echo.
  echo  La copie des sources a echoue.
  rmdir /s /q "%TMPD%" 2>nul
  pause
  exit /b 1
)
echo  Creation de lumen.zip...
tar -a -c -f "%OUT%" -C "%TMPD%" lumen
set "ERR=%errorlevel%"
rmdir /s /q "%TMPD%" 2>nul
if not "%ERR%"=="0" (
  echo.
  echo  La creation de lumen.zip a echoue.
  pause
  exit /b 1
)
echo.
echo  lumen.zip est pret, a cote du dossier Lumen :
echo  %OUT%
echo.
echo  Sur GitHub : Add file, Upload files, glisse lumen.zip, Commit changes.
echo  Apres la coche verte, la TV proposera la mise a jour.
echo.
explorer /select,"%OUT%"
pause
