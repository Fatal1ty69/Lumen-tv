# Lumen, lecteur IPTV façon Netflix pour PC

Electron + React. Lit les serveurs Xtream Codes (direct, films, séries, guide des programmes) et enrichit les fiches avec TMDB.

## Lancer l'appli sans rien installer

1. Dézippe `Lumen-0.1.0-win.zip` où tu veux.
2. Lance `Lumen.exe`. Windows SmartScreen peut afficher un avertissement (appli non signée) : « Informations complémentaires » puis « Exécuter quand même ».
3. Saisis l'adresse de ton serveur, ton identifiant et ton mot de passe Xtream. La clé TMDB est facultative mais recommandée.

## Lancer depuis le code source (si Windows bloque Lumen.exe)

1. Installe Node.js version LTS depuis https://nodejs.org
2. Dézippe le code source, ouvre le dossier `lumen` et double-clique sur `Lancer Lumen.bat`.
3. Le tout premier lancement installe les composants (Electron) une seule fois, dans `%LOCALAPPDATA%\Lumen\runtime`. Ensuite Lumen s'ouvre en quelques secondes, même après une mise à jour : remplacer le dossier `lumen` ne les efface plus, et l'interface est livrée déjà construite (dossier `dist`).
4. Les composants ne sont réinstallés que si une nouvelle version de Lumen en a besoin.

## Travailler sur le code

Prérequis : Node.js 20 ou plus récent (https://nodejs.org).

```
npm install
npm run dev      # appli en mode développement, rechargement à chaud
npm run start    # appli compilée, comme en production
npm run dist     # fabrique l'installateur Windows dans release/
```

## Clé TMDB (gratuite)

Crée un compte sur https://www.themoviedb.org, puis Paramètres, API, demande une clé « Developer ». Colle la clé API v3 ou le jeton de lecture v4 dans Réglages, TMDB. Elle apporte :
- les grands visuels et les logos de titres du bandeau et des fiches
- le casting avec photos, les bandes-annonces, les images d'épisodes
- les tendances de la semaine et le Top 10
- les pages Plateformes (Netflix, Prime Video, Disney+, Canal+, Apple TV+, Max, Paramount+) croisées avec ton catalogue

## Raccourcis du lecteur

| Touche | Action |
|---|---|
| Espace ou K | Lecture / pause |
| Flèches gauche / droite | Reculer / avancer de 10 s (1 min en replay) |
| Flèches haut / bas | Volume (films et séries), chaîne précédente / suivante (direct) |
| F ou double-clic | Plein écran |
| M | Couper le son |
| N | Épisode suivant |
| S | Passer l'intro |
| Entrée | Enchaîner quand l'anneau de l'épisode suivant s'affiche |
| Échap | Retour |

## Organisation du code

```
electron/main.cjs     fenêtre, en-têtes réseau (CORS, User-Agent IPTV), lecteur externe
electron/preload.cjs  pont sécurisé vers l'interface
src/lib/xtream.js     API Xtream Codes
src/lib/catalog.js    chargement, cache (12 h) et indexation du catalogue
src/lib/tmdb.js       API TMDB
src/lib/details.js    fusion des fiches serveur + TMDB
src/lib/player.js     moteurs de lecture (mpegts.js, hls.js, natif)
src/screens/          Accueil, Plateformes, Fiche, Films/Séries, Direct, Recherche, Ma liste, Réglages, Lecteur
src/styles.css        thème (couleur d'accent dans --accent)
```

## Nouveautés de la v0.3

- **Direct** : trois vues (Liste, Guide en grille horaire, Guide en images). Les doublons SD, HD, FHD et 4K d'une chaîne sont réunis en une seule, avec un sélecteur de qualité. Un deuxième clic sur une chaîne lance le plein écran.
- **Replay** : sur les chaînes qui gardent les archives, un programme passé se revoit d'un clic dans le guide. « Depuis le début » relance le programme en cours, et une pause du direct reprend en différé. Le bouton « Direct » ramène au direct.
- **La cloche** : sur un programme à venir, « Me prévenir » ou « Zapper tout seul à l'heure ». Les rappels sont dans la cloche de l'en-tête.
- **Lecteur** : anneau de l'épisode suivant, carton de fin de saison avec tes statistiques et la date de la suite, entracte quand la lecture est en pause, bouton « Passer l'intro » qui apprend la durée de l'intro de chaque série.
- **Audio et sous-titres** : choix de la piste audio quand le fichier en contient plusieurs, sous-titres depuis un fichier .srt/.vtt ou depuis OpenSubtitles (clé gratuite dans les Réglages), avec décalage et taille.
- **Agenda** : prochains épisodes de tes séries (Ma liste et séries commencées), vue liste ou calendrier mural, épisodes à rattraper, rappel le jour de la sortie.

## Nouveautés de la v0.4

- **Continuer à regarder** : une croix au survol d'une carte la retire (la série entière pour une série). « Tout retirer » dans Ma liste. Un titre retiré revient si tu le relances.
- **Épisodes vus** : une coche par épisode, une option pour toute la saison, et la proposition de cocher aussi les épisodes précédents. Un épisode lu jusqu'au générique est coché tout seul.
- **Épisode suivant** : après un épisode vu, la suite apparaît dans « Continuer à regarder » (badge « À SUIVRE ») et sur le bouton principal de la fiche.
- **Historique de recherche** : les 15 dernières recherches, proposées quand tu cliques dans la recherche, avec suppression une par une ou en bloc.
- **Découvrir** : recommandations selon ce que tu as regardé, tendances, cinéma, séries de la semaine, populaires, mieux notés, grandes sagas et genres, avec le badge « CHEZ TOI » et le filtre « Seulement chez moi ».

## Nouveautés de la v0.5

- **Groupes affichés** (Réglages) : pour le Direct, les Films et les Séries, une case par groupe du serveur, un filtre (par exemple « AR | ») et les boutons « Tout afficher », « Tout masquer », « Masquer ces… ». Un groupe masqué disparaît partout dans Lumen. Le réglage est propre à chaque serveur et inclus dans la sauvegarde. Raccourci « Gérer les groupes » en haut des listes du Direct, des Films et des Séries.

## Nouveautés de la v0.6

- **Moteur mpv** (Réglages › Lecture) : lit tous les formats (MKV, HEVC, AC3, DTS, sous-titres intégrés, toutes les pistes audio). En mode « Automatique », mpv prend le relais dès qu'un fichier ne passe pas dans le lecteur intégré. mpv s'ouvre en plein écran et Lumen devient la télécommande : progression sauvée, épisode suivant (touche N), pistes audio et sous-titres, son, zapping. Bouton « Installer mpv automatiquement » ou « Choisir mpv.exe ».
- **Égaliseur** : Normal, Dialogues, Nuit, Basses, dans le menu Audio et sous-titres du lecteur et dans les Réglages.
- **Mosaïque** (Direct) : grille d'aperçus rafraîchis chaîne après chaîne avec une seule connexion, direct au survol, et en option 1 à 3 chaînes en direct permanent selon ton abonnement.
- **Trakt** (Réglages) : connexion par code, historique importé (les épisodes vus sur Trakt sont cochés dans Lumen), ce que tu coches est envoyé à Trakt, et scrobble en direct.
- **Serveurs fusionnés** (Réglages › Serveurs, à partir de deux serveurs) : un seul catalogue, les doublons réunis, et bascule automatique sur un autre serveur si un film, un épisode ou une chaîne ne passe pas.
- **Vues de catalogue** (Films, Séries) : Grille, Mur d'affiches, Chronologie, Vidéoclub, Liste.
- **Thèmes** : Nuit, Noir OLED, Ardoise, Velours, Forêt, Aube, grain de pellicule animé, intro animée du logo.
- **Continuer à regarder** : la suite d'une série est retrouvée sur le serveur même pour les anciennes séries, et un épisode ajouté depuis ton dernier visionnage est signalé « NOUVEL ÉPISODE ».

## Limites connues de cette version

- Le lecteur intégré repose sur Chromium : MP4/H.264/AAC et les flux TS/HLS passent. Pour le reste (MKV, HEVC, AC3, DTS), installe mpv depuis les Réglages : il prend le relais tout seul.
- Les serveurs IPTV ne fournissent pas les repères d'intro et de générique : Lumen les apprend série par série quand tu utilises « Passer l'intro » et « Épisode suivant ».
- Les pistes audio multiples ne se choisissent que sur les films et séries (pas sur le direct).
- Avec mpv, la vidéo s'affiche dans la fenêtre de mpv (plein écran) et non dans celle de Lumen.
- Pas encore de multi-vue ni d'enregistrement.

## Nouveautés de la v0.7

- Onglet « Mes séries » : toutes les séries que tu suis (regardées dans Lumen, ajoutées à Ma liste ou vues sur Trakt), avec leur progression, le nombre d'épisodes vus et le bouton qui lance directement le bon épisode.
- Statuts : Nouvel épisode, En cours, À jour, Pas commencée, Terminée, Pas sur ton serveur.
- Filtres par statut, tri (dernier visionnage, progression, statut, A à Z) et statistiques (séries suivies, épisodes vus, heures).
- « Ne plus suivre » retire une série de la liste ; elle revient si tu la regardes à nouveau, et le lien « Les remettre » annule tout.

### v0.7.1
- Mes séries : les séries suivies sur Trakt sont maintenant reliées à celles de ton serveur même quand les titres diffèrent (titre anglais sur Trakt, titre français sur le serveur), grâce à l'identifiant TMDB.
- Bouton « Synchroniser Trakt » directement dans Mes séries.

### v0.7.2
- Import de l'historique Trakt : les épisodes vus et les lectures en pause (films et épisodes) sont repris dans Lumen à chaque synchro. « Continuer à regarder » propose le bon épisode, à la bonne minute.
- Un visionnage local plus récent n'est jamais écrasé par Trakt, et une série retirée de « Continuer à regarder » reste retirée.

### v0.7.3
- Compatible avec la nouvelle API Trakt (juillet 2026) : l'historique est lu page par page (plus de limite à 100 séries et 100 films) et les épisodes vus sont bien récupérés.

## Nouveautés de la v0.8
- Ma liste : filtres Tout / Films / Séries, tri (ajout récent, A à Z, année, note) et les cinq vues du catalogue (grille, mur d'affiches, chronologie, vidéoclub, liste).
- Notes sur les fiches : TMDB, et avec une clé OMDb gratuite (Réglages), IMDb, Rotten Tomatoes et Metacritic.
- Mes séries s'ouvre sur « En cours » (séries avec un nouvel épisode comprises).
- Agenda repensé : prochaine sortie en grand avec compte à rebours, vue Semaine sur deux semaines, badges nouvelle saison / final, épisodes arrivés sur ton serveur, épisodes sortis ces derniers jours avec leur disponibilité, séries à rattraper, statut des séries sans date, filtre « Sur mon serveur » et export vers ton calendrier (.ics). Il couvre toutes les séries de Mes séries, Trakt compris.

## Nouveautés de la v0.9 : Lumen TV (Android TV, Nvidia Shield)
- Le même Lumen sur la TV, à la télécommande : flèches pour se déplacer, OK pour ouvrir, Retour pour revenir.
- Lecture dans le lecteur natif d'Android (ExoPlayer) : MKV, HEVC, 4K, AC3, pistes audio et sous-titres. OK pause, gauche -10 s, droite +30 s, bas pour les commandes. En direct, haut et bas changent de chaîne.
- Épisodes enchaînés automatiquement, « Épisode suivant » proposé pendant le générique, progression gardée.
- Configuration sans taper à la télécommande : depuis le téléphone (QR code affiché sur la TV) ou depuis Lumen PC (Réglages, « Envoyer vers ma TV », qui recopie tout : serveurs, clés, Trakt, Ma liste, progression).
- Compilation de l'APK par GitHub : voir GUIDE-ANDROID-TV.md.

## Nouveautés de la v0.10 : Lumen TV, lot B
- Direct plus rapide : tampon de démarrage court, format du flux (.ts ou .m3u8) mémorisé par serveur, chaînes envoyées une seule fois au lecteur, plus d'aperçu dans l'écran Direct (un seul OK lance la chaîne).
- Dans le lecteur en direct : OK ouvre la liste des chaînes avec logos et programme en cours, gauche/droite changent de groupe (Favoris en premier), haut/bas zappent, gauche revient à la chaîne précédente, droite affiche le bandeau du programme (en cours, progression, ensuite). Option pour démarrer Lumen sur la dernière chaîne.
- Menu du lecteur (appui long sur OK ou touche Menu) : pistes audio, sous-titres, sous-titres OpenSubtitles, format d'image (ajustée, zoom, étirée). Langues mémorisées par série.
- « Passer l'intro » avec OK, appris par série et automatique si l'option est activée.
- Recherche : clavier à l'écran et recherche vocale (bouton « Parler »).
- Mise à jour automatique : Lumen TV propose les nouvelles versions publiées sur GitHub et les installe.

## Nouveautés de la v0.11 : Lumen TV, ergonomie
- Direct (écran) : vues Liste et Guide seulement, plus de bouton de gestion des groupes ni de champ de recherche (les groupes se gèrent dans les Réglages). Au retour du lecteur, la chaîne regardée est sélectionnée.
- Lecteur en direct : haut chaîne suivante, bas chaîne précédente, gauche liste des chaînes du groupe, droite chaîne précédemment regardée, OK menu (programme en cours, liste, pistes, image). Zapping rapide : le bandeau suit tout de suite, le flux se charge quand on s'arrête. Dans la liste : programme en cours et suivant, appui long sur OK pour les favoris.
- Retour : ferme la fenêtre ouverte, remonte en haut de page, revient à l'accueil, puis demande « Quitter Lumen ? ».
- Mémoire du focus en revenant d'une fiche, rangées alignées en montant ou descendant.
- Appui long sur OK : menu rapide (fiche, Ma liste, marquer comme vu, favoris, retirer de « Continuer à regarder »).
- Fiche : focus direct sur Lecture, gauche/droite changent de saison, appui long sur un épisode pour le marquer comme vu.
- Accueil : rangée « Chaînes récentes ».
- Écran d'accueil de la Shield : rangée « Continuer à regarder » alimentée par Lumen, qui s'ouvre au bon épisode.
- Réglages TV allégés.

## Nouveautés de la v0.12 : Lumen TV épurée
- Moins de boutons sur la TV : plus de son ni de bande-annonce dans le bandeau d'accueil, plus de points du carrousel, plus de « Seulement chez moi » (automatique), plus de bouton fermer ni « + » sur les fiches, plus de pastilles de saison, plus de boutons qualité, favori et plein écran dans le Direct, horloge non sélectionnable.
- Un seul bouton « Options » par écran pour les tris, filtres et affichages (Films, Séries, Ma liste, Mes séries, Agenda).
- Appui long sur OK pour les options : Lecture d'une fiche (Ma liste, marquer comme vu, saison vue, bande-annonce), cartes de Mes séries, épisodes de l'Agenda (rappel).
- Replay : appui long sur une chaîne, « Revoir un programme » (liste par jour, gauche/droite pour changer de jour). Dans le lecteur du direct, le menu OK propose « Reprendre depuis le début » et « Programmes passés ».

## Nouveautés de la v0.13
- Navigation TV : haut/bas restent dans la même colonne (liste des chaînes, groupes, catégories), gauche/droite passent des groupes au contenu et inversement (gauche arrive sur le groupe sélectionné), haut depuis le début d'une liste remonte au menu.
- Direct : bascule Liste/Guide en bas de la colonne des groupes (plus de clic en trop vers le menu). Qualité d'une chaîne dans l'appui long. Par défaut, la 4K est exclue (« La meilleure (sans 4K) » ; « 4K comprise » dans les Réglages).
- Films et Séries : « Options » en haut de la colonne des catégories. Ma liste et Agenda : « Options » en bas de page.
- Plateformes : logos officiels sur les boutons et les tuiles de l'accueil.
- Découvrir (TV) : Tendances du jour films et séries, Films populaires, Séries populaires, Grandes sagas, puis « Explorer par genre » en bas.
- Trakt : les séries abandonnées ou masquées sur Trakt sortent de Mes séries et de l'Agenda ; l'Agenda ne garde que les séries de Ma liste ou regardées dans l'année.

## Nouveautés de la v0.14 (TV)
- Accueil : images dans « Continuer à regarder » (serveur, sinon TMDB, sinon affiche), rangée « En direct maintenant » avec l'image du programme en cours, rangées « Films tendance du moment » et « Séries tendance du moment ». Plus de Décennies ni de Groupes films.
- En remontant vers le menu, le curseur arrive sur l'onglet de l'écran en cours.
- La fenêtre Options de Films et Séries s'affiche bien au premier plan.

## Nouveautés de la v0.15 (TV)
- Miniature du direct dans l'écran Direct (vue Liste) : 1er OK, la chaîne démarre en petit ; 2e OK, plein écran sans relancer le flux (même lecteur, même connexion). Retour : la miniature reprend la chaîne regardée, même si tu as zappé entre-temps. La miniature se masque quand une fenêtre s'ouvre et s'arrête en quittant le Direct ou l'appli.

### v0.15.1
- Lecteur TV : plus de cercle de chargement figé en passant de la miniature au plein écran, bandeaux affichés 3 secondes.
- Accueil TV : « En direct maintenant » suit l'ordre du premier groupe et ignore les fausses chaînes servant de titres de rubrique.
- Réglages TV : le curseur arrive sur le premier réglage ; « Mettre à jour Lumen » installe en un seul clic et reprend tout seul après l'autorisation d'Android.

### v0.15.2
- Accueil TV : la première entrée du premier groupe (souvent un titre de rubrique) est écartée ; images des programmes trouvées plus souvent (titres proches acceptés).

## Nouveautés de la v0.16
- Profils : Alex et Jess (« Qui regarde ? » à l'ouverture). Chacun a sa progression, Continuer à regarder, Ma liste, Mes séries, ses chaînes favorites, ses langues, ses rappels et son compte Trakt. Le serveur, les clés et les groupes affichés sont communs. Réglages, carte « Profils » : renommer, couleur, ajouter, supprimer. Tes données existantes sont rangées dans le profil Alex.
- Synchronisation maison PC ↔ TV : le PC se synchronise avec la TV à son ouverture (avant l'accueil), après chaque lecture et toutes les 90 secondes. La TV fait référence, le changement le plus récent gagne, élément par élément pour la progression et Ma liste. Association une seule fois (Réglages, carte « Synchronisation », adresse et code de la TV) ; si l'adresse de la TV change, le PC la retrouve tout seul sur le réseau. Le PC n'ouvre aucun port : rien à autoriser dans le pare-feu.
- Rappels sur la TV : pendant la lecture, le lecteur affiche le rappel en haut à droite, « OK pour y aller » change de chaîne. Nouveaux épisodes des séries suivies signalés dès leur arrivée sur le serveur.
- Ton année : récap par profil dans les Réglages (heures, films, épisodes, séries préférées, mois le plus chargé, chaînes les plus regardées).

### v0.16.1
- Trakt : Trakt ne donne plus que des connexions de 24 h, et chaque renouvellement annule le précédent. Avec le PC et la TV synchronisés, l'un annulait la connexion de l'autre. Lumen ne renouvelle plus qu'en dernière heure, reprend la connexion renouvelée par l'autre appareil et réessaie tout seul avant de demander de se reconnecter.

### v0.16.2
- Trakt : les séries que ton serveur découpe autrement que Trakt (Lupin en « Partie 1, 2, 3 » au lieu de 2 saisons) sont reconnues. Lumen compare la découpe du serveur à celle de TMDB et, si elles diffèrent, fait correspondre les épisodes par leur rang dans la série, dans les deux sens (import depuis Trakt, et envoi vers Trakt de ce que tu regardes).

### v0.16.3
- Trakt et Lumen comptent un épisode comme vu au même moment : 90 % (avant, Trakt à 80 % et Lumen à 95 %, un épisode arrêté pendant le générique était vu sur Trakt mais pas dans Lumen). En dessous de 90 %, Lumen envoie une pause à Trakt, qui garde la minute.
- Synchro Trakt toutes les 20 minutes tant que Lumen est ouvert, et au retour sur l'appli après 10 minutes (avant : seulement au lancement).

### v0.16.4
- Fiche d'une série (PC) : bouton « Comparer avec Trakt ». Il montre la série Trakt reliée, la découpe du serveur et celle de Trakt, puis chaque épisode avec son numéro côté Trakt, vu ou non de chaque côté ; les écarts sont surlignés.
- Mes séries : une série vue sur Trakt est rattachée en priorité à la série du serveur que tu suis déjà (utile quand le serveur a plusieurs versions, MULTI et VF).
- « Reprendre » ne propose plus un épisode commencé dans Lumen s'il est déjà vu sur Trakt.

### v0.16.5
- Mes séries s'affiche tout de suite : le dernier état connu est gardé (pendant la session et d'un lancement à l'autre), les épisodes du serveur et TMDB sont revérifiés en arrière-plan sans bloquer l'affichage, et le calcul de la progression ne reparcourt plus tout l'historique pour chaque série.

### v0.16.6
- Réglages (PC) : carte « Portail Stalker (test) ». Avec l'adresse du portail et l'adresse MAC, Lumen vérifie la connexion, le boîtier, l'abonnement, les chaînes, le replay, le guide, les films, les séries et la lecture d'une chaîne et d'un film, puis donne un rapport à copier. Première étape avant l'ajout complet des portails Stalker.

### v0.16.7
- Test Stalker : si le portail signale un refus au profil, Lumen essaie une variante courte de la demande, note exactement ce que le portail répond, et poursuit le test (chaînes, lecture…) pour voir si l'accès fonctionne malgré tout.

### v0.16.8
- Test Stalker : Lumen essaie toutes les adresses d'API du portail (/portal.php, /server/load.php, /stalker_portal/…) avec trois façons de présenter le boîtier, garde la première combinaison qui accepte la MAC et note chaque essai dans le rapport.

### v0.16.9
- Test Stalker : Lumen suit la redirection de l'adresse du portail (comme les boîtiers MAG) et essaie l'API du vrai portail, essaie plusieurs modèles de boîtier (MAG250, MAG254, MAG322), et accepte en option les identifiants recopiés d'une autre appli (numéro de série, Device ID, signature). Rapport regroupé.

### v0.16.10
- Test Stalker : essaie aussi d'envoyer la MAC telle quelle (00:1A:…) ou encodée, en majuscules ou minuscules, avec des en-têtes de boîtier MAG ou d'appli Android (façon TiviMate). Réponses compressées décodées.

### v0.16.11
- Test Stalker : lecture essayée sur 3 chaînes (lien temporaire, commande nettoyée, puis lien direct de la chaîne), avec la réponse exacte du portail en cas d'échec ; guide essayé sur 3 chaînes puis en version globale ; si le serveur vidéo refuse, nouvel essai avec un en-tête de lecteur classique ; message d'erreur du serveur vidéo affiché.

### v0.16.12
- Playlists M3U (direct) : à la connexion ou dans Réglages, « J'ai plutôt un lien M3U » ajoute une liste de chaînes du direct à partir de son adresse. Les groupes (group-title), noms, logos et numéros sont repris. À fusionner avec un serveur Xtream pour les films et séries. Un lien get.php?...&type=m3u est reconnu comme un serveur Xtream et bascule vers la connexion complète. Fonctionne sur le PC et sur la Shield. Pas de guide des programmes ni de replay pour ces chaînes (une playlist M3U ne les fournit pas).

## Nouveautés de la v0.17

### Rôle par serveur
- Dans Réglages, carte « Serveurs », chaque serveur a un rôle : **Tout**, **Direct seulement**, **Films et séries**, ou **Désactivé**. Exemple : une playlist M3U pour le Direct et un serveur Xtream pour les Films et séries. « Désactivé » met un serveur de côté sans le retirer. La case « Fusionner » est remplacée par ces rôles.

### Guide XMLTV (pour les chaînes M3U)
- Les chaînes d'une playlist M3U reçoivent un guide des programmes depuis un fichier XMLTV. Lumen reprend l'adresse annoncée par la playlist (`url-tvg`) ou celle que tu saisis (à l'ajout, ou dans la carte Serveurs). Les chaînes sont reliées au guide par leur identifiant (`tvg-id`) puis, à défaut, par leur nom. Le guide et le « maintenant / ensuite » s'affichent sur PC et sur la Shield. Les fichiers `.xml` et `.xml.gz` sont acceptés (décompression sur PC).

### Séries numérotées en continu
- Les séries dont le serveur numérote les épisodes en continu (l'épisode 18 rangé dans la « Saison 3 » au lieu de recommencer à 1) sont maintenant comprises : la correspondance avec Trakt se fait par le rang réel de l'épisode dans la série, dans les deux sens. Corrige les séries de certains serveurs où le compte était faux (épisode vu reporté au mauvais endroit).

### v0.17.1
- Playlist M3U : Lumen essaie plusieurs identités de lecteur (VLC, TiviMate, okhttp, navigateur…) et suit les redirections, car certains serveurs refusent une requête qui ne ressemble pas à un lecteur connu. Les playlists compressées (gzip) sont décompressées. En cas d'échec, le message indique précisément ce que le serveur a répondu à chaque essai (code, redirection, début de la réponse).

### v0.17.2
- Playlist M3U : les champs d'adresse (serveur, playlist, guide) n'ont plus de saisie automatique ni de correction, qui pouvaient remplacer un caractère du jeton par une valeur essayée avant. Sous le champ M3U, Lumen affiche l'URL exacte qu'il utilisera, pour vérifier le dernier caractère d'un coup d'œil. Les caractères invisibles collés par erreur sont retirés.

### v0.17.3
- Playlist M3U et guide XMLTV : récupérés d'abord par une requête minimale (comme TiviMate), sans l'empreinte de navigateur que certains serveurs refusent par un 404. C'était la cause du « Lien introuvable » alors que l'adresse était bonne : le serveur bloquait la requête de type navigateur, pas l'adresse. Le navigateur reste un secours. En cas d'échec, le message détaille chaque essai. Fonctionne sur PC (requête directe) et sur la Shield (accès natif).

### v0.17.4
- Playlist M3U et guide XMLTV : les requêtes imitent maintenant exactement de vrais lecteurs (okhttp, ExoPlayer, VLC) avec les mêmes en-têtes (gzip, connexion persistante), car certaines protections 404 une requête qui n'a pas l'air d'un lecteur. Lumen n'envoie plus de requête sans User-Agent (qui déclenchait un 429). Champ « User-Agent » ajouté à la source M3U (comme dans TiviMate), à remplir si le fournisseur en impose un. Message d'erreur plus clair, avec le conseil d'essayer sur la Shield quand le PC est bloqué.

### v0.17.5
- Playlist M3U sur la Shield : la TV récupère la playlist en se présentant comme okhttp/ExoPlayer (comme TiviMate), au lieu de VLC seulement. C'est ce qui permet de passer les protections qui refusent VLC. La requête native d'Android gère gzip et redirections. Le champ User-Agent de la source est pris en compte sur la TV aussi.

## Nouveautés de la v0.18
- Playlist M3U derrière une protection : sur la Shield, Lumen récupère la playlist (et le guide) avec OkHttp, exactement la même bibliothèque réseau que TiviMate. Certaines protections ne regardent pas le User-Agent mais la signature réseau de la connexion, et n'acceptent que celle d'OkHttp. C'est ce qui permet à Lumen de lire une playlist qui marche dans TiviMate mais était refusée (404) jusqu'ici. OkHttp gère gzip et redirections.

### v0.18.1
- Ajouter une source depuis le téléphone : la page web servie par la TV (QR code, Réglages « Ajouter une source depuis ton téléphone ») propose maintenant « Playlist M3U » en plus d'Xtream. Tu colles l'URL M3U (et au besoin le guide XMLTV et le User-Agent) depuis le clavier du téléphone, au lieu de tout taper à la télécommande. La playlist s'ajoute à côté de tes serveurs, sans changer le principal.

### v0.18.2
- Ajout d'une playlist M3U sur le PC : si le PC n'arrive pas à lire la playlist (serveur qui le bloque), un bouton « Ajouter quand même (pour l'envoyer à la TV) » permet de l'enregistrer sans vérification, puis de l'envoyer à la Shield avec « Envoyer vers ma TV ». Une playlist illisible sur le PC n'empêche plus le reste du catalogue (films, séries) de se charger.
