@echo off
chcp 65001 >nul
setlocal EnableExtensions
title Lumen - Reconstruction
cd /d "%~dp0"

set "NO_LAUNCH="
if /i "%~1"=="--no-launch" set "NO_LAUNCH=1"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js n'est pas installe sur ce PC.
  echo  Installe la version LTS depuis la page qui va s'ouvrir, puis relance.
  echo.
  start "" https://nodejs.org/fr/download
  pause
  exit /b 1
)
if not exist "%~dp0package.json" (
  echo.
  echo  Fichier package.json introuvable a la racine de Lumen.
  echo.
  pause
  exit /b 1
)

echo.
echo  Mise a jour de Lumen
echo  1/2 - Verification des dependances du projet...
echo.
call npm install --no-audit --no-fund --loglevel=error
if errorlevel 1 (
  echo.
  echo  L'installation des dependances a echoue.
  echo  L'ancienne version construite n'a pas ete modifiee.
  echo.
  pause
  exit /b 1
)

echo.
echo  2/2 - Reconstruction propre de l'interface...
echo.
if exist "%~dp0dist.previous" rmdir /s /q "%~dp0dist.previous"
if exist "%~dp0dist" (
  move "%~dp0dist" "%~dp0dist.previous" >nul
  if errorlevel 1 (
    echo.
    echo  Impossible de sauvegarder le dossier dist.
    echo  Ferme completement Lumen puis relance cette mise a jour.
    echo.
    pause
    exit /b 1
  )
)

call npm run build --silent
set "ERR=%errorlevel%"
if not "%ERR%"=="0" goto restore
if not exist "%~dp0dist\index.html" goto restore

if exist "%~dp0dist.previous" rmdir /s /q "%~dp0dist.previous"
echo.
echo  Reconstruction terminee avec succes.
echo  Les sources actuelles sont maintenant dans dist.
echo.
if defined NO_LAUNCH exit /b 0
call "%~dp0Lancer Lumen.bat"
exit /b %errorlevel%

:restore
echo.
echo  La reconstruction a echoue. Restauration de l'ancienne version...
if exist "%~dp0dist" rmdir /s /q "%~dp0dist"
if exist "%~dp0dist.previous" move "%~dp0dist.previous" "%~dp0dist" >nul
echo  L'ancien dist a ete conserve. Corrige l'erreur affichee puis recommence.
echo.
pause
exit /b 1
