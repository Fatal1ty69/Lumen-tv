import React, { useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { Xtream, normalizeServer } from '../lib/xtream.js';
import { M3uClient, xtreamFromM3u, normalizeM3u } from '../lib/m3u.js';
import { Tmdb } from '../lib/tmdb.js';
import { Spinner } from '../components/ui.jsx';
import { isTV } from '../tv/native.js';
import TvReceive from '../tv/TvReceive.jsx';

export function AccountForm({ initial = {}, onDone, submitLabel = 'Se connecter' }) {
  const { settings, updateSettings } = useApp();
  const [mode, setMode] = useState(initial.kind === 'm3u' ? 'm3u' : 'xtream');
  const [f, setF] = useState({ name: '', server: '', username: '', password: '', ...initial });
  const [tmdbKey, setTmdbKey] = useState(settings.tmdbKey || '');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));

  // Ajout d'une playlist M3U (direct uniquement)
  const submitM3u = async (e) => {
    e.preventDefault();
    setErr('');
    const url = normalizeM3u(f.server);
    if (!url) { setErr('Colle l\'adresse de ta playlist M3U.'); return; }
    const xtream = xtreamFromM3u(url);
    if (xtream) {
      setMode('xtream');
      setF((s) => ({ ...s, ...xtream }));
      setErr('Ce lien est en fait un serveur Xtream : j\'ai rempli les champs, clique sur « Se connecter » pour avoir aussi les films, les séries et le guide.');
      return;
    }
    setBusy(true);
    try {
      const acc = { kind: 'm3u', server: url, name: f.name.trim() || 'Playlist M3U', epgUrl: (f.epgUrl || '').trim(), ua: (f.ua || '').trim() };
      const res = await new M3uClient(acc).auth();
      // Guide XMLTV : celui saisi, sinon celui annoncé par la playlist
      if (!acc.epgUrl && res.tvgUrl) acc.epgUrl = res.tvgUrl;
      onDone(acc);
    } catch (e2) {
      setErr(e2.message || String(e2));
    } finally {
      setBusy(false);
    }
  };

  if (mode === 'm3u') {
    return (
      <form onSubmit={submitM3u} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <label className="lbl">Nom de la source
          <input value={f.name} onChange={set('name')} placeholder="Mes chaînes" />
        </label>
        <label className="lbl">Adresse de la playlist M3U
          <input value={f.server} onChange={set('server')} placeholder="https://exemple.com/m3u/…" autoFocus autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <small>La liste des chaînes du direct. Les films et séries passent par un serveur Xtream.</small>
          {f.server.trim() && <code style={{ display: 'block', marginTop: 6, fontSize: 12, wordBreak: 'break-all', opacity: 0.85 }}>Lumen utilisera : {normalizeM3u(f.server)}</code>}
        </label>
        <label className="lbl">Adresse du guide XMLTV (optionnelle)
          <input value={f.epgUrl || ''} onChange={set('epgUrl')} placeholder="https://exemple.com/epg.xml" autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <small>Pour les programmes du direct. Si la playlist l'indique déjà, Lumen la reprend tout seul.</small>
        </label>
        <label className="lbl">User-Agent (optionnel)
          <input value={f.ua || ''} onChange={set('ua')} placeholder="Laisse vide sauf si ton fournisseur en impose un" autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <small>Comme le champ User-Agent de TiviMate. À remplir seulement si le serveur refuse la playlist.</small>
        </label>
        {err && <p className={/Xtream/.test(err) ? 'ok' : 'err'}>{err}</p>}
        <button className="btn btn-primary" type="submit" disabled={busy} style={{ justifyContent: 'center', marginTop: 6 }}>
          {busy ? <><Spinner /> Lecture de la playlist…</> : (submitLabel === 'Se connecter' ? 'Ajouter la playlist' : submitLabel)}
        </button>
        <button type="button" className="btn btn-ghost btn-sm" style={{ alignSelf: 'center' }} onClick={() => { setMode('xtream'); setErr(''); }}>Plutôt un serveur Xtream</button>
      </form>
    );
  }

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    // Lien M3U ou API collé en entier : on en extrait identifiant et mot de passe
    let fx = { ...f, server: f.server.trim() };
    const m = fx.server.match(/[?&]username=([^&]+)/i);
    const pw = fx.server.match(/[?&]password=([^&]+)/i);
    if (m && !fx.username) fx.username = decodeURIComponent(m[1]);
    if (pw && !fx.password) fx.password = decodeURIComponent(pw[1]);
    if (fx.username !== f.username || fx.password !== f.password) setF(fx);
    const f2 = fx;
    if (!f2.server || !f2.username || !f2.password) { setErr('Renseigne l\'adresse du serveur, l\'identifiant et le mot de passe.'); return; }
    setBusy(true);
    try {
      const acc = { ...f2, username: f2.username.trim(), password: f2.password.trim(), server: normalizeServer(f2.server), name: f2.name.trim() || 'Serveur principal' };
      const info = await new Xtream(acc).auth();
      if (tmdbKey && tmdbKey !== settings.tmdbKey) {
        try { await new Tmdb(tmdbKey).test(); updateSettings({ tmdbKey }); }
        catch { setErr('Connexion au serveur réussie, mais la clé TMDB est refusée. Tu pourras la corriger dans les Réglages.'); }
      }
      const exp = Number(info.user_info.exp_date);
      onDone({ ...acc, expires: exp ? exp * 1000 : null, maxConn: Number(info.user_info.max_connections) || null });
    } catch (e2) {
      setErr(e2.message || String(e2));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <label className="lbl">Nom du profil
        <input value={f.name} onChange={set('name')} placeholder="Serveur principal" />
      </label>
      <label className="lbl">Adresse du serveur
        <input value={f.server} onChange={set('server')} placeholder="http://exemple.com:8080" autoFocus autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
        <small>Avec le port s'il y en a un (le nombre après les deux-points). Tu peux aussi coller ton lien M3U complet.</small>
      </label>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <label className="lbl">Identifiant
          <input value={f.username} onChange={set('username')} autoComplete="username" />
        </label>
        <label className="lbl">Mot de passe
          <input type="password" value={f.password} onChange={set('password')} autoComplete="current-password" />
        </label>
      </div>
      <label className="lbl">Clé API TMDB (optionnelle)
        <input value={tmdbKey} onChange={(e) => setTmdbKey(e.target.value)} placeholder="Clé v3 ou jeton de lecture v4" />
        <small>Elle apporte les grands visuels, les logos de titres, les bandes-annonces et les plateformes. Gratuite sur themoviedb.org, rubrique Paramètres puis API.</small>
      </label>
      {err && <p className="err">{err}</p>}
      <button className="btn btn-primary" type="submit" disabled={busy} style={{ justifyContent: 'center', marginTop: 6 }}>
        {busy ? <><Spinner /> Connexion…</> : submitLabel}
      </button>
      <button type="button" className="btn btn-ghost btn-sm" style={{ alignSelf: 'center' }} onClick={() => { setMode('m3u'); setErr(''); }}>J'ai plutôt un lien M3U (direct seulement)</button>
    </form>
  );
}

export default function Login() {
  const { addAccount } = useApp();
  const [manual, setManual] = useState(false);
  if (isTV && !manual) {
    return (
      <div className="login tv-login">
        <div className="login-bg" />
        <div className="login-card" style={{ width: 'min(1100px, 92vw)' }}>
          <div className="logo" style={{ fontSize: 64 }}>LUMEN</div>
          <p className="muted" style={{ fontSize: 20, lineHeight: 1.5 }}>Bienvenue ! Le plus simple pour configurer la TV, c'est d'envoyer tes réglages depuis ton téléphone ou ton PC : pas besoin de taper tes identifiants à la télécommande.</p>
          <TvReceive />
          <button className="btn btn-ghost" style={{ alignSelf: 'flex-start' }} onClick={() => setManual(true)}>Saisir mon serveur à la télécommande</button>
        </div>
      </div>
    );
  }
  return (
    <div className="login">
      <div className="login-bg" />
      <div className="login-card">
        <div className="logo" style={{ fontSize: 52 }}>LUMEN</div>
        <p className="muted" style={{ fontSize: 16, lineHeight: 1.5 }}>Ajoute ton serveur Xtream Codes pour commencer. Tes identifiants restent sur {isTV ? 'cette TV' : 'ce PC'}.</p>
        <AccountForm onDone={addAccount} />
      </div>
    </div>
  );
}

Login.SwitchButton = function SwitchButton() {
  const { account, removeAccount } = useApp();
  return <button className="btn btn-ghost" onClick={() => account && removeAccount(account.id)}>Changer de serveur</button>;
};
