import React, { useEffect, useState } from 'react';
import { saveJSON, getProfiles, saveProfiles } from '../lib/store.js';
import { useApp } from '../lib/app.jsx';
import { Xtream, normalizeServer } from '../lib/xtream.js';
import { M3uClient, xtreamFromM3u, normalizeM3u } from '../lib/m3u.js';
import { MODELS, normalizeMac, normalizeStalkerPortal } from '../lib/stalker.js';
import { Tmdb } from '../lib/tmdb.js';
import { Spinner } from '../components/ui.jsx';
import { isTV } from '../tv/native.js';
import TvReceive from '../tv/TvReceive.jsx';

export function AccountForm({ initial = {}, onDone, submitLabel = 'Se connecter', editing = false, lockKind = editing }) {
  const { settings, updateSettings } = useApp();
  const [mode, setMode] = useState(initial.kind === 'm3u' ? 'm3u' : initial.kind === 'stalker' ? 'stalker' : 'xtream');
  const [f, setF] = useState({ name: '', server: '', username: '', password: '', mac: '', model: 'MAG254', sn: '', device: '', device2: '', sig: '', ...initial });
  const [tmdbKey, setTmdbKey] = useState(settings.tmdbKey || '');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [force, setForce] = useState(false);
  const [showAdv, setShowAdv] = useState(() => !!(initial.sn || initial.device || initial.device2 || initial.sig));
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));
  const chooseMode = (next) => { setMode(next); setErr(''); setForce(false); };
  // Toujours visible en tête : auparavant Stalker n'était proposé que par un
  // petit bouton placé sous tout le formulaire Xtream, donc souvent hors écran.
  const sourcePicker = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <span className="muted" style={{ fontSize: 13 }}>Type de source</span>
      <div className="seg" role="tablist" aria-label="Type de source" style={{ alignSelf: 'stretch', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)' }}>
        <button type="button" role="tab" aria-selected={mode === 'xtream'} className={mode === 'xtream' ? 'on' : ''} disabled={lockKind} onClick={() => chooseMode('xtream')}>Xtream</button>
        <button type="button" role="tab" aria-selected={mode === 'm3u'} className={mode === 'm3u' ? 'on' : ''} disabled={lockKind} onClick={() => chooseMode('m3u')}>M3U</button>
        <button type="button" role="tab" aria-selected={mode === 'stalker'} className={mode === 'stalker' ? 'on' : ''} disabled={lockKind} onClick={() => chooseMode('stalker')}>Stalker / MAG</button>
      </div>
    </div>
  );

  // Ajout d'une playlist M3U (direct uniquement)
  const submitM3u = async (e) => {
    e.preventDefault();
    setErr('');
    const url = normalizeM3u(f.server);
    if (!url) { setErr('Colle l\'adresse de ta playlist M3U.'); return; }
    const xtream = xtreamFromM3u(url);
    if (xtream) {
      setMode('xtream');
      setF((s) => ({ ...s, ...xtream }));
      setErr('Ce lien est en fait un serveur Xtream : j\'ai rempli les champs, clique sur « Se connecter » pour avoir aussi les films, les séries et le guide.');
      return;
    }
    setBusy(true);
    setForce(false);
    try {
      const acc = { ...initial, ...f, id: initial.id, kind: 'm3u', server: url, name: f.name.trim() || 'Playlist M3U', epgUrl: (f.epgUrl || '').trim(), ua: (f.ua || '').trim() };
      if (editing) { onDone(acc); return; }
      const res = await new M3uClient(acc).auth();
      // Guide XMLTV : celui saisi, sinon celui annoncé par la playlist
      if (!acc.epgUrl && res.tvgUrl) acc.epgUrl = res.tvgUrl;
      onDone(acc);
    } catch (e2) {
      setErr(e2.message || String(e2));
      setForce(true); // le PC n'a pas pu lire la playlist : proposer de l'ajouter quand même pour l'envoyer à la TV
    } finally {
      setBusy(false);
    }
  };

  // Ajout sans vérification (ex. playlist bloquée sur le PC mais lisible sur la Shield)
  const addAnyway = () => {
    const url = normalizeM3u(f.server);
    if (!url) return;
    onDone({ ...initial, ...f, id: initial.id, kind: 'm3u', server: url, name: f.name.trim() || 'Playlist M3U', epgUrl: (f.epgUrl || '').trim(), ua: (f.ua || '').trim() });
  };

  const submitStalker = (e) => {
    e.preventDefault();
    setErr('');
    const portal = normalizeStalkerPortal(f.server || f.portal);
    const mac = normalizeMac(f.mac);
    if (!portal) { setErr('Renseigne l’adresse du portail Stalker.'); return; }
    if (!mac) { setErr('Adresse MAC invalide. Format attendu : 00:1A:79:12:34:56.'); return; }
    const model = MODELS[f.model] ? f.model : 'MAG254';
    const identityChanged = editing && (portal !== normalizeStalkerPortal(initial.server || initial.portal) || mac !== normalizeMac(initial.mac) || model !== (initial.model || 'MAG254'));
    const acc = {
      ...initial, ...f, id: initial.id,
      kind: 'stalker',
      name: f.name.trim() || 'Portail Stalker',
      server: portal,
      portal,
      mac,
      model,
      sn: (f.sn || '').trim(),
      device: (f.device || '').trim(),
      device2: (f.device2 || '').trim(),
      sig: (f.sig || '').trim(),
      epgUrl: (f.epgUrl || '').trim(),
      epgMap: f.epgMap || initial.epgMap || {},
      ...(identityChanged ? { api: undefined, stalkerStyle: undefined } : {})
    };
    // Enregistrement volontairement local et immédiat. Le diagnostic Stalker
    // est un outil séparé : aucune requête réseau, EPG ou authentification ne
    // conditionne l'ajout du compte dans le store.
    onDone(acc);
  };

  if (mode === 'stalker') {
    return (
      <form onSubmit={submitStalker} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {sourcePicker}
        <label className="lbl">Nom de la source
          <input value={f.name} onChange={set('name')} placeholder="Mon portail Stalker" />
        </label>
        <label className="lbl">Adresse du portail
          <input value={f.server || f.portal || ''} onChange={set('server')} placeholder="http://exemple.com/c/" autoFocus autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <small>L’adresse fournie par ton opérateur, avec le port éventuel.</small>
        </label>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12 }}>
          <label className="lbl">Adresse MAC
            <input value={f.mac || ''} onChange={set('mac')} placeholder="00:1A:79:12:34:56" autoComplete="off" autoCorrect="off" autoCapitalize="characters" spellCheck={false} />
          </label>
          <label className="lbl">Modèle MAG
            <select value={f.model || 'MAG254'} onChange={set('model')}>
              {Object.keys(MODELS).map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </label>
        </div>
        <label className="lbl">Guide XMLTV externe (optionnel)
          <input value={f.epgUrl || ''} onChange={set('epgUrl')} placeholder="https://exemple.com/guide.xml ou guide.xml.gz" autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <small>Tu pourras vérifier les correspondances et les corriger dans Réglages.</small>
        </label>
        <button type="button" className="btn btn-ghost btn-sm" style={{ alignSelf: 'flex-start' }} onClick={() => setShowAdv((v) => !v)}>
          {showAdv ? 'Masquer' : 'Afficher'} les identifiants avancés
        </button>
        {showAdv && (
          <div className="stk-adv">
            <p className="muted" style={{ fontSize: 13, margin: 0, gridColumn: '1 / -1', lineHeight: 1.5 }}>Laisse ces champs vides sauf si ton fournisseur exige les mêmes identifiants que STBEmu ou un autre boîtier déjà autorisé.</p>
            <label className="lbl">Numéro de série<input value={f.sn || ''} onChange={set('sn')} autoComplete="off" /></label>
            <label className="lbl">Device ID<input value={f.device || ''} onChange={set('device')} autoComplete="off" /></label>
            <label className="lbl">Device ID 2<input value={f.device2 || ''} onChange={set('device2')} autoComplete="off" /></label>
            <label className="lbl">Signature<input value={f.sig || ''} onChange={set('sig')} autoComplete="off" /></label>
          </div>
        )}
        {err && <p className="err">{err}</p>}
        <p className="muted" style={{ fontSize: 13, lineHeight: 1.5, margin: 0 }}>
          Le compte sera enregistré directement en conservant son identifiant. Tu peux utiliser ensuite le Diagnostic Stalker des Réglages pour tester le portail, sans que son résultat modifie ou bloque le compte.
        </p>
        <button className="btn btn-primary" type="submit" style={{ justifyContent: 'center', marginTop: 6 }}>
          {submitLabel === 'Se connecter' ? 'Enregistrer le compte Stalker' : submitLabel}
        </button>
      </form>
    );
  }

  if (mode === 'm3u') {
    return (
      <form onSubmit={submitM3u} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {sourcePicker}
        <label className="lbl">Nom de la source
          <input value={f.name} onChange={set('name')} placeholder="Mes chaînes" />
        </label>
        <label className="lbl">Adresse de la playlist M3U
          <input value={f.server} onChange={set('server')} placeholder="https://exemple.com/m3u/…" autoFocus autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <small>La liste des chaînes du direct. Les films et séries passent par un serveur Xtream.</small>
          {f.server.trim() && <code style={{ display: 'block', marginTop: 6, fontSize: 12, wordBreak: 'break-all', opacity: 0.85 }}>Lumen utilisera : {normalizeM3u(f.server)}</code>}
        </label>
        <label className="lbl">Adresse du guide XMLTV (optionnelle)
          <input value={f.epgUrl || ''} onChange={set('epgUrl')} placeholder="https://exemple.com/epg.xml" autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <small>Pour les programmes du direct. Si la playlist l'indique déjà, Lumen la reprend tout seul.</small>
        </label>
        <label className="lbl">User-Agent (optionnel)
          <input value={f.ua || ''} onChange={set('ua')} placeholder="Laisse vide sauf si ton fournisseur en impose un" autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <small>Comme le champ User-Agent de TiviMate. À remplir seulement si le serveur refuse la playlist.</small>
        </label>
        {err && <p className={/Xtream/.test(err) ? 'ok' : 'err'}>{err}</p>}
        {force && (
          <div className="card-box" style={{ gap: 10, background: 'rgba(242,169,59,.08)', borderColor: 'rgba(242,169,59,.35)' }}>
            <p className="muted" style={{ fontSize: 14, lineHeight: 1.6, margin: 0 }}>Ce PC n'arrive pas à lire la playlist (le serveur le bloque), mais la Shield y arrive peut-être. Tu peux l'ajouter quand même : elle sera vide ici, mais tu pourras l'envoyer à la TV avec « Envoyer vers ma TV » (carte plus bas), et la Shield la chargera.</p>
            <button type="button" className="btn btn-ghost btn-sm" style={{ alignSelf: 'flex-start' }} onClick={addAnyway}>Ajouter quand même (pour l'envoyer à la TV)</button>
          </div>
        )}
        <button className="btn btn-primary" type="submit" disabled={busy} style={{ justifyContent: 'center', marginTop: 6 }}>
          {busy ? <><Spinner /> Lecture de la playlist…</> : (submitLabel === 'Se connecter' ? 'Ajouter la playlist' : submitLabel)}
        </button>
      </form>
    );
  }

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    // Lien M3U ou API collé en entier : on en extrait identifiant et mot de passe
    let fx = { ...f, server: f.server.trim() };
    const m = fx.server.match(/[?&]username=([^&]+)/i);
    const pw = fx.server.match(/[?&]password=([^&]+)/i);
    if (m && !fx.username) fx.username = decodeURIComponent(m[1]);
    if (pw && !fx.password) fx.password = decodeURIComponent(pw[1]);
    if (fx.username !== f.username || fx.password !== f.password) setF(fx);
    const f2 = fx;
    if (!f2.server || !f2.username || !f2.password) { setErr('Renseigne l\'adresse du serveur, l\'identifiant et le mot de passe.'); return; }
    setBusy(true);
    try {
      const acc = { ...initial, ...f2, id: initial.id, kind: 'xtream', username: f2.username.trim(), password: f2.password.trim(), server: normalizeServer(f2.server), name: f2.name.trim() || 'Serveur principal' };
      if (editing) { onDone(acc); return; }
      const info = await new Xtream(acc).auth();
      if (tmdbKey && tmdbKey !== settings.tmdbKey) {
        try { await new Tmdb(tmdbKey).test(); updateSettings({ tmdbKey }); }
        catch { setErr('Connexion au serveur réussie, mais la clé TMDB est refusée. Tu pourras la corriger dans les Réglages.'); }
      }
      const exp = Number(info.user_info.exp_date);
      onDone({ ...acc, expires: exp ? exp * 1000 : null, maxConn: Number(info.user_info.max_connections) || null });
    } catch (e2) {
      setErr(e2.message || String(e2));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {sourcePicker}
      <label className="lbl">Nom du profil
        <input value={f.name} onChange={set('name')} placeholder="Serveur principal" />
      </label>
      <label className="lbl">Adresse du serveur
        <input value={f.server} onChange={set('server')} placeholder="http://exemple.com:8080" autoFocus autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
        <small>Avec le port s'il y en a un (le nombre après les deux-points). Tu peux aussi coller ton lien M3U complet.</small>
      </label>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <label className="lbl">Identifiant
          <input value={f.username} onChange={set('username')} autoComplete="username" />
        </label>
        <label className="lbl">Mot de passe
          <input type="password" value={f.password} onChange={set('password')} autoComplete="current-password" />
        </label>
      </div>
      <label className="lbl">Clé API TMDB (optionnelle)
        <input value={tmdbKey} onChange={(e) => setTmdbKey(e.target.value)} placeholder="Clé v3 ou jeton de lecture v4" />
        <small>Elle apporte les grands visuels, les logos de titres, les bandes-annonces et les plateformes. Gratuite sur themoviedb.org, rubrique Paramètres puis API.</small>
      </label>
      {err && <p className="err">{err}</p>}
      <button className="btn btn-primary" type="submit" disabled={busy} style={{ justifyContent: 'center', marginTop: 6 }}>
        {busy ? <><Spinner /> Connexion…</> : submitLabel}
      </button>
    </form>
  );
}

export default function Login() {
  const { addAccount } = useApp();
  const [manual, setManual] = useState(false);
  if (isTV && !manual) {
    return (
      <div className="login tv-login">
        <div className="login-bg" />
        <div className="login-card" style={{ width: 'min(1100px, 92vw)' }}>
          <div className="logo" style={{ fontSize: 64 }}>LUMEN</div>
          <p className="muted" style={{ fontSize: 20, lineHeight: 1.5 }}>Bienvenue ! Le plus simple pour configurer la TV, c'est d'envoyer tes réglages depuis ton téléphone ou ton PC : pas besoin de taper tes identifiants à la télécommande.</p>
          <TvReceive />
          <button className="btn btn-ghost" style={{ alignSelf: 'flex-start' }} onClick={() => setManual(true)}>Saisir mon serveur à la télécommande</button>
        </div>
      </div>
    );
  }
  return (
    <div className="login">
      <div className="login-bg" />
      <div className="login-card">
        <div className="logo" style={{ fontSize: 52 }}>LUMEN</div>
        <p className="muted" style={{ fontSize: 16, lineHeight: 1.5 }}>Ajoute une source Xtream, M3U ou Stalker pour commencer. Tes identifiants restent sur {isTV ? 'cette TV' : 'ce PC'}.</p>
        <BackupOffer />
        <AccountForm onDone={addAccount} />
      </div>
    </div>
  );
}

// v30 : si Lumen démarre sans compte alors qu'une copie de sécurité existe, on propose de tout remettre
function BackupOffer() {
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!window.lumen || !window.lumen.backupLoad) return;
    window.lumen.backupLoad().then((d) => { if (d && d.accounts && d.accounts.length) setData(d); }).catch(() => {});
  }, []);
  if (!data) return null;
  const when = data.savedAt ? new Date(data.savedAt).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' }) : '';
  const restore = () => {
    setBusy(true);
    saveJSON('accounts', data.accounts);
    if (data.activeId) saveJSON('activeId', data.activeId);
    if (data.settings) saveJSON('settings', data.settings);
    // Profils : seulement si ceux d'aujourd'hui sont ceux par défaut (stockage reparti à zéro)
    const cur = getProfiles();
    const isDefault = cur.length === 2 && cur[0].id === 'alex' && cur[1].id === 'jess' && cur[0].name === 'Alex' && cur[1].name === 'Jess';
    if (Array.isArray(data.profiles) && data.profiles.length && isDefault) saveProfiles(data.profiles);
    window.location.reload();
  };
  return (
    <div className="backup-offer" role="status">
      <div>
        <b>Tes comptes ont été sauvegardés</b>
        <p className="muted">{data.accounts.map((a) => a.name || 'Sans nom').join(', ')}{when ? ` · copie du ${when}` : ''}</p>
      </div>
      <button className="btn btn-primary" disabled={busy} onClick={restore}>{busy ? 'Restauration…' : 'Restaurer'}</button>
    </div>
  );
}

Login.SwitchButton = function SwitchButton() {
  const { account, removeAccount } = useApp();
  return <button className="btn btn-ghost" onClick={() => account && removeAccount(account.id)}>Changer de serveur</button>;
};
