import React, { useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { Xtream, normalizeServer } from '../lib/xtream.js';
import { Tmdb } from '../lib/tmdb.js';
import { Spinner } from '../components/ui.jsx';
import { isTV } from '../tv/native.js';
import TvReceive from '../tv/TvReceive.jsx';

export function AccountForm({ initial = {}, onDone, submitLabel = 'Se connecter' }) {
  const { settings, updateSettings } = useApp();
  const [f, setF] = useState({ name: '', server: '', username: '', password: '', ...initial });
  const [tmdbKey, setTmdbKey] = useState(settings.tmdbKey || '');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    // Lien M3U ou API collé en entier : on en extrait identifiant et mot de passe
    let fx = { ...f, server: f.server.trim() };
    const m = fx.server.match(/[?&]username=([^&]+)/i);
    const pw = fx.server.match(/[?&]password=([^&]+)/i);
    if (m && !fx.username) fx.username = decodeURIComponent(m[1]);
    if (pw && !fx.password) fx.password = decodeURIComponent(pw[1]);
    if (fx.username !== f.username || fx.password !== f.password) setF(fx);
    const f2 = fx;
    if (!f2.server || !f2.username || !f2.password) { setErr('Renseigne l\'adresse du serveur, l\'identifiant et le mot de passe.'); return; }
    setBusy(true);
    try {
      const acc = { ...f2, username: f2.username.trim(), password: f2.password.trim(), server: normalizeServer(f2.server), name: f2.name.trim() || 'Serveur principal' };
      const info = await new Xtream(acc).auth();
      if (tmdbKey && tmdbKey !== settings.tmdbKey) {
        try { await new Tmdb(tmdbKey).test(); updateSettings({ tmdbKey }); }
        catch { setErr('Connexion au serveur réussie, mais la clé TMDB est refusée. Tu pourras la corriger dans les Réglages.'); }
      }
      const exp = Number(info.user_info.exp_date);
      onDone({ ...acc, expires: exp ? exp * 1000 : null, maxConn: Number(info.user_info.max_connections) || null });
    } catch (e2) {
      setErr(e2.message || String(e2));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <label className="lbl">Nom du profil
        <input value={f.name} onChange={set('name')} placeholder="Serveur principal" />
      </label>
      <label className="lbl">Adresse du serveur
        <input value={f.server} onChange={set('server')} placeholder="http://exemple.com:8080" autoFocus />
        <small>Avec le port s'il y en a un (le nombre après les deux-points). Tu peux aussi coller ton lien M3U complet.</small>
      </label>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <label className="lbl">Identifiant
          <input value={f.username} onChange={set('username')} autoComplete="username" />
        </label>
        <label className="lbl">Mot de passe
          <input type="password" value={f.password} onChange={set('password')} autoComplete="current-password" />
        </label>
      </div>
      <label className="lbl">Clé API TMDB (optionnelle)
        <input value={tmdbKey} onChange={(e) => setTmdbKey(e.target.value)} placeholder="Clé v3 ou jeton de lecture v4" />
        <small>Elle apporte les grands visuels, les logos de titres, les bandes-annonces et les plateformes. Gratuite sur themoviedb.org, rubrique Paramètres puis API.</small>
      </label>
      {err && <p className="err">{err}</p>}
      <button className="btn btn-primary" type="submit" disabled={busy} style={{ justifyContent: 'center', marginTop: 6 }}>
        {busy ? <><Spinner /> Connexion…</> : submitLabel}
      </button>
    </form>
  );
}

export default function Login() {
  const { addAccount } = useApp();
  const [manual, setManual] = useState(false);
  if (isTV && !manual) {
    return (
      <div className="login tv-login">
        <div className="login-bg" />
        <div className="login-card" style={{ width: 'min(1100px, 92vw)' }}>
          <div className="logo" style={{ fontSize: 64 }}>LUMEN</div>
          <p className="muted" style={{ fontSize: 20, lineHeight: 1.5 }}>Bienvenue ! Le plus simple pour configurer la TV, c'est d'envoyer tes réglages depuis ton téléphone ou ton PC : pas besoin de taper tes identifiants à la télécommande.</p>
          <TvReceive />
          <button className="btn btn-ghost" style={{ alignSelf: 'flex-start' }} onClick={() => setManual(true)}>Saisir mon serveur à la télécommande</button>
        </div>
      </div>
    );
  }
  return (
    <div className="login">
      <div className="login-bg" />
      <div className="login-card">
        <div className="logo" style={{ fontSize: 52 }}>LUMEN</div>
        <p className="muted" style={{ fontSize: 16, lineHeight: 1.5 }}>Ajoute ton serveur Xtream Codes pour commencer. Tes identifiants restent sur {isTV ? 'cette TV' : 'ce PC'}.</p>
        <AccountForm onDone={addAccount} />
      </div>
    </div>
  );
}

Login.SwitchButton = function SwitchButton() {
  const { account, removeAccount } = useApp();
  return <button className="btn btn-ghost" onClick={() => account && removeAccount(account.id)}>Changer de serveur</button>;
};
