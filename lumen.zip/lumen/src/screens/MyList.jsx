import React, { useMemo, useState } from 'react';
import { loadJSON, saveJSON } from '../lib/store.js';
import { CatalogView, VIEWS } from '../components/CatalogViews.jsx';
import { isTV } from '../tv/native.js';
import TvOptions from '../tv/TvOptions.jsx';
import { useApp } from '../lib/app.jsx';
import { resumeList } from '../lib/play.js';
import { fmtRemain } from '../lib/player.js';
import { useResume } from '../lib/upnext.js';
import { PosterCard, LandCard, Row } from '../components/ui.jsx';

export default function MyList() {
  const { favorites, catalog, navigate, progress, hideResume, clearResume } = useApp();
  const favs = Object.values(favorites).filter((f) => f.kind === 'movie' || f.kind === 'series').sort((a, b) => b.t - a.t);
  const resume = useResume(50);
  const [kind, setKind] = useState('all');
  const [sort, setSort] = useState(() => loadJSON('mylistSort', 'added'));
  const [view, setView] = useState(() => loadJSON('mylistView', 'grille'));
  const all = useMemo(() => favs.map((f) => catalog.byKey.get(f.key)).filter(Boolean), [favorites, catalog]);
  const added = useMemo(() => Object.fromEntries(favs.map((f) => [f.key, f.t || 0])), [favorites]);
  const items = useMemo(() => {
    let l = kind === 'all' ? all : all.filter((it) => it.kind === kind);
    l = [...l];
    if (sort === 'added') l.sort((a, b) => (added[b.key] || 0) - (added[a.key] || 0));
    if (sort === 'az') l.sort((a, b) => a.title.localeCompare(b.title, 'fr'));
    if (sort === 'year') l.sort((a, b) => (b.year || 0) - (a.year || 0));
    if (sort === 'rating') l.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    return l;
  }, [all, kind, sort, added]);
  const nMovies = all.filter((it) => it.kind === 'movie').length;
  const nSeries = all.length - nMovies;

  return (
    <div style={{ paddingTop: 110, paddingBottom: 80 }}>
      <h1 className="page-title" style={{ padding: '0 var(--gutter)', marginBottom: 10 }}>Ma liste</h1>
      <p className="muted" style={{ padding: '0 var(--gutter)', marginBottom: 20 }}>{favs.length} titres enregistrés · {resume.length} à reprendre</p>
      {resume.length > 0 && (
        <Row title="À reprendre" action={{ label: 'Tout retirer', onClick: () => { if (window.confirm('Retirer tous les titres de « Continuer à regarder » ?')) clearResume(); } }}>
          {resume.map((p) => (
            <LandCard key={p.ref.key} badge={p.fresh ? 'NOUVEL ÉPISODE' : p.next ? 'À SUIVRE' : null} title={p.ref.title} image={p.ref.image} pct={(p.pos / p.dur) * 100}
              sub={p.fresh ? 'Nouveau · ' + p.ref.sub.split(' · ').slice(0, 2).join(' · ') : p.next ? 'Épisode suivant · ' + p.ref.sub.split(' · ').slice(0, 2).join(' · ') : (p.ref.kind === 'episode' ? p.ref.sub.split(' · ').slice(0, 2).join(' · ') + ' · ' : '') + fmtRemain(p.pos, p.dur)}
              onOpen={() => navigate({ name: 'player', ref: p.ref, startAt: p.pos })} onRemove={() => hideResume(p.ref)} />
          ))}
        </Row>
      )}
      <div style={{ padding: '24px var(--gutter) 0' }}>
        <h2 className="row-title" style={{ marginBottom: 16 }}>Enregistrés</h2>
        {favs.length === 0
          ? <p className="empty">Ajoute des films et séries avec le bouton + de leur fiche.</p>
          : (
            <>
              {isTV ? (
                <div className="toolbar">
                  <TvOptions sections={[
                    { label: 'Afficher', value: kind, onChange: setKind, choices: [['all', 'Tout · ' + all.length], ['movie', 'Films · ' + nMovies], ['series', 'Séries · ' + nSeries]] },
                    { label: 'Trier par', value: sort, onChange: (k) => { setSort(k); saveJSON('mylistSort', k); }, choices: [['added', 'Ajout récent'], ['az', 'A à Z'], ['year', 'Année'], ['rating', 'Note']] },
                    { label: 'Affichage', value: view, onChange: (v) => { setView(v); saveJSON('mylistView', v); }, choices: VIEWS.map((v) => [v.id, v.name]) }
                  ]} />
                </div>
              ) : (
              <div className="toolbar">
                <div className="pills" role="group" aria-label="Type">
                  {[['all', 'Tout', all.length], ['movie', 'Films', nMovies], ['series', 'Séries', nSeries]].map(([k, l, n]) => (
                    <button key={k} className={'pill' + (kind === k ? ' on' : '')} onClick={() => setKind(k)}>{l} · {n}</button>
                  ))}
                </div>
                <div className="seg" role="group" aria-label="Tri">
                  {[['added', 'Ajout récent'], ['az', 'A à Z'], ['year', 'Année'], ['rating', 'Note']].map(([k, l]) => (
                    <button key={k} className={sort === k ? 'on' : ''} onClick={() => { setSort(k); saveJSON('mylistSort', k); }}>{l}</button>
                  ))}
                </div>
                <div className="seg" role="group" aria-label="Vue" style={{ marginLeft: 'auto' }}>
                  {VIEWS.map((v) => (
                    <button key={v.id} className={view === v.id ? 'on' : ''} onClick={() => { setView(v.id); saveJSON('mylistView', v.id); }}>{v.name}</button>
                  ))}
                </div>
              </div>
              )}
              <CatalogView view={view} items={items} onOpen={(it) => navigate({ name: 'fiche', item: it })} />
            </>
          )}
      </div>
    </div>
  );
}
