import React, { useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { testOmdb } from '../lib/ratings.js';
import { isTV } from '../tv/native.js';
import { focusTop } from '../tv/spatial.js';
import TvReceive from '../tv/TvReceive.jsx';
import { checkUpdate, UpdatePanel } from '../tv/UpdateCheck.jsx';
import SendToTv from '../components/SendToTv.jsx';
import { Tmdb } from '../lib/tmdb.js';
import { clearCache, loadJSON } from '../lib/store.js';
import { AccountForm } from './Login.jsx';
import { Icon } from '../components/ui.jsx';
import Categories from '../components/Categories.jsx';
import { THEMES } from '../lib/themes.js';
import { EQ_MODES } from '../lib/audio.js';
import TraktCard from '../components/TraktCard.jsx';

const ACCENTS = ['#F2A93B', '#3DDC84', '#E5484D', '#7C8CFF', '#FF6FB5', '#22C3E6', '#FFD43B', '#FFFFFF'];

export default function Settings({ route }) {
  const app = useApp();
  const { mpvExe, recheckMpv } = app;
  const [dl, setDl] = useState(null);
  // TV : en ouvrant les Réglages, le curseur va directement sur le premier réglage
  React.useEffect(() => {
    if (!isTV || (route && route.anchor)) return;
    const t = setTimeout(focusTop, 150);
    return () => clearTimeout(t);
  }, []);
  const { settings, updateSettings, accounts, account, setActiveId, removeAccount, addAccount, refreshCatalog, catState, catalog } = app;
  const [key, setKey] = useState(settings.tmdbKey);
  const [keyMsg, setKeyMsg] = useState(null);
  const [adding, setAdding] = useState(false);
  const [msg, setMsg] = useState('');
  React.useEffect(() => {
    if (route && route.anchor) setTimeout(() => { const el = document.getElementById(route.anchor); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 80);
  }, [route && route.anchor]);

  const saveKey = async () => {
    setKeyMsg(null);
    if (!key.trim()) { updateSettings({ tmdbKey: '' }); setKeyMsg({ ok: true, t: 'Clé retirée.' }); return; }
    try {
      await new Tmdb(key).test();
      updateSettings({ tmdbKey: key.trim() });
      setKeyMsg({ ok: true, t: 'Clé TMDB valide et enregistrée.' });
    } catch (e) {
      setKeyMsg({ ok: false, t: e.message || 'Clé refusée' });
    }
  };

  const pick = async () => {
    if (!window.lumen) return;
    const p = await window.lumen.pickPlayer();
    if (p) updateSettings({ playerPath: p });
  };

  const exportBackup = () => {
    const data = {
      app: 'lumen', v: 1, date: new Date().toISOString(),
      accounts, activeId: account && account.id, settings,
      favorites: loadJSON('favorites', {}), progress: loadJSON('progress', {}), reminders: loadJSON('reminders', []),
      hidden: Object.fromEntries(accounts.map((a) => [a.id, loadJSON('hiddenCats:' + a.id, null)]).filter((x) => x[1]))
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `lumen-sauvegarde-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };

  const importBackup = (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    f.text().then((t) => {
      const d = JSON.parse(t);
      if (d.app !== 'lumen') throw new Error();
      app.importBackup(d);
      setMsg('Sauvegarde importée.');
    }).catch(() => setMsg('Ce fichier n\'est pas une sauvegarde Lumen.'));
  };

  return (
    <div className="screen-pad">
      <h1 className="page-title" style={{ marginBottom: 28 }}>Réglages</h1>
      <div className="settings">
        {isTV && <TvUpdateCard />}
        {isTV && (
          <section className="card-box">
            <h2>Recevoir des réglages</h2>
            <TvReceive compact />
          </section>
        )}
        {window.lumen && !isTV && <SendToTv />}

        <section className="card-box">
          <h2>Serveurs</h2>
          {accounts.map((a) => (
            <div key={a.id} className="server-row" style={{ gap: 16 }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4, minWidth: 0 }}>
                <span>{a.name}{account && a.id === account.id ? ' · actif' : ''}</span>
                <span className="muted" style={{ fontSize: 13, fontWeight: 400 }}>
                  {a.server} · {a.username}{a.expires ? ' · expire le ' + new Date(a.expires).toLocaleDateString('fr-FR') : ''}{a.maxConn ? ` · ${a.maxConn} connexion${a.maxConn > 1 ? 's' : ''}` : ''}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {account && a.id !== account.id && <button className="btn btn-ghost btn-sm" onClick={() => setActiveId(a.id)}>Utiliser</button>}
                <button className="btn btn-ghost btn-sm" onClick={() => removeAccount(a.id)}>Retirer</button>
              </div>
            </div>
          ))}
          {catalog && (
            <p className="muted" style={{ fontSize: 14 }}>
              Catalogue : {catalog.live.length} chaînes, {catalog.vod.length} films, {catalog.series.length} séries · mis à jour le {new Date(catalog.t).toLocaleString('fr-FR')}
              {catalog.mergedFrom ? ' · fusion de ' + catalog.mergedFrom.join(', ') : ''}
            </p>
          )}
          {accounts.length > 1 && (
            <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, fontSize: 15, lineHeight: 1.5 }}>
              <input type="checkbox" checked={!!settings.merge} onChange={(e) => updateSettings({ merge: e.target.checked })} style={{ marginTop: 4 }} />
              <span>
                Fusionner tous mes serveurs en un seul catalogue
                <span className="muted" style={{ display: 'block', fontSize: 13 }}>
                  Le serveur actif reste le principal. Les titres présents sur plusieurs serveurs n'apparaissent qu'une fois, et si un film, un épisode ou une chaîne ne passe pas, Lumen bascule tout seul sur un autre serveur.
                </span>
              </span>
            </label>
          )}
          <div className="actions" style={{ marginTop: 0 }}>
            <button className="btn btn-ghost btn-sm" onClick={() => refreshCatalog(true)} disabled={catState.loading}>
              <Icon name="refresh" size={16} />{catState.loading ? catState.step + '…' : 'Recharger le catalogue'}
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => setAdding((v) => !v)}><Icon name="plus" size={16} />Ajouter un serveur</button>
          </div>
          {adding && <AccountForm submitLabel="Ajouter ce serveur" onDone={(acc) => { addAccount(acc); setAdding(false); }} />}
        </section>

        <section className="card-box" id="groupes">
          <h2>Groupes affichés</h2>
          <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>
            Choisis les groupes de ton serveur à afficher dans le Direct, les Films et les Séries. Un groupe masqué disparaît partout : listes, accueil, recherche, zapping. Rien n'est supprimé sur le serveur, tu peux le réafficher quand tu veux.
          </p>
          <Categories />
        </section>

        {isTV && (
          <section className="card-box">
            <h2>Clés</h2>
            <div className="server-row"><span>TMDB (visuels, agenda, notes)</span><span className={settings.tmdbKey ? 'ok' : 'muted'}>{settings.tmdbKey ? 'Configurée' : 'Absente'}</span></div>
            <div className="server-row"><span>OMDb (IMDb, Rotten Tomatoes)</span><span className={settings.omdbKey ? 'ok' : 'muted'}>{settings.omdbKey ? 'Configurée' : 'Absente'}</span></div>
            <div className="server-row"><span>OpenSubtitles</span><span className={settings.osKey ? 'ok' : 'muted'}>{settings.osKey ? 'Configurée' : 'Absente'}</span></div>
            <span className="muted" style={{ fontSize: 14 }}>Les clés se saisissent sur le PC (ou le téléphone) puis s'envoient à la TV avec « Recevoir des réglages ».</span>
          </section>
        )}

        {!isTV && <section className="card-box">
          <h2>TMDB</h2>
          <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>
            TMDB fournit les grands visuels, les logos de titres, le casting, les bandes-annonces, les tendances et les pages plateformes. Crée un compte gratuit sur themoviedb.org, puis Paramètres, API, et colle ici la clé API v3 ou le jeton de lecture v4.
          </p>
          <div style={{ display: 'flex', gap: 10 }}>
            <label className="lbl" style={{ flex: '1 1 auto' }}>
              <span className="sr-only" style={{ position: 'absolute', left: -9999 }}>Clé TMDB</span>
              <input value={key} onChange={(e) => setKey(e.target.value)} placeholder="Clé API TMDB" aria-label="Clé API TMDB" />
            </label>
            <button className="btn btn-primary btn-sm" onClick={saveKey}>Vérifier et enregistrer</button>
          </div>
          {keyMsg && <p className={keyMsg.ok ? 'ok' : 'err'}>{keyMsg.t}</p>}
        </section>}

        {!isTV && <OmdbCard />}

        <section className="card-box">
          <h2>Trakt</h2>
          <TraktCard />
        </section>

        <section className="card-box">
          <h2>Apparence</h2>
          <div className="swatches" role="group" aria-label="Couleur d'accent">
            {ACCENTS.map((c) => (
              <button key={c} className={settings.accent === c ? 'on' : ''} style={{ background: c }} aria-label={'Accent ' + c}
                onClick={() => updateSettings({ accent: c })} />
            ))}
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }} className="muted">
              Autre
              <input type="color" value={settings.accent} onChange={(e) => updateSettings({ accent: e.target.value })} aria-label="Couleur personnalisée" />
            </label>
          </div>
          <span style={{ fontSize: 15 }}>Thème</span>
          <div className="themes" role="group" aria-label="Thème">
            {THEMES.map((t) => (
              <button key={t.id} className={'theme-card' + (settings.theme === t.id ? ' on' : '')} onClick={() => updateSettings({ theme: t.id })}
                style={{ background: t.bg, borderColor: settings.theme === t.id ? 'var(--accent)' : t.line }}>
                <span className="tc-panel" style={{ background: t.panel }}><i style={{ background: settings.accent }} /></span>
                <span className="tc-name">{t.name}</span>
              </button>
            ))}
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
            <input type="checkbox" checked={settings.grain} onChange={(e) => updateSettings({ grain: e.target.checked })} />
            Grain de pellicule animé (effet cinéma)
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
            <input type="checkbox" checked={settings.intro} onChange={(e) => updateSettings({ intro: e.target.checked })} />
            Intro animée du logo au démarrage
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
            <input type="checkbox" checked={settings.heroTrailer} onChange={(e) => updateSettings({ heroTrailer: e.target.checked })} />
            Lancer la bande-annonce en fond du bandeau d'accueil
          </label>
        </section>

        <section className="card-box">
          <h2>Lecture</h2>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
            <input type="checkbox" checked={settings.autoNext} onChange={(e) => updateSettings({ autoNext: e.target.checked })} />
            Enchaîner automatiquement l'épisode suivant
          </label>
{isTV ? (
            <span className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>Sur la TV, la lecture se fait dans le lecteur natif d'Android : bouton OK pour pause, gauche et droite pour reculer de 10 s ou avancer de 30 s, bas pour afficher les commandes (pistes audio et sous-titres via l'icône des réglages). En direct, haut et bas changent de chaîne.</span>
          ) : (<>
          <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 14 }}>
            <span style={{ fontSize: 15 }}>Son par défaut</span>
            <div className="seg" role="group" aria-label="Égaliseur">
              {EQ_MODES.map((m) => <button key={m.id} title={m.desc} className={(settings.eq || 'normal') === m.id ? 'on' : ''} onClick={() => updateSettings({ eq: m.id })}>{m.name}</button>)}
            </div>
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
            <input type="checkbox" checked={settings.autoSkipIntro} onChange={(e) => updateSettings({ autoSkipIntro: e.target.checked })} />
            Passer l'intro automatiquement quand Lumen la connaît
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
            <input type="checkbox" checked={settings.entracte} onChange={(e) => updateSettings({ entracte: e.target.checked })} />
            Afficher l'entracte (heure et fin du film) quand la lecture est en pause
          </label>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <span style={{ fontSize: 15 }}>Moteur de lecture</span>
            <div className="seg" role="group" aria-label="Moteur de lecture" style={{ alignSelf: 'flex-start' }}>
              {[['auto', 'Automatique'], ['chromium', 'Lecteur intégré'], ['mpv', 'Toujours mpv']].map(([k, l]) => (
                <button key={k} className={(settings.engine || 'auto') === k ? 'on' : ''} onClick={() => updateSettings({ engine: k })}>{l}</button>
              ))}
            </div>
            <span className="muted" style={{ fontSize: 13, lineHeight: 1.5 }}>
              Automatique : le lecteur intégré d'abord, et mpv prend le relais dès qu'un format ne passe pas (MKV, HEVC, AC3, DTS, sous-titres intégrés). Avec mpv, toutes les pistes audio et sous-titres sont disponibles.
            </span>
            <div className="server-row">
              <span>{mpvExe ? 'mpv trouvé' : 'mpv n\'est pas installé'}</span>
              <span className="muted" style={{ fontWeight: 400, fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis' }}>{mpvExe || 'Nécessaire pour les formats que le lecteur intégré ne lit pas'}</span>
            </div>
            <div className="actions" style={{ marginTop: 0 }}>
              {window.lumen && (
                <button className="btn btn-primary btn-sm" disabled={!!dl && dl.p < 100 && !dl.error} onClick={async () => {
                  setDl({ p: 0, step: 'Préparation' });
                  const off = window.lumen.onMpvDl((v) => setDl(v));
                  const r = await window.lumen.mpvDownload();
                  off();
                  if (r.ok) { updateSettings({ mpvPath: r.path }); setDl({ p: 100, step: 'mpv est installé' }); recheckMpv(); }
                  else setDl({ p: 0, error: r.error });
                }}>{mpvExe ? 'Mettre à jour mpv' : 'Installer mpv automatiquement'}</button>
              )}
              <button className="btn btn-ghost btn-sm" onClick={async () => { if (!window.lumen) return; const p = await window.lumen.pickPlayer(); if (p) { updateSettings({ mpvPath: p }); } }}>Choisir mpv.exe</button>
              {settings.mpvPath && <button className="btn btn-ghost btn-sm" onClick={() => updateSettings({ mpvPath: '' })}>Détection automatique</button>}
            </div>
            {dl && !dl.error && <div className="dl-bar"><i style={{ width: dl.p + '%' }} /><span>{dl.step} {dl.p ? dl.p + ' %' : ''}</span></div>}
            {dl && dl.error && <p className="err">{dl.error}</p>}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <span style={{ fontSize: 15 }}>Lecteur externe pour les formats non pris en charge</span>
            <span className="muted" style={{ fontSize: 14 }}>{settings.playerPath || 'Détection automatique de VLC ou mpv'}</span>
            <div className="actions" style={{ marginTop: 0 }}>
              <button className="btn btn-ghost btn-sm" onClick={pick}>Choisir le programme</button>
              {settings.playerPath && <button className="btn btn-ghost btn-sm" onClick={() => updateSettings({ playerPath: '' })}>Revenir à la détection</button>}
            </div>
          </div>
          </>)}
        </section>

        <section className="card-box">
          <h2>Direct</h2>
          <span style={{ fontSize: 15 }}>Qualité choisie quand une chaîne existe en plusieurs versions</span>
          <div className="seg" role="group" aria-label="Qualité du direct" style={{ alignSelf: 'flex-start' }}>
            {[['best', 'La meilleure (sans 4K)'], ['uhd', '4K comprise'], ['hd', 'HD maximum']].map(([k, l]) => (
              <button key={k} className={settings.liveQuality === k ? 'on' : ''} onClick={() => updateSettings({ liveQuality: k })}>{l}</button>
            ))}
          </div>
          <span className="muted" style={{ fontSize: 13, lineHeight: 1.5 }}>Si tu changes la qualité d'une chaîne à la main, Lumen s'en souvient pour cette chaîne.</span>
          {isTV && (
            <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
              <input type="checkbox" checked={!!settings.tvStartLive} onChange={(e) => updateSettings({ tvStartLive: e.target.checked })} />
              Démarrer Lumen directement sur la dernière chaîne regardée
            </label>
          )}
        </section>

        <section className="card-box">
          <h2>Sous-titres</h2>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, alignItems: 'center' }}>
            {!isTV && <span style={{ fontSize: 15 }}>Taille</span>}
            {!isTV && <div className="seg" role="group" aria-label="Taille des sous-titres">
              {[['s', 'Petite'], ['m', 'Moyenne'], ['l', 'Grande']].map(([k, l]) => (
                <button key={k} className={settings.subSize === k ? 'on' : ''} onClick={() => updateSettings({ subSize: k })}>{l}</button>
              ))}
            </div>}
            <span style={{ fontSize: 15, marginLeft: isTV ? 0 : 12 }}>Langue d'abord</span>
            <div className="seg" role="group" aria-label="Langue des sous-titres">
              {[['fr', 'Français'], ['en', 'Anglais']].map(([k, l]) => (
                <button key={k} className={settings.subLang === k ? 'on' : ''} onClick={() => updateSettings({ subLang: k })}>{l}</button>
              ))}
            </div>
          </div>
          {!isTV && (<>
          <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>
            Pour chercher des sous-titres en ligne : crée un compte gratuit sur opensubtitles.com, puis dans ton profil, « API consumers », crée une clé. L'identifiant et le mot de passe sont facultatifs mais augmentent le nombre de téléchargements par jour.
          </p>
          <label className="lbl">Clé API OpenSubtitles
            <input value={settings.osKey} onChange={(e) => updateSettings({ osKey: e.target.value.trim() })} placeholder="Clé API" />
          </label>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <label className="lbl">Identifiant OpenSubtitles
              <input value={settings.osUser} onChange={(e) => updateSettings({ osUser: e.target.value.trim() })} autoComplete="off" />
            </label>
            <label className="lbl">Mot de passe
              <input type="password" value={settings.osPass} onChange={(e) => updateSettings({ osPass: e.target.value })} autoComplete="off" />
            </label>
          </div>
          </>)}
        </section>

        {!isTV && <section className="card-box">
          <h2>Sauvegarde</h2>
          <p className="muted" style={{ fontSize: 14 }}>Serveurs, réglages, Ma liste et reprises de lecture dans un seul fichier.</p>
          <div className="actions" style={{ marginTop: 0 }}>
            <button className="btn btn-ghost btn-sm" onClick={exportBackup}>Exporter</button>
            <label className="btn btn-ghost btn-sm" style={{ cursor: 'pointer' }}>
              Importer
              <input type="file" accept="application/json,.json" onChange={importBackup} style={{ display: 'none' }} />
            </label>
            <button className="btn btn-ghost btn-sm" onClick={() => clearCache().then(() => setMsg('Cache des fiches vidé.'))}>Vider le cache des fiches</button>
          </div>
          {msg && <p className="ok">{msg}</p>}
        </section>}
      </div>
    </div>
  );
}

// Notes IMDb, Rotten Tomatoes et Metacritic
function OmdbCard() {
  const { settings, updateSettings } = useApp();
  const [k, setK] = useState(settings.omdbKey || '');
  const [m, setM] = useState(null);
  const save = async () => {
    setM(null);
    if (!k.trim()) { updateSettings({ omdbKey: '' }); setM({ ok: true, t: 'Clé retirée.' }); return; }
    try { await testOmdb(k.trim()); updateSettings({ omdbKey: k.trim() }); setM({ ok: true, t: 'Clé OMDb valide : les notes IMDb et Rotten Tomatoes s\'affichent sur les fiches.' }); }
    catch (e) { setM({ ok: false, t: e.message }); }
  };
  return (
    <section className="card-box">
      <h2>Notes IMDb et Rotten Tomatoes</h2>
      <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>
        La note TMDB s'affiche déjà sur les fiches. Pour ajouter IMDb, Rotten Tomatoes et Metacritic, demande une clé gratuite sur omdbapi.com (menu « API Key », formule FREE, 1 000 fiches par jour) : elle arrive par e-mail, il faut cliquer sur le lien d'activation, puis la coller ici. Lumen retrouve chaque titre sur IMDb grâce à TMDB : la clé TMDB reste nécessaire.
      </p>
      <div style={{ display: 'flex', gap: 10 }}>
        <label className="lbl" style={{ flex: '1 1 auto' }}>
          <input value={k} onChange={(e) => setK(e.target.value)} placeholder="Clé OMDb (8 caractères)" aria-label="Clé OMDb" />
        </label>
        <button className="btn btn-primary btn-sm" onClick={save}>Vérifier et enregistrer</button>
      </div>
      {m && <p className={m.ok ? 'ok' : 'err'}>{m.t}</p>}
    </section>
  );
}

// TV : version installée et recherche de mise à jour
function TvUpdateCard() {
  const [st, setSt] = useState({ busy: false, msg: '', upd: null });
  const check = async () => {
    setSt({ busy: true, msg: '', upd: null });
    try {
      const u = await checkUpdate();
      if (u && u.newer) setSt({ busy: false, msg: '', upd: u });
      else setSt({ busy: false, msg: u ? `Tu as la dernière version (${u.currentName || u.current}).` : 'Vérification impossible.', upd: null });
    } catch (e) {
      setSt({ busy: false, msg: e.message, upd: null });
    }
  };
  return (
    <section className="card-box">
      <h2>Mises à jour</h2>
      <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>Lumen TV vérifie au démarrage s'il existe une nouvelle version sur GitHub. Ce bouton cherche la dernière version et l'installe directement.</p>
      <button className="btn btn-primary btn-sm" style={{ alignSelf: 'flex-start' }} onClick={check} disabled={st.busy}>{st.busy ? 'Vérification…' : 'Mettre à jour Lumen'}</button>
      {st.msg && <p className="muted">{st.msg}</p>}
      {st.upd && <UpdatePanel upd={st.upd} auto onClose={() => setSt({ busy: false, msg: '', upd: null })} />}
    </section>
  );
}

