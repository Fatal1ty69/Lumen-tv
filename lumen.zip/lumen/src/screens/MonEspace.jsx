// « Mon espace » : l'unique écran personnel. Onglets : À voir plus tard (watchlist), Ma liste,
// À reprendre, Chaînes favorites, et accès à Mes séries et à l'Agenda.
import React, { useMemo, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { liveRef } from '../lib/play.js';
import { pickVariant } from '../lib/live.js';
import { matchTmdb } from '../lib/catalog.js';
import { loadJSON, saveJSON } from '../lib/store.js';
import { useResume } from '../lib/resume-v26.js';
import { isTV } from '../tv/native.js';
import { Icon, PosterCard, Tile, EmptyState, Row } from '../components/ui.jsx';
import ItemCard from '../components/ItemCard.jsx';
import { EspaceTabs } from '../components/SubTabs.jsx';
import MyList from './MyList.jsx';
import HistoryRow from '../components/HistoryRow.jsx';

const SORTS = [['added', 'Ajout récent'], ['rating', 'Note'], ['year', 'Année'], ['az', 'A à Z']];

export default function MonEspace({ route = {} }) {
  const { favorites, watchlist, catalog, navigate, goRoot, toggleWatch, importWatch, settings, trakt } = useApp();
  const watch = useMemo(() => Object.values(watchlist || {}).sort((a, b) => b.t - a.t), [watchlist]);
  const favVod = Object.values(favorites).filter((f) => f.kind === 'movie' || f.kind === 'series');
  const favLive = Object.values(favorites).filter((f) => f.kind === 'group').sort((a, b) => b.t - a.t);
  const resume = useResume(50);
  const counts = { plus: watch.length, liste: favVod.length, reprendre: resume.length, chaines: favLive.length };

  // Onglet demandé, sinon le premier qui contient quelque chose
  const firstFilled = ['plus', 'liste', 'reprendre', 'chaines'].find((k) => counts[k] > 0) || 'plus';
  const tab = route.name === 'mylist' ? 'liste' : (route.tab || (isTV ? 'tout' : firstFilled));

  const [sort, setSort] = useState(() => loadJSON('watchSort', 'added'));
  const watchItems = useMemo(() => {
    const l = watch.map((f) => ({ f, it: catalog.byKey.get(f.key) || null }));
    const v = (x) => x.it || x.f;
    if (sort === 'rating') l.sort((a, b) => ((v(b).rating || 0) - (v(a).rating || 0)));
    if (sort === 'year') l.sort((a, b) => ((v(b).year || 0) - (v(a).year || 0)));
    if (sort === 'az') l.sort((a, b) => String(v(a).title).localeCompare(String(v(b).title), 'fr'));
    return l;
  }, [watch, catalog, sort]);

  // Une chaîne favorite se lance directement, avec les autres favoris en chaînes suivante/précédente
  const playChannel = (f) => {
    const g = catalog.byKey.get(f.key);
    const ch = g && pickVariant(g, settings.liveQuality);
    if (!ch) { goRoot({ name: 'live' }); return; }
    const list = favLive.filter((x) => catalog.byKey.get(x.key)).map((x) => x.key);
    navigate({ name: 'player', ref: liveRef(ch, list, g) });
  };

  // Import de la watchlist Trakt : on ne garde que les titres présents sur tes serveurs
  const [imp, setImp] = useState({ busy: false, msg: '' });
  const importTrakt = async () => {
    setImp({ busy: true, msg: '' });
    try {
      const [m, s] = await Promise.all([trakt.reqAll('/sync/watchlist/movies'), trakt.reqAll('/sync/watchlist/shows')]);
      const found = [];
      let missing = 0;
      for (const [list, key, type] of [[m, 'movie', 'movie'], [s, 'show', 'tv']]) {
        for (const e of list || []) {
          const x = e && e[key];
          if (!x || !x.ids) continue;
          const date = x.year ? x.year + '-01-01' : '';
          const it = matchTmdb(catalog, { id: x.ids.tmdb, title: x.title, name: x.title, release_date: date, first_air_date: date }, type);
          if (it) found.push({ ...it, tmdb: it.tmdb || x.ids.tmdb || null }); else missing += 1;
        }
      }
      const fresh = found.filter((it) => !watchlist[it.key]);
      if (fresh.length) importWatch(fresh);
      const parts = [fresh.length ? `${fresh.length} titre${fresh.length > 1 ? 's' : ''} ajouté${fresh.length > 1 ? 's' : ''}` : 'Rien de nouveau à ajouter'];
      if (found.length - fresh.length) parts.push(`${found.length - fresh.length} déjà présent${found.length - fresh.length > 1 ? 's' : ''}`);
      if (missing) parts.push(`${missing} absent${missing > 1 ? 's' : ''} de tes serveurs`);
      setImp({ busy: false, msg: parts.join(' · ') });
    } catch (e) {
      setImp({ busy: false, msg: 'Import Trakt impossible : ' + (e && e.message ? e.message : 'erreur inconnue') });
    }
  };

  const showAll = tab === 'tout';

  // v49 : sur la TV, des rangées (gauche/droite pour parcourir, haut/bas pour changer de liste),
  // avec en tête les accès à Mes séries et à l'Agenda, qui ne sont plus dans le menu
  if (isTV) {
    const favItems = favVod.sort((a, b) => b.t - a.t).map((f) => ({ f, it: catalog.byKey.get(f.key) })).filter((x) => x.it);
    const watchOk = watchItems.filter((x) => x.it);
    const empty = !resume.length && !watchOk.length && !favItems.length && !favLive.length;
    return (
      <div className="screen-pad" style={{ paddingLeft: 0, paddingRight: 0 }}>
        <h1 className="page-title" style={{ padding: '0 var(--gutter)', marginBottom: 10 }}>Mon espace</h1>
        <div className="rows" style={{ marginTop: 0, gap: 26 }}>
          <Row title="Raccourcis">
            <Tile name="Mes séries" sub="Séries en cours et à jour" onOpen={() => goRoot({ name: 'messeries' })} />
            <Tile name="Agenda" sub="Sorties et rappels" onOpen={() => goRoot({ name: 'agenda' })} />
          </Row>
          {resume.length > 0 && <MyList embedded="resume" />}
          {watchOk.length > 0 && (
            <Row title={'À voir plus tard · ' + watchOk.length}>
              {watchOk.map(({ f, it }) => <ItemCard key={f.key} item={it} poster={it.poster || f.poster} />)}
            </Row>
          )}
          {favItems.length > 0 && (
            <Row title={'Ma liste · ' + favItems.length}>
              {favItems.map(({ f, it }) => <ItemCard key={f.key} item={it} poster={it.poster || f.poster} />)}
            </Row>
          )}
          {favLive.length > 0 && (
            <Row title={'Chaînes favorites · ' + favLive.length}>
              {favLive.map((f) => <Tile key={f.key} name={f.title} logo={f.poster} sub="Regarder en direct" onOpen={() => playChannel(f)} />)}
            </Row>
          )}
          {empty && (
            <EmptyState icon="plus" title="Rien ici pour l'instant"
              hint="Dans une fiche, le bouton « Options » permet d'ajouter un titre à Ma liste ou à À voir plus tard. Les chaînes favorites s'ajoutent par un appui long sur OK dans le Direct." />
          )}
        </div>
      </div>
    );
  }

  return (
    <div style={{ paddingTop: 110, paddingBottom: 80 }}>
      <h1 className="page-title" style={{ padding: '0 var(--gutter)', marginBottom: 14 }}>Mon espace</h1>
      <EspaceTabs current={tab} counts={counts} style={{ margin: '0 var(--gutter) 22px' }} />

      {(tab === 'plus' || showAll) && (
        <section style={{ padding: '0 var(--gutter)', marginBottom: 34 }}>
          {showAll && <h2 className="row-title" style={{ marginBottom: 14 }}>À voir plus tard</h2>}
          {!isTV && (
            <div className="toolbar" style={{ marginBottom: 18 }}>
              {watch.length > 1 && (
                <div className="seg" role="group" aria-label="Tri">
                  {SORTS.map(([k, l]) => <button key={k} className={sort === k ? 'on' : ''} onClick={() => { setSort(k); saveJSON('watchSort', k); }}>{l}</button>)}
                </div>
              )}
              {trakt && trakt.connected && (
                <button className="btn btn-ghost btn-sm" onClick={importTrakt} disabled={imp.busy}>
                  <Icon name="refresh" size={15} />{imp.busy ? 'Import en cours…' : 'Importer ma watchlist Trakt'}
                </button>
              )}
              {imp.msg && <span className="muted" role="status" style={{ fontSize: 14 }}>{imp.msg}</span>}
            </div>
          )}
          {watch.length === 0 ? (
            <EmptyState icon="calendar" title="Rien à voir plus tard pour l'instant"
              hint="Passe la souris sur une affiche et clique sur le calendrier, ou utilise le bouton « Plus tard » d'une fiche."
              action={{ label: 'Parcourir les films', onClick: () => goRoot({ name: 'browse', kind: 'movie' }) }} />
          ) : (
            <div className="grid">
              {watchItems.map(({ f, it }) => (it
                ? <ItemCard key={f.key} item={it} poster={it.poster || f.poster} sub={it.kind === 'series' ? 'Série' : 'Film'} />
                : <PosterCard key={f.key} title={f.title} poster={f.poster} sub="Plus sur tes serveurs" onOpen={() => {}} onRemove={() => toggleWatch(f)} removeLabel="À voir plus tard" />))}
            </div>
          )}
        </section>
      )}

      {(tab === 'liste' || showAll) && <MyList embedded="list" />}
      {(tab === 'reprendre' || showAll) && <MyList embedded="resume" />}
      {(tab === 'reprendre' || showAll) && <div style={{ marginTop: 26 }}><HistoryRow /></div>}

      {(tab === 'chaines' || showAll) && (
        <section style={{ padding: '0 var(--gutter)', marginTop: showAll ? 34 : 0 }}>
          {showAll && <h2 className="row-title" style={{ marginBottom: 14 }}>Chaînes favorites</h2>}
          {favLive.length === 0 ? (
            <EmptyState icon="tv" title="Aucune chaîne favorite"
              hint="Dans le Direct, clique sur l'étoile d'une chaîne pour la retrouver ici et la lancer en un clic."
              action={{ label: 'Ouvrir le Direct', onClick: () => goRoot({ name: 'live' }) }} />
          ) : (
            <div className="tile-grid">
              {favLive.map((f) => <Tile key={f.key} name={f.title} logo={f.poster} sub="Regarder en direct" onOpen={() => playChannel(f)} />)}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
