import { isTV } from '../tv/native.js';
import { focusTop } from '../tv/spatial.js';
import React, { useEffect, useMemo, useState, useRef } from 'react';
import { DecouvrirTabs } from '../components/SubTabs.jsx';
import { useApp } from '../lib/app.jsx';
import { img, tmdbView, PROVIDERS, serverPlatformCount, useProviderLogos } from '../lib/tmdb.js';
import { matchTmdb } from '../lib/catalog.js';
import { Row, PosterCard, CatTile, Spinner, Icon, Tile, HeroChips } from '../components/ui.jsx';
import { loadJSON, saveJSON } from '../lib/store.js';

const H6 = 6 * 3600 * 1000;
const DAY = 24 * H6 / 6;

// Grandes sagas proposées (identifiants de collections TMDB)
const SAGAS = [10, 1241, 119, 645, 87359, 9485, 2344, 263, 86311, 528, 8091, 10194];

function asItem(t, type, catalog) {
  const mt = t.media_type || type;
  return {
    uid: mt + t.id, type: mt, id: t.id, title: t.title || t.name,
    date: t.release_date || t.first_air_date || '', score: t.vote_average || 0,
    poster: img(t.poster_path), backdrop: img(t.backdrop_path, 'original'), overview: t.overview,
    item: matchTmdb(catalog, t, mt)
  };
}

export default function Decouvrir() {
  const { tmdb, catalog, navigate, goRoot, progress } = useApp();
  const [rows, setRows] = useState(null);
  const [genres, setGenres] = useState({ movie: [], tv: [] });
  const [genre, setGenre] = useState(null);
  const [genreRows, setGenreRows] = useState([]);
  const [sagas, setSagas] = useState([]);
  const [saga, setSaga] = useState(null);
  // v34 : Découvrir explore tes serveurs ; les titres absents ne sont plus proposés
  const onlyHome = true;
  const logos = useProviderLogos(tmdb);
  const [pepKind, setPepKind] = useState(() => loadJSON('decPepKind', 'movie'));
  const [focus, setFocus] = useState(null);
  // v50 : TV : le bandeau ne change qu'une fois la sélection posée (pas à chaque carte survolée en défilant)
  const focusT = useRef(0);
  const hoverFocus = (x) => { if (!isTV) { setFocus(x); return; } clearTimeout(focusT.current); focusT.current = setTimeout(() => setFocus(x), 450); };
  useEffect(() => () => clearTimeout(focusT.current), []);
  const [fv, setFv] = useState(null);

  // Ce que tu as regardé récemment, pour les recommandations
  const seeds = useMemo(() => {
    const seen = new Set();
    return Object.values(progress)
      .filter((p) => p && p.ref && p.ref.tmdbId && (p.ref.kind === 'movie' || p.ref.kind === 'episode'))
      .sort((a, b) => b.t - a.t)
      .map((p) => ({ type: p.ref.kind === 'movie' ? 'movie' : 'tv', id: p.ref.tmdbId, title: p.ref.title }))
      .filter((s) => (seen.has(s.type + s.id) ? false : seen.add(s.type + s.id)))
      .slice(0, 2);
  }, [progress]);

  useEffect(() => {
    if (!tmdb.enabled) return;
    let off = false;
    const list = (path, type, params = {}, ttl = H6) => tmdb.req(path, { region: 'FR', ...params }, ttl)
      .then((d) => (d.results || d.parts || []).map((t) => asItem(t, type, catalog))).catch(() => []);
    const pages = (path, type, n, params) => Promise.all(Array.from({ length: n }, (_, i) => list(path, type, { ...params, page: i + 1 }, DAY))).then((l) => l.flat());
    // v49 : même sélection sur PC et TV (tendances et populaires sont déjà sur l'accueil)
    const defs = [
      // v34 : tendances, populaires et mieux notés sont sur l'accueil ; ici, ce qu'on ne trouve pas ailleurs.
      // Pépites : très bien notées (7,4+) mais peu connues, plusieurs pages pour en trouver sur tes serveurs.
      { title: 'Pépites méconnues · Films', kind: 'movie', p: pages('/discover/movie', 'movie', 6, { sort_by: 'vote_average.desc', 'vote_average.gte': 7.4, 'vote_count.gte': 250, 'vote_count.lte': 4000 }) },
      { title: 'Pépites méconnues · Séries', kind: 'series', p: pages('/discover/tv', 'tv', 4, { sort_by: 'vote_average.desc', 'vote_average.gte': 7.4, 'vote_count.gte': 150, 'vote_count.lte': 3000 }) }
    ];
    Promise.all(defs.map((d) => d.p)).then((res) => {
      if (off) return;
      const r = defs.map((d, i) => ({ title: d.title, kind: d.kind, items: res[i].filter((x) => x.title) })).filter((x) => x.items.length);
      setRows(r);
      const firstTrend = r.find((x) => x.title.startsWith('Tendances du jour'));
      setFocus((firstTrend || r[0] || { items: [] }).items.find((x) => x.backdrop && x.item) || null);
    });
    Promise.all([tmdb.req('/genre/movie/list', {}, 30 * DAY), tmdb.req('/genre/tv/list', {}, 30 * DAY)])
      .then(([m, t]) => !off && setGenres({ movie: m.genres || [], tv: t.genres || [] })).catch(() => {});
    Promise.all(SAGAS.map((id) => tmdb.req(`/collection/${id}`, {}, 30 * DAY).catch(() => null)))
      // Seulement les sagas dont au moins un film est sur tes serveurs
      .then((l) => !off && setSagas(l.filter((c) => c && c.parts && c.parts.some((pt) => matchTmdb(catalog, pt, 'movie')))));
    return () => { off = true; };
  }, [tmdb, catalog, seeds.map((s) => s.type + s.id).join(',')]);

  // Rangées d'un genre
  useEffect(() => {
    if (!genre) { setGenreRows([]); return; }
    let off = false;
    const tvId = genres.tv.find((g) => g.name === genre.name);
    const mvId = genres.movie.find((g) => g.name === genre.name);
    Promise.all([
      mvId ? tmdb.req('/discover/movie', { with_genres: String(mvId.id), sort_by: 'popularity.desc', region: 'FR' }, H6).then((d) => (d.results || []).map((t) => asItem(t, 'movie', catalog))).catch(() => []) : [],
      tvId ? tmdb.req('/discover/tv', { with_genres: String(tvId.id), sort_by: 'popularity.desc' }, H6).then((d) => (d.results || []).map((t) => asItem(t, 'tv', catalog))).catch(() => []) : []
    ]).then(([m, t]) => !off && setGenreRows([
      { title: `Films · ${genre.name}`, items: m },
      { title: `Séries · ${genre.name}`, items: t }
    ].filter((r) => r.items.length)));
    return () => { off = true; };
  }, [genre && genre.name]);

  // Logo et détails du titre mis en avant
  useEffect(() => {
    if (!focus) return;
    setFv(null);
    let off = false;
    const t = setTimeout(() => {
      tmdb.details(focus.type, focus.id).then((d) => !off && setFv(tmdbView(d, focus.type))).catch(() => {});
    }, 220);
    return () => { off = true; clearTimeout(t); };
  }, [focus && focus.uid]);

  const open = (x) => navigate({ name: 'fiche', item: x.item || null, tmdb: { type: x.type, id: x.id, title: x.title, date: x.date } });
  const filt = (items) => (onlyHome ? items.filter((x) => x.item) : items);

  if (!tmdb.enabled) {
    return (
      <div className="screen-pad">
        <div style={{ marginBottom: 18 }}><DecouvrirTabs current="decouvrir" /></div>
        <h1 className="page-title">Découvrir</h1>
        <p className="muted" style={{ margin: '16px 0 24px', maxWidth: 620, lineHeight: 1.6 }}>
          Cet onglet s'appuie sur TMDB pour explorer tes serveurs : pépites méconnues, sagas, genres et plateformes. Ajoute ta clé TMDB gratuite dans les Réglages.
        </p>
        <button className="btn btn-primary" onClick={() => goRoot({ name: 'settings' })}>Ouvrir les réglages</button>
      </div>
    );
  }

  const allGenres = [...new Map([...genres.movie, ...genres.tv].map((g) => [g.name, g])).values()];
  const shown = saga
    ? [{ title: saga.name, items: saga.parts.map((t) => asItem(t, 'movie', catalog)).sort((a, b) => a.date.localeCompare(b.date)) }]
    : genre ? genreRows : rows || [];

  return (
    <main>
      <section className="hero" style={{ height: 'max(640px, min(74vh, 720px))' }}>
        {focus && <img key={focus.uid} className="hero-bg" src={(fv && fv.backdrop) || focus.backdrop} alt="" />}
        <div className="scrim-left" />
        <div className="scrim-bottom" />
        {!isTV && <div className="vitrine-bar">
          <DecouvrirTabs current="decouvrir" />
          <div className="pills bar-scroll" role="group" aria-label="Genres">
            <button className={'pill' + (!genre && !saga ? ' on' : '')} onClick={() => { setGenre(null); setSaga(null); }}>À la une</button>
            {allGenres.slice(0, 14).map((g) => (
              <button key={g.name} className={'pill' + (genre && genre.name === g.name ? ' on' : '')} onClick={() => { setSaga(null); setGenre(g); }}>{g.name}</button>
            ))}
          </div>
          <div style={{ flex: '1 1 auto' }} />
        </div>}
        {focus && (
          <div className="hero-body" key={focus.uid} style={{ bottom: 110, maxWidth: 760 }}>
            <div className="kicker">{saga ? 'Saga' : genre ? genre.name : 'À découvrir'} · {focus.type === 'tv' ? 'Série' : 'Film'}</div>
            {fv && fv.logo ? <img className="title-logo" src={fv.logo} alt={focus.title} /> : <h1 className="big-title" style={{ fontSize: 'clamp(40px, 4.4vw, 72px)' }}>{focus.title}</h1>}
            <HeroChips x={focus} fv={fv} />
            <p className="synopsis" style={{ fontSize: 17 }}>{focus.overview}</p>
            <div className="actions">
              <button className="btn btn-primary" onClick={() => open(focus)}>Voir la fiche</button>
              {fv && fv.trailer && <span className="muted" style={{ alignSelf: 'center', fontSize: 14 }}>Bande-annonce dans la fiche</span>}
              {!focus.item && <span className="muted" style={{ alignSelf: 'center', fontSize: 14 }}>Pas sur ton serveur</span>}
            </div>
          </div>
        )}
      </section>

      {!rows && <div style={{ position: 'relative', height: 200 }}><Spinner center /></div>}

      <div className="rows" style={{ marginTop: -70 }}>
        {saga && (
          <div style={{ padding: '0 var(--gutter)' }}>
            <button className="btn btn-ghost btn-sm" onClick={() => setSaga(null)}><Icon name="back" size={16} />Toutes les propositions</button>
          </div>
        )}
        {!isTV && !saga && !genre && <PlatformsRow catalog={catalog} logos={logos} tmdb={tmdb} navigate={navigate} />}
        {!isTV && !saga && !genre && (() => {
          const pm = rows ? filt((rows.find((r) => r.kind === 'movie') || { items: [] }).items) : [];
          const ps = rows ? filt((rows.find((r) => r.kind === 'series') || { items: [] }).items) : [];
          if (!pm.length && !ps.length) return null;
          const k = pm.length && ps.length ? pepKind : (pm.length ? 'movie' : 'series');
          const pick = (v) => { setPepKind(v); saveJSON('decPepKind', v); };
          return (
            <Row title="Pépites méconnues" extra={pm.length && ps.length ? (
              <div className="row-pills" role="group" aria-label="Type de titres">
                {[['movie', 'Films'], ['series', 'Séries']].map(([v, l]) => <button key={v} className={k === v ? 'on' : ''} aria-pressed={k === v} onClick={() => pick(v)}>{l}</button>)}
              </div>) : null}>
              {(k === 'movie' ? pm : ps).slice(0, 30).map((x) => (
                <PosterCard key={x.uid} itemKey={x.item.key} title={x.title} poster={x.item.poster || x.poster} item={x.item}
                  focused={focus && focus.uid === x.uid} onFocus={() => x.backdrop && hoverFocus(x)} onOpen={() => open(x)} />
              ))}
            </Row>
          );
        })()}
        {!isTV && !saga && !genre && <DecadesRow catalog={catalog} navigate={navigate} />}
        {shown.filter((r) => isTV || saga || genre || !r.kind).map((r) => {
          const items = filt(r.items);
          if (!items.length) return null;
          return (
            <Row key={r.title} title={r.title}>
              {items.map((x) => (
                <PosterCard key={x.uid} itemKey={x.item && x.item.key} title={x.title} poster={(x.item && x.item.poster) || x.poster} focused={focus && focus.uid === x.uid}
                  item={x.item || undefined} meta={x.item ? undefined : { year: Number(x.date.slice(0, 4)) || 0, rating: x.score || 0, kind: x.type === 'tv' ? 'series' : 'movie' }}
                  onFocus={() => x.backdrop && hoverFocus(x)} onOpen={() => open(x)} />
              ))}
            </Row>
          );
        })}
        {/* v49 : sur la TV aussi, après les pépites */}
        {isTV && !saga && !genre && <PlatformsRow catalog={catalog} logos={logos} tmdb={tmdb} navigate={navigate} />}
        {isTV && !saga && !genre && <DecadesRow catalog={catalog} navigate={navigate} />}
        {!saga && !genre && sagas.length > 0 && (
          <Row title="Les grandes sagas">
            {sagas.map((c) => (
              <CatTile key={c.id} name={c.name.replace(/\s*-\s*Saga$|\s*Collection$|\s*- Collection$/i, '')} image={img(c.backdrop_path, 'w780')}
                onOpen={() => { setSaga(c); const first = c.parts.find((p) => p.backdrop_path); if (first) setFocus(asItem(first, 'movie', catalog)); }} />
            ))}
          </Row>
        )}
        {rows && shown.every((r) => !filt(r.items).length) && <p className="empty">{genre ? 'Rien de ce genre sur ton serveur pour l\'instant.' : 'Rien à afficher avec ce filtre.'}</p>}
        {isTV && allGenres.length > 0 && (
          <section style={{ padding: '10px var(--gutter) 0' }}>
            <h2 className="row-title" style={{ marginBottom: 14 }}>Explorer par genre</h2>
            <div className="genre-grid">
              <button className={'genre-btn' + (!genre && !saga ? ' on' : '')} onClick={() => { setGenre(null); setSaga(null); setTimeout(focusTop, 80); }}>À la une</button>
              {allGenres.map((g) => (
                <button key={g.name} className={'genre-btn' + (genre && genre.name === g.name ? ' on' : '')} onClick={() => { setSaga(null); setGenre(g); setTimeout(focusTop, 300); }}>{g.name}</button>
              ))}
            </div>
          </section>
        )}
      </div>
    </main>
  );
}

// v34 : portes d'entrée vers les plateformes (titres de tes serveurs)
function PlatformsRow({ catalog, logos, tmdb, navigate }) {
  return (
    <Row title="Plateformes">
      {PROVIDERS.map((p) => {
        const count = serverPlatformCount(catalog, p);
        return (
          <Tile key={p.id} name={p.name} logo={logos[p.id]}
            sub={count ? `${count} titres sur ton serveur` : tmdb.enabled ? 'Ce qui est chez toi' : 'Clé TMDB conseillée'}
            onOpen={() => navigate({ name: 'vitrine', provider: p.id })} />
        );
      })}
    </Row>
  );
}

// v34 : explorer les films par décennie, illustrée par le mieux noté de l'époque sur tes serveurs
const DECADES = [2020, 2010, 2000, 1990, 1980, 1970];
function DecadesRow({ catalog, navigate }) {
  // v49 : un seul passage sur le catalogue (au lieu d'un filtre et d'un tri par décennie)
  const tiles = useMemo(() => {
    const acc = new Map(DECADES.map((d) => [d, { d, count: 0, best: null }]));
    for (const m of catalog.vod) {
      const t = m.year >= 1970 ? acc.get(Math.floor(m.year / 10) * 10) : null;
      if (!t) continue;
      t.count++;
      if (m.poster && (!t.best || (m.rating || 0) > (t.best.rating || 0))) t.best = m;
    }
    return [...acc.values()].filter((t) => t.count > 0).map((t) => ({ d: t.d, count: t.count, image: t.best ? t.best.poster : '' }));
  }, [catalog]);
  if (!tiles.length) return null;
  return (
    <Row title="Par décennie">
      {tiles.map((t) => (
        <CatTile key={t.d} name={`Années ${String(t.d).slice(2)} · ${t.count} films`} image={t.image}
          onOpen={() => navigate({ name: 'browse', kind: 'movie', decade: t.d })} />
      ))}
    </Row>
  );
}
