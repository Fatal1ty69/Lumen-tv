import { isTV } from '../tv/native.js';
import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { img, tmdbView } from '../lib/tmdb.js';
import { matchTmdb } from '../lib/catalog.js';
import { Row, PosterCard, CatTile, Spinner, Icon } from '../components/ui.jsx';

const H6 = 6 * 3600 * 1000;
const DAY = 24 * H6 / 6;

// Grandes sagas proposées (identifiants de collections TMDB)
const SAGAS = [10, 1241, 119, 645, 87359, 9485, 2344, 263, 86311, 528, 8091, 10194];

function asItem(t, type, catalog) {
  const mt = t.media_type || type;
  return {
    uid: mt + t.id, type: mt, id: t.id, title: t.title || t.name,
    date: t.release_date || t.first_air_date || '', score: t.vote_average || 0,
    poster: img(t.poster_path), backdrop: img(t.backdrop_path, 'original'), overview: t.overview,
    item: matchTmdb(catalog, t, mt)
  };
}

export default function Decouvrir() {
  const { tmdb, catalog, navigate, goRoot, progress } = useApp();
  const [rows, setRows] = useState(null);
  const [genres, setGenres] = useState({ movie: [], tv: [] });
  const [genre, setGenre] = useState(null);
  const [genreRows, setGenreRows] = useState([]);
  const [sagas, setSagas] = useState([]);
  const [saga, setSaga] = useState(null);
  const [onlyHome, setOnlyHome] = useState(isTV);
  const [focus, setFocus] = useState(null);
  const [fv, setFv] = useState(null);

  // Ce que tu as regardé récemment, pour les recommandations
  const seeds = useMemo(() => {
    const seen = new Set();
    return Object.values(progress)
      .filter((p) => p && p.ref && p.ref.tmdbId && (p.ref.kind === 'movie' || p.ref.kind === 'episode'))
      .sort((a, b) => b.t - a.t)
      .map((p) => ({ type: p.ref.kind === 'movie' ? 'movie' : 'tv', id: p.ref.tmdbId, title: p.ref.title }))
      .filter((s) => (seen.has(s.type + s.id) ? false : seen.add(s.type + s.id)))
      .slice(0, 2);
  }, [progress]);

  useEffect(() => {
    if (!tmdb.enabled) return;
    let off = false;
    const list = (path, type, params = {}, ttl = H6) => tmdb.req(path, { region: 'FR', ...params }, ttl)
      .then((d) => (d.results || d.parts || []).map((t) => asItem(t, type, catalog))).catch(() => []);
    const defs = [
      ...seeds.map((s) => ({ title: `Parce que tu as regardé ${s.title}`, p: list(`/${s.type}/${s.id}/recommendations`, s.type, {}, DAY) })),
      { title: 'Tendances du jour', p: list('/trending/all/day', null) },
      { title: 'Au cinéma en ce moment', p: list('/movie/now_playing', 'movie') },
      { title: 'Bientôt au cinéma', p: list('/movie/upcoming', 'movie') },
      { title: 'Séries diffusées cette semaine', p: list('/tv/on_the_air', 'tv') },
      { title: 'Films populaires', p: list('/movie/popular', 'movie') },
      { title: 'Séries populaires', p: list('/tv/popular', 'tv') },
      { title: 'Les films les mieux notés', p: list('/movie/top_rated', 'movie', {}, DAY) },
      { title: 'Les séries les mieux notées', p: list('/tv/top_rated', 'tv', {}, DAY) }
    ];
    Promise.all(defs.map((d) => d.p)).then((res) => {
      if (off) return;
      const r = defs.map((d, i) => ({ title: d.title, items: res[i].filter((x) => x.title) })).filter((x) => x.items.length);
      setRows(r);
      const firstTrend = r.find((x) => x.title === 'Tendances du jour');
      setFocus((firstTrend || r[0] || { items: [] }).items.find((x) => x.backdrop) || null);
    });
    Promise.all([tmdb.req('/genre/movie/list', {}, 30 * DAY), tmdb.req('/genre/tv/list', {}, 30 * DAY)])
      .then(([m, t]) => !off && setGenres({ movie: m.genres || [], tv: t.genres || [] })).catch(() => {});
    Promise.all(SAGAS.map((id) => tmdb.req(`/collection/${id}`, {}, 30 * DAY).catch(() => null)))
      .then((l) => !off && setSagas(l.filter((c) => c && c.parts && c.parts.length)));
    return () => { off = true; };
  }, [tmdb, catalog, seeds.map((s) => s.type + s.id).join(',')]);

  // Rangées d'un genre
  useEffect(() => {
    if (!genre) { setGenreRows([]); return; }
    let off = false;
    const tvId = genres.tv.find((g) => g.name === genre.name);
    const mvId = genres.movie.find((g) => g.name === genre.name);
    Promise.all([
      mvId ? tmdb.req('/discover/movie', { with_genres: String(mvId.id), sort_by: 'popularity.desc', region: 'FR' }, H6).then((d) => (d.results || []).map((t) => asItem(t, 'movie', catalog))).catch(() => []) : [],
      tvId ? tmdb.req('/discover/tv', { with_genres: String(tvId.id), sort_by: 'popularity.desc' }, H6).then((d) => (d.results || []).map((t) => asItem(t, 'tv', catalog))).catch(() => []) : []
    ]).then(([m, t]) => !off && setGenreRows([
      { title: `Films · ${genre.name}`, items: m },
      { title: `Séries · ${genre.name}`, items: t }
    ].filter((r) => r.items.length)));
    return () => { off = true; };
  }, [genre && genre.name]);

  // Logo et détails du titre mis en avant
  useEffect(() => {
    if (!focus) return;
    setFv(null);
    let off = false;
    const t = setTimeout(() => {
      tmdb.details(focus.type, focus.id).then((d) => !off && setFv(tmdbView(d, focus.type))).catch(() => {});
    }, 220);
    return () => { off = true; clearTimeout(t); };
  }, [focus && focus.uid]);

  const open = (x) => navigate({ name: 'fiche', item: x.item || null, tmdb: { type: x.type, id: x.id, title: x.title, date: x.date } });
  const filt = (items) => (onlyHome ? items.filter((x) => x.item) : items);

  if (!tmdb.enabled) {
    return (
      <div className="screen-pad">
        <h1 className="page-title">Découvrir</h1>
        <p className="muted" style={{ margin: '16px 0 24px', maxWidth: 620, lineHeight: 1.6 }}>
          Cet onglet s'appuie sur TMDB pour te proposer les tendances, les sorties cinéma, les séries du moment, les grandes sagas et des recommandations selon ce que tu regardes. Ajoute ta clé TMDB gratuite dans les Réglages.
        </p>
        <button className="btn btn-primary" onClick={() => goRoot({ name: 'settings' })}>Ouvrir les réglages</button>
      </div>
    );
  }

  const allGenres = [...new Map([...genres.movie, ...genres.tv].map((g) => [g.name, g])).values()];
  const shown = saga
    ? [{ title: saga.name, items: saga.parts.map((t) => asItem(t, 'movie', catalog)).sort((a, b) => a.date.localeCompare(b.date)) }]
    : genre ? genreRows : rows || [];

  return (
    <main>
      <section className="hero" style={{ height: 'max(640px, min(74vh, 720px))' }}>
        {focus && <img key={focus.uid} className="hero-bg" src={(fv && fv.backdrop) || focus.backdrop} alt="" />}
        <div className="scrim-left" />
        <div className="scrim-bottom" />
        <div className="vitrine-bar">
          <div className="pills" role="group" aria-label="Genres" style={{ maxWidth: '100%' }}>
            <button className={'pill' + (!genre && !saga ? ' on' : '')} onClick={() => { setGenre(null); setSaga(null); }}>À la une</button>
            {allGenres.slice(0, 14).map((g) => (
              <button key={g.name} className={'pill' + (genre && genre.name === g.name ? ' on' : '')} onClick={() => { setSaga(null); setGenre(g); }}>{g.name}</button>
            ))}
          </div>
          <div style={{ flex: '1 1 auto' }} />
          {!isTV && <button className={'pill' + (onlyHome ? ' on' : '')} onClick={() => setOnlyHome((v) => !v)} aria-pressed={onlyHome}>Seulement chez moi</button>}
        </div>
        {focus && (
          <div className="hero-body" key={focus.uid} style={{ bottom: 120, maxWidth: 620 }}>
            <div className="kicker">{saga ? 'Saga' : genre ? genre.name : 'Découvrir'} · {focus.type === 'tv' ? 'Série' : 'Film'}{focus.item ? ' · Chez toi' : ''}</div>
            {fv && fv.logo ? <img className="title-logo" src={fv.logo} alt={focus.title} /> : <h1 className="big-title" style={{ fontSize: 'clamp(48px, 6vw, 92px)' }}>{focus.title}</h1>}
            <div className="meta">
              {focus.score > 0 && <span className="score">{focus.score.toFixed(1)}</span>}
              <span>{[focus.date.slice(0, 4), fv && fv.genres.slice(0, 3).join(', '), fv && fv.len].filter(Boolean).join(' · ')}</span>
            </div>
            <p className="synopsis" style={{ fontSize: 17 }}>{focus.overview}</p>
            <div className="actions">
              <button className="btn btn-primary" onClick={() => open(focus)}>Voir la fiche</button>
              {fv && fv.trailer && <span className="muted" style={{ alignSelf: 'center', fontSize: 14 }}>Bande-annonce dans la fiche</span>}
              {!focus.item && <span className="muted" style={{ alignSelf: 'center', fontSize: 14 }}>Pas sur ton serveur</span>}
            </div>
          </div>
        )}
      </section>

      {!rows && <div style={{ position: 'relative', height: 200 }}><Spinner center /></div>}

      <div className="rows" style={{ marginTop: -70 }}>
        {saga && (
          <div style={{ padding: '0 var(--gutter)' }}>
            <button className="btn btn-ghost btn-sm" onClick={() => setSaga(null)}><Icon name="back" size={16} />Toutes les propositions</button>
          </div>
        )}
        {shown.map((r) => {
          const items = filt(r.items);
          if (!items.length) return null;
          return (
            <Row key={r.title} title={r.title}>
              {items.map((x) => (
                <PosterCard key={x.uid} itemKey={x.item && x.item.key} title={x.title} poster={(x.item && x.item.poster) || x.poster}
                  home={!!x.item} focused={focus && focus.uid === x.uid}
                  sub={[x.date.slice(0, 4), x.score ? '★ ' + x.score.toFixed(1) : ''].filter(Boolean).join(' · ')}
                  onFocus={() => x.backdrop && setFocus(x)} onOpen={() => open(x)} />
              ))}
            </Row>
          );
        })}
        {!saga && !genre && sagas.length > 0 && (
          <Row title="Les grandes sagas">
            {sagas.map((c) => (
              <CatTile key={c.id} name={c.name.replace(/\s*-\s*Saga$|\s*Collection$|\s*- Collection$/i, '')} image={img(c.backdrop_path, 'w780')}
                onOpen={() => { setSaga(c); const first = c.parts.find((p) => p.backdrop_path); if (first) setFocus(asItem(first, 'movie', catalog)); }} />
            ))}
          </Row>
        )}
        {rows && shown.every((r) => !filt(r.items).length) && <p className="empty">Rien à afficher avec ce filtre.</p>}
      </div>
    </main>
  );
}
