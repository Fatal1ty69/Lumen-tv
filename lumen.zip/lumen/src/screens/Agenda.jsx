import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { img } from '../lib/tmdb.js';
import { loadJSON, saveJSON } from '../lib/store.js';
import { useMySeries } from '../lib/series.js';
import { dayLabel } from '../lib/epg.js';
import { Icon, Img, Spinner } from '../components/ui.jsx';
import { isTV } from '../tv/native.js';
import TvOptions from '../tv/TvOptions.jsx';

const DAY = 86400000;
const H12 = 12 * 3600 * 1000;

function startOfDay(t) { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }
// Ajout de jours calendaires (sans se tromper aux changements d'heure)
function addDays(t, n) { const d = new Date(t); d.setDate(d.getDate() + n); return d.getTime(); }
function startOfWeek(t) { const d = new Date(startOfDay(t)); return addDays(d.getTime(), -((d.getDay() + 6) % 7)); }

// « Ce soir », « Demain », « Dans 3 jours », « Dans 2 semaines »
function countdown(t) {
  const n = Math.round((startOfDay(t) - startOfDay(Date.now())) / DAY);
  if (n < 0) return n === -1 ? 'Hier' : `Il y a ${-n} jours`;
  if (n === 0) return 'Ce soir';
  if (n === 1) return 'Demain';
  if (n < 14) return `Dans ${n} jours`;
  if (n < 60) return `Dans ${Math.round(n / 7)} semaines`;
  return `Dans ${Math.round(n / 30)} mois`;
}

// Première de saison, final, mi-saison
function badgeOf(e) {
  if (e.type === 'finale' && e.num > 1) return { t: e.isLast ? 'Final de série' : 'Final de saison', c: 'fin' };
  if (e.type === 'mid_season') return { t: 'Mi-saison', c: 'mid' };
  if (e.num === 1) return { t: e.season === 1 ? 'Nouvelle série' : 'Nouvelle saison', c: 'new' };
  return null;
}

const TV_STATUS = { 'Returning Series': 'Renouvelée', 'In Production': 'En production', Planned: 'Annoncée', Ended: 'Terminée', Canceled: 'Annulée', Pilot: 'Pilote' };

// Fichier .ics : à importer dans Google Agenda, Outlook ou le calendrier du téléphone
function exportIcs(list) {
  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (t) => { const d = new Date(t); return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`; };
  const esc = (s) => String(s || '').replace(/[\\;,]/g, (m) => '\\' + m).replace(/\n/g, '\\n');
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Lumen//Agenda//FR', 'CALSCALE:GREGORIAN', 'X-WR-CALNAME:Lumen · mes séries'];
  for (const e of list) {
    lines.push('BEGIN:VEVENT', `UID:${e.id.replace(/[^a-z0-9:]/gi, '')}@lumen`, `DTSTAMP:${ymd(Date.now())}T000000Z`,
      `DTSTART;VALUE=DATE:${ymd(e.date)}`, `DTEND;VALUE=DATE:${ymd(e.date + DAY)}`,
      `SUMMARY:${esc(`${e.s.title} · S${e.season}E${String(e.num).padStart(2, '0')}`)}`,
      `DESCRIPTION:${esc(e.name || '')}`, 'END:VEVENT');
  }
  lines.push('END:VCALENDAR');
  const url = URL.createObjectURL(new Blob([lines.join('\r\n')], { type: 'text/calendar' }));
  const a = document.createElement('a');
  a.href = url; a.download = 'lumen-agenda.ics'; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export default function Agenda() {
  const { tmdb, navigate, reminders, addReminder, removeReminder } = useApp();
  const { list: series } = useMySeries();
  // Séries suivies pour de vrai : dans Ma liste, ou regardées dans l'année
  const followed = useMemo(() => series.filter((s) => s.tmdbId && (s.fav || (s.last || 0) > Date.now() - 365 * DAY)), [series]);
  const [view, setView] = useState(() => { const v = loadJSON('agendaView', 'semaine'); return ['semaine', 'liste', 'mois'].includes(v) ? v : 'semaine'; });
  const [data, setData] = useState(null);
  const [week, setWeek] = useState(() => startOfWeek(Date.now()));
  const [month, setMonth] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1).getTime(); });
  const [day, setDay] = useState(null);
  const [only, setOnly] = useState(() => loadJSON('agendaOnly', 'all'));

  useEffect(() => saveJSON('agendaView', view), [view]);
  useEffect(() => saveJSON('agendaOnly', only), [only]);

  // Épisodes à venir et sortis récemment, via TMDB
  const ids = followed.map((s) => s.key + '=' + s.tmdbId).join(',');
  useEffect(() => {
    if (!tmdb.enabled) { setData({ upcoming: [], recent: [], noDate: [] }); return; }
    let off = false;
    (async () => {
      const today = startOfDay(Date.now());
      const upcoming = [];
      const recent = [];
      const noDate = [];
      await Promise.all(followed.map(async (s) => {
        try {
          const d = await tmdb.req(`/tv/${s.tmdbId}`, {}, H12);
          const poster = s.poster || img(d.poster_path);
          const backdrop = img(d.backdrop_path, 'w1280');
          const onServer = new Set((s.eps || []).map((e) => e.season + ':' + e.num));
          const seasons = new Set();
          if (d.next_episode_to_air && d.next_episode_to_air.air_date) seasons.add(d.next_episode_to_air.season_number);
          if (d.last_episode_to_air && d.last_episode_to_air.air_date) seasons.add(d.last_episode_to_air.season_number);
          if (!d.next_episode_to_air) noDate.push({ s, poster, status: d.status });
          for (const n of seasons) {
            const season = await tmdb.req(`/tv/${s.tmdbId}/season/${n}`, {}, H12).catch(() => ({ episodes: [] }));
            const eps = season.episodes || [];
            for (const e of eps) {
              if (!e.air_date) continue;
              const date = Date.parse(e.air_date + 'T10:00:00');
              const x = {
                id: `${s.key}:${e.season_number}:${e.episode_number}`, s, date, season: e.season_number, num: e.episode_number,
                name: e.name, type: e.episode_type, runtime: e.runtime,
                isLast: d.status === 'Ended' && n === d.number_of_seasons && e.episode_number === eps.length,
                still: img(e.still_path, 'w500') || backdrop || poster, backdrop: backdrop || img(e.still_path, 'w780') || poster, poster,
                onServer: onServer.has(e.season_number + ':' + e.episode_number)
              };
              if (date >= today && date <= today + 180 * DAY) upcoming.push(x);
              else if (date < today && date >= today - 10 * DAY) recent.push(x);
            }
          }
        } catch { /* série inconnue de TMDB */ }
      }));
      const uniq = (l) => [...new Map(l.map((x) => [x.id, x])).values()];
      if (!off) setData({ upcoming: uniq(upcoming).sort((a, b) => a.date - b.date), recent: uniq(recent).sort((a, b) => b.date - a.date), noDate });
    })();
    return () => { off = true; };
  }, [ids, tmdb]);

  // Arrivés récemment sur le serveur
  const arrived = useMemo(() => {
    const out = [];
    const since = Date.now() - 14 * DAY;
    for (const s of series) {
      if (!s.item) continue;
      const fresh = (s.eps || []).filter((e) => e.added > since);
      if (!fresh.length) continue;
      const last = fresh[fresh.length - 1];
      out.push({ s, n: fresh.length, last, added: Math.max(...fresh.map((e) => e.added)) });
    }
    return out.sort((a, b) => b.added - a.added);
  }, [series]);

  const bellFor = (e) => reminders.find((r) => r.type === 'episode' && r.key === e.id);
  const toggleBell = (e) => {
    const r = bellFor(e);
    if (r) removeReminder(r.id);
    else addReminder({ type: 'episode', key: e.id, seriesKey: e.s.key, title: e.s.title, sub: `S${e.season} · É${e.num}${e.name ? ' · ' + e.name : ''}`, start: e.date });
  };
  const open = (s) => (s.item ? navigate({ name: 'fiche', item: s.item }) : null);

  // TV : appui long sur un épisode = rappel ou fiche
  const [agMenu, setAgMenu] = useState(null);
  useEffect(() => {
    if (!isTV) return;
    const on = (ev) => { const el = ev.target.closest && ev.target.closest('[data-ag-id]'); if (el) { ev.preventDefault(); setAgMenu(el.getAttribute('data-ag-id')); } };
    document.addEventListener('tv-longpress', on);
    return () => document.removeEventListener('tv-longpress', on);
  }, []);
  useEffect(() => {
    if (!agMenu) return;
    const on = (ev) => { ev.preventDefault(); setAgMenu(null); };
    window.addEventListener('tv-back', on);
    return () => window.removeEventListener('tv-back', on);
  }, [agMenu]);
  const play = (s) => (s.ref ? navigate({ name: 'player', ref: s.ref, startAt: s.resumeAt || 0 }) : open(s));

  const filt = (l) => (only === 'server' ? l.filter((e) => e.s.item) : l);
  const up = filt((data && data.upcoming) || []);
  const recent = filt((data && data.recent) || []);
  const hero = up[0];
  const loading = tmdb.enabled && (!data || series.some((s) => s.loading));
  const catchup = series.filter((s) => (s.status === 'progress' || s.status === 'fresh') && s.total > s.watchedCount).sort((a, b) => b.last - a.last).slice(0, 8);

  const agE = agMenu && data ? [...(data.upcoming || []), ...(data.recent || [])].find((x) => x.id === agMenu) : null;
  return (
    <div className="screen-pad ag2">
      {agE && (
        <div className="modal tv-quick" data-tv-layer role="dialog" aria-label={agE.s.title} onClick={() => setAgMenu(null)}>
          <div className="modal-inner" onClick={(ev) => ev.stopPropagation()}>
            <h2 className="page-title" style={{ fontSize: 32, marginBottom: 4 }}>{agE.s.title}</h2>
            <p className="muted" style={{ marginBottom: 8 }}>S{agE.season} · É{agE.num}{agE.name ? ' · ' + agE.name : ''} · {dayLabel(agE.date)}</p>
            {agE.date >= startOfDay(Date.now()) && <button className="btn btn-ghost tv-quick-btn" data-tv-autofocus onClick={() => { toggleBell(agE); setAgMenu(null); }}>{bellFor(agE) ? 'Retirer le rappel' : 'Me prévenir le jour de la sortie'}</button>}
            {agE.s.item && <button className="btn btn-ghost tv-quick-btn" {...(agE.date < startOfDay(Date.now()) ? { 'data-tv-autofocus': true } : {})} onClick={() => { setAgMenu(null); open(agE.s); }}>Voir la fiche</button>}
            <button className="btn btn-ghost tv-quick-btn" onClick={() => setAgMenu(null)}>Fermer</button>
          </div>
        </div>
      )}
      <div className="toolbar" style={{ marginBottom: 6 }}>
        <h1 className="page-title" style={{ fontSize: 44, marginRight: 8 }}>Agenda</h1>
        {!isTV && (<>
        <div className="seg" role="group" aria-label="Vue">
          {[['semaine', 'Semaine'], ['liste', 'Liste'], ['mois', 'Mois']].map(([k, l]) => <button key={k} className={view === k ? 'on' : ''} onClick={() => setView(k)}>{l}</button>)}
        </div>
        <div className="seg" role="group" aria-label="Séries">
          <button className={only === 'all' ? 'on' : ''} onClick={() => setOnly('all')}>Toutes mes séries</button>
          <button className={only === 'server' ? 'on' : ''} onClick={() => setOnly('server')}>Sur mon serveur</button>
        </div>
        </>)}
        <span style={{ flex: '1 1 auto' }} />
        {up.length > 0 && !isTV && (
          <button className="btn btn-ghost btn-sm" onClick={() => exportIcs(up)} title="Fichier à importer dans Google Agenda, Outlook ou ton téléphone">
            <Icon name="calendar" size={16} />Exporter vers mon calendrier
          </button>
        )}
      </div>
      <p className="muted" style={{ fontSize: 14, marginBottom: 24 }}>
        {followed.length} série{followed.length > 1 ? 's' : ''} suivie{followed.length > 1 ? 's' : ''} · {up.length} épisode{up.length > 1 ? 's' : ''} à venir. {isTV ? 'Appui long sur OK sur un épisode pour être prévenu le jour de sa sortie.' : 'La cloche pose un rappel le jour de la sortie.'}
      </p>

      {!tmdb.enabled && <p className="empty">Ajoute ta clé TMDB dans les Réglages pour voir les prochains épisodes de tes séries.</p>}
      {tmdb.enabled && loading && !data && <div style={{ position: 'relative', height: 160 }}><Spinner center /></div>}
      {tmdb.enabled && !loading && series.length === 0 && <p className="empty">Regarde une série, ajoute-la à Ma liste ou connecte Trakt pour remplir ton agenda.</p>}

      {hero && (
        <section className="ag-hero">
          <Img src={hero.backdrop} className="cover" title={hero.s.title} />
          <div className="ag-hero-shade" />
          <div className="ag-hero-body">
            <span className="kicker">Prochaine sortie</span>
            <div className="ag-count">{countdown(hero.date)}</div>
            <h2>{hero.s.title}</h2>
            <div className="ag-hero-sub">
              <b>S{hero.season} · É{hero.num}</b>{hero.name ? ' · ' + hero.name : ''}
              <span className="muted"> · {new Date(hero.date).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
            </div>
            <div className="ag-hero-act">
              {badgeOf(hero) && <span className={'ag-badge ' + badgeOf(hero).c}>{badgeOf(hero).t}</span>}
              <button className={'btn btn-sm ' + (bellFor(hero) ? 'btn-primary' : 'btn-ghost')} onClick={() => toggleBell(hero)}>
                <Icon name="bell" size={16} />{bellFor(hero) ? 'Rappel posé' : 'Me prévenir'}
              </button>
              {hero.s.item && <button className="btn btn-ghost btn-sm" onClick={() => open(hero.s)}>Voir la fiche</button>}
            </div>
          </div>
          {up.length > 1 && (
            <div className="ag-hero-next" aria-label="Ensuite">
              <span className="kicker" style={{ fontSize: 11 }}>Ensuite</span>
              {up.slice(1, 4).map((e) => (
                <button key={e.id} onClick={() => open(e.s)}>
                  <Img src={e.poster} className="cover" title={e.s.title} />
                  <span><b>{e.s.title}</b><small>{countdown(e.date)} · S{e.season} · É{e.num}</small></span>
                </button>
              ))}
            </div>
          )}
        </section>
      )}

      {data && view === 'semaine' && <WeekView week={week} setWeek={setWeek} up={up} recent={recent} bellFor={bellFor} toggleBell={toggleBell} open={open} />}

      {data && view === 'liste' && (
        <div className="ag-list">
          {[
            { title: "Aujourd'hui", items: up.filter((e) => startOfDay(e.date) === startOfDay(Date.now())) },
            { title: 'Cette semaine', items: up.filter((e) => startOfDay(e.date) > startOfDay(Date.now()) && e.date < startOfDay(Date.now()) + 7 * DAY) },
            { title: 'Ce mois-ci', items: up.filter((e) => e.date >= startOfDay(Date.now()) + 7 * DAY && e.date < startOfDay(Date.now()) + 31 * DAY) },
            { title: 'Plus tard', items: up.filter((e) => e.date >= startOfDay(Date.now()) + 31 * DAY) }
          ].filter((g) => g.items.length).map((g) => (
            <section key={g.title}>
              <h2 className="row-title" style={{ margin: '8px 0 12px' }}>{g.title} <span className="muted" style={{ fontSize: 15 }}>· {g.items.length}</span></h2>
              {g.items.map((e) => <EpisodeRow key={e.id} e={e} bell={!!bellFor(e)} onBell={() => toggleBell(e)} onOpen={() => open(e.s)} />)}
            </section>
          ))}
          {up.length === 0 && followed.length > 0 && <p className="muted">Aucun épisode annoncé dans les six prochains mois.</p>}
        </div>
      )}

      {data && view === 'mois' && (
        <MonthView month={month} setMonth={setMonth} up={up} day={day} setDay={setDay} bellFor={bellFor} toggleBell={toggleBell} open={open} />
      )}

      {arrived.length > 0 && (
        <section className="ag-sec">
          <h2 className="row-title">Arrivés sur ton serveur <span className="muted" style={{ fontSize: 15 }}>· 14 derniers jours</span></h2>
          <div className="ag-arrived">
            {arrived.map((a) => (
              <div key={a.s.key} className="ag-arr">
                <button className="ag-arr-th" onClick={() => open(a.s)} aria-label={a.s.title} tabIndex={isTV ? -1 : undefined}>
                  <Img src={a.last.still || a.s.poster} className="cover" title={a.s.title} />
                  <span className="ag-arr-n">+{a.n}</span>
                </button>
                <div className="ag-arr-tx">
                  <b>{a.s.title}</b>
                  <span className="muted">{a.n} épisode{a.n > 1 ? 's' : ''} ajouté{a.n > 1 ? 's' : ''} · jusqu'à S{a.last.season} · É{a.last.num}</span>
                  <span className="muted" style={{ fontSize: 12 }}>{dayLabel(a.added)}</span>
                </div>
                {a.s.ref && <button className="btn btn-primary btn-sm" onClick={() => play(a.s)}><Icon name="play" size={14} />S{a.s.next.season} · É{a.s.next.num}</button>}
              </div>
            ))}
          </div>
        </section>
      )}

      {recent.length > 0 && (
        <section className="ag-sec">
          <h2 className="row-title">Sortis ces derniers jours</h2>
          <div className="ag-recent">
            {recent.map((e) => (
              <button key={e.id} className="ag-rc" onClick={() => open(e.s)} disabled={!e.s.item} data-ag-id={e.id}>
                <span className="ag-rc-th"><Img src={e.still} className="cover" title={e.s.title} /></span>
                <b>{e.s.title}</b>
                <span className="muted">S{e.season} · É{e.num} · {dayLabel(e.date)}</span>
                <span className={'ag-avail' + (e.onServer ? ' ok' : '')}>{e.onServer ? 'Dispo sur ton serveur' : e.s.item ? 'Pas encore sur ton serveur' : 'Pas sur ton serveur'}</span>
              </button>
            ))}
          </div>
        </section>
      )}

      {catchup.length > 0 && (
        <section className="ag-sec">
          <h2 className="row-title">À rattraper</h2>
          <div className="ag-catch2">
            {catchup.map((s) => (
              <button key={s.key} className="ag-cu" onClick={() => play(s)}>
                <Img src={s.poster} className="cover" title={s.title} />
                <span className="ag-cu-tx">
                  <b>{s.title}</b>
                  <small>{s.total - s.watchedCount} épisode{s.total - s.watchedCount > 1 ? 's' : ''} à voir{s.next ? ` · reprendre S${s.next.season} · É${s.next.num}` : ''}</small>
                  <span className="ms-bar"><i style={{ width: s.pct + '%' }} /></span>
                </span>
              </button>
            ))}
          </div>
        </section>
      )}

      {isTV && <div style={{ marginTop: 40 }}>
          <TvOptions sections={[
            { label: 'Affichage', value: view, onChange: setView, choices: [['semaine', 'Semaine'], ['liste', 'Liste'], ['mois', 'Mois']] },
            { label: 'Séries', value: only, onChange: setOnly, choices: [['all', 'Toutes mes séries'], ['server', 'Sur mon serveur']] }
          ]} />
      </div>}

      {data && data.noDate.length > 0 && (
        <section className="ag-sec">
          <h2 className="row-title">Pas de date annoncée <span className="muted" style={{ fontSize: 15 }}>· {data.noDate.length}</span></h2>
          <div className="ag-nodate">
            {filt(data.noDate.map((n) => ({ ...n, s: n.s }))).map((n) => (
              <button key={n.s.key} className="card poster" onClick={() => open(n.s)} aria-label={n.s.title}>
                <div className="frame"><Img src={n.poster} className="cover" title={n.s.title} />{TV_STATUS[n.status] && <span className={'ag-st st-' + n.status.split(' ')[0]}>{TV_STATUS[n.status]}</span>}</div>
                <div className="card-sub">{n.s.title}</div>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function EpisodeRow({ e, bell, onBell, onOpen }) {
  const b = badgeOf(e);
  return (
    <div className="ag-row">
      <button className="ag-th" onClick={onOpen} aria-label={e.s.title} tabIndex={isTV ? -1 : undefined}><Img src={e.still} className="cover" title={e.s.title} /></button>
      <button className="ag-tx" onClick={onOpen} data-ag-id={e.id}>
        <span className="kicker" style={{ fontSize: 11 }}>{dayLabel(e.date)} · {countdown(e.date)}</span>
        <b>{e.s.title}</b>
        <span className="muted">S{e.season} · É{e.num}{e.name ? ' · ' + e.name : ''}{e.runtime ? ` · ${e.runtime} min` : ''}</span>
        {(b || !e.s.item) && <span style={{ display: 'flex', gap: 6 }}>{b && <span className={'ag-badge ' + b.c}>{b.t}</span>}{!e.s.item && <span className="ag-badge off">Pas sur ton serveur</span>}</span>}
      </button>
      {isTV ? (bell ? <span className="ag-bell on" style={{ position: 'static' }}><Icon name="bell" size={18} /></span> : null) : <button className={'btn btn-round' + (bell ? ' on' : '')} style={bell ? { borderColor: 'var(--accent)', color: 'var(--accent)' } : undefined}
        onClick={onBell} aria-label={bell ? 'Retirer le rappel' : 'Me prévenir'} title={bell ? 'Rappel posé' : 'Me prévenir le jour J'}>
        <Icon name="bell" size={20} />
      </button>}
    </div>
  );
}

// Deux semaines côte à côte, un jour par colonne
function WeekView({ week, setWeek, up, recent, bellFor, toggleBell, open }) {
  const today = startOfDay(Date.now());
  const days = Array.from({ length: 14 }, (_, i) => addDays(week, i));
  const all = [...recent, ...up];
  const byDay = new Map();
  for (const e of all) {
    const k = startOfDay(e.date);
    if (!byDay.has(k)) byDay.set(k, []);
    byDay.get(k).push(e);
  }
  const end = addDays(week, 13);
  const fmt = (t, o) => new Date(t).toLocaleDateString('fr-FR', o);
  const count = days.reduce((a, t) => a + (byDay.get(t) || []).length, 0);
  return (
    <section className="ag-week">
      <div className="ag-mnav" style={{ marginBottom: 14 }}>
        <button className="icon-btn" onClick={() => setWeek(addDays(week, -7))} aria-label="Semaine précédente"><Icon name="back" /></button>
        <h2 className="page-title" style={{ fontSize: 30, textTransform: 'none' }}>Du {fmt(week, { day: 'numeric', month: new Date(week).getMonth() === new Date(end).getMonth() ? undefined : 'long' })} au {fmt(end, { day: 'numeric', month: 'long' })}</h2>
        <button className="icon-btn" onClick={() => setWeek(addDays(week, 7))} aria-label="Semaine suivante"><Icon name="next" /></button>
        {week !== startOfWeek(Date.now()) && <button className="btn btn-ghost btn-sm" onClick={() => setWeek(startOfWeek(Date.now()))}>Aujourd'hui</button>}
        <span className="muted" style={{ fontSize: 14 }}>{count} épisode{count > 1 ? 's' : ''}</span>
      </div>
      <div className="ag-wgrid">
        {days.map((t) => {
          const items = byDay.get(t) || [];
          const d = new Date(t);
          return (
            <div key={t} className={'ag-wday' + (t === today ? ' today' : '') + (t < today ? ' past' : '') + (items.length ? ' has' : '')}>
              <div className="ag-wd-h"><span>{fmt(t, { weekday: 'short' }).replace('.', '')}</span><b>{d.getDate()}</b></div>
              {items.map((e) => (
                <div key={e.id} className="ag-wep">
                  <button className="ag-wep-th" onClick={() => open(e.s)} aria-label={e.s.title} data-ag-id={e.id}>
                    <Img src={e.still} className="cover" title={e.s.title} />
                    {badgeOf(e) && <span className={'ag-badge sm ' + badgeOf(e).c}>{badgeOf(e).t}</span>}
                  </button>
                  <b title={e.s.title}>{e.s.title}</b>
                  <span className="muted">S{e.season} · É{e.num}</span>
                  {t >= today && isTV
                    ? (bellFor(e) ? <span className="ag-bell on"><Icon name="bell" size={14} /></span> : null)
                    : t >= today
                    ? <button className={'ag-bell' + (bellFor(e) ? ' on' : '')} onClick={() => toggleBell(e)} aria-label={bellFor(e) ? 'Retirer le rappel' : 'Me prévenir'}><Icon name="bell" size={14} /></button>
                    : <span className={'ag-dot' + (e.onServer ? ' ok' : '')} title={e.onServer ? 'Dispo sur ton serveur' : 'Pas encore sur ton serveur'} />}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function MonthView({ month, setMonth, up, day, setDay, bellFor, toggleBell, open }) {
  const m = new Date(month);
  const first = new Date(m.getFullYear(), m.getMonth(), 1);
  const startOffset = (first.getDay() + 6) % 7;
  const daysIn = new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= daysIn; d++) cells.push(new Date(m.getFullYear(), m.getMonth(), d).getTime());
  const byDay = new Map();
  for (const e of up) {
    const k = startOfDay(e.date);
    if (!byDay.has(k)) byDay.set(k, []);
    byDay.get(k).push(e);
  }
  const today = startOfDay(Date.now());
  const dayItems = day ? byDay.get(day) || [] : [];

  return (
    <div className="ag-month">
      <div className="ag-mnav" style={{ marginBottom: 14 }}>
        <button className="icon-btn" onClick={() => setMonth(new Date(m.getFullYear(), m.getMonth() - 1, 1).getTime())} aria-label="Mois précédent"><Icon name="back" /></button>
        <h2 className="page-title" style={{ fontSize: 34 }}>{m.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}</h2>
        <button className="icon-btn" onClick={() => setMonth(new Date(m.getFullYear(), m.getMonth() + 1, 1).getTime())} aria-label="Mois suivant"><Icon name="next" /></button>
      </div>
      <div className="ag-cal">
        {['lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.', 'dim.'].map((d) => <div key={d} className="ag-dow">{d}</div>)}
        {cells.map((t, i) => {
          if (!t) return <div key={'x' + i} />;
          const items = byDay.get(t) || [];
          return (
            <button key={t} className={'ag-day' + (t === today ? ' today' : '') + (t === day ? ' sel' : '') + (items.length ? ' has' : '')}
              onClick={() => setDay(t === day ? null : t)} aria-label={`${new Date(t).getDate()}, ${items.length} épisode(s)`}>
              <span className="n">{new Date(t).getDate()}</span>
              {items[0] && <Img src={items[0].poster} className="cover" />}
              {items.length > 1 && <span className="more">+{items.length - 1}</span>}
            </button>
          );
        })}
      </div>
      {day && (
        <div style={{ marginTop: 20 }}>
          <h3 className="row-title" style={{ marginBottom: 10 }}>{dayLabel(day)}</h3>
          {dayItems.length === 0 && <p className="muted">Rien ce jour-là.</p>}
          {dayItems.map((e) => <EpisodeRow key={e.id} e={e} bell={!!bellFor(e)} onBell={() => toggleBell(e)} onOpen={() => open(e.s)} />)}
        </div>
      )}
    </div>
  );
}
