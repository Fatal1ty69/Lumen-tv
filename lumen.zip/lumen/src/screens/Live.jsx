import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { attachSource, hhmm } from '../lib/player.js';
import { liveRef, replayRef } from '../lib/play.js';
import { norm } from '../lib/titles.js';
import { pickVariant, rememberVariant, variantLabel } from '../lib/live.js';
import { getEpg, nowNext, canReplay, dayLabel } from '../lib/epg.js';
import { cached, loadJSON, saveJSON } from '../lib/store.js';
import { img } from '../lib/tmdb.js';
import { BellDialog } from '../lib/reminders.jsx';
import Mosaic from '../components/Mosaic.jsx';
import { isTV } from '../tv/native.js';
import { focusEl } from '../tv/spatial.js';
import { Icon, Img, Spinner } from '../components/ui.jsx';

const PPM = 6; // pixels par minute dans la grille
const MIN = 60000;

// Charge le guide de plusieurs chaînes, au fil de l'eau
function useEpgs(xtOf, chans) {
  const [map, setMap] = useState({});
  const keys = chans.map((c) => c.key).join(',');
  useEffect(() => {
    let off = false;
    chans.forEach((c) => {
      getEpg(xtOf(c.acc), c).then((list) => !off && setMap((m) => (m[c.key] === list ? m : { ...m, [c.key]: list }))).catch(() => {});
    });
    return () => { off = true; };
  }, [keys]);
  return map;
}

function useNow(ms = 30000) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), ms); return () => clearInterval(t); }, [ms]);
  return now;
}

// Image d'un programme (films et séries reconnus sur TMDB)
function cleanProg(t) {
  return String(t || '').replace(/^(film|série|serie|téléfilm|telefilm|documentaire)\s*:\s*/i, '').replace(/\(?S\d+\s*E\d+\)?/i, '').replace(/\s*-\s*épisode.*$/i, '').trim();
}
function useProgImage(tmdb, title) {
  const [src, setSrc] = useState('');
  useEffect(() => {
    setSrc('');
    const q = cleanProg(title);
    if (!tmdb.enabled || q.length < 3) return;
    let off = false;
    cached('progimg:' + norm(q), 7 * 24 * 3600 * 1000, async () => {
      const d = await tmdb.req('/search/multi', { query: q }, 7 * 24 * 3600 * 1000);
      const hit = (d.results || []).find((r) => r.backdrop_path && norm(r.title || r.name) === norm(q));
      return hit ? img(hit.backdrop_path, 'w780') : '';
    }).then((u) => !off && setSrc(u)).catch(() => {});
    return () => { off = true; };
  }, [title, tmdb]);
  return src;
}

export default function Live({ active }) {
  const { catalog, xt, xtOf, tmdb, navigate, favorites, toggleFav, settings, updateSettings, reminders, goRoot, account } = useApp();
  const [view, setView] = useState(() => { const v = loadJSON('liveView', 'liste'); return isTV && (v === 'mosaique' || v === 'images') ? 'liste' : v; });
  const [cat, setCat] = useState(() => loadJSON('liveCat', catalog.liveCats[0] ? catalog.liveCats[0].id : ''));
  const [q, setQ] = useState('');
  const [selKey, setSelKey] = useState(null);
  const [bell, setBell] = useState(null);

  // TV : au retour du lecteur, on se place sur la chaîne regardée en dernier
  useEffect(() => {
    if (!isTV) return;
    const on = (e) => {
      const key = e.detail && e.detail.key;
      const g = key && catalog.byKey.get(key);
      if (!g) return;
      if (!(cat === '__fav' && favorites[key])) setCat(g.cat);
      setQ('');
      setSelKey(key);
      setTimeout(() => {
        const el = document.querySelector(`.chan[data-key="${CSS.escape(key)}"]`);
        if (el) focusEl(el);
      }, 120);
    };
    window.addEventListener('lumen:live-return', on);
    return () => window.removeEventListener('lumen:live-return', on);
  }, [catalog, cat, favorites]);
  const [pickTick, setPickTick] = useState(0);
  const now = useNow();

  useEffect(() => saveJSON('liveView', view), [view]);
  useEffect(() => saveJSON('liveCat', cat), [cat]);
  useEffect(() => {
    if (cat !== '__fav' && !catalog.liveCats.some((c) => c.id === cat)) setCat(catalog.liveCats[0] ? catalog.liveCats[0].id : '__fav');
  }, [catalog]);

  const counts = useMemo(() => {
    const m = new Map();
    for (const g of catalog.liveGroups) m.set(g.cat, (m.get(g.cat) || 0) + 1);
    return m;
  }, [catalog]);

  const groups = useMemo(() => {
    const n = norm(q);
    if (n) return catalog.liveGroups.filter((g) => norm(g.name).includes(n)).slice(0, 300);
    if (cat === '__fav') return catalog.liveGroups.filter((g) => favorites[g.key]);
    return catalog.liveGroups.filter((g) => g.cat === cat);
  }, [catalog, cat, q, favorites]);

  // Variante retenue pour chaque groupe
  const chosen = useMemo(() => {
    const m = {};
    for (const g of groups) m[g.key] = pickVariant(g, settings.liveQuality);
    return m;
  }, [groups, settings.liveQuality, pickTick]);

  const visible = groups.slice(0, view === 'liste' ? 400 : 80);
  const epgChans = view === 'liste' ? (selKey && chosen[selKey] ? [chosen[selKey]] : []) : visible.map((g) => chosen[g.key]);
  const epgs = useEpgs(xtOf, epgChans.filter(Boolean));

  const listKeys = groups.map((g) => g.key);
  const playLive = (g) => navigate({ name: 'player', ref: liveRef(chosen[g.key], listKeys, g) });
  const playReplay = (g, prog) => navigate({ name: 'player', ref: replayRef(chosen[g.key], prog, g) });
  const onProg = (g, prog) => {
    const ch = chosen[g.key];
    if (prog.start <= now && prog.end > now) return playLive(g);
    if (prog.end <= now) { if (canReplay(ch, prog, now)) playReplay(g, prog); return; }
    setBell({ prog, ch, group: g });
  };
  const hasBell = (g, prog) => reminders.some((r) => r.chKey === g.key && r.start === prog.start);

  return (
    <div className="screen-pad" style={{ paddingBottom: 20 }}>
      <div className="toolbar" style={{ marginBottom: 18 }}>
        <h1 className="page-title" style={{ fontSize: 44, marginRight: 8 }}>Direct</h1>
        <div className="seg" role="group" aria-label="Vue">
          {[['liste', 'Liste'], ['grille', 'Guide'], ...(isTV ? [] : [['images', 'Guide en images'], ['mosaique', 'Mosaïque']])].map(([k, l]) => (
            <button key={k} className={view === k ? 'on' : ''} onClick={() => setView(k)}>{l}</button>
          ))}
        </div>
        {!isTV && (
          <div className="field">
            <Icon name="search" size={18} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Chercher une chaîne" aria-label="Chercher une chaîne" />
          </div>
        )}
        <span className="muted" style={{ fontSize: 14 }}>{groups.length} chaînes</span>
      </div>

      <div className="live-layout">
        <aside className="side live-cats" aria-label="Groupes de chaînes">
          {!isTV && <button className="manage-link" onClick={() => goRoot({ name: 'settings', anchor: 'groupes' })}><Icon name="gear" size={14} />Gérer les groupes</button>}
          <button className={cat === '__fav' && !q ? 'on' : ''} onClick={() => { setCat('__fav'); setQ(''); }}>
            Favoris <span>{catalog.liveGroups.filter((g) => favorites[g.key]).length}</span>
          </button>
          {catalog.liveCats.map((c) => (
            <button key={c.id} className={cat === c.id && !q ? 'on' : ''} onClick={() => { setCat(c.id); setQ(''); }}>
              {c.name}<span>{counts.get(c.id) || 0}</span>
            </button>
          ))}
        </aside>

        <div style={{ flex: '999 1 600px', minWidth: 0 }}>
          {view === 'liste' && (
            <ListView groups={visible} chosen={chosen} selKey={selKey} setSelKey={setSelKey} epgs={epgs} now={now}
              active={active} onPlay={playLive} onProg={onProg} hasBell={hasBell}
              onPick={(g, ch) => { rememberVariant(g, ch); setPickTick((t) => t + 1); }}
              favorites={favorites} toggleFav={toggleFav} />
          )}
          {view === 'grille' && <GridView groups={visible} chosen={chosen} epgs={epgs} now={now} onProg={onProg} hasBell={hasBell} onPlay={playLive} />}
          {view === 'mosaique' && (
            <>
              <div className="toolbar" style={{ marginBottom: 10 }}>
                <span style={{ fontSize: 14 }}>Chaînes en direct permanent</span>
                <div className="seg" role="group" aria-label="Chaînes en direct permanent">
                  {[0, 1, 2, 3].map((n) => (
                    <button key={n} className={(settings.mosaicLive || 0) === n ? 'on' : ''} disabled={account && account.maxConn && n + 1 > account.maxConn}
                      onClick={() => updateSettings({ mosaicLive: n })}>{n === 0 ? 'Aucune' : n}</button>
                  ))}
                </div>
              </div>
              <Mosaic xtOf={xtOf} groups={visible} chosen={chosen} epgs={epgs} now={now} onPlay={playLive}
                liveCount={Math.min(settings.mosaicLive || 0, account && account.maxConn ? Math.max(0, account.maxConn - 1) : 3)} maxConn={account && account.maxConn} />
            </>
          )}
          {view === 'images' && <ImagesView groups={visible} chosen={chosen} epgs={epgs} now={now} onPlay={playLive} tmdb={tmdb} />}
          {groups.length === 0 && <p className="empty">Aucune chaîne ici.</p>}
        </div>
      </div>
      {bell && <BellDialog prog={bell.prog} ch={bell.ch} group={bell.group} onClose={() => setBell(null)} />}
    </div>
  );
}

function QualityPills({ group, current, onPick }) {
  if (!group || group.variants.length < 2) return null;
  return (
    <div className="qpills" role="group" aria-label="Qualité">
      {group.variants.map((v) => (
        <button key={v.ch.key} className={v.ch.key === current.key ? 'on' : ''} onClick={(e) => { e.stopPropagation(); onPick(group, v.ch); }}
          title={v.ch.name}>{variantLabel(group, v)}</button>
      ))}
    </div>
  );
}

function ListView({ groups, chosen, selKey, setSelKey, epgs, now, active, onPlay, onProg, hasBell, onPick, favorites, toggleFav }) {
  const { xtOf } = useApp();
  const video = useRef(null);
  const [state, setState] = useState('idle');
  const [day, setDay] = useState(0);
  const sel = groups.find((g) => g.key === selKey) || null;
  const ch = sel ? chosen[sel.key] : null;

  useEffect(() => {
    // Sur la TV, pas d'aperçu : il occuperait la connexion du serveur et ralentirait le plein écran
    if (isTV || !ch || !active || !video.current) return;
    setState('loading');
    const v = video.current;
    const src = attachSource(v, xtOf(ch.acc).liveUrl(ch.id, 'ts'), { live: true, onFatal: () => setState('error') });
    const onPlay2 = () => setState('playing');
    v.addEventListener('playing', onPlay2);
    v.play().catch(() => {});
    return () => { v.removeEventListener('playing', onPlay2); src.destroy(); };
  }, [ch && ch.key, active]);

  useEffect(() => setDay(0), [selKey]);

  const progs = (ch && epgs[ch.key]) || [];
  const days = [...new Set(progs.map((p) => new Date(p.start).toDateString()))];
  const todayIdx = Math.max(0, days.indexOf(new Date().toDateString()));
  const dayStr = days[todayIdx + day];
  const dayProgs = dayStr ? progs.filter((p) => new Date(p.start).toDateString() === dayStr) : progs;
  const listRef = useRef(null);
  useEffect(() => {
    const el = listRef.current && listRef.current.querySelector('.epg-item.now');
    if (el) el.scrollIntoView({ block: 'center' });
  }, [ch && ch.key, progs.length, day]);

  return (
    <div className="live-list">
      <div className="live-col">
        {groups.map((g) => {
          const c = chosen[g.key];
          const nn = nowNext(epgs[c.key] || [], now);
          return (
            <button key={g.key} data-key={g.key} className={'chan' + (selKey === g.key ? ' on' : '')}
              onClick={() => (isTV || selKey === g.key ? onPlay(g) : setSelKey(g.key))}
              onFocus={isTV ? () => setSelKey(g.key) : undefined}
              title={selKey === g.key ? 'Cliquer pour le plein écran' : undefined}>
              <span className="no">{g.num}</span>
              <span className="lg"><Img src={g.logo} fit="contain" /></span>
              <span className="nm">{g.name}</span>
              {g.variants.length > 1 && <span className="qtag">{g.variants.length} qualités</span>}
              {nn.now && <span className="nowline">{nn.now.title}</span>}
            </button>
          );
        })}
      </div>

      <div className="live-col" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {isTV ? (
          <div className="preview tv-prev">
            {sel ? <><span className="lg"><Img src={sel.logo} fit="contain" /></span><span className="muted">OK pour regarder · dans le lecteur, OK affiche la liste des chaînes</span></> : <div className="hint">Choisis une chaîne avec les flèches, puis OK.</div>}
          </div>
        ) : (
        <div className="preview" onClick={() => sel && onPlay(sel)} style={{ cursor: sel ? 'pointer' : 'default' }}>
          <video ref={video} playsInline />
          {!sel && <div className="hint">Choisis une chaîne pour l'aperçu.<br />Clique une deuxième fois dessus pour le plein écran.</div>}
          {sel && state === 'loading' && <Spinner center />}
          {sel && state === 'error' && <div className="hint">Ce flux ne passe pas dans l'aperçu. Essaie le plein écran.</div>}
        </div>
        )}
        {sel && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <h2 style={{ fontSize: 22, flex: '1 1 auto', minWidth: 0 }}>{sel.name}</h2>
              <QualityPills group={sel} current={ch} onPick={onPick} />
              <button className={'btn btn-round' + (favorites[sel.key] ? ' on' : '')} style={{ width: 42, height: 42 }}
                onClick={() => toggleFav({ key: sel.key, kind: 'group', id: sel.key, title: sel.name, poster: sel.logo })} aria-label="Favori">
                <Icon name={favorites[sel.key] ? 'check' : 'plus'} size={18} />
              </button>
              <button className="btn btn-primary btn-sm" onClick={() => onPlay(sel)}><Icon name="full" size={16} />Plein écran</button>
            </div>
            {ch.archive && <div className="muted" style={{ fontSize: 13 }}>Replay disponible sur {ch.archiveDays || 1} jour{ch.archiveDays > 1 ? 's' : ''} : clique sur un programme passé pour le revoir.</div>}
            {days.length > 1 && (
              <div className="pills">
                {days.map((d, i) => (
                  <button key={d} className={'pill' + (i === todayIdx + day ? ' on' : '')} onClick={() => setDay(i - todayIdx)}>{dayLabel(new Date(d).getTime())}</button>
                ))}
              </div>
            )}
            <div ref={listRef} style={{ overflowY: 'auto', minHeight: 0, flex: '1 1 auto' }}>
              {progs.length === 0 && <p className="muted" style={{ fontSize: 14 }}>Pas de guide des programmes pour cette chaîne.</p>}
              {dayProgs.map((p) => {
                const isNow = p.start <= now && p.end > now;
                const past = p.end <= now;
                const rep = past && canReplay(ch, p, now);
                return (
                  <button key={p.id + p.start} className={'epg-item' + (isNow ? ' now' : '') + (past && !rep ? ' past' : '')} onClick={() => onProg(sel, p)}>
                    <div className="tm">
                      {isNow ? 'EN COURS · ' : ''}{hhmm(p.start)} – {hhmm(p.end)}
                      {rep && <span className="tag">REVOIR</span>}
                      {!past && !isNow && <span className={'tag bell' + (hasBell(sel, p) ? ' on' : '')}><Icon name="bell" size={12} />{hasBell(sel, p) ? 'Rappel posé' : 'Rappel'}</span>}
                    </div>
                    <b>{p.title}</b>
                    {isNow && <div className="epg-prog"><i style={{ width: ((now - p.start) / (p.end - p.start)) * 100 + '%' }} /></div>}
                    {p.desc && (isNow || !past) && <p>{p.desc}</p>}
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function GridView({ groups, chosen, epgs, now, onProg, hasBell, onPlay }) {
  const scroller = useRef(null);
  const maxArchive = Math.min(3, Math.max(0, ...groups.map((g) => (chosen[g.key].archive ? chosen[g.key].archiveDays || 1 : 0))));
  const t0 = Math.floor((now - Math.max(2, maxArchive * 24) * 60 * MIN) / (30 * MIN)) * 30 * MIN;
  const t1 = now + 12 * 60 * MIN;
  const width = ((t1 - t0) / MIN) * PPM;
  const slots = [];
  for (let t = t0; t <= t1; t += 30 * MIN) slots.push(t);

  useEffect(() => {
    if (scroller.current) scroller.current.scrollLeft = ((now - t0) / MIN) * PPM - 120;
  }, [groups.length]);

  const x = (t) => ((t - t0) / MIN) * PPM;
  return (
    <div className="grid-epg" ref={scroller}>
      <div style={{ width: width + 220, position: 'relative' }}>
        <div className="ge-head">
          <div className="ge-corner">{dayLabel(now)}</div>
          <div style={{ position: 'relative', width, height: 36 }}>
            {slots.map((t) => (
              <span key={t} className="ge-slot" style={{ left: x(t) }}>
                {new Date(t).getHours() === 0 && new Date(t).getMinutes() === 0 ? dayLabel(t).slice(0, 3) + ' ' : ''}{hhmm(t)}
              </span>
            ))}
          </div>
        </div>
        {groups.map((g) => {
          const ch = chosen[g.key];
          const progs = (epgs[ch.key] || []).filter((p) => p.end > t0 && p.start < t1);
          return (
            <div className="ge-row" key={g.key}>
              <button className="ge-ch" onClick={() => onPlay(g)} title={'Regarder ' + g.name}>
                <span className="lg"><Img src={g.logo} fit="contain" /></span>
                <span className="nm">{g.name}</span>
              </button>
              <div style={{ position: 'relative', width, height: 64 }}>
                {progs.length === 0 && <div className="ge-empty" style={{ left: x(Math.max(t0, now - 60 * MIN)), width: 180 * PPM }}>Pas de guide</div>}
                {progs.map((p) => {
                  const left = Math.max(0, x(p.start));
                  const w = Math.max(4, x(Math.min(p.end, t1)) - left - 3);
                  const isNow = p.start <= now && p.end > now;
                  const past = p.end <= now;
                  const rep = past && canReplay(ch, p, now);
                  return (
                    <button key={p.id + p.start} className={'ge-prog' + (isNow ? ' now' : '') + (past ? ' past' : '') + (rep ? ' rep' : '')}
                      style={{ left, width: w }} onClick={() => onProg(g, p)}
                      title={`${hhmm(p.start)} – ${hhmm(p.end)} · ${p.title}${rep ? ' · Revoir' : ''}`}>
                      <b>{p.title}</b>
                      <span>{hhmm(p.start)}{rep ? ' · Revoir' : ''}{hasBell(g, p) ? ' · rappel posé' : ''}</span>
                      {isNow && <i className="ge-bar" style={{ width: ((now - p.start) / (p.end - p.start)) * 100 + '%' }} />}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
        <div className="ge-now" style={{ left: 220 + x(now) }} />
      </div>
    </div>
  );
}

function ImageCard({ g, ch, progs, now, onPlay, tmdb }) {
  const nn = nowNext(progs, now);
  const pic = useProgImage(tmdb, nn.now && nn.now.title);
  return (
    <button className="card img-card" onClick={() => onPlay(g)} aria-label={`${g.name}${nn.now ? ', ' + nn.now.title : ''}`}>
      <div className="frame">
        {pic ? <img className="cover" src={pic} alt="" /> : <div className="img-logo"><Img src={g.logo} fit="contain" title={g.name} /></div>}
        <div className="shade" />
        <span className="img-ch"><Img src={g.logo} fit="contain" /></span>
        {ch.archive && <span className="badge home" style={{ top: 10 }}>REPLAY</span>}
        <div className="img-txt">
          <span className="kicker" style={{ fontSize: 11 }}>{g.name}</span>
          <b>{nn.now ? nn.now.title : 'Programme inconnu'}</b>
          {nn.now && <span className="muted">{hhmm(nn.now.start)} – {hhmm(nn.now.end)}</span>}
        </div>
        {nn.now && <div className="bar"><i style={{ width: ((now - nn.now.start) / (nn.now.end - nn.now.start)) * 100 + '%' }} /></div>}
      </div>
      <div className="card-sub">{nn.next ? `Ensuite ${hhmm(nn.next.start)} · ${nn.next.title}` : ' '}</div>
    </button>
  );
}

function ImagesView({ groups, chosen, epgs, now, onPlay, tmdb }) {
  return (
    <div className="img-grid">
      {groups.map((g) => (
        <ImageCard key={g.key} g={g} ch={chosen[g.key]} progs={epgs[chosen[g.key].key] || []} now={now} onPlay={onPlay} tmdb={tmdb} />
      ))}
    </div>
  );
}
