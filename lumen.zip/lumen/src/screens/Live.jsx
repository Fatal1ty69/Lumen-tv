import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { attachSource, hhmm } from '../lib/player.js';
import { liveRef, replayRef } from '../lib/play.js';
import { norm } from '../lib/titles.js';
import { pickVariant, rememberVariant, forgetVariant, variantLabel } from '../lib/live.js';
import { getEpg, getCachedEpg, nowNext, canReplay, dayLabel } from '../lib/epg.js';
import { resolveMediaUrl } from '../lib/media.js';
import { cached, loadJSON, saveJSON } from '../lib/store.js';
import { img } from '../lib/tmdb.js';
import { BellDialog } from '../lib/reminders.jsx';
import Mosaic from '../components/Mosaic.jsx';
import { isTV } from '../tv/native.js';
import TvOptions from '../tv/TvOptions.jsx';
import { focusEl } from '../tv/spatial.js';
import { previewShow, previewStop, previewKey } from '../tv/preview.js';
import { Icon, Img, Spinner, EmptyState } from '../components/ui.jsx';
import SideMine from '../components/SideMine.jsx';
import { useEpgs, useNow, ImageCard, ImageRow } from '../components/LiveShared.jsx';
// v28 : ces outils vivent dans LiveShared.jsx pour que l'accueil puisse les utiliser sans charger tout le Direct
export { useEpgs, useNow, ImageCard };

const PPM = 6; // pixels par minute dans la grille
const MIN = 60000;
const LIVE_VIEWS = new Set(['liste', 'grille', 'images', 'mosaique']);

// Garde-fou de démarrage : l'EPG de masse ne part qu'après le premier média.
// Le listener reste actif même quand Direct est démonté pendant le plein écran.
let directMediaStarted = false;
if (typeof window !== 'undefined') window.addEventListener('lumen:media-started', () => { directMediaStarted = true; });

// Une vue avancée ne doit jamais pouvoir condamner tout l'écran Direct. Cette
// frontière intercepte les erreurs de rendu React (Mosaïque, guide, images) et
// demande immédiatement au parent de revenir à la Liste.
class LiveModeBoundary extends React.Component {
  constructor(props) { super(props); this.state = { error: null }; }
  static getDerivedStateFromError(error) { return { error }; }
  componentDidCatch(error, info) {
    console.error('[Lumen] Vue Direct désactivée après une erreur', this.props.mode, error, info);
    if (this.props.onFail) this.props.onFail(error);
  }
  render() {
    if (this.state.error) return (
      <div className="live-recovery">
        <Spinner />
        <span>Récupération de la vue Direct standard…</span>
      </div>
    );
    return this.props.children;
  }
}

export function safeLiveView(saved, pending, tv = isTV) {
  if (pending || !LIVE_VIEWS.has(saved)) return 'liste';
  // v49 : sur la TV, le guide en images est disponible ; la mosaïque (plusieurs vidéos à la fois) reste réservée au PC
  return tv && saved === 'mosaique' ? 'liste' : saved;
}

export function playableLiveGroups(groups, chosen) {
  return (groups || []).filter((g) => g && chosen && chosen[g.key] && chosen[g.key].key);
}

function storedLiveView() {
  const pending = loadJSON('liveViewPending', null);
  const saved = loadJSON('liveView', 'liste');
  const safe = safeLiveView(saved, pending);
  // Si l'application a été interrompue avant que la vue choisie soit validée,
  // le prochain passage repart obligatoirement sur la vue robuste.
  if (safe !== saved || pending) {
    saveJSON('liveViewPending', null);
    saveJSON('liveView', safe);
  }
  return safe;
}

// Charge le guide de plusieurs chaînes, au fil de l'eau
export default function Live({ active }) {
  const { catalog, xt, xtOf, tmdb, navigate, favorites, toggleFav, settings, updateSettings, reminders, goRoot, account, refreshCatalog } = useApp();
  const [view, setView] = useState(storedLiveView);
  const [viewNotice, setViewNotice] = useState('');
  const [cat, setCat] = useState(() => loadJSON('liveCat', catalog.liveCats[0] ? catalog.liveCats[0].id : ''));
  const [q, setQ] = useState('');
  const [selKey, setSelKey] = useState(null);
  const [bell, setBell] = useState(null);
  const [epgNetwork, setEpgNetwork] = useState(false);
  // « Récentes » : relu à chaque retour sur le Direct, et vidable
  const [recentVer, setRecentVer] = useState(0);
  const recentKeys = useMemo(() => loadJSON('recentLive', []), [recentVer, active]);
  const clearRecent = () => { saveJSON('recentLive', []); setRecentVer((v) => v + 1); };

  // TV : au retour du lecteur, on se place sur la chaîne regardée en dernier
  useEffect(() => {
    if (!isTV) return;
    const on = (e) => {
      const key = e.detail && e.detail.key;
      const g = key && catalog.byKey.get(key);
      if (!g) return;
      if (!(cat === '__fav' && favorites[key])) setCat(g.cat);
      setQ('');
      setSelKey(key);
      setTimeout(() => {
        const el = document.querySelector(`.chan[data-key="${CSS.escape(key)}"]`);
        if (el) focusEl(el);
      }, 120);
    };
    window.addEventListener('lumen:live-return', on);
    return () => window.removeEventListener('lumen:live-return', on);
  }, [catalog, cat, favorites]);
  const [pickTick, setPickTick] = useState(0);
  useEffect(() => {
    const on = () => setPickTick((t) => t + 1);
    window.addEventListener('lumen:pick', on);
    return () => window.removeEventListener('lumen:pick', on);
  }, []);
  const now = useNow();
  useEffect(() => {
    if (!directMediaStarted) return undefined;
    const t = setTimeout(() => setEpgNetwork(true), 1800);
    return () => clearTimeout(t);
  }, [active]);
  const markMediaStarted = React.useCallback(() => {
    directMediaStarted = true;
    window.dispatchEvent(new CustomEvent('lumen:media-started', { detail: { kind: 'live' } }));
    setTimeout(() => setEpgNetwork(true), 2500);
  }, []);

  const recoverView = React.useCallback((reason = '') => {
    saveJSON('liveViewPending', null);
    saveJSON('liveView', 'liste');
    setView('liste');
    setViewNotice(reason || 'La vue choisie a rencontré un problème. Lumen est revenu automatiquement à la Liste.');
  }, []);
  // v42/v49 : présentation du guide en images (Liste ou Grille de 3), mémorisée, réglable aussi depuis la TV
  const [imgMode, setImgMode] = useState(() => loadJSON('liveImgMode', 'liste'));
  const pickImgMode = (m) => { setImgMode(m); saveJSON('liveImgMode', m); };
  const selectView = React.useCallback((next) => {
    const safe = LIVE_VIEWS.has(next) ? next : 'liste';
    setViewNotice('');
    if (safe === 'liste') {
      saveJSON('liveViewPending', null);
      saveJSON('liveView', 'liste');
    } else {
      // Marqueur de transaction : il n'est effacé qu'après un rendu réussi.
      saveJSON('liveViewPending', { mode: safe, t: Date.now() });
    }
    setView(safe);
  }, []);
  useEffect(() => {
    // Arrivé ici, React a rendu et validé la vue sans déclencher la frontière.
    const t = setTimeout(() => {
      saveJSON('liveView', view);
      saveJSON('liveViewPending', null);
    }, 250);
    return () => clearTimeout(t);
  }, [view]);
  useEffect(() => {
    if (view === 'liste') return undefined;
    const fail = (event) => {
      const msg = event && event.reason && event.reason.message || event && event.message || '';
      recoverView(`La vue « ${view} » a été désactivée après une erreur${msg ? ` : ${msg}` : '.'}`);
    };
    window.addEventListener('error', fail);
    window.addEventListener('unhandledrejection', fail);
    return () => {
      window.removeEventListener('error', fail);
      window.removeEventListener('unhandledrejection', fail);
    };
  }, [view, recoverView]);
  useEffect(() => saveJSON('liveCat', cat), [cat]);
  useEffect(() => {
    if (!['__all', '__fav', '__recent'].includes(cat) && !catalog.liveCats.some((c) => c.id === cat)) setCat(catalog.liveCats[0] ? catalog.liveCats[0].id : '__fav');
  }, [catalog]);

  const counts = useMemo(() => {
    const m = new Map();
    for (const g of catalog.liveGroups) m.set(g.cat, (m.get(g.cat) || 0) + 1);
    return m;
  }, [catalog]);

  const groups = useMemo(() => {
    const n = norm(q);
    if (n) return catalog.liveGroups.filter((g) => norm(g.name).includes(n)).slice(0, 300);
    if (cat === '__all') return catalog.liveGroups;
    if (cat === '__fav') return catalog.liveGroups.filter((g) => favorites[g.key]);
    if (cat === '__recent') {
      return recentKeys.map((key) => catalog.byKey.get(key)).filter(Boolean);
    }
    return catalog.liveGroups.filter((g) => g.cat === cat);
  }, [catalog, cat, q, favorites, recentKeys]);
  useEffect(() => {
    if (!groups.length) { setSelKey(null); return; }
    // PC : aucune chaîne n'est pré-lancée sans action de l'utilisateur. Cela
    // évite un create_link inutile juste avant qu'il clique sur une autre chaîne.
    if (!groups.some((g) => g.key === selKey)) setSelKey(isTV ? groups[0].key : null);
  }, [cat, q, groups.length]);

  // Variante retenue pour chaque groupe
  const chosen = useMemo(() => {
    const m = {};
    for (const g of groups) m[g.key] = pickVariant(g, settings.liveQuality);
    return m;
  }, [groups, settings.liveQuality, pickTick]);

  // v28 : affichage progressif. On rend d'abord une page de chaînes, puis la suivante quand on
  // approche du bas. Démarrage plus rapide, moins de guides demandés d'un coup, et plus de plafond
  // à 400 : toutes les chaînes d'une grosse catégorie (ou de « Toutes ») restent accessibles.
  const PAGE = view === 'liste' ? 120 : 60;
  const [limit, setLimit] = useState(PAGE);
  useEffect(() => { setLimit(PAGE); }, [cat, q, view]);
  const visible = groups.slice(0, limit);
  const hasMore = groups.length > visible.length;
  const showMore = React.useCallback(() => setLimit((n) => n + PAGE), [PAGE]);
  // La chaîne sélectionnée (retour du lecteur, reprise) est toujours dans la partie affichée
  useEffect(() => {
    if (!selKey) return;
    const idx = groups.findIndex((g) => g.key === selKey);
    if (idx >= 0) setLimit((n) => (idx < n ? n : idx + PAGE));
  }, [selKey, groups]);
  // Les anciens catalogues ou un rafraîchissement différentiel peuvent laisser
  // brièvement un groupe sans variante exploitable. Les vues avancées ne doivent
  // jamais déréférencer ce groupe : c'était la cause du rendu noir persistant.
  const safeVisible = playableLiveGroups(visible, chosen);
  useEffect(() => {
    if (view !== 'liste' && visible.length && !safeVisible.length) {
      recoverView('La vue avancée ne trouve aucun flux exploitable. Retour automatique à la Liste.');
    }
  }, [view, visible.length, safeVisible.length, recoverView]);
  // Sources Xtream et M3U : le guide est préchargé au démarrage et se complète dès l'ouverture
  // du Direct. Une source Stalker garde son rythme d'origine (guide après la première lecture).
  const stalkerInView = useMemo(() => safeVisible.some((g) => {
    const c = chosen[g.key];
    const x = c && xtOf(c.acc);
    return !!(x && x.kind === 'stalker');
  }), [safeVisible, chosen]);
  useEffect(() => {
    if (epgNetwork || stalkerInView) return undefined;
    const t = setTimeout(() => setEpgNetwork(true), 400);
    return () => clearTimeout(t);
  }, [epgNetwork, stalkerInView]);
  // Stalker : aucun EPG réseau avant le premier frame. Après lecture, le guide de la
  // liste se remplit progressivement et reste ensuite servi par le cache v10.
  const epgSource = epgNetwork ? safeVisible : safeVisible.slice(0, 30);
  const epgChans = epgSource.map((g) => chosen[g.key]).filter(Boolean);
  const epgs = useEpgs(xtOf, epgChans, epgNetwork);

  const listKeys = groups.filter((g) => chosen[g.key]).map((g) => g.key);
  const playLive = (g, o = {}) => {
    const ch = g && chosen[g.key];
    if (!ch) { recoverView('Cette chaîne ne possède plus de flux valide. Retour automatique à la Liste.'); return; }
    navigate({ name: 'player', ref: liveRef(ch, listKeys, g), ...o });
  };
  const playReplay = (g, prog) => {
    const ch = g && chosen[g.key];
    if (!ch) { recoverView('Le flux Replay de cette chaîne est indisponible. Retour automatique à la Liste.'); return; }
    navigate({ name: 'player', ref: replayRef(ch, prog, g) });
  };
  const onProg = (g, prog) => {
    const ch = g && chosen[g.key];
    if (!ch || !prog) return recoverView('Le guide a rencontré une donnée incomplète. Retour automatique à la Liste.');
    if (prog.start <= now && prog.end > now) return playLive(g);
    if (prog.end <= now) { if (canReplay(ch, prog, now)) playReplay(g, prog); return; }
    setBell({ prog, ch, group: g });
  };
  const hasBell = (g, prog) => reminders.some((r) => r.chKey === g.key && r.start === prog.start);

  return (
    <div className="screen-pad" style={{ paddingBottom: 20 }}>
      <div className="toolbar" style={{ marginBottom: 18 }}>
        <h1 className="page-title" style={{ fontSize: 44, marginRight: 8 }}>Direct</h1>
        {!isTV && <div className="seg" role="group" aria-label="Vue">
          {[['liste', 'Liste'], ['grille', 'Guide'], ['images', 'Guide en images'], ['mosaique', 'Mosaïque']].map(([k, l]) => (
            <button key={k} className={view === k ? 'on' : ''} onClick={() => selectView(k)}>{l}</button>
          ))}
        </div>}
        {!isTV && (
          <div className="field">
            <Icon name="search" size={18} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Chercher une chaîne" aria-label="Chercher une chaîne" />
          </div>
        )}
        {!isTV && (() => { const last = loadJSON('lastLive', ''); const g = last && catalog.byKey.get(last); return g ? <button className="btn btn-ghost btn-sm" onClick={() => playLive(g)}><Icon name="play" size={14} />Reprendre {g.name}</button> : null; })()}
        <span className="muted" style={{ fontSize: 14 }}>{groups.length} chaînes</span>
        {cat === '__recent' && !q && recentKeys.length > 0 && (
          <button className="btn btn-ghost btn-sm" onClick={clearRecent}><Icon name="close" size={14} />Vider les récentes</button>
        )}
      </div>
      {viewNotice && (
        <div className="live-recovery-notice" role="status">
          <Icon name="refresh" size={16} /><span>{viewNotice}</span>
          <button className="btn btn-ghost btn-sm" onClick={() => setViewNotice('')}>Fermer</button>
        </div>
      )}

      <div className="live-layout">
        <aside className="side live-cats" aria-label="Groupes de chaînes">
          {!isTV && <button className="manage-link" onClick={() => goRoot({ name: 'settings', anchor: 'groupes' })}><Icon name="gear" size={14} />Gérer les groupes</button>}
          {isTV && (
            <div className="side-opts">
              <TvOptions sections={[
                { label: 'Affichage', value: view, onChange: selectView, choices: [['liste', 'Liste'], ['grille', 'Guide'], ['images', 'Images']] },
                ...(view === 'images' ? [{ label: 'Guide en images', value: imgMode, onChange: pickImgMode, choices: [['liste', 'Liste'], ['grille', 'Grille de 3']] }] : [])
              ]} />
            </div>
          )}
          {/* v39 : tes listes à part, puis les catégories du serveur */}
          <SideMine>
            <button className={cat === '__fav' && !q ? 'on' : ''} onClick={() => { setCat('__fav'); setQ(''); }}>
              <span className="side-ic"><Icon name="star" size={15} />Favoris</span><span>{catalog.liveGroups.filter((g) => favorites[g.key]).length}</span>
            </button>
            <button className={cat === '__recent' && !q ? 'on' : ''} onClick={() => { setCat('__recent'); setQ(''); }}><span className="side-ic"><Icon name="clock" size={15} />Récentes</span><span>{recentKeys.length}</span></button>
          </SideMine>
          <div className="side-label">Sur ton serveur</div>
          <button className={cat === '__all' && !q ? 'on' : ''} onClick={() => { setCat('__all'); setQ(''); }}>Toutes <span>{catalog.liveGroups.length}</span></button>
          {catalog.liveCats.filter((c) => counts.get(c.id) || cat === c.id).map((c) => (
            <button key={c.id} className={cat === c.id && !q ? 'on' : ''} onClick={() => { setCat(c.id); setQ(''); }}>
              {c.name}<span>{counts.get(c.id) || 0}</span>
            </button>
          ))}
        </aside>

        <div style={{ flex: '999 1 600px', minWidth: 0 }}>
          <LiveModeBoundary key={view} mode={view} onFail={() => recoverView(`La vue « ${view} » a échoué. Retour automatique à la Liste.`)}>
            {view === 'liste' && (
              <ListView groups={safeVisible} chosen={chosen} selKey={selKey} setSelKey={setSelKey} epgs={epgs} now={now}
                active={active} onPlay={playLive} onProg={onProg} hasBell={hasBell}
                onPick={(g, ch) => { rememberVariant(g, ch); setPickTick((t) => t + 1); }}
                onAuto={(g) => { forgetVariant(g); setPickTick((t) => t + 1); }}
                favorites={favorites} toggleFav={toggleFav} onMediaStarted={markMediaStarted} epgNetwork={epgNetwork}
                hasMore={hasMore} onMore={showMore} />
            )}
            {view === 'grille' && <GridView groups={safeVisible} chosen={chosen} epgs={epgs} now={now} onProg={onProg} hasBell={hasBell} onPlay={playLive} />}
            {view === 'mosaique' && (
              <>
                <div className="toolbar" style={{ marginBottom: 10 }}>
                  <span style={{ fontSize: 14 }}>Grille avec prévisualisations</span>
                  <div className="seg" role="group" aria-label="Chaînes en direct permanent">
                    {[0, 1, 2, 3].map((n) => (
                      <button key={n} className={(settings.mosaicLive || 0) === n ? 'on' : ''} disabled={account && account.maxConn && n + 1 > account.maxConn}
                        onClick={() => updateSettings({ mosaicLive: n })}>{n === 0 ? 'Aucune' : n}</button>
                    ))}
                  </div>
                </div>
                <Mosaic xtOf={xtOf} groups={safeVisible} chosen={chosen} epgs={epgs} now={now} onPlay={playLive}
                  liveCount={Math.min(settings.mosaicLive || 0, account && account.maxConn ? Math.max(0, account.maxConn - 1) : 3)} maxConn={account && account.maxConn} />
              </>
            )}
            {view === 'images' && <ImagesView groups={safeVisible} chosen={chosen} epgs={epgs} now={now} onPlay={playLive} tmdb={tmdb} mode={imgMode} pick={pickImgMode} />}
            {view !== 'liste' && hasMore && (
              <div className="live-more-btn">
                <button className="btn btn-ghost" onClick={showMore}>Afficher plus de chaînes ({groups.length - visible.length} restantes)</button>
              </div>
            )}
            {groups.length === 0 && (
              catalog.liveGroups.length === 0
                ? <EmptyState icon="tv" title="Aucune chaîne en direct"
                    hint="Cette source ne fournit pas de direct, ou le serveur du direct n'a pas encore répondu."
                    action={{ label: 'Recharger', onClick: () => refreshCatalog(true) }} />
                : q
                  ? <EmptyState icon="search" title={'Aucune chaîne pour « ' + q + ' »'} hint="Essaie un autre mot, ou efface la recherche." />
                  : cat === '__fav'
                    ? <EmptyState icon="bell" title="Aucune chaîne en favori" hint={isTV ? "Appui long sur OK sur une chaîne, puis « Ajouter aux favoris »." : "Mets une chaîne en favori avec l'étoile pour la retrouver ici."} />
                    : cat === '__recent'
                      ? <EmptyState icon="tv" title="Aucune chaîne récente" hint="Les chaînes que tu lances apparaîtront ici." />
                      : <EmptyState icon="tv" title="Aucune chaîne dans ce groupe" />
            )}
            {groups.length > 0 && safeVisible.length === 0 && <p className="empty">Aucun flux exploitable dans ce groupe.</p>}
          </LiveModeBoundary>
        </div>
      </div>
      {bell && <BellDialog prog={bell.prog} ch={bell.ch} group={bell.group} onClose={() => setBell(null)} />}
    </div>
  );
}

function QualityPills({ group, current, onPick, onAuto }) {
  if (!group || !current || !Array.isArray(group.variants) || group.variants.length < 2) return null;
  const manual = loadJSON('livePick', {})[group.key];
  return (
    <div className="qpills" role="group" aria-label="Qualité">
      <button className={!manual ? 'on' : ''} onClick={(e) => { e.stopPropagation(); onAuto(group); }} title="Suivre la préférence globale et permettre le secours automatique">Auto</button>
      {group.variants.map((v) => (
        <button key={v.ch.key} className={manual === v.ch.key ? 'on' : ''} onClick={(e) => { e.stopPropagation(); onPick(group, v.ch); }}
          title={v.ch.name}>{variantLabel(group, v)}</button>
      ))}
    </div>
  );
}

// Repère invisible en bas de la liste : quand il devient visible, la page suivante de chaînes est rendue
function MoreSentinel({ onMore }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') return undefined;
    const io = new IntersectionObserver((entries) => { if (entries.some((e) => e.isIntersecting)) onMore(); }, { rootMargin: '600px 0px' });
    io.observe(el);
    return () => io.disconnect();
  }, [onMore]);
  return <div ref={ref} className="live-more" aria-hidden="true" />;
}

// v37 : temps restant du programme en cours (« encore 25 min », « encore 1h10 »)
function leftLabel(ms) {
  const m = Math.ceil(ms / 60000);
  if (!(m > 0)) return '';
  return 'encore ' + (m >= 60 ? Math.floor(m / 60) + 'h' + String(m % 60).padStart(2, '0') : m + ' min');
}

function ListView({ groups, chosen, selKey, setSelKey, epgs, now, active, onPlay, onProg, hasBell, onPick, onAuto, favorites, toggleFav, onMediaStarted, epgNetwork, hasMore = false, onMore }) {
  const { xtOf } = useApp();
  const video = useRef(null);
  const [state, setState] = useState('idle');
  const [day, setDay] = useState(0);
  const sel = groups.find((g) => g.key === selKey) || null;
  const ch = sel ? chosen[sel.key] : null;

  useEffect(() => {
    // Sur la TV, pas d'aperçu : il occuperait la connexion du serveur et ralentirait le plein écran
    if (isTV || !ch || !active || !video.current) return;
    setState('loading');
    const v = video.current;
    const client = xtOf(ch.acc);
    let src = null;
    let off = false;
    const onPlay2 = () => { setState('playing'); onMediaStarted(); };
    v.addEventListener('playing', onPlay2);
    resolveMediaUrl(client, { kind: 'live', id: ch.id }, { ext: 'ts' }).then((url) => {
      if (off) return;
      src = attachSource(v, url, { live: true, onFatal: () => { if (client.invalidateMedia) client.invalidateMedia(ch); setState('error'); } });
      v.play().catch(() => {});
    }).catch(() => !off && setState('error'));
    return () => { off = true; v.removeEventListener('playing', onPlay2); if (src) src.destroy(); };
  }, [ch && ch.key, active]);

  useEffect(() => setDay(0), [selKey]);

  // TV : miniature en direct. 1er OK : la chaîne démarre en petit ; 2e OK : plein écran, sans relancer le flux.
  const box = useRef(null);
  const [mini, setMini] = useState(null);
  useEffect(() => {
    if (!isTV) return;
    if (!active || !mini || !box.current) return;
    const g = groups.find((x) => x.key === mini);
    const c = g && chosen[g.key];
    if (!c) return;
    const x = xtOf(c.acc);
    const ext = loadJSON('liveExt', {})[c.acc || ''] || 'ts';
    let off = false;
    Promise.all([
      resolveMediaUrl(x, { kind: 'live', id: c.id }, { ext }),
      resolveMediaUrl(x, { kind: 'live', id: c.id }, { ext: ext === 'ts' ? 'm3u8' : 'ts' })
    ]).then(([url, alt]) => { if (!off) previewShow(g.key, url, alt, box.current); }).catch(() => {});
    return () => { off = true; };
  }, [mini, active, chosen]);
  useEffect(() => () => { if (isTV) previewStop(); }, []);
  // Retour du plein écran : la miniature reprend la chaîne regardée
  useEffect(() => {
    if (!isTV) return;
    const on = (e) => { if (e.detail && e.detail.key) setMini(e.detail.key); };
    window.addEventListener('lumen:live-return', on);
    return () => window.removeEventListener('lumen:live-return', on);
  }, []);
  const tvClick = (g) => {
    if (mini === g.key && previewKey() === g.key) { onPlay(g, { reuse: true, keepPreview: true }); return; }
    setSelKey(g.key);
    setMini(g.key);
  };

  const progs = (ch && epgs[ch.key]) || [];
  const days = [...new Set(progs.map((p) => new Date(p.start).toDateString()))];
  const todayIdx = Math.max(0, days.indexOf(new Date().toDateString()));
  const dayStr = days[todayIdx + day];
  const dayProgs = dayStr ? progs.filter((p) => new Date(p.start).toDateString() === dayStr) : progs;
  const listRef = useRef(null);
  useEffect(() => {
    const el = listRef.current && listRef.current.querySelector('.epg-item.now');
    if (el) el.scrollIntoView({ block: 'center' });
  }, [ch && ch.key, progs.length, day]);

  return (
    <div className={"live-list" + (!isTV && !sel ? " list-only" : "")}>
      <div className="live-col">
        {groups.map((g) => {
          const c = chosen[g.key];
          if (!c) return null;
          const nn = nowNext(epgs[c.key] || [], now);
          return (
            <button key={g.key} data-key={g.key} className={'chan' + (selKey === g.key ? ' on' : '')}
              onClick={() => (isTV ? tvClick(g) : onPlay(g))}
              onFocus={isTV ? () => setSelKey(g.key) : undefined}
              title={!isTV ? 'Lancer immédiatement la chaîne' : undefined}>
              <span className="no">{g.num}</span>
              <span className="lg"><Img src={g.logo} fit="contain" /></span>
              <span className="nm">{g.name}</span>
              {g.variants.length > 1 && <span className="qtag">{g.variants.length} sources</span>}
              {epgs[c.key] === undefined && <span className="nowline epg-loading-line"><small>{epgNetwork ? 'Guide en cours de chargement…' : 'Guide chargé après la première lecture'}</small></span>}
              {epgs[c.key] !== undefined && !nn.now && <span className="nowline epg-empty-line"><small>Guide indisponible pour le moment</small></span>}
              {nn.now && <span className="nowline"><span className="now-main"><small>{hhmm(nn.now.start)}–{hhmm(nn.now.end)}</small><b>{nn.now.title}</b><small className="now-left">{leftLabel(nn.now.end - now)}</small></span>{nn.next && <small>Ensuite · {hhmm(nn.next.start)} · {nn.next.title}</small>}<i><em style={{ width: Math.max(0, Math.min(100, ((now - nn.now.start) / (nn.now.end - nn.now.start)) * 100)) + '%' }} /></i></span>}
              {c.archive && <span className="replay-mark">REPLAY</span>}
              {!isTV && <span role="button" tabIndex={0} className={'live-fav-inline' + (favorites[g.key] ? ' on' : '')} title={favorites[g.key] ? 'Retirer des favoris' : 'Ajouter aux favoris'} onClick={(e) => { e.stopPropagation(); toggleFav({ key: g.key, kind: 'group', id: g.key, title: g.name, poster: g.logo }); }}>★</span>}
            </button>
          );
        })}
        {hasMore && onMore && <MoreSentinel key={groups.length} onMore={onMore} />}
      </div>

      {(isTV || sel) && <div className="live-col" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {isTV ? (<>
          <div className="preview tv-prev" ref={box}>
            {sel ? <><span className="lg"><Img src={sel.logo} fit="contain" /></span><span className="muted">{mini === sel.key ? 'Chargement de la chaîne…' : 'OK pour lancer la chaîne ici, puis OK pour le plein écran'}</span></> : <div className="hint">Choisis une chaîne avec les flèches, puis OK.</div>}
          </div>
          {mini && <span className="muted" style={{ fontSize: 14 }}>{mini === (sel && sel.key) ? 'OK pour passer en plein écran' : 'OK sur une autre chaîne pour la lancer ici'}</span>}
        </>) : (
        <div className="preview" onClick={() => sel && onPlay(sel)} style={{ cursor: sel ? 'pointer' : 'default' }}>
          <video ref={video} playsInline />
          {!sel && <div className="hint">Choisis une chaîne pour l'aperçu.<br />Clique une deuxième fois dessus pour le plein écran.</div>}
          {sel && state === 'loading' && <Spinner center />}
          {sel && state === 'error' && <div className="hint">Ce flux ne passe pas dans l'aperçu. Essaie le plein écran.</div>}
        </div>
        )}
        {sel && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <h2 style={{ fontSize: 22, flex: '1 1 auto', minWidth: 0 }}>{sel.name}</h2>
              {!isTV && <QualityPills group={sel} current={ch} onPick={onPick} onAuto={onAuto} />}
              {!isTV && <button className={'btn btn-round' + (favorites[sel.key] ? ' on' : '')} style={{ width: 42, height: 42 }}
                onClick={() => toggleFav({ key: sel.key, kind: 'group', id: sel.key, title: sel.name, poster: sel.logo })} aria-label="Favori">
                <Icon name={favorites[sel.key] ? 'check' : 'plus'} size={18} />
              </button>}
              {!isTV && <button className="btn btn-primary btn-sm" onClick={() => onPlay(sel)}><Icon name="full" size={16} />Plein écran</button>}
              {isTV && favorites[sel.key] && <span className="muted">★ Favori</span>}
            </div>
            {ch.archive && <div className="muted" style={{ fontSize: 13 }}>Replay disponible sur {ch.archiveDays || 1} jour{ch.archiveDays > 1 ? 's' : ''} : {isTV ? 'appui long sur OK sur la chaîne pour revoir un programme.' : 'clique sur un programme passé pour le revoir.'}</div>}
            {days.length > 1 && !isTV && (
              <div className="pills">
                {days.map((d, i) => (
                  <button key={d} className={'pill' + (i === todayIdx + day ? ' on' : '')} onClick={() => setDay(i - todayIdx)}>{dayLabel(new Date(d).getTime())}</button>
                ))}
              </div>
            )}
            <div ref={listRef} style={{ overflowY: 'auto', minHeight: 0, flex: '1 1 auto' }}>
              {progs.length === 0 && <p className="muted" style={{ fontSize: 14 }}>Pas de guide des programmes pour cette chaîne.</p>}
              {dayProgs.map((p) => {
                const isNow = p.start <= now && p.end > now;
                const past = p.end <= now;
                const rep = past && canReplay(ch, p, now);
                return (
                  <button key={p.id + p.start} className={'epg-item' + (isNow ? ' now' : '') + (past && !rep ? ' past' : '')} onClick={() => onProg(sel, p)} tabIndex={isTV ? -1 : undefined}>
                    <div className="tm">
                      {isNow ? 'EN COURS · ' : ''}{hhmm(p.start)} – {hhmm(p.end)}
                      {rep && <span className="tag">REVOIR</span>}
                      {!past && !isNow && <span className={'tag bell' + (hasBell(sel, p) ? ' on' : '')}><Icon name="bell" size={12} />{hasBell(sel, p) ? 'Rappel posé' : 'Rappel'}</span>}
                    </div>
                    <b>{p.title}</b>
                    {isNow && <div className="epg-prog"><i style={{ width: ((now - p.start) / (p.end - p.start)) * 100 + '%' }} /></div>}
                    {p.desc && (isNow || !past) && <p>{p.desc}</p>}
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>}
    </div>
  );
}

function GridView({ groups, chosen, epgs, now, onProg, hasBell, onPlay }) {
  const scroller = useRef(null);
  const valid = groups.filter((g) => g && chosen[g.key]);
  const maxArchive = Math.min(3, Math.max(0, ...valid.map((g) => (chosen[g.key].archive ? chosen[g.key].archiveDays || 1 : 0))));
  const t0 = Math.floor((now - Math.max(2, maxArchive * 24) * 60 * MIN) / (30 * MIN)) * 30 * MIN;
  const t1 = now + 12 * 60 * MIN;
  const width = ((t1 - t0) / MIN) * PPM;
  const slots = [];
  for (let t = t0; t <= t1; t += 30 * MIN) slots.push(t);

  useEffect(() => {
    if (scroller.current) scroller.current.scrollLeft = ((now - t0) / MIN) * PPM - 120;
  }, [valid.length]);

  const x = (t) => ((t - t0) / MIN) * PPM;
  return (
    <div className="grid-epg" ref={scroller}>
      <div style={{ width: width + 220, position: 'relative' }}>
        <div className="ge-head">
          <div className="ge-corner">{dayLabel(now)}</div>
          <div style={{ position: 'relative', width, height: 36 }}>
            {slots.map((t) => (
              <span key={t} className="ge-slot" style={{ left: x(t) }}>
                {new Date(t).getHours() === 0 && new Date(t).getMinutes() === 0 ? dayLabel(t).slice(0, 3) + ' ' : ''}{hhmm(t)}
              </span>
            ))}
          </div>
        </div>
        {valid.map((g) => {
          const ch = chosen[g.key];
          const progs = (epgs[ch.key] || []).filter((p) => p.end > t0 && p.start < t1);
          return (
            <div className="ge-row" key={g.key}>
              <button className="ge-ch" onClick={() => onPlay(g)} title={'Regarder ' + g.name}>
                <span className="lg"><Img src={g.logo} fit="contain" /></span>
                <span className="nm">{g.name}</span>
              </button>
              <div style={{ position: 'relative', width, height: 44 }}>
                {progs.length === 0 && <div className="ge-empty" style={{ left: x(Math.max(t0, now - 60 * MIN)), width: 180 * PPM }}>Pas de guide</div>}
                {progs.map((p) => {
                  const left = Math.max(0, x(p.start));
                  const w = Math.max(4, x(Math.min(p.end, t1)) - left - 3);
                  const isNow = p.start <= now && p.end > now;
                  const past = p.end <= now;
                  const rep = past && canReplay(ch, p, now);
                  return (
                    <button key={p.id + p.start} className={'ge-prog' + (isNow ? ' now' : '') + (past ? ' past' : '') + (rep ? ' rep' : '')}
                      style={{ left, width: w }} onClick={() => onProg(g, p)}
                      title={`${hhmm(p.start)} – ${hhmm(p.end)} · ${p.title}${rep ? ' · Revoir' : ''}`}>
                      <b>{p.title}</b>
                      <span>{hhmm(p.start)}{rep ? ' · Revoir' : ''}{hasBell(g, p) ? ' · rappel posé' : ''}</span>
                      {isNow && <i className="ge-bar" style={{ width: ((now - p.start) / (p.end - p.start)) * 100 + '%' }} />}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
        <div className="ge-now" style={{ left: 220 + x(now) }} />
      </div>
    </div>
  );
}

// v42 : deux présentations, mémorisées : Liste compacte (par défaut) ou Grille de 3, moins haute
function ImagesView({ groups, chosen, epgs, now, onPlay, tmdb, mode, pick }) {
  const valid = groups.filter((g) => g && chosen[g.key]);
  return (
    <div>
      {!isTV && (
        <div className="imgv-bar">
          <div className="seg imgv-toggle" role="group" aria-label="Présentation">
            {[['liste', 'Liste'], ['grille', 'Grille']].map(([k, l]) => <button key={k} className={mode === k ? 'on' : ''} aria-pressed={mode === k} onClick={() => pick(k)}>{l}</button>)}
          </div>
        </div>
      )}
      {mode === 'grille' ? (
        <div className="img-grid compact">
          {valid.map((g) => <ImageCard key={g.key} g={g} ch={chosen[g.key]} progs={epgs[chosen[g.key].key] || []} now={now} onPlay={onPlay} tmdb={tmdb} />)}
        </div>
      ) : (
        <div className="img-rows">
          {valid.map((g) => <ImageRow key={g.key} g={g} ch={chosen[g.key]} progs={epgs[chosen[g.key].key] || []} now={now} onPlay={onPlay} tmdb={tmdb} />)}
        </div>
      )}
    </div>
  );
}
