import React, { useMemo, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { useMySeries, STATUS } from '../lib/series.js';
import { loadJSON, saveJSON } from '../lib/store.js';
import { Icon, Img, Spinner } from '../components/ui.jsx';

const DAY = 86400000;

function ago(t) {
  if (!t) return '';
  const d = Math.floor((Date.now() - t) / DAY);
  if (d <= 0) return "vu aujourd'hui";
  if (d === 1) return 'vu hier';
  if (d < 30) return `vu il y a ${d} jours`;
  if (d < 365) return `vu il y a ${Math.round(d / 30)} mois`;
  return `vu il y a ${Math.round(d / 365)} an${d >= 730 ? 's' : ''}`;
}

const FILTERS = [
  ['progress', 'En cours'], ['fresh', 'Nouveaux épisodes'], ['all', 'Toutes'], ['uptodate', 'À jour'],
  ['notstarted', 'Pas commencées'], ['ended', 'Terminées'], ['absent', 'Pas sur le serveur']
];
const SORTS = [['last', 'Dernier visionnage'], ['progress', 'Progression'], ['status', 'Statut'], ['az', 'A à Z']];

export default function MesSeries() {
  const { navigate, trakt, traktSync, traktState, traktImport, tmdb } = useApp();
  const { list, unfollow, refollowAll, unfollowedCount } = useMySeries();
  const [filter, setFilter] = useState('progress');
  const [sort, setSort] = useState(() => loadJSON('seriesSort', 'last'));
  const [menu, setMenu] = useState(null);

  const counts = useMemo(() => {
    const c = { all: list.length };
    for (const s of list) c[s.status] = (c[s.status] || 0) + 1;
    // « En cours » compte aussi les séries avec un nouvel épisode
    c.progress = (c.progress || 0) + (c.fresh || 0);
    return c;
  }, [list]);

  const shown = useMemo(() => {
    const f = filter === 'progress' && !counts.progress && !list.some((s) => s.loading) ? 'all' : filter;
    let l = f === 'all' ? list : f === 'progress' ? list.filter((s) => s.status === 'progress' || s.status === 'fresh') : list.filter((s) => s.status === f);
    l = [...l];
    if (sort === 'last') l.sort((a, b) => b.last - a.last);
    if (sort === 'progress') l.sort((a, b) => b.pct - a.pct);
    if (sort === 'status') l.sort((a, b) => STATUS[a.status].order - STATUS[b.status].order || b.last - a.last);
    if (sort === 'az') l.sort((a, b) => a.title.localeCompare(b.title, 'fr'));
    return l;
  }, [list, filter, sort, counts]);

  const totals = useMemo(() => ({
    eps: list.reduce((a, s) => a + s.watchedCount, 0),
    hours: Math.round(list.reduce((a, s) => a + s.hours, 0)),
    done: list.filter((s) => s.status === 'ended' && s.total && s.watchedCount >= s.total).length
  }), [list]);

  const play = (s) => navigate({ name: 'player', ref: s.ref, startAt: s.resumeAt || 0 });
  const open = (s) => (s.item ? navigate({ name: 'fiche', item: s.item }) : null);

  return (
    <div className="screen-pad">
      <div className="toolbar" style={{ marginBottom: 18 }}>
        <h1 className="page-title" style={{ fontSize: 44, marginRight: 8 }}>Mes séries</h1>
        {trakt.connected && (
          <button className="btn btn-ghost btn-sm" style={{ marginLeft: 'auto' }} onClick={traktSync} disabled={traktState.syncing}>
            <Icon name="refresh" size={16} />{traktState.syncing || (traktImport && traktImport.running) ? 'Synchronisation…' : 'Synchroniser Trakt'}
          </button>
        )}
      </div>

      {traktState.error && <p className="err" style={{ marginBottom: 16 }}>Trakt : {traktState.error}</p>}
      <div className="ms-stats">
        <div><b>{list.length}</b><span>séries suivies</span></div>
        <div><b>{totals.eps}</b><span>épisodes vus</span></div>
        <div><b>{totals.hours}</b><span>heures de séries</span></div>
        <div><b>{counts.fresh || 0}</b><span>avec un nouvel épisode</span></div>
        <div><b>{totals.done}</b><span>terminées et vues en entier</span></div>
      </div>

      <div className="toolbar">
        <div className="pills" role="group" aria-label="Statut">
          {FILTERS.filter(([k]) => k === 'all' || k === filter || counts[k]).map(([k, l]) => (
            <button key={k} className={'pill' + ((filter === k && (k !== 'progress' || counts.progress || list.some((s) => s.loading))) || (k === 'all' && filter === 'progress' && !counts.progress && !list.some((s) => s.loading)) ? ' on' : '')} onClick={() => setFilter(k)}>{l} · {counts[k] || 0}</button>
          ))}
        </div>
        <div className="seg" role="group" aria-label="Tri" style={{ marginLeft: 'auto' }}>
          {SORTS.map(([k, l]) => <button key={k} className={sort === k ? 'on' : ''} onClick={() => { setSort(k); saveJSON('seriesSort', k); }}>{l}</button>)}
        </div>
      </div>

      {list.length === 0 && (
        <p className="empty">
          Aucune série suivie pour l'instant. Une série apparaît ici dès que tu en regardes un épisode, que tu l'ajoutes à Ma liste ou que tu connectes Trakt.
        </p>
      )}

      <div className="ms-grid">
        {shown.map((s) => (
          <article key={s.key} className={'ms-card st-' + s.status}>
            <button className="ms-poster" onClick={() => open(s)} aria-label={s.title} disabled={!s.item}>
              <Img src={s.poster} className="cover" title={s.title} />
            </button>
            <div className="ms-body">
              <div className="ms-top">
                <span className={'ms-status st-' + s.status}>{STATUS[s.status].label}</span>
                {s.trakt && <span className="ms-tag">Trakt</span>}
                {s.fav && <span className="ms-tag">Ma liste</span>}
                <span style={{ flex: '1 1 auto' }} />
                <div style={{ position: 'relative' }}>
                  <button className="icon-btn" style={{ width: 36, height: 36 }} onClick={() => setMenu(menu === s.key ? null : s.key)} aria-label={'Options pour ' + s.title}>
                    <span style={{ fontSize: 20, lineHeight: 1, marginTop: -8 }}>…</span>
                  </button>
                  {menu === s.key && (
                    <div className="ms-menu" onMouseLeave={() => setMenu(null)}>
                      {s.item && <button onClick={() => { setMenu(null); open(s); }}>Voir la fiche</button>}
                      <button onClick={() => { setMenu(null); unfollow(s.key); }}>Ne plus suivre</button>
                    </div>
                  )}
                </div>
              </div>
              <button className="ms-title" onClick={() => open(s)} disabled={!s.item}>{s.title}</button>
              <div className="ms-progress" aria-label={`${s.watchedCount} épisodes vus sur ${s.total || '?'}`}>
                <div className="ms-bar"><i style={{ width: s.pct + '%' }} /></div>
                <span>{s.loading ? 'Chargement…' : s.total ? `${s.watchedCount} / ${s.total} épisodes · ${Math.round(s.pct)} %` : `${s.watchedCount} épisode${s.watchedCount > 1 ? 's' : ''} vu${s.watchedCount > 1 ? 's' : ''}`}</span>
              </div>
              <div className="ms-next">
                {s.next && <span>{s.resumeAt ? 'Reprendre' : 'Prochain'} : <b>S{s.next.season} · É{s.next.num}</b>{s.next.title ? ' · ' + s.next.title : ''}</span>}
                {!s.next && s.status === 'uptodate' && <span>{s.nextAir ? `Suite S${s.nextAir.season} · É${s.nextAir.num} le ${new Date(s.nextAir.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}` : 'Tu es à jour, en attente de la suite'}</span>}
                {!s.next && s.status === 'ended' && <span>Série terminée, tout est vu</span>}
                {s.status === 'absent' && <span>Vue sur Trakt, introuvable sur ton serveur</span>}
              </div>
              <div className="ms-foot">
                <span className="muted">{ago(s.last)}</span>
                <span style={{ flex: '1 1 auto' }} />
                {s.ref && (
                  <button className="btn btn-primary btn-sm" onClick={() => play(s)}>
                    <Icon name="play" size={14} />{s.resumeAt ? 'Reprendre' : s.status === 'notstarted' ? 'Commencer' : 'Lecture'}
                  </button>
                )}
                {!s.ref && s.item && <button className="btn btn-ghost btn-sm" onClick={() => open(s)}>Voir la fiche</button>}
              </div>
            </div>
          </article>
        ))}
      </div>
      {!tmdb.enabled && counts.absent > 0 && (
        <p className="muted" style={{ marginTop: 24, fontSize: 14 }}>Ajoute une clé TMDB dans les Réglages : Lumen pourra relier les séries Trakt à leur titre français sur ton serveur.</p>
      )}
      {list.some((s) => s.loading) && <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 20 }}><Spinner /><span className="muted">Vérification des épisodes sur ton serveur…</span></div>}
      {unfollowedCount > 0 && (
        <p className="muted" style={{ marginTop: 30, fontSize: 14 }}>
          {unfollowedCount} série{unfollowedCount > 1 ? 's' : ''} retirée{unfollowedCount > 1 ? 's' : ''} du suivi. <button className="see-all" onClick={refollowAll}>Les remettre</button>
        </p>
      )}
    </div>
  );
}
