// Lecture dans mpv : la vidéo s'ouvre en plein écran dans mpv, Lumen sert de télécommande
// et garde la main sur la progression, l'épisode suivant, les pistes et le son
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { fmtTime } from '../lib/player.js';
import { nextEpisodeRef, liveRef } from '../lib/play.js';
import { timeshiftUrl } from '../lib/epg.js';
import { pickVariant } from '../lib/live.js';
import { MPV_AF, EQ_MODES } from '../lib/audio.js';
import { loadJSON } from '../lib/store.js';
import { Icon, Spinner } from '../components/ui.jsx';

function urlFor(xt, ref, tz) {
  if (ref.kind === 'live') return xt.liveUrl(ref.id, 'ts');
  if (ref.kind === 'replay') return timeshiftUrl(xt, ref.id, ref.start, (ref.end - ref.start) / 60000 + 2, tz, 'ts');
  return ref.kind === 'movie' ? xt.movieUrl(ref.id, ref.ext) : xt.episodeUrl(ref.id, ref.ext);
}

function titleOf(ref) {
  return ref.kind === 'episode' ? `${ref.title} · ${ref.sub}` : ref.title;
}

export default function MpvPlayer({ route }) {
  const app = useApp();
  const { xtOf, back, replace, saveProgress, settings, updateSettings, catalog, mpvExe, trakt } = app;
  const [ref, setRef] = useState(route.ref);
  const [state, setState] = useState('starting');
  const [error, setError] = useState('');
  const [pos, setPos] = useState(0);
  const [dur, setDur] = useState(0);
  const [paused, setPaused] = useState(false);
  const [tracks, setTracks] = useState([]);
  const [size, setSize] = useState('');
  const refNow = useRef(ref);
  const posRef = useRef({ pos: 0, dur: 0 });
  const nextShown = useRef(false);
  refNow.current = ref;

  const isVod = ref.kind === 'movie' || ref.kind === 'episode';
  const nextEp = ref.queue && ref.queue[0];
  const credits = ref.seriesKey ? ((loadJSON('skips', {})[ref.seriesKey] || {}).credits || 40) : 40;
  const cmd = (c) => window.lumen.mpvCmd(c);

  const save = useCallback((watchedForce) => {
    const r = refNow.current;
    const { pos: p, dur: d } = posRef.current;
    if (!(r.kind === 'movie' || r.kind === 'episode') || !d || d < 60 || p < 5) return;
    const watched = watchedForce || p / d >= 0.95;
    saveProgress(r.key, { hidden: false, watched, pos: p, dur: d, ref: { ...r, queue: (r.queue || []).slice(0, 30) } });
    if (watched && trakt && trakt.connected && settings.traktScrobble !== false) trakt.scrobble('stop', r, 100);
  }, [saveProgress, trakt, settings.traktScrobble]);

  // Lance une référence dans la fenêtre mpv déjà ouverte
  const loadRef = useCallback((r) => {
    save();
    nextShown.current = false;
    setRef(r);
    posRef.current = { pos: 0, dur: 0 };
    cmd(['loadfile', urlFor(xtOf(r.acc), r, catalog.serverTz), 'replace']);
    cmd(['set_property', 'force-media-title', titleOf(r)]);
    cmd(['show-text', titleOf(r), 3000]);
  }, [save, xtOf, catalog]);

  const goNext = useCallback(() => {
    const r = refNow.current;
    const n = r.queue && r.queue[0];
    if (!n) return;
    save(true);
    loadRef(nextEpisodeRef(r, n));
  }, [save, loadRef]);

  const zap = useCallback((dir) => {
    const r = refNow.current;
    if (r.kind !== 'live' || !r.list || r.list.length < 2) return;
    const i = r.list.indexOf(r.groupKey || r.key);
    const it = catalog.byKey.get(r.list[(i + dir + r.list.length) % r.list.length]);
    if (!it) return;
    loadRef(it.kind === 'group' ? liveRef(pickVariant(it, settings.liveQuality), r.list, it) : liveRef(it, r.list));
  }, [catalog, loadRef, settings.liveQuality]);

  // Démarrage
  useEffect(() => {
    let alive = true;
    const off = window.lumen.onMpv((ev) => {
      if (!alive) return;
      if (ev.type === 'prop') {
        if (ev.name === 'time-pos' && typeof ev.data === 'number') { setPos(ev.data); posRef.current.pos = ev.data; setState('playing'); }
        if (ev.name === 'duration' && typeof ev.data === 'number') { setDur(ev.data); posRef.current.dur = ev.data; }
        if (ev.name === 'pause') setPaused(!!ev.data);
        if (ev.name === 'track-list' && Array.isArray(ev.data)) setTracks(ev.data);
        if (ev.name === 'video-params' && ev.data && ev.data.h) setSize(`${ev.data.w}×${ev.data.h}`);
        if (ev.name === 'eof-reached' && ev.data === true) {
          const r = refNow.current;
          if (r.kind === 'episode' && r.queue && r.queue[0] && settings.autoNext) goNext();
          else if (r.kind !== 'live') { save(true); window.lumen.mpvStop(); }
        }
      }
      if (ev.type === 'msg') {
        if (ev.args[0] === 'lumen-next') goNext();
        if (ev.args[0] === 'lumen-next-channel') zap(1);
        if (ev.args[0] === 'lumen-prev-channel') zap(-1);
      }
      if (ev.type === 'exit') { save(); back(); }
      if (ev.type === 'error') { setState('error'); setError(ev.error); }
    });
    window.lumen.mpvPlay({
      url: urlFor(xtOf(ref.acc), ref, catalog.serverTz), title: titleOf(ref), start: route.startAt || 0,
      path: settings.mpvPath || mpvExe, af: MPV_AF[settings.eq || 'normal'], volume: loadJSON('volume', 1), live: ref.kind === 'live'
    }).then((r) => {
      if (!alive) return;
      if (!r.ok) { setState('error'); setError(r.error); }
      else if (trakt && trakt.connected && settings.traktScrobble !== false && isVod) trakt.scrobble('start', ref, 0);
    });
    const t = setInterval(() => save(), 10000);
    return () => { alive = false; off(); clearInterval(t); save(); window.lumen.mpvStop(); };
  }, []);

  // Annonce de l'épisode suivant pendant le générique
  useEffect(() => {
    if (ref.kind !== 'episode' || !nextEp || !dur || nextShown.current) return;
    if (dur - pos <= credits && dur - pos > 1) {
      nextShown.current = true;
      cmd(['show-text', `Épisode suivant : S${nextEp.season} · É${nextEp.num}${nextEp.title ? ' · ' + nextEp.title : ''}\nAppuie sur N pour enchaîner${settings.autoNext ? ', ou attends la fin' : ''}`, 8000]);
    }
  }, [pos, dur]);

  // Égaliseur : appliqué en direct dans mpv
  useEffect(() => { if (state === 'playing') cmd(['set_property', 'af', MPV_AF[settings.eq || 'normal'] || '']); }, [settings.eq]);

  const audio = tracks.filter((t) => t.type === 'audio');
  const subs = tracks.filter((t) => t.type === 'sub');
  const label = (t) => [t.lang && t.lang.toUpperCase(), t.title, t.codec, t['demux-channel-count'] ? t['demux-channel-count'] + ' canaux' : ''].filter(Boolean).join(' · ') || 'Piste ' + t.id;
  const pct = dur ? Math.min(100, (pos / dur) * 100) : 0;

  return (
    <div className="player mpv-remote" style={{ backgroundImage: ref.image ? `url("${ref.image}")` : undefined }}>
      <div className="mpv-veil" />
      <div className="mpv-body">
        <button className="icon-btn" onClick={() => { save(); window.lumen.mpvStop(); back(); }} aria-label="Retour"><Icon name="back" size={26} /></button>
        <span className="kicker">Lecture dans mpv{size ? ' · ' + size : ''}</span>
        <h1 className="big-title" style={{ fontSize: 'clamp(40px, 5vw, 72px)' }}>{ref.title}</h1>
        <p className="synopsis">{ref.kind === 'live' ? 'En direct' : ref.sub}</p>

        {state === 'starting' && <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}><Spinner /><span className="muted">Ouverture de mpv…</span></div>}
        {state === 'error' && (
          <div className="p-msg" style={{ position: 'static', transform: 'none', alignItems: 'flex-start', textAlign: 'left' }}>
            <b>mpv n'a pas pu démarrer</b>
            <p className="muted">{error}</p>
            <div className="actions">
              <button className="btn btn-primary" onClick={() => replace({ ...route, engine: 'chromium' })}>Lecteur intégré</button>
              <button className="btn btn-ghost" onClick={back}>Retour</button>
            </div>
          </div>
        )}

        {state === 'playing' && (
          <>
            {ref.kind !== 'live' && (
              <div className="seek" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); cmd(['seek', ((e.clientX - r.left) / r.width) * dur, 'absolute']); }}>
                <div className="tr" /><div className="pl" style={{ width: pct + '%' }} /><div className="kn" style={{ left: pct + '%' }} />
              </div>
            )}
            <div className="p-ctrl">
              <button className="icon-btn" onClick={() => cmd(['cycle', 'pause'])} aria-label={paused ? 'Lecture' : 'Pause'}><Icon name={paused ? 'play' : 'pause'} size={26} /></button>
              {ref.kind !== 'live' && <button className="icon-btn" onClick={() => cmd(['seek', -10])} aria-label="Reculer"><Icon name="rewind" /></button>}
              {ref.kind !== 'live' && <button className="icon-btn" onClick={() => cmd(['seek', 10])} aria-label="Avancer"><Icon name="forward" /></button>}
              {ref.kind === 'live' && <button className="icon-btn" onClick={() => zap(-1)} aria-label="Chaîne précédente"><Icon name="back" /></button>}
              {ref.kind === 'live' && <button className="icon-btn" onClick={() => zap(1)} aria-label="Chaîne suivante"><Icon name="next" /></button>}
              <span className="time">{ref.kind === 'live' ? 'EN DIRECT' : `${fmtTime(pos)} / ${fmtTime(dur)}`}</span>
              <span className="grow" />
              {nextEp && <button className="btn btn-ghost btn-sm" onClick={goNext}>Épisode suivant</button>}
              <button className="btn btn-ghost btn-sm" onClick={() => cmd(['set_property', 'fullscreen', true])}>Plein écran mpv</button>
            </div>
            <div className="mpv-tracks">
              <div className="tr-col">
                <b>Audio</b>
                {audio.map((t) => <button key={t.id} className={'tr-opt' + (t.selected ? ' on' : '')} onClick={() => cmd(['set_property', 'aid', t.id])}>{label(t)}</button>)}
                {!audio.length && <span className="muted">Piste unique</span>}
              </div>
              <div className="tr-col">
                <b>Sous-titres</b>
                <button className={'tr-opt' + (!subs.some((t) => t.selected) ? ' on' : '')} onClick={() => cmd(['set_property', 'sid', 'no'])}>Désactivés</button>
                {subs.map((t) => <button key={t.id} className={'tr-opt' + (t.selected ? ' on' : '')} onClick={() => cmd(['set_property', 'sid', t.id])}>{label(t)}</button>)}
              </div>
              <div className="tr-col">
                <b>Son</b>
                {EQ_MODES.map((m) => <button key={m.id} className={'tr-opt' + ((settings.eq || 'normal') === m.id ? ' on' : '')} onClick={() => updateSettings({ eq: m.id })}>{m.name}<small> · {m.desc}</small></button>)}
              </div>
            </div>
            <p className="muted" style={{ fontSize: 13 }}>Dans la fenêtre mpv : Espace pause, flèches pour avancer, F plein écran, N épisode suivant, Q pour quitter et revenir à Lumen.</p>
          </>
        )}
      </div>
    </div>
  );
}
