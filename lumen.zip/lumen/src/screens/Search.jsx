import React, { useMemo } from 'react';
import { useApp } from '../lib/app.jsx';
import { searchCatalog } from '../lib/catalog.js';
import { liveRef } from '../lib/play.js';
import { Row, PosterCard, Img } from '../components/ui.jsx';

export default function Search({ route }) {
  const { catalog, navigate: nav, addSearch, searchHistory, removeSearch, clearSearch, goRoot } = useApp();
  // Ouvrir un résultat mémorise la recherche
  const navigate = (r) => { addSearch(route.q); nav(r); };
  const q = route.q || '';
  const r = useMemo(() => searchCatalog(catalog, q), [catalog, q]);
  const total = r.movies.length + r.series.length + r.live.length;

  return (
    <div style={{ paddingTop: 110 }}>
      <h1 className="page-title" style={{ padding: '0 var(--gutter)', marginBottom: 20 }}>{q ? `« ${q} »` : 'Recherche'}</h1>
      {q.length >= 2 && total === 0 && <p className="empty">Rien trouvé sur ton serveur.</p>}
      {q.length < 2 && (
        <div style={{ padding: '0 var(--gutter)' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginBottom: 14 }}>
            <h2 className="row-title">Recherches récentes</h2>
            {searchHistory.length > 0 && <button className="see-all" onClick={clearSearch}>Effacer l'historique</button>}
          </div>
          {searchHistory.length === 0 && <p className="muted">Tes recherches apparaîtront ici.</p>}
          <div className="pills">
            {searchHistory.map((h) => (
              <span key={h} className="hist-chip">
                <button onClick={() => goRoot({ name: 'search', q: h })}>{h}</button>
                <button onClick={() => removeSearch(h)} aria-label={'Retirer ' + h}>×</button>
              </span>
            ))}
          </div>
        </div>
      )}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 30 }}>
        {r.movies.length > 0 && (
          <Row title={`Films · ${r.movies.length}`}>
            {r.movies.map((m) => <PosterCard key={m.key} title={m.title} poster={m.poster} sub={String(m.year || '')} onOpen={() => navigate({ name: 'fiche', item: m })} />)}
          </Row>
        )}
        {r.series.length > 0 && (
          <Row title={`Séries · ${r.series.length}`}>
            {r.series.map((m) => <PosterCard key={m.key} title={m.title} poster={m.poster} sub={String(m.year || '')} onOpen={() => navigate({ name: 'fiche', item: m })} />)}
          </Row>
        )}
        {r.live.length > 0 && (
          <Row title={`Chaînes · ${r.live.length}`}>
            {r.live.map((c) => (
              <button key={c.key} className="card tile" onClick={() => navigate({ name: 'player', ref: liveRef(c, r.live.map((x) => x.key)) })}>
                <div style={{ position: 'relative', width: 120, height: 60 }}><Img src={c.logo} fit="contain" className="cover" style={{ width: '100%', height: '100%' }} /></div>
                <span style={{ color: '#fff', fontWeight: 600 }}>{c.name}</span>
              </button>
            ))}
          </Row>
        )}
      </div>
    </div>
  );
}
