import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { searchCatalog, matchTmdb } from '../lib/catalog.js';
import { img } from '../lib/tmdb.js';
import { liveRef } from '../lib/play.js';
import { Row, PosterCard, Img, EmptyState } from '../components/ui.jsx';
import ItemCard from '../components/ItemCard.jsx';
import { isTV } from '../tv/native.js';
import TvKeyboard from '../tv/TvKeyboard.jsx';

const DAY = 24 * 3600 * 1000;
const TYPES = [['all', 'Tout'], ['movie', 'Films'], ['series', 'Séries'], ['live', 'Chaînes']];
const SORTS = [['rel', 'Pertinence'], ['year', 'Année'], ['rating', 'Note'], ['az', 'A à Z']];
const NOTES = [[0, 'Toutes notes'], [6, '6+'], [7, '7+'], [8, '8+']];

// Filtre et tri des résultats (fonction pure, testée à part)
export function refine(list, { minNote = 0, sort = 'rel' } = {}) {
  let l = minNote ? list.filter((x) => (x.rating || 0) >= minNote) : list;
  if (sort === 'year') l = [...l].sort((a, b) => (b.year || 0) - (a.year || 0));
  if (sort === 'rating') l = [...l].sort((a, b) => (b.rating || 0) - (a.rating || 0));
  if (sort === 'az') l = [...l].sort((a, b) => String(a.title).localeCompare(String(b.title), 'fr'));
  return l;
}
const dedupe = (list) => { const seen = new Set(); return list.filter((x) => (seen.has(x.key) ? false : seen.add(x.key))); };

// Complément TMDB : titres trouvés autrement que par leur nom (titre original, acteur, réalisateur)
// et titres connus mais absents de tes serveurs.
function useTmdbSearch(tmdb, catalog, q) {
  const [st, setSt] = useState({ extra: [], missing: [], person: null });
  useEffect(() => {
    setSt({ extra: [], missing: [], person: null });
    const query = q.trim();
    if (!tmdb || !tmdb.enabled || query.length < 3) return undefined;
    let off = false;
    const t = setTimeout(async () => {
      try {
        const d = await tmdb.req('/search/multi', { query, language: 'fr-FR' }, DAY);
        const res = (d && d.results) || [];
        const extra = [];
        const missing = [];
        for (const r of res) {
          if (r.media_type !== 'movie' && r.media_type !== 'tv') continue;
          const type = r.media_type === 'tv' ? 'tv' : 'movie';
          const it = matchTmdb(catalog, r, type);
          if (it) extra.push(it);
          else if (r.poster_path) missing.push({ id: r.id, type, title: r.title || r.name, date: r.release_date || r.first_air_date || '', poster: img(r.poster_path) });
        }
        let person = null;
        const pr = res.slice(0, 3).find((r) => r.media_type === 'person');
        if (pr) {
          const c = await tmdb.req('/person/' + pr.id + '/combined_credits', { language: 'fr-FR' }, 7 * DAY);
          const all = [...((c && c.cast) || []), ...((c && c.crew) || []).filter((x) => x.job === 'Director')]
            .sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
          const seen = new Set();
          const items = [];
          for (const x of all) {
            const it = matchTmdb(catalog, x, x.media_type === 'tv' ? 'tv' : 'movie');
            if (it && !seen.has(it.key)) { seen.add(it.key); items.push(it); }
            if (items.length >= 40) break;
          }
          if (items.length) person = { name: pr.name, items };
        }
        if (!off) setSt({ extra, missing: missing.slice(0, 20), person });
      } catch { /* TMDB indisponible : la recherche locale suffit */ }
    }, 350);
    return () => { off = true; clearTimeout(t); };
  }, [q, tmdb, catalog]);
  return st;
}

export default function Search({ route }) {
  const { catalog, tmdb, navigate: nav, addSearch, searchHistory, removeSearch, clearSearch, goRoot } = useApp();
  // Ouvrir un résultat mémorise la recherche
  const navigate = (r) => { addSearch(route.q); nav(r); };
  const q = route.q || '';
  const [type, setType] = useState('all');
  const [sort, setSort] = useState('rel');
  const [minNote, setMinNote] = useState(0);
  const r = useMemo(() => searchCatalog(catalog, q, 200), [catalog, q]);
  const ext = useTmdbSearch(tmdb, catalog, q);

  const movies = useMemo(() => refine(dedupe([...r.movies, ...ext.extra.filter((x) => x.kind === 'movie')]), { minNote, sort }), [r, ext, minNote, sort]);
  const series = useMemo(() => refine(dedupe([...r.series, ...ext.extra.filter((x) => x.kind === 'series')]), { minNote, sort }), [r, ext, minNote, sort]);
  const personItems = useMemo(() => (ext.person ? refine(ext.person.items, { minNote, sort }) : []), [ext, minNote, sort]);
  const live = r.live;
  const show = (k) => type === 'all' || type === k;
  const total = movies.length + series.length + live.length + personItems.length;
  const active = q.length >= 2;
  const openItem = (m) => navigate({ name: 'fiche', item: m });
  const card = (m) => <ItemCard key={m.key} item={m} onOpen={() => openItem(m)} />;

  return (
    <div style={{ paddingTop: 110, paddingBottom: 60 }}>
      {isTV
        ? <div style={{ padding: '0 var(--gutter)', marginBottom: 26 }}><TvKeyboard value={q} onChange={(v) => goRoot({ name: 'search', q: v })} /></div>
        : <h1 className="page-title" style={{ padding: '0 var(--gutter)', marginBottom: 16 }}>{q ? `« ${q} »` : 'Recherche'}</h1>}

      {active && !isTV && (
        <div className="toolbar search-tools" style={{ padding: '0 var(--gutter)', marginBottom: 22 }}>
          <div className="pills" role="group" aria-label="Type">
            {TYPES.map(([k, l]) => {
              const n = k === 'movie' ? movies.length : k === 'series' ? series.length : k === 'live' ? live.length : total;
              return <button key={k} className={'pill' + (type === k ? ' on' : '')} onClick={() => setType(k)}>{l} · {n}</button>;
            })}
          </div>
          <div className="seg" role="group" aria-label="Tri">
            {SORTS.map(([k, l]) => <button key={k} className={sort === k ? 'on' : ''} onClick={() => setSort(k)}>{l}</button>)}
          </div>
          <div className="seg" role="group" aria-label="Note minimale">
            {NOTES.map(([k, l]) => <button key={k} className={minNote === k ? 'on' : ''} onClick={() => setMinNote(k)}>{l}</button>)}
          </div>
        </div>
      )}

      {active && total === 0 && (
        <EmptyState icon="search" title={'Rien sur tes serveurs pour « ' + q + ' »'}
          hint={minNote ? 'Essaie sans le filtre de note, ou un autre mot.' : ext.missing.length ? 'Des titres correspondants existent, mais pas chez toi : ils sont listés juste en dessous.' : 'Vérifie l\'orthographe, ou explore les tendances.'}
          action={minNote ? { label: 'Retirer le filtre de note', onClick: () => setMinNote(0) } : { label: 'Explorer Découvrir', onClick: () => goRoot({ name: 'decouvrir' }) }} />
      )}

      {!active && (
        <div style={{ padding: '0 var(--gutter)' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginBottom: 14 }}>
            <h2 className="row-title">Recherches récentes</h2>
            {searchHistory.length > 0 && <button className="see-all" onClick={clearSearch}>Effacer l'historique</button>}
          </div>
          {searchHistory.length === 0 && <p className="muted">Tes recherches apparaîtront ici. Tu peux chercher un titre, un acteur ou un réalisateur.</p>}
          <div className="pills">
            {searchHistory.map((h) => (
              <span key={h} className="hist-chip">
                <button onClick={() => goRoot({ name: 'search', q: h })}>{h}</button>
                <button onClick={() => removeSearch(h)} aria-label={'Retirer ' + h}>×</button>
              </span>
            ))}
          </div>
        </div>
      )}

      {active && (type === 'movie' || type === 'series') ? (
        <div style={{ padding: '0 var(--gutter)' }}>
          <div className="grid">{(type === 'movie' ? movies : series).map(card)}</div>
        </div>
      ) : active && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 30 }}>
          {show('movie') && movies.length > 0 && <Row title={`Films · ${movies.length}`}>{movies.slice(0, 60).map(card)}</Row>}
          {show('series') && series.length > 0 && <Row title={`Séries · ${series.length}`}>{series.slice(0, 60).map(card)}</Row>}
          {type === 'all' && personItems.length > 0 && <Row title={`Avec ${ext.person.name}, chez toi · ${personItems.length}`}>{personItems.map(card)}</Row>}
          {show('live') && live.length > 0 && (
            <Row title={`Chaînes · ${live.length}`}>
              {live.slice(0, 60).map((c) => (
                <button key={c.key} className="card tile" onClick={() => navigate({ name: 'player', ref: liveRef(c, live.map((x) => x.key)) })}>
                  <div style={{ position: 'relative', width: 120, height: 60 }}><Img src={c.logo} fit="contain" className="cover" style={{ width: '100%', height: '100%' }} /></div>
                  <span style={{ color: '#fff', fontWeight: 600 }}>{c.name}</span>
                </button>
              ))}
            </Row>
          )}
        </div>
      )}

      {active && type !== 'live' && ext.missing.length > 0 && (
        <div style={{ marginTop: 30 }}>
          <Row title={`Pas sur tes serveurs · ${ext.missing.length}`}>
            {ext.missing.map((m) => (
              <PosterCard key={m.type + m.id} title={m.title} poster={m.poster} meta={{ year: Number(String(m.date).slice(0, 4)) || 0, kind: m.type === 'tv' ? 'series' : 'movie' }}
                onOpen={() => navigate({ name: 'fiche', item: null, tmdb: { type: m.type, id: m.id, title: m.title, date: m.date } })} />
            ))}
          </Row>
        </div>
      )}
    </div>
  );
}
