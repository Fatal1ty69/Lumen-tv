import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { getDetails } from '../lib/details.js';
import { matchTmdb } from '../lib/catalog.js';
import { PROVIDERS, img, serverPlatformItems, useProviderLogos } from '../lib/tmdb.js';
import { resumeList, movieRef, liveRef } from '../lib/play.js';
import { pickVariant } from '../lib/live.js';
import { loadJSON, saveJSON } from '../lib/store.js';
import { isTV } from '../tv/native.js';
import { Img } from '../components/ui.jsx';
import { useEpgs, useNow, ImageCard } from '../components/LiveShared.jsx';
import { fmtRemain, epSub, endAt, lenMinutes } from '../lib/fmt.js';
import { useResumeArt } from '../lib/upnext.js';
import { useResume } from '../lib/resume-v26.js';
import { Icon, Row, PosterCard, LandCard, Tile, HeroSkel, EmptyState, MetaChips } from '../components/ui.jsx';
import { SurpriseBar } from '../components/Surprise.jsx';
import ItemCard from '../components/ItemCard.jsx';
import { useHomeReco, personalHeroPool } from '../lib/homeGuide.js';

export default function Home({ active }) {
  const app = useApp();
  const { catalog, tmdb, progress, favorites, watchlist, navigate, settings, hideResume } = app;
  const [heroes, setHeroes] = useState([]);
  const logos = useProviderLogos(tmdb);
  const [idx, setIdx] = useState(0);
  const [trendMovies, setTrendMovies] = useState([]);
  const [trendSeries, setTrendSeries] = useState([]);
  // v32 : populaires et mieux notés, uniquement ce qui est sur tes serveurs
  const [popular, setPopular] = useState({ movie: [], series: [] });
  const [topRated, setTopRated] = useState({ movie: [], series: [] });
  const [showTrailer, setShowTrailer] = useState(false);
  const [heroSound, setHeroSound] = useState(false);
  const yt = useRef(null);

  const newMovies = useMemo(() => [...catalog.vod].sort((a, b) => b.added - a.added).slice(0, 30), [catalog]);
  const newSeries = useMemo(() => [...catalog.series].sort((a, b) => b.added - a.added).slice(0, 30), [catalog]);

  const trending = useMemo(() => [...trendMovies, ...trendSeries], [trendMovies, trendSeries]);

  // Tendances TMDB, strictement limitées aux titres présents dans le catalogue.
  // Si TMDB n'est pas configuré ou ne répond pas, les rangées restent simplement
  // absentes et les autres rubriques de l'accueil continuent de fonctionner.
  useEffect(() => {
    let off = false;
    setTrendMovies([]);
    setTrendSeries([]);
    if (!tmdb.enabled || !catalog) return undefined;
    const localHits = (list, type) => {
      const seen = new Set();
      return (list || []).map((t) => {
        const item = matchTmdb(catalog, t, type);
        if (!item || seen.has(item.key)) return null;
        seen.add(item.key);
        return { item, t: { ...t, media_type: type } };
      }).filter(Boolean).slice(0, 30);
    };
    // Plusieurs pages TMDB par liste : seule une partie des titres est sur ton serveur
    const pages = (path, n, ttl) => Promise.all(Array.from({ length: n }, (_, i) =>
      tmdb.req(path, { language: 'fr-FR', page: i + 1 }, ttl).then((d) => d.results || []).catch(() => []))).then((l) => l.flat());
    const H6 = 6 * 3600 * 1000;
    Promise.all([
      pages('/trending/movie/week', 3, H6), pages('/trending/tv/week', 3, H6),
      pages('/movie/popular', 5, H6), pages('/tv/popular', 5, H6),
      pages('/movie/top_rated', 8, 4 * H6), pages('/tv/top_rated', 8, 4 * H6)
    ]).then(([tm, ts, pm, ps, rm, rs]) => {
      if (off) return;
      const tMovies = localHits(tm, 'movie'), tSeries = localHits(ts, 'tv');
      setTrendMovies(tMovies);
      setTrendSeries(tSeries);
      // Pas de doublon d'une rangée à l'autre : chaque rangée apporte d'autres titres
      const used = new Set([...tMovies, ...tSeries].map((h) => h.item.key));
      const unique = (list) => list.filter((h) => (used.has(h.item.key) ? false : (used.add(h.item.key), true)));
      const pop = { movie: unique(localHits(pm, 'movie')), series: unique(localHits(ps, 'tv')) };
      setPopular(pop);
      setTopRated({ movie: unique(localHits(rm, 'movie')), series: unique(localHits(rs, 'tv')) });
    }).catch(() => {
      if (!off) { setTrendMovies([]); setTrendSeries([]); }
    });
    return () => { off = true; };
  }, [catalog, tmdb]);

  const resume = useResume(20);
  const artOf = useResumeArt(resume);
  // v31 : une seule rangée de recommandations, 15 titres minimum, alternée titre / genre
  const reco = useHomeReco(app, active);

  // v31 : « à la une » personnel. D'abord un nouvel épisode, ta liste et une recommandation,
  // puis les tendances et les nouveautés comme avant. Chaque titre dit pourquoi il est là.
  const personal = useMemo(() => personalHeroPool({ catalog, resume, watchlist, progress, reco }),
    [catalog, resume.map((r) => r.ref.key + (r.fresh ? '!' : '')).join('|'), Object.keys(watchlist || {}).join('|'), reco && reco.items[0] && reco.items[0].key]);
  const personalSig = personal.map((p) => p.item.key).join('|');
  useEffect(() => {
    let off = false;
    const pool = [...personal];
    const add = (item, reason) => { if (item && !pool.some((p) => p.item.key === item.key)) pool.push({ item, reason }); };
    trending.slice(0, 5).forEach((h) => { if (pool.length < 5) add(h.item, 'Tendance cette semaine'); });
    for (const m of newMovies) { if (pool.length >= 5) break; add(m, 'Nouveau sur ton serveur'); }
    if (pool.length < 5) for (const s of newSeries) { if (pool.length >= 5) break; add(s, 'Nouveau sur ton serveur'); }
    const pick = pool.slice(0, 5);
    Promise.all(pick.map((p) => getDetails(app, p.item).catch(() => null))).then((list) => {
      if (off) return;
      setHeroes(list.map((d, i) => d && { ...d, reason: pick[i].reason }).filter((d) => d && d.view.backdrop));
      setIdx(0);
    });
    return () => { off = true; };
  }, [trending, newMovies, catalog, personalSig]);

  // Défilement automatique du bandeau
  useEffect(() => {
    setShowTrailer(false);
    setHeroSound(false);
    if (!active || !settings.heroTrailer) return;
    const trailerT = setTimeout(() => setShowTrailer(true), 4000);
    return () => clearTimeout(trailerT);
  }, [idx, heroes.length, active, settings.heroTrailer]);

  // Passage au titre suivant, sauf si on écoute la bande-annonce avec le son
  useEffect(() => {
    if (!active || heroes.length < 2 || heroSound) return;
    const t = setTimeout(() => {
      // TV : on ne change pas le titre à la une pendant qu'il est sélectionné
      if (isTV && document.activeElement && document.activeElement.closest && document.activeElement.closest('.hero')) { setIdx((i) => i); return; }
      setIdx((i) => (i + 1) % heroes.length);
    }, 45000);
    return () => clearTimeout(t);
  }, [idx, heroes.length, active, heroSound]);

  const hero = heroes[idx];
  const favs = Object.values(favorites).filter((f) => f.kind === 'movie' || f.kind === 'series').sort((a, b) => b.t - a.t);
  // Cette source ne fournit que le direct (pas de films ni de séries) : on l'indique au lieu d'un accueil vide
  const noVod = catalog.vod.length === 0 && catalog.series.length === 0;

  // Recommandations « Parce que tu as regardé … » : titres similaires (TMDB) présents sur ton serveur

  const openItem = (item) => navigate({ name: 'fiche', item });
  const playHero = () => {
    if (!hero) return;
    if (hero.item.kind === 'movie') {
      const p = progress[hero.item.key];
      navigate({ name: 'player', ref: movieRef(hero.item, hero.view), startAt: p ? p.pos : 0 });
    } else navigate({ name: 'fiche', item: hero.item });
  };

  return (
    <main>
      <section className="hero">
        {hero ? (
          <>
            <img key={hero.view.backdrop} className="hero-bg" src={hero.view.backdrop} alt="" />
            {!isTV && showTrailer && hero.view.trailer && active && (
              <iframe ref={yt} key={'t' + idx} className="hero-video" title="Bande-annonce" allow="autoplay; encrypted-media"
                src={`https://www.youtube-nocookie.com/embed/${hero.view.trailer}?autoplay=1&mute=1&controls=0&loop=1&playlist=${hero.view.trailer}&modestbranding=1&rel=0&iv_load_policy=3&disablekb=1&hl=fr&enablejsapi=1`} />
            )}
            {!isTV && showTrailer && hero.view.trailer && active && (
              <div className="hero-ctrl">
                <button className="btn btn-round" aria-label={heroSound ? 'Couper le son' : 'Activer le son'} title={heroSound ? 'Couper le son' : 'Activer le son'}
                  onClick={() => {
                    const next = !heroSound;
                    setHeroSound(next);
                    if (yt.current) yt.current.contentWindow.postMessage(JSON.stringify({ event: 'command', func: next ? 'unMute' : 'mute', args: [] }), '*');
                  }}>
                  <Icon name={heroSound ? 'volume' : 'mute'} size={20} />
                </button>
                <button className="btn btn-round" aria-label="Arrêter la bande-annonce" title="Arrêter la bande-annonce" onClick={() => setShowTrailer(false)}>
                  <Icon name="close" size={18} />
                </button>
              </div>
            )}
            <div className="scrim-left" />
            <div className="scrim-bottom" />
            <div className="hero-body" key={'b' + idx}>
              <div className={'kicker' + (hero.reason && !/Tendance|Nouveau sur/.test(hero.reason) ? ' kicker-mine' : '')}>{hero.item.kind === 'series' ? 'Série' : 'Film'}{' · ' + (hero.reason || 'Nouveau sur ton serveur')}</div>
              {hero.view.logo
                ? <img className="title-logo" src={hero.view.logo} alt={hero.view.title} />
                : <h1 className="big-title">{hero.view.title}</h1>}
              <MetaChips score={hero.view.score} year={hero.view.year} len={hero.view.len}
                end={hero.item.kind === 'movie' ? endAt(Math.max(1, lenMinutes(hero.view.len) - ((progress[hero.item.key] && !progress[hero.item.key].watched && progress[hero.item.key].pos) || 0) / 60)) : ''}
                extra={hero.item.kind === 'series' && hero.seasons && hero.seasons.filter((n) => n > 0).length
                  ? hero.seasons.filter((n) => n > 0).length + (hero.seasons.filter((n) => n > 0).length > 1 ? ' saisons' : ' saison') : ''} />
              {hero.view.genres.length > 0 && <div className="hero-genres">{hero.view.genres.join(' · ')}</div>}
              <p className="synopsis">{hero.view.overview}</p>
              <div className="actions">
                <button className="btn btn-primary" onClick={playHero}><Icon name="play" size={18} />Lecture</button>
                <button className="btn btn-ghost" onClick={() => openItem(hero.item)}><Icon name="info" size={20} />Plus d'infos</button>
              </div>
            </div>
            {!isTV && <div className="dots">
              {heroes.map((h, i) => (
                <button key={i} className={i === idx ? 'on' : ''} onClick={() => setIdx(i)} aria-label={'À la une ' + (i + 1) + ', ' + h.view.title} />
              ))}
            </div>}
          </>
        ) : (noVod ? <div className="scrim-bottom" /> : <HeroSkel />)}
      </section>

      <div className="rows">
        {noVod && (
          <EmptyState icon="tv" title="Pas encore de films ni de séries ici"
            hint="Cette source alimente le direct. Ajoute un serveur Xtream dans les réglages pour voir arriver films et séries."
            action={{ label: 'Ouvrir les réglages', onClick: () => navigate({ name: 'settings' }) }} />
        )}
        {!noVod && !isTV && <SurpriseBar />}
        {resume.length > 0 && (
          <Row title="Continuer à regarder">
            {resume.map((p) => (
              <LandCard key={p.ref.key} item={catalog.byKey.get(p.ref.kind === 'episode' ? p.ref.seriesKey : p.ref.key)} badge={p.fresh ? 'NOUVEL ÉPISODE' : p.next ? 'À SUIVRE' : null} title={p.ref.title} image={artOf(p)} fallback={artOf.fb(p)} pct={(p.pos / p.dur) * 100}
                sub={p.fresh ? 'Nouveau · ' + epSub(p.ref) : p.next ? 'Épisode suivant · ' + epSub(p.ref) : (p.ref.kind === 'episode' ? epSub(p.ref) + ' · ' : 'Film · ') + fmtRemain(p.pos, p.dur)}
                onOpen={() => navigate({ name: 'player', ref: p.ref, startAt: p.pos })} onRemove={() => hideResume(p.ref)} />
            ))}
          </Row>
        )}

        {!isTV && reco && (
          <Row title={reco.title}>
            {reco.items.map((it) => (
              <ItemCard key={it.key} item={it} />
            ))}
          </Row>
        )}

        {isTV && <LiveNow />}

        {favs.length > 0 && (
          <Row title="Ma liste" onSeeAll={() => navigate({ name: 'monespace', tab: 'liste' })}>
            {favs.slice(0, 30).map((f) => {
              const it = catalog.byKey.get(f.key);
              return it ? <ItemCard key={f.key} item={it} poster={f.poster} /> : null;
            })}
          </Row>
        )}


        {/* v32 : tout l'accueil, uniquement ce qui est sur tes serveurs */}
        <DualRow title="Tendances du moment" store="homeTrendKind"
          movies={trendMovies} series={trendSeries} card={(h) => <ItemCard key={h.item.key} item={h.item} poster={h.item.poster || img(h.t.poster_path)} />} />
        <DualRow title="Populaires" store="homePopKind"
          movies={popular.movie} series={popular.series} card={(h) => <ItemCard key={h.item.key} item={h.item} poster={h.item.poster || img(h.t.poster_path)} />} />
        <DualRow title="Les mieux notés" store="homeTopKind"
          movies={topRated.movie} series={topRated.series} card={(h) => <ItemCard key={h.item.key} item={h.item} poster={h.item.poster || img(h.t.poster_path)} />} />
        <DualRow title="Nouveau sur tes serveurs" store="homeNewKind" min={1}
          movies={newMovies} series={newSeries}
          onSeeAll={(k) => navigate({ name: 'browse', kind: k, sort: 'added' })}
          card={(it) => it.kind === 'movie'
            ? <ItemCard key={it.key} item={it} badge="NOUVEAU" onOpen={() => openItem(it)} />
            : <ItemCard key={it.key} item={it} sub={(it.genre || '').split(/[,/]/)[0].trim() || undefined} onOpen={() => openItem(it)} />} />

        {/* v34 : les plateformes reviennent, en portes d'entrée (même page que l'onglet de Découvrir) */}
        <Row title="Plateformes">
          {PROVIDERS.map((p) => {
            const n = serverPlatformItems(catalog, p);
            const count = n.movies.length + n.series.length;
            return (
              <Tile key={p.id} name={p.name} logo={logos[p.id]}
                sub={count ? `${count} titres sur ton serveur` : tmdb.enabled ? 'Ce qui est chez toi' : 'Clé TMDB conseillée'}
                onOpen={() => navigate({ name: 'vitrine', provider: p.id })} />
            );
          })}
        </Row>
      </div>
    </main>
  );
}

// v32 : rangée Films / Séries. Choix mémorisé ; masquée sous « min » titres ; pastilles seulement si les deux existent
function DualRow({ title, store, movies, series, card, onSeeAll, min = 6 }) {
  const okM = movies.length >= min, okS = series.length >= min;
  const [kind, setKind] = useState(() => loadJSON(store, 'movie'));
  if (!okM && !okS) return null;
  const k = okM && okS ? kind : (okM ? 'movie' : 'series');
  const pick = (v) => { setKind(v); saveJSON(store, v); };
  return (
    <Row title={title} extra={<KindPills value={k} onPick={pick} has={{ movie: okM, series: okS }} />}
      onSeeAll={onSeeAll ? () => onSeeAll(k) : undefined}
      tvSwitch={okM && okS ? { label: k === 'movie' ? 'Voir les séries' : 'Voir les films', onClick: () => pick(k === 'movie' ? 'series' : 'movie') } : undefined}>
      {(k === 'movie' ? movies : series).map(card)}
    </Row>
  );
}

// v31 : bascule Films / Séries d'une rangée fusionnée (masquée s'il n'y a qu'un des deux)
function KindPills({ value, onPick, has }) {
  if (!has.movie || !has.series) return null;
  return (
    <div className="row-pills" role="group" aria-label="Type de titres">
      {[['movie', 'Films'], ['series', 'Séries']].map(([k, label]) => (
        <button key={k} className={value === k ? 'on' : ''} aria-pressed={value === k} onClick={() => onPick(k)} tabIndex={isTV ? -1 : undefined}>{label}</button>
      ))}
    </div>
  );
}

// Fausse chaîne servant de titre de rubrique (« ##### SPORT ##### », « ----- FRANCE ----- »…)
function isSeparator(name) {
  const n = String(name || '').trim();
  return /^[#=*★☆✦•◆♦\-_|~+]{2,}/.test(n) || /[#=*★]{3,}|-{4,}|={3,}/.test(n) || n.length < 2;
}

// TV : ce qui passe en ce moment sur les chaînes du premier groupe, avec l'image du programme
function LiveNow() {
  const { catalog, navigate, settings, favorites, xtOf, tmdb } = useApp();
  // Chaînes du premier groupe, dans l'ordre du serveur, sans les fausses chaînes qui servent de titres de rubrique
  const groups = useMemo(() => {
    const first = catalog.liveCats[0];
    const l = catalog.liveGroups.filter((g) => (!first || g.cat === first.id) && !isSeparator(g.name) && !isSeparator(g.variants[0] && g.variants[0].ch.name));
    // La première entrée du groupe est presque toujours le titre du groupe : on l'écarte d'office
    return [...l].sort((a, b) => (a.num || 0) - (b.num || 0)).slice(1, 17);
  }, [catalog]);
  const chosen = useMemo(() => Object.fromEntries(groups.map((g) => [g.key, pickVariant(g, settings.liveQuality)])), [groups, settings.liveQuality]);
  const epgs = useEpgs(xtOf, groups.map((g) => chosen[g.key]).filter(Boolean));
  const now = useNow();
  if (!groups.length) return null;
  const play = (g) => {
    const ch = chosen[g.key];
    if (ch) navigate({ name: 'player', ref: liveRef(ch, catalog.liveGroups.filter((x) => x.cat === g.cat).map((x) => x.key), g) });
  };
  return (
    <Row title="En direct maintenant">
      {groups.map((g) => chosen[g.key] && (
        <ImageCard key={g.key} g={g} ch={chosen[g.key]} progs={epgs[chosen[g.key].key] || []} now={now} onPlay={play} tmdb={tmdb} />
      ))}
    </Row>
  );
}
