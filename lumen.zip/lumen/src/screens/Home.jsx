import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { getDetails } from '../lib/details.js';
import { matchTmdb } from '../lib/catalog.js';
import { PROVIDERS, img, serverPlatformItems, useProviderLogos } from '../lib/tmdb.js';
import { resumeList, movieRef, liveRef } from '../lib/play.js';
import { pickVariant } from '../lib/live.js';
import { loadJSON } from '../lib/store.js';
import { isTV } from '../tv/native.js';
import { Img } from '../components/ui.jsx';
import { useEpgs, useNow, ImageCard } from './Live.jsx';
import { fmtRemain } from '../lib/player.js';
import { useResume, useResumeArt } from '../lib/upnext.js';
import { Icon, Row, PosterCard, LandCard, Top10Card, Tile, CatTile } from '../components/ui.jsx';

const DECADES = [2020, 2010, 2000, 1990, 1980];

export default function Home({ active }) {
  const app = useApp();
  const { catalog, tmdb, progress, favorites, navigate, settings, hideResume } = app;
  const [heroes, setHeroes] = useState([]);
  const logos = useProviderLogos(tmdb);
  const [idx, setIdx] = useState(0);
  const [trending, setTrending] = useState([]);
  const [showTrailer, setShowTrailer] = useState(false);
  const [heroSound, setHeroSound] = useState(false);
  const yt = useRef(null);

  const newMovies = useMemo(() => [...catalog.vod].sort((a, b) => b.added - a.added).slice(0, 30), [catalog]);
  const newSeries = useMemo(() => [...catalog.series].sort((a, b) => b.added - a.added).slice(0, 30), [catalog]);

  // Tendances TMDB disponibles sur le serveur
  useEffect(() => {
    let off = false;
    if (!tmdb.enabled) return;
    const src = isTV
      ? Promise.all([tmdb.trending('movie'), tmdb.trending('tv')]).then(([m, t]) => [...m.map((x) => ({ ...x, media_type: 'movie' })), ...t.map((x) => ({ ...x, media_type: 'tv' }))])
      : tmdb.trending('all');
    src.then((list) => {
      if (off) return;
      const hits = list.map((t) => {
        const type = t.media_type === 'tv' ? 'tv' : 'movie';
        const m = matchTmdb(catalog, t, type);
        return m ? { item: m, t } : null;
      }).filter(Boolean);
      setTrending(hits);
    }).catch(() => {});
    return () => { off = true; };
  }, [catalog, tmdb]);

  // Sélection des titres "à la une"
  useEffect(() => {
    let off = false;
    const pool = [];
    trending.slice(0, 5).forEach((h) => pool.push(h.item));
    for (const m of newMovies) { if (pool.length >= 5) break; if (!pool.includes(m)) pool.push(m); }
    if (pool.length < 5) for (const s of newSeries) { if (pool.length >= 5) break; pool.push(s); }
    Promise.all(pool.slice(0, 5).map((it) => getDetails(app, it).catch(() => null))).then((list) => {
      if (off) return;
      setHeroes(list.filter((d) => d && d.view.backdrop));
      setIdx(0);
    });
    return () => { off = true; };
  }, [trending, newMovies, catalog]);

  // Défilement automatique du bandeau
  useEffect(() => {
    setShowTrailer(false);
    setHeroSound(false);
    if (!active || !settings.heroTrailer) return;
    const trailerT = setTimeout(() => setShowTrailer(true), 4000);
    return () => clearTimeout(trailerT);
  }, [idx, heroes.length, active, settings.heroTrailer]);

  // Passage au titre suivant, sauf si on écoute la bande-annonce avec le son
  useEffect(() => {
    if (!active || heroes.length < 2 || heroSound) return;
    const t = setTimeout(() => {
      // TV : on ne change pas le titre à la une pendant qu'il est sélectionné
      if (isTV && document.activeElement && document.activeElement.closest && document.activeElement.closest('.hero')) { setIdx((i) => i); return; }
      setIdx((i) => (i + 1) % heroes.length);
    }, 45000);
    return () => clearTimeout(t);
  }, [idx, heroes.length, active, heroSound]);

  const hero = heroes[idx];
  const resume = useResume(20);
  const artOf = useResumeArt(resume);
  const favs = Object.values(favorites).filter((f) => f.kind === 'movie' || f.kind === 'series').sort((a, b) => b.t - a.t);

  const openItem = (item) => navigate({ name: 'fiche', item });
  const decades = DECADES.map((d) => {
    const films = catalog.vod.filter((m) => m.year >= d && m.year < d + 10);
    const pick = films.find((m) => m.poster) || null;
    return { d, count: films.length, image: pick ? pick.poster : '' };
  }).filter((x) => x.count > 0);

  const vodCats = catalog.vodCats.slice(0, 14).map((c) => {
    const first = catalog.vod.find((m) => m.cat === c.id && m.poster);
    return { ...c, image: first ? first.poster : '' };
  });

  const playHero = () => {
    if (!hero) return;
    if (hero.item.kind === 'movie') {
      const p = progress[hero.item.key];
      navigate({ name: 'player', ref: movieRef(hero.item, hero.view), startAt: p ? p.pos : 0 });
    } else navigate({ name: 'fiche', item: hero.item });
  };

  return (
    <main>
      <section className="hero">
        {hero ? (
          <>
            <img key={hero.view.backdrop} className="hero-bg" src={hero.view.backdrop} alt="" />
            {!isTV && showTrailer && hero.view.trailer && active && (
              <iframe ref={yt} key={'t' + idx} className="hero-video" title="Bande-annonce" allow="autoplay; encrypted-media"
                src={`https://www.youtube-nocookie.com/embed/${hero.view.trailer}?autoplay=1&mute=1&controls=0&loop=1&playlist=${hero.view.trailer}&modestbranding=1&rel=0&iv_load_policy=3&disablekb=1&hl=fr&enablejsapi=1`} />
            )}
            {!isTV && showTrailer && hero.view.trailer && active && (
              <div className="hero-ctrl">
                <button className="btn btn-round" aria-label={heroSound ? 'Couper le son' : 'Activer le son'} title={heroSound ? 'Couper le son' : 'Activer le son'}
                  onClick={() => {
                    const next = !heroSound;
                    setHeroSound(next);
                    if (yt.current) yt.current.contentWindow.postMessage(JSON.stringify({ event: 'command', func: next ? 'unMute' : 'mute', args: [] }), '*');
                  }}>
                  <Icon name={heroSound ? 'volume' : 'mute'} size={20} />
                </button>
                <button className="btn btn-round" aria-label="Arrêter la bande-annonce" title="Arrêter la bande-annonce" onClick={() => setShowTrailer(false)}>
                  <Icon name="close" size={18} />
                </button>
              </div>
            )}
            <div className="scrim-left" />
            <div className="scrim-bottom" />
            <div className="hero-body" key={'b' + idx}>
              <div className="kicker">{hero.item.kind === 'series' ? 'Série' : 'Film'}{trending.find((t) => t.item === hero.item) ? ' · Tendance cette semaine' : ' · Nouveau sur ton serveur'}</div>
              {hero.view.logo
                ? <img className="title-logo" src={hero.view.logo} alt={hero.view.title} />
                : <h1 className="big-title">{hero.view.title}</h1>}
              <div className="meta">
                {hero.view.score && <span className="score">{hero.view.score}</span>}
                <span>{[hero.view.year, hero.view.genres.join(', '), hero.view.len].filter(Boolean).join(' · ')}</span>
              </div>
              <p className="synopsis">{hero.view.overview}</p>
              <div className="actions">
                <button className="btn btn-primary" onClick={playHero}><Icon name="play" size={18} />Lecture</button>
                <button className="btn btn-ghost" onClick={() => openItem(hero.item)}><Icon name="info" size={20} />Plus d'infos</button>
              </div>
            </div>
            {!isTV && <div className="dots">
              {heroes.map((h, i) => (
                <button key={i} className={i === idx ? 'on' : ''} onClick={() => setIdx(i)} aria-label={'À la une ' + (i + 1) + ', ' + h.view.title} />
              ))}
            </div>}
          </>
        ) : <div className="scrim-bottom" />}
      </section>

      <div className="rows">
        {resume.length > 0 && (
          <Row title="Continuer à regarder">
            {resume.map((p) => (
              <LandCard key={p.ref.key} badge={p.fresh ? 'NOUVEL ÉPISODE' : p.next ? 'À SUIVRE' : null} title={p.ref.title} image={artOf(p)} fallback={artOf.fb(p)} pct={(p.pos / p.dur) * 100}
                sub={p.fresh ? 'Nouveau · ' + p.ref.sub.split(' · ').slice(0, 2).join(' · ') : p.next ? 'Épisode suivant · ' + p.ref.sub.split(' · ').slice(0, 2).join(' · ') : (p.ref.kind === 'episode' ? p.ref.sub.split(' · ').slice(0, 2).join(' · ') + ' · ' : 'Film · ') + fmtRemain(p.pos, p.dur)}
                onOpen={() => navigate({ name: 'player', ref: p.ref, startAt: p.pos })} onRemove={() => hideResume(p.ref)} />
            ))}
          </Row>
        )}

        {isTV && <LiveNow />}

        {favs.length > 0 && (
          <Row title="Ma liste" onSeeAll={() => navigate({ name: 'mylist' })}>
            {favs.slice(0, 30).map((f) => {
              const it = catalog.byKey.get(f.key);
              return it ? <PosterCard key={f.key} itemKey={f.key} title={f.title} poster={f.poster} onOpen={() => openItem(it)} /> : null;
            })}
          </Row>
        )}

        <Row title="Plateformes">
          {PROVIDERS.map((p) => {
            const n = serverPlatformItems(catalog, p);
            const count = n.movies.length + n.series.length;
            return (
              <Tile key={p.id} name={p.name} logo={logos[p.id]}
                sub={count ? `${count} titres sur ton serveur` : tmdb.enabled ? 'Ce qui est chez toi' : 'Clé TMDB conseillée'}
                onOpen={() => navigate({ name: 'vitrine', provider: p.id })} />
            );
          })}
        </Row>

        <Row title="Nouveautés films" onSeeAll={() => navigate({ name: 'browse', kind: 'movie', sort: 'added' })}>
          {newMovies.map((m) => (
            <PosterCard key={m.key} itemKey={m.key} title={m.title} poster={m.poster} badge="NOUVEAU"
              sub={[m.year, m.rating ? '★ ' + m.rating.toFixed(1) : ''].filter(Boolean).join(' · ')} onOpen={() => openItem(m)} />
          ))}
        </Row>

        {isTV && trending.some((h) => h.item.kind === 'movie') && (
          <Row title="Films tendance du moment">
            {trending.filter((h) => h.item.kind === 'movie').slice(0, 20).map((h) => (
              <PosterCard key={h.item.key} itemKey={h.item.key} title={h.item.title} poster={h.item.poster || img(h.t.poster_path)} onOpen={() => openItem(h.item)} />
            ))}
          </Row>
        )}
        {isTV && trending.some((h) => h.item.kind === 'series') && (
          <Row title="Séries tendance du moment">
            {trending.filter((h) => h.item.kind === 'series').slice(0, 20).map((h) => (
              <PosterCard key={h.item.key} itemKey={h.item.key} title={h.item.title} poster={h.item.poster || img(h.t.poster_path)} onOpen={() => openItem(h.item)} />
            ))}
          </Row>
        )}
        {!isTV && trending.length > 0 && (
          <Row title="Top 10 de la semaine, disponibles chez toi">
            {trending.slice(0, 10).map((h, i) => (
              <Top10Card key={h.item.key} rank={i + 1} title={h.item.title} poster={h.item.poster || img(h.t.poster_path)} onOpen={() => openItem(h.item)} />
            ))}
          </Row>
        )}

        <Row title="Nouveautés séries" onSeeAll={() => navigate({ name: 'browse', kind: 'series', sort: 'added' })}>
          {newSeries.map((s) => (
            <PosterCard key={s.key} itemKey={s.key} title={s.title} poster={s.poster}
              sub={[s.year, s.genre.split(/[,/]/)[0]].filter(Boolean).join(' · ')} onOpen={() => openItem(s)} />
          ))}
        </Row>

        {!isTV && decades.length > 0 && (
          <Row title="Décennies">
            {decades.map((x) => (
              <CatTile key={x.d} name={'Années ' + x.d} image={x.image} onOpen={() => navigate({ name: 'browse', kind: 'movie', decade: x.d })} />
            ))}
          </Row>
        )}

        {!isTV && <Row title="Groupes films">
          {vodCats.map((c) => (
            <CatTile key={c.id} name={c.name} image={c.image} onOpen={() => navigate({ name: 'browse', kind: 'movie', cat: c.id })} />
          ))}
        </Row>}
      </div>
    </main>
  );
}

// Fausse chaîne servant de titre de rubrique (« ##### SPORT ##### », « ----- FRANCE ----- »…)
function isSeparator(name) {
  const n = String(name || '').trim();
  return /^[#=*★☆✦•◆♦\-_|~+]{2,}/.test(n) || /[#=*★]{3,}|-{4,}|={3,}/.test(n) || n.length < 2;
}

// TV : ce qui passe en ce moment sur les chaînes du premier groupe, avec l'image du programme
function LiveNow() {
  const { catalog, navigate, settings, favorites, xtOf, tmdb } = useApp();
  // Chaînes du premier groupe, dans l'ordre du serveur, sans les fausses chaînes qui servent de titres de rubrique
  const groups = useMemo(() => {
    const first = catalog.liveCats[0];
    const l = catalog.liveGroups.filter((g) => (!first || g.cat === first.id) && !isSeparator(g.name) && !isSeparator(g.variants[0] && g.variants[0].ch.name));
    return [...l].sort((a, b) => (a.num || 0) - (b.num || 0)).slice(0, 16);
  }, [catalog]);
  const chosen = useMemo(() => Object.fromEntries(groups.map((g) => [g.key, pickVariant(g, settings.liveQuality)])), [groups, settings.liveQuality]);
  const epgs = useEpgs(xtOf, groups.map((g) => chosen[g.key]).filter(Boolean));
  const now = useNow();
  if (!groups.length) return null;
  const play = (g) => {
    const ch = chosen[g.key];
    if (ch) navigate({ name: 'player', ref: liveRef(ch, catalog.liveGroups.filter((x) => x.cat === g.cat).map((x) => x.key), g) });
  };
  return (
    <Row title="En direct maintenant">
      {groups.map((g) => chosen[g.key] && (
        <ImageCard key={g.key} g={g} ch={chosen[g.key]} progs={epgs[chosen[g.key].key] || []} now={now} onPlay={play} tmdb={tmdb} />
      ))}
    </Row>
  );
}
