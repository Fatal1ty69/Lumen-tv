import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { PROVIDERS, img, tmdbView, serverPlatformItems } from '../lib/tmdb.js';
import { matchTmdb } from '../lib/catalog.js';
import { getDetails } from '../lib/details.js';
import { Row, PosterCard, Spinner } from '../components/ui.jsx';

// Un titre affichable, qu'il vienne de TMDB ou seulement du serveur
function fromTmdb(t, catalog) {
  return {
    uid: t.media_type + t.id, type: t.media_type, real: true, item: matchTmdb(catalog, t, t.media_type),
    title: t.title || t.name, overview: t.overview, score: t.vote_average || 0,
    date: t.release_date || t.first_air_date || '', poster: img(t.poster_path), backdrop: img(t.backdrop_path, 'original'), tmdbId: t.id
  };
}
function fromItem(it) {
  return {
    uid: it.key, type: it.kind === 'series' ? 'tv' : 'movie', real: false, item: it,
    title: it.title, overview: it.plot || '', score: it.rating || 0,
    date: it.year ? String(it.year) : '', poster: it.poster, backdrop: it.backdrop || it.poster, tmdbId: it.tmdb
  };
}

export default function Vitrine({ route }) {
  const app = useApp();
  const { tmdb, catalog, navigate, goRoot } = app;
  const provider = PROVIDERS.find((p) => p.id === route.provider) || PROVIDERS[0];
  const [lists, setLists] = useState(null);
  const [loading, setLoading] = useState(false);
  const [type, setType] = useState('all');
  const [onlyHome, setOnlyHome] = useState(false);
  const [view, setView] = useState('vitrine');
  const [focus, setFocus] = useState(null);
  const [fv, setFv] = useState(null);
  const timer = useRef(null);

  const server = useMemo(() => serverPlatformItems(catalog, provider), [catalog, provider.id]);

  useEffect(() => {
    setLists(null);
    if (!tmdb.enabled) return;
    let off = false;
    setLoading(true);
    const get = (t, sort, page = 1) => tmdb.byProvider(provider.id, t, sort, page).catch(() => []);
    Promise.all([
      get('movie', 'primary_release_date.desc'), get('tv', 'first_air_date.desc'),
      get('movie', 'popularity.desc'), get('movie', 'popularity.desc', 2),
      get('tv', 'popularity.desc'), get('tv', 'popularity.desc', 2)
    ]).then(([nm, nt, pm1, pm2, pt1, pt2]) => {
      if (off) return;
      const dec = (arr) => arr.map((t) => fromTmdb(t, catalog));
      setLists({
        news: dec([...nm, ...nt]).sort((a, b) => b.date.localeCompare(a.date)),
        movies: dec([...pm1, ...pm2]),
        shows: dec([...pt1, ...pt2])
      });
    }).finally(() => !off && setLoading(false));
    return () => { off = true; };
  }, [provider.id, tmdb, catalog]);

  const filt = (arr) => arr.filter((x) => (type === 'all' || x.type === type) && (!onlyHome || x.item));
  const rows = useMemo(() => {
    const out = [];
    const sm = server.movies.slice(0, 60).map(fromItem);
    const ss = server.series.slice(0, 60).map(fromItem);
    if (lists) {
      const home = [...lists.news, ...lists.movies, ...lists.shows].filter((x) => x.item);
      const seen = new Set();
      out.push({ title: `Chez toi, depuis ${provider.name}`, items: filt(home.filter((x) => (seen.has(x.item.key) ? false : seen.add(x.item.key)))) });
      out.push({ title: `Nouveautés ${provider.name}`, items: filt(lists.news) });
    }
    out.push({ title: `Films ${provider.name} de ton serveur`, items: filt(sm) });
    out.push({ title: `Séries ${provider.name} de ton serveur`, items: filt(ss) });
    if (lists) {
      out.push({ title: `Populaires sur ${provider.name} · Films`, items: filt(lists.movies) });
      out.push({ title: `Populaires sur ${provider.name} · Séries`, items: filt(lists.shows) });
    }
    return out.filter((r) => r.items.length);
  }, [lists, server, type, onlyHome, provider.name]);

  // Premier titre mis en avant
  useEffect(() => {
    if (!rows.length) { setFocus(null); return; }
    if (!focus || !rows.some((r) => r.items.some((x) => x.uid === focus.uid))) setFocus(rows[0].items[0]);
  }, [rows]);

  // Fiche du titre survolé (logo, grand visuel, casting)
  useEffect(() => {
    if (!focus) return;
    setFv(null);
    clearTimeout(timer.current);
    let off = false;
    timer.current = setTimeout(() => {
      if (focus.real) tmdb.details(focus.type, focus.tmdbId).then((d) => !off && setFv(tmdbView(d, focus.type))).catch(() => {});
      else getDetails(app, focus.item).then((d) => !off && setFv({ ...d.view, cast: d.view.cast || [] })).catch(() => {});
    }, 220);
    return () => { off = true; clearTimeout(timer.current); };
  }, [focus && focus.uid]);

  const open = (x) => navigate(x.real
    ? { name: 'fiche', item: x.item || null, tmdb: { type: x.type, id: x.tmdbId, title: x.title, date: x.date } }
    : { name: 'fiche', item: x.item });

  const nothing = !loading && rows.length === 0;

  return (
    <main>
      <section className="hero" style={{ height: 'max(680px, min(78vh, 740px))' }}>
        {focus && <img key={focus.uid} className="hero-bg" src={(fv && fv.backdrop) || focus.backdrop} alt="" />}
        <div className="scrim-left" style={{ background: 'linear-gradient(90deg, var(--bg) 0%, rgba(var(--bg-rgb),.88) 36%, rgba(var(--bg-rgb),.1) 72%)' }} />
        <div className="scrim-bottom" />
        <div className="vitrine-bar">
          <div className="pills" role="tablist" aria-label="Plateforme">
            {PROVIDERS.map((p) => (
              <button key={p.id} role="tab" aria-selected={p.id === provider.id} className={'pill' + (p.id === provider.id ? ' on' : '')}
                onClick={() => goRoot({ name: 'vitrine', provider: p.id })}>{p.name}</button>
            ))}
          </div>
          <div style={{ flex: '1 1 auto' }} />
          <div className="seg" role="group" aria-label="Type">
            {[['all', 'Tout'], ['movie', 'Films'], ['tv', 'Séries']].map(([k, l]) => (
              <button key={k} className={type === k ? 'on' : ''} onClick={() => setType(k)}>{l}</button>
            ))}
          </div>
          {tmdb.enabled && <button className={'pill' + (onlyHome ? ' on' : '')} onClick={() => setOnlyHome((v) => !v)} aria-pressed={onlyHome}>Seulement chez moi</button>}
          <div className="seg" role="group" aria-label="Vue">
            <button className={view === 'grille' ? 'on' : ''} onClick={() => setView('grille')}>Grille</button>
            <button className={view === 'vitrine' ? 'on' : ''} onClick={() => setView('vitrine')}>Vitrine</button>
          </div>
        </div>

        {focus && (
          <div className="hero-body" key={focus.uid} style={{ bottom: 120, maxWidth: 620 }}>
            <div className="kicker">{provider.name} · {focus.type === 'tv' ? 'Série' : 'Film'}{focus.item ? ' · Chez toi' : ''}</div>
            {fv && fv.logo ? <img className="title-logo" src={fv.logo} alt={focus.title} /> : <h1 className="big-title" style={{ fontSize: 'clamp(48px, 6vw, 92px)' }}>{focus.title}</h1>}
            <div className="meta">
              {focus.score > 0 && <span className="score">{Number(focus.score).toFixed(1)}</span>}
              <span>{[focus.date.slice(0, 4), fv && fv.genres && fv.genres.slice(0, 3).join(', '), fv && fv.len].filter(Boolean).join(' · ')}</span>
            </div>
            <p className="synopsis" style={{ fontSize: 17 }}>{focus.overview || (fv && fv.overview)}</p>
            {fv && fv.cast && fv.cast.length > 0 && <div className="muted" style={{ fontSize: 14 }}>Avec {fv.cast.slice(0, 4).map((c) => c.name).join(', ')}</div>}
            <div className="actions">
              <button className="btn btn-primary" onClick={() => open(focus)}>Voir la fiche</button>
              {!focus.item && <span className="muted" style={{ alignSelf: 'center', fontSize: 14 }}>Pas encore sur ton serveur</span>}
            </div>
          </div>
        )}

        {nothing && (
          <div className="hero-body" style={{ bottom: 160 }}>
            <h1 className="big-title" style={{ fontSize: 72 }}>{provider.name}</h1>
            <p className="synopsis">
              {tmdb.enabled
                ? 'Rien trouvé pour cette plateforme.'
                : `Ton serveur n'a pas de groupe ${provider.name}. Ajoute ta clé TMDB gratuite pour voir tout ce qui sort sur ${provider.name} et le retrouver sur ton serveur.`}
            </p>
            {!tmdb.enabled && <div className="actions"><button className="btn btn-primary" onClick={() => goRoot({ name: 'settings' })}>Ajouter ma clé TMDB</button></div>}
          </div>
        )}
      </section>

      {loading && rows.length === 0 && <div style={{ position: 'relative', height: 200 }}><Spinner center /></div>}

      {view === 'vitrine' && rows.length > 0 && (
        <div className="rows" style={{ marginTop: -70 }}>
          {rows.map((r) => (
            <Row key={r.title} title={r.title}>
              {r.items.map((x) => (
                <PosterCard key={x.uid} title={x.title} poster={(x.item && x.item.poster) || x.poster}
                  home={x.real && !!x.item} focused={focus && focus.uid === x.uid}
                  sub={[x.date.slice(0, 4), x.score ? '★ ' + Number(x.score).toFixed(1) : ''].filter(Boolean).join(' · ')}
                  onFocus={() => setFocus(x)} onOpen={() => open(x)} />
              ))}
            </Row>
          ))}
        </div>
      )}

      {view === 'grille' && rows.length > 0 && (
        <div style={{ position: 'relative', zIndex: 3, marginTop: -40, padding: '0 var(--gutter) 80px' }}>
          <div className="grid">
            {Array.from(new Map(rows.flatMap((r) => r.items).map((x) => [x.uid, x])).values()).map((x) => (
              <PosterCard key={x.uid} title={x.title} poster={(x.item && x.item.poster) || x.poster}
                home={x.real && !!x.item} sub={x.date.slice(0, 4)}
                onFocus={() => setFocus(x)} onOpen={() => open(x)} />
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
