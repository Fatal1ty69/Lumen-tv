import React, { useEffect, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { useRatings } from '../lib/ratings.js';
import { isTV } from '../tv/native.js';
import { focusEl } from '../tv/spatial.js';
import { getDetails, seasonStills } from '../lib/details.js';
import { movieRef, episodeRef, lastEpisodeOf, isWatched } from '../lib/play.js';
import { fmtRemain } from '../lib/player.js';
import { buildMap, tmdbSeasons, translate, rememberMap } from '../lib/numbering.js';
import TraktCompare from '../components/TraktCompare.jsx';
import { learnLink } from '../lib/traktImport.js';
import { Icon, Img, PosterCard, Spinner, TrailerModal } from '../components/ui.jsx';

// Référence de lecture d'un épisode, avec la file des épisodes suivants
function epRefFor(d, e, s) {
  const all = d.seasons.flatMap((n) => (d.episodes[n] || []).map((x) => ({ e: x, s: n })));
  const count = (n) => (d.episodes[n] || []).length;
  const i = all.findIndex((x) => x.e.id === e.id);
  const queue = all.slice(i + 1, i + 30).map((x) => ({ id: x.e.id, num: x.e.num, season: x.s, title: x.e.title, ext: x.e.ext, still: x.e.still, seasonCount: count(x.s) }));
  return { ...episodeRef(d.item, e, s, d.view, queue), tmdbId: d.tmdbId, seasonCount: count(s) };
}

// Épisode à proposer : celui en cours, sinon le suivant du dernier vu, sinon le premier non vu
function nextUpOf(d, progress) {
  const all = d.seasons.flatMap((s) => (d.episodes[s] || []).map((e) => ({ e, s })));
  if (!all.length || !d.item) return null;
  const seen = (x) => isWatched(progress['e:' + x.e.id]);
  const last = lastEpisodeOf(progress, d.item.key);
  if (last) {
    const i = all.findIndex((x) => 'e:' + x.e.id === last.ref.key);
    if (i >= 0 && !isWatched(last) && last.pos / last.dur > 0.02) return { ...all[i], mode: 'resume' };
    if (i >= 0) {
      const after = all.slice(i + 1).find((x) => !seen(x));
      if (after) return { ...after, mode: 'next' };
    }
  }
  const firstUnseen = all.find((x) => !seen(x));
  if (firstUnseen) return { ...firstUnseen, mode: all.some(seen) ? 'next' : 'start' };
  return { ...all[0], mode: 'again' };
}

export default function Fiche({ route, hidden }) {
  const app = useApp();
  const { back, navigate, progress, favorites, toggleFav, tmdb, account, setWatched, traktWatched } = app;
  const [askPrev, setAskPrev] = useState(null);
  const [d, setD] = useState(null);
  const [err, setErr] = useState('');
  const [season, setSeason] = useState(null);
  const [stills, setStills] = useState({});
  const [trailer, setTrailer] = useState('');
  const [compare, setCompare] = useState(false);

  useEffect(() => {
    let off = false;
    setD(null);
    getDetails(app, route.item || null, route.tmdb || null)
      .then((r) => {
        if (off) return;
        setD(r);
        if (r.seasons.length) {
          const up = r.item ? nextUpOf(r, progress) : null;
          setSeason(up && r.seasons.includes(up.s) ? up.s : r.seasons[0]);
        }
      })
      .catch((e) => !off && setErr(e.message || String(e)));
    return () => { off = true; };
  }, [route.item && route.item.key, route.tmdb && route.tmdb.id]);

  useEffect(() => {
    if (!d || !season || d.type !== 'tv') return;
    let off = false;
    seasonStills(tmdb, d.tmdbId, season).then((m) => !off && setStills(m));
    return () => { off = true; };
  }, [d, season]);

  // Ce qui est marqué vu sur Trakt est reporté dans Lumen
  useEffect(() => {
    if (!d || !d.item || !d.tmdbId || !traktWatched) return;
    if (d.type === 'tv') {
      const raw = traktWatched.shows && traktWatched.shows[d.tmdbId];
      if (!raw) return;
      // Même lien que la fiche dans Mes séries
      learnLink('tid', d.item.key, Number(d.tmdbId));
      let off = false;
      (async () => {
        const all = d.seasons.flatMap((n) => (d.episodes[n] || []).map((e) => ({ e, s: Number(n) })));
        // Le serveur peut découper la série autrement que Trakt (parties au lieu de saisons)
        const map = buildMap(all.map((x) => ({ season: x.s, num: Number(x.e.num) })), await tmdbSeasons(tmdb, d.tmdbId));
        rememberMap(d.tmdbId, map);
        const m = translate(raw, map);
        const list = all.filter((x) => m[x.s + ':' + x.e.num] && !isWatched(progress['e:' + x.e.id])).map((x) => ({ ref: epRefFor(d, x.e, x.s) }));
        if (!off && list.length) setWatched(list, true, { fromTrakt: true });
      })();
      return () => { off = true; };
    } else if (traktWatched.movies && traktWatched.movies[d.tmdbId] && !isWatched(progress[d.item.key])) {
      setWatched([{ ref: { ...movieRef(d.item, d.view), tmdbId: d.tmdbId } }], true, { fromTrakt: true });
    }
  }, [d, traktWatched]);

  // TV : appui long sur Lecture = options de la fiche
  const [opts, setOpts] = useState(false);
  useEffect(() => {
    if (!isTV) return;
    const on = (ev) => { if (ev.target && ev.target.closest && ev.target.closest('[data-fiche-opts]')) { ev.preventDefault(); setOpts(true); } };
    document.addEventListener('tv-longpress', on);
    return () => document.removeEventListener('tv-longpress', on);
  }, []);
  useEffect(() => {
    if (!opts) return;
    const on = (e) => { e.preventDefault(); setOpts(false); };
    window.addEventListener('tv-back', on);
    return () => window.removeEventListener('tv-back', on);
  }, [opts]);

  // TV : appui long sur un épisode = marquer comme vu / non vu
  useEffect(() => {
    if (!isTV) return;
    const on = (ev) => {
      const id = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-ep-id');
      const b = id && document.querySelector(`[data-ep-check="${id}"]`);
      if (b) b.click();
    };
    document.addEventListener('ep-toggle', on);
    return () => document.removeEventListener('ep-toggle', on);
  }, []);

  if (hidden) return null;

  const item = d && d.item;
  const v = d && d.view;
  const eps = d && season ? (d.episodes[season] || []).map((e) => ({
    ...e,
    still: e.still || (stills[e.num] && stills[e.num].still) || '',
    plot: e.plot || (stills[e.num] && stills[e.num].plot) || '',
    title: e.title && !/^Épisode \d+$/.test(e.title) ? e.title : (stills[e.num] && stills[e.num].title) || e.title
  })) : [];

  const allEps = d ? d.seasons.flatMap((s) => (d.episodes[s] || []).map((e) => ({ e, s }))) : [];
  const count = (n) => (d.episodes[n] || []).length;
  const refOf = (e, s) => epRefFor(d, e, s);
  const playEp = (e, s) => {
    const ref = refOf(e, s);
    const p = progress[ref.key];
    navigate({ name: 'player', ref, startAt: p && !isWatched(p) ? p.pos : 0 });
  };
  const watchedEp = (e) => isWatched(progress['e:' + e.id]);

  // Coche "vu" : propose aussi de cocher les épisodes précédents de la saison
  // TV : gauche/droite dans la liste des épisodes changent de saison
  const onEpKeys = (ev) => {
    if (ev.key !== 'ArrowLeft' && ev.key !== 'ArrowRight') return;
    ev.preventDefault();
    const i = d.seasons.indexOf(season);
    const n = d.seasons[i + (ev.key === 'ArrowRight' ? 1 : -1)];
    if (n === undefined) return;
    setSeason(n);
    setTimeout(() => focusEl(document.querySelector('.overlay .ep')), 80);
  };

  const toggleWatched = (e, s) => {
    if (watchedEp(e)) { setWatched([{ ref: refOf(e, s) }], false); setAskPrev(null); return; }
    setWatched([{ ref: refOf(e, s) }], true);
    const prev = (d.episodes[s] || []).filter((x) => x.num < e.num && !watchedEp(x));
    setAskPrev(prev.length ? { s, list: prev } : null);
  };
  const markList = (list, s, value) => setWatched(list.map((x) => ({ ref: refOf(x, s) })), value);
  const seasonAllWatched = season && (d.episodes[season] || []).length > 0 && (d.episodes[season] || []).every(watchedEp);

  const up = d && item && item.kind === 'series' ? nextUpOf(d, progress) : null;

  const main = () => {
    if (!item) return;
    if (item.kind === 'movie') {
      const p = progress[item.key];
      navigate({ name: 'player', ref: { ...movieRef(item, v), tmdbId: d.tmdbId }, startAt: p && !isWatched(p) ? p.pos : 0 });
    } else if (up) playEp(up.e, up.s);
  };

  let mainLabel = 'Lecture';
  if (item && item.kind === 'movie' && progress[item.key] && !isWatched(progress[item.key])) mainLabel = 'Reprendre · ' + fmtRemain(progress[item.key].pos, progress[item.key].dur);
  if (item && item.kind === 'movie' && isWatched(progress[item.key])) mainLabel = 'Revoir';
  if (up) {
    const tag = `S${up.s} · É${up.e.num}`;
    mainLabel = up.mode === 'resume' ? `Reprendre ${tag}` : up.mode === 'next' ? `Épisode suivant · ${tag}` : up.mode === 'again' ? `Revoir ${tag}` : `Lecture ${tag}`;
  }

  return (
    <div className="overlay" onClick={back} role="dialog" aria-label={v ? v.title : 'Fiche'}>
      {opts && d && item && (
        <div className="modal tv-quick" data-tv-layer role="dialog" aria-label="Options" onClick={(e) => { e.stopPropagation(); setOpts(false); }}>
          <div className="modal-inner" onClick={(e) => e.stopPropagation()}>
            <h2 className="page-title" style={{ fontSize: 34, marginBottom: 8 }}>{v.title}</h2>
            <button className="btn btn-ghost tv-quick-btn" data-tv-autofocus onClick={() => { toggleFav(item); setOpts(false); }}>{favorites[item.key] ? 'Retirer de Ma liste' : 'Ajouter à Ma liste'}</button>
            {item.kind === 'movie' && (
              <button className="btn btn-ghost tv-quick-btn" onClick={() => { const seen = isWatched(progress[item.key]); setWatched([{ ref: { ...movieRef(item, v), tmdbId: d.tmdbId } }], !seen); setOpts(false); }}>{isWatched(progress[item.key]) ? 'Marquer comme non vu' : 'Marquer comme vu'}</button>
            )}
            {d.type === 'tv' && season && (
              <button className="btn btn-ghost tv-quick-btn" onClick={() => { markList(d.episodes[season] || [], season, !seasonAllWatched); setAskPrev(null); setOpts(false); }}>{seasonAllWatched ? `Marquer la saison ${season} comme non vue` : `Marquer la saison ${season} comme vue`}</button>
            )}
            {v.trailer && <button className="btn btn-ghost tv-quick-btn" onClick={() => { setOpts(false); setTrailer(v.trailer); }}>Bande-annonce</button>}
            <button className="btn btn-ghost tv-quick-btn" onClick={() => setOpts(false)}>Fermer</button>
          </div>
        </div>
      )}
      {compare && d && <TraktCompare d={d} onClose={() => setCompare(false)} />}
      <article className="fiche" onClick={(e) => e.stopPropagation()}>
        {!d && !err && <div style={{ height: 540, position: 'relative' }}><Spinner center /></div>}
        {err && <div className="empty err">{err}</div>}
        {d && (
          <>
            <div className="fiche-hero">
              {v.backdrop ? <img className="bg" src={v.backdrop} alt="" /> : <div className="bg" style={{ position: 'absolute', inset: 0, background: '#1A1A1F' }} />}
              <div className="fade" />
              {!isTV && <button className="icon-btn close" onClick={back} aria-label="Fermer la fiche"><Icon name="close" /></button>}
              <div className="body">
                <div className="kicker">{d.type === 'tv' ? 'Série' : 'Film'}{item ? '' : ' · Pas sur tes serveurs'}</div>
                {v.logo ? <img className="title-logo" src={v.logo} alt={v.title} /> : <h1 className="big-title">{v.title}</h1>}
                <div className="actions">
                  {item && (allEps.length > 0 || item.kind === 'movie') && (
                    <button className="btn btn-primary" onClick={main} autoFocus data-tv-autofocus data-fiche-opts="1"><Icon name="play" size={18} />{mainLabel}</button>
                  )}
                  {isTV && item && <span className="muted" style={{ alignSelf: 'center', fontSize: 14 }}>{favorites[item.key] ? '✓ Dans Ma liste · ' : ''}Appui long sur OK : plus d'options</span>}
                  {v.trailer && <button className="btn btn-ghost" onClick={() => setTrailer(v.trailer)}>Bande-annonce</button>}
                  {!isTV && item && d.type === 'tv' && d.tmdbId && app.trakt && app.trakt.connected && <button className="btn btn-ghost" onClick={() => setCompare(true)}>Comparer avec Trakt</button>}
                  {item && !isTV && (
                    <button className={'btn btn-round' + (favorites[item.key] ? ' on' : '')} onClick={() => toggleFav(item)}
                      aria-label={favorites[item.key] ? 'Retirer de ma liste' : 'Ajouter à ma liste'} title={favorites[item.key] ? 'Dans ma liste' : 'Ajouter à ma liste'}>
                      <Icon name={favorites[item.key] ? 'check' : 'plus'} />
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="fiche-main">
              <div className="cols">
                <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                  <div className="meta">
                    <Ratings v={v} type={d.type} />
                    <span>{[v.year, v.len].filter(Boolean).join(' · ')}</span>
                    {v.video && v.video.height >= 2000 && <span className="chip">4K</span>}
                    {v.video && v.video.height >= 1000 && v.video.height < 2000 && <span className="chip">FHD</span>}
                    {v.audio && v.audio.channels >= 6 && <span className="chip">5.1</span>}
                  </div>
                  <p style={{ fontSize: 17, lineHeight: 1.6, color: '#D4D4DA' }}>{v.overview || 'Pas de résumé disponible.'}</p>
                </div>
                <div className="facts">
                  {v.genres.length > 0 && <div><span className="k">Genres : </span>{v.genres.join(', ')}</div>}
                  {v.director && <div><span className="k">Réalisation : </span>{v.director}</div>}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
                    <span className="k">Disponibilité</span>
                    {item
                      ? <div className="server-row"><span>{account.name}</span><span style={{ color: 'var(--accent)' }}>Disponible</span></div>
                      : <div className="server-row"><span>Aucun de tes serveurs</span><span className="muted">Indisponible</span></div>}
                  </div>
                </div>
              </div>

              {v.cast.length > 0 && (
                <section>
                  <h2 className="section-title">Casting</h2>
                  <div className="cast">
                    {v.cast.map((c, i) => (
                      <div key={i}>
                        <div className="ph">{c.photo ? <img src={c.photo} alt="" loading="lazy" /> : c.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}</div>
                        {c.name}{c.role && <small>{c.role}</small>}
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {d.seasons.length > 0 && (
                <section>
                  <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 16, marginBottom: 12 }}>
                    <h2 className="section-title" style={{ margin: 0 }}>Épisodes</h2>
                    {isTV ? <span className="muted" style={{ fontSize: 16 }}>Saison {season} sur {d.seasons.length}</span> : <div className="pills" role="group" aria-label="Saison">
                      {d.seasons.map((s) => (
                        <button key={s} className={'pill' + (s === season ? ' on' : '')} onClick={() => setSeason(s)}>Saison {s}</button>
                      ))}
                    </div>}
                  </div>
                  {!isTV && <div className="ep-tools">
                    <button className="btn btn-ghost btn-sm" onClick={() => { markList(d.episodes[season] || [], season, !seasonAllWatched); setAskPrev(null); }}>
                      <Icon name={seasonAllWatched ? 'close' : 'check'} size={16} />{seasonAllWatched ? 'Marquer la saison comme non vue' : 'Marquer la saison comme vue'}
                    </button>
                    {up && up.mode === 'next' && up.s === season && <span className="muted" style={{ fontSize: 14 }}>À suivre : épisode {up.e.num}</span>}
                  </div>}
                  {askPrev && askPrev.s === season && (
                    <div className="ask-prev">
                      <span>Marquer aussi {askPrev.list.length > 1 ? `les ${askPrev.list.length} épisodes précédents` : "l'épisode précédent"} comme vu{askPrev.list.length > 1 ? 's' : ''} ?</span>
                      <button className="btn btn-primary btn-sm" onClick={() => { markList(askPrev.list, askPrev.s, true); setAskPrev(null); }}>Oui</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => setAskPrev(null)}>Non</button>
                    </div>
                  )}
                  <div {...(isTV ? { 'data-tv-keys': 'lr', onKeyDown: onEpKeys } : {})}>
                    {isTV && d.seasons.length > 1 && <p className="muted" style={{ fontSize: 14, margin: '0 0 10px' }}>Gauche et droite : saison précédente ou suivante · appui long sur OK : marquer comme vu</p>}
                    {eps.map((e) => {
                      const p = progress['e:' + e.id];
                      const seen = isWatched(p);
                      const pct = seen ? 100 : p ? Math.min(100, (p.pos / p.dur) * 100) : 0;
                      const isUp = up && up.e.id === e.id;
                      return (
                        <div key={e.id} className={'ep-row' + (seen ? ' seen' : '') + (isUp ? ' up' : '')}>
                          <button className="ep" onClick={() => playEp(e, season)} data-ep-id={e.id}
                            {...(isTV ? { ref: (el) => { if (el && !el.__lp) { el.__lp = true; el.addEventListener('tv-longpress', (ev) => { ev.preventDefault(); el.dispatchEvent(new CustomEvent('ep-toggle', { bubbles: true })); }); } } } : {})}>
                            <span className="n">{e.num}</span>
                            <div className="th">
                              <Img src={e.still || v.backdrop} className="cover" />
                              {seen && <span className="seen-mark"><Icon name="check" size={22} /></span>}
                              {pct > 0 && <div className="bar"><i style={{ width: pct + '%' }} /></div>}
                            </div>
                            <div className="tx">
                              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
                                <b>{e.title}{isUp && <span className="up-tag">{up.mode === 'resume' ? 'EN COURS' : 'À SUIVRE'}</span>}</b>
                                <span className="muted" style={{ fontSize: 14, flex: '0 0 auto' }}>{e.len}</span>
                              </div>
                              {e.plot && <p>{e.plot}</p>}
                            </div>
                          </button>
                          <button className={'ep-check' + (seen ? ' on' : '')} onClick={() => toggleWatched(e, season)} tabIndex={isTV ? -1 : undefined} data-ep-check={e.id}
                            aria-label={seen ? `Marquer l'épisode ${e.num} comme non vu` : `Marquer l'épisode ${e.num} comme vu`} title={seen ? 'Vu · cliquer pour annuler' : 'Marquer comme vu'}>
                            <Icon name="check" size={18} />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </section>
              )}

              {d.similar && d.similar.length > 0 && (
                <section>
                  <h2 className="section-title">Titres similaires chez toi</h2>
                  <div className="sim-grid">
                    {d.similar.map((s) => (
                      <PosterCard key={s.item.key} itemKey={s.item.key} title={s.item.title} poster={s.poster}
                        onOpen={() => navigate({ name: 'fiche', item: s.item })} />
                    ))}
                  </div>
                </section>
              )}
            </div>
          </>
        )}
      </article>
      <TrailerModal ytKey={trailer} onClose={() => setTrailer('')} />
    </div>
  );
}

// Notes : TMDB, IMDb, Rotten Tomatoes, Metacritic (les trois dernières via OMDb)
function Ratings({ v, type }) {
  const { settings } = useApp();
  const r = useRatings(v.imdbId, settings.omdbKey);
  const open = (url) => (window.lumen ? window.lumen.openExternal(url) : window.open(url));
  const out = [];
  if (r && r.imdb) {
    out.push(
      <button key="imdb" className="rate rate-imdb" onClick={() => open('https://www.imdb.com/title/' + v.imdbId + '/')} title={r.imdbVotes ? r.imdbVotes + ' votes sur IMDb' : 'IMDb'}>
        <span className="rate-k">IMDb</span><b>{r.imdb}</b><small>/10</small>
      </button>
    );
  }
  if (r && r.rt != null) {
    const fresh = r.rt >= 60;
    out.push(
      <span key="rt" className={'rate rate-rt' + (fresh ? ' fresh' : ' rotten')} title={'Rotten Tomatoes · ' + (fresh ? 'frais' : 'pourri')}>
        <span className="rate-ico" aria-hidden="true">{fresh ? '●' : '✱'}</span><span className="rate-k">Rotten Tomatoes</span><b>{r.rt}%</b>
      </span>
    );
  }
  if (r && r.meta != null) {
    out.push(<span key="mc" className={'rate rate-mc ' + (r.meta >= 61 ? 'hi' : r.meta >= 40 ? 'mid' : 'lo')} title="Metacritic"><span className="rate-k">Metacritic</span><b>{r.meta}</b></span>);
  }
  if (v.tmdbScore) {
    out.push(
      <button key="tmdb" className="rate rate-tmdb" onClick={() => v.tmdbId && open(`https://www.themoviedb.org/${type === 'tv' ? 'tv' : 'movie'}/${v.tmdbId}`)} title={v.tmdbVotes + ' votes sur TMDB'}>
        <span className="rate-k">TMDB</span><b>{Math.round(v.tmdbScore * 10)}%</b>
      </button>
    );
  }
  if (!out.length && v.score) out.push(<span key="srv" className="score" title="Note du serveur">{v.score}</span>);
  return out;
}

