import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { norm } from '../lib/titles.js';
import { Icon, PosterCard } from '../components/ui.jsx';
import { CatalogView, VIEWS } from '../components/CatalogViews.jsx';
import { useKindReco } from '../lib/homeGuide.js';
import SideMine from '../components/SideMine.jsx';
import { useMySeries } from '../lib/series.js';
import { isTV } from '../tv/native.js';
import TvOptions from '../tv/TvOptions.jsx';

const PAGE = 120;

export default function Browse({ route }) {
  const app = useApp();
  const { catalog, navigate, goRoot, settings, updateSettings, favorites } = app;
  const view = settings.catalogView || 'grille';
  const isSeries = route.kind === 'series';
  const all = isSeries ? catalog.series : catalog.vod;
  const cats = isSeries ? catalog.seriesCats : catalog.vodCats;
  const [cat, setCat] = useState(route.cat || '');
  const [decade, setDecade] = useState(route.decade || 0);
  const [sort, setSort] = useState(route.sort || 'added');
  const [q, setQ] = useState('');
  const [limit, setLimit] = useState(PAGE);
  const sentinel = useRef(null);

  const counts = useMemo(() => {
    const m = new Map();
    for (const it of all) m.set(it.cat, (m.get(it.cat) || 0) + 1);
    return m;
  }, [all]);

  // v39 : listes personnelles (« Pour toi »), séparées des catégories du serveur
  const kind = isSeries ? 'series' : 'movie';
  const reco = useKindReco(app, kind);
  const { list: mySeries } = useMySeries();
  const mine = useMemo(() => (isSeries ? mySeries.filter((s) => s.item).sort((a, b) => (b.last || 0) - (a.last || 0)).map((s) => s.item) : []), [mySeries, isSeries]);
  const favs = useMemo(() => all.filter((it) => favorites[it.key]).sort((a, b) => ((favorites[b.key] || {}).t || 0) - ((favorites[a.key] || {}).t || 0)), [all, favorites]);
  // Recommandations : rien de ce que tu suis déjà ou as en favori
  const recoList = useMemo(() => {
    const known = new Set([...mine.map((x) => x.key), ...favs.map((x) => x.key)]);
    return (reco || []).filter((it) => !known.has(it.key));
  }, [reco, mine, favs]);
  const PERSONAL = { __mine: mine, __fav: favs, __reco: recoList };
  const personal = cat in PERSONAL;

  const list = useMemo(() => {
    const n = norm(q);
    const base = personal ? PERSONAL[cat] : all;
    let l = base.filter((it) => (personal || !cat || it.cat === cat) && (!decade || (it.year >= decade && it.year < decade + 10)) && (!n || norm(it.title).includes(n)));
    // Listes personnelles : leur ordre (dernier visionnage, ajout, pertinence) sauf si tu choisis un autre tri
    if (sort === 'added' && !personal) l = [...l].sort((a, b) => b.added - a.added);
    if (sort === 'az') l = [...l].sort((a, b) => a.title.localeCompare(b.title, 'fr'));
    if (sort === 'rating') l = [...l].sort((a, b) => b.rating - a.rating);
    if (sort === 'year') l = [...l].sort((a, b) => (b.year || 0) - (a.year || 0));
    return l;
  }, [all, cat, decade, sort, q, mine, favs, recoList]);

  useEffect(() => setLimit(PAGE), [cat, decade, sort, q]);

  useEffect(() => {
    const el = sentinel.current;
    if (!el) return;
    const io = new IntersectionObserver((ent) => {
      if (ent[0].isIntersecting) setLimit((l) => l + PAGE);
    }, { rootMargin: '800px' });
    io.observe(el);
    return () => io.disconnect();
  }, [list]);

  const PLABEL = { __mine: 'Mes séries', __fav: isSeries ? 'Mes séries favorites' : 'Mes films favoris', __reco: isSeries ? 'Séries recommandées' : 'Films recommandés' };
  const catLabel = personal ? PLABEL[cat] : cat ? catalog.catName.get(cat) : isSeries ? 'Toutes les séries' : 'Tous les films';

  return (
    <div className="screen-pad">
      <div className="browse">
        <aside className="side" aria-label="Groupes">
          {!isTV && <button className="manage-link" onClick={() => goRoot({ name: 'settings', anchor: 'groupes' })}><Icon name="gear" size={14} />Gérer les groupes</button>}
          {isTV && (
            <div className="side-opts">
              <TvOptions sections={[
                { label: 'Trier par', value: sort, onChange: setSort, choices: [['added', 'Récents'], ['year', 'Année'], ['rating', 'Note'], ['az', 'A à Z']] },
                { label: 'Années', value: decade, onChange: setDecade, choices: [[0, 'Toutes'], [2020, '2020s'], [2010, '2010s'], [2000, '2000s'], [1990, '1990s'], [1980, '1980s']] },
                { label: 'Affichage', value: view, onChange: (v) => updateSettings({ catalogView: v }), choices: VIEWS.map((v) => [v.id, v.name]) }
              ]} />
            </div>
          )}
          <SideMine>
            {isSeries && <button className={cat === '__mine' ? 'on' : ''} onClick={() => setCat('__mine')}><span className="side-ic"><Icon name="tv" size={15} />Mes séries</span><span>{mine.length}</span></button>}
            <button className={cat === '__fav' ? 'on' : ''} onClick={() => setCat('__fav')}><span className="side-ic"><Icon name="star" size={15} />{isSeries ? 'Mes favorites' : 'Mes favoris'}</span><span>{favs.length}</span></button>
            <button className={cat === '__reco' ? 'on' : ''} onClick={() => setCat('__reco')}><span className="side-ic"><Icon name="spark" size={15} />{isSeries ? 'Recommandées' : 'Recommandés'}</span><span>{reco ? recoList.length : '…'}</span></button>
          </SideMine>
          <div className="side-label">Sur ton serveur</div>
          <button className={!cat ? 'on' : ''} onClick={() => setCat('')}>Tout <span>{all.length}</span></button>
          {/* v45 : les catégories vides du serveur (ex. « Mes favoris » à 0) sont masquées : pas de doublon avec « Pour toi » */}
          {cats.filter((c) => counts.get(c.id) || cat === c.id).map((c) => (
            <button key={c.id} className={cat === c.id ? 'on' : ''} onClick={() => setCat(c.id)}>
              {c.name}<span>{counts.get(c.id) || 0}</span>
            </button>
          ))}
        </aside>
        <div style={{ flex: '999 1 560px', minWidth: 0 }}>
          <h1 className="page-title" style={{ marginBottom: 18 }}>{decade ? `Années ${decade}` : catLabel}</h1>
          {isTV ? (
            <p className="muted" style={{ fontSize: 14, margin: '-8px 0 14px' }}>{list.length} titres</p>
          ) : (
          <div className="toolbar">
            <div className="field">
              <Icon name="search" size={18} />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={'Filtrer ' + (isSeries ? 'les séries' : 'les films')} aria-label="Filtrer" />
            </div>
            <div className="seg" role="group" aria-label="Tri">
              {[['added', 'Récents'], ['year', 'Année'], ['rating', 'Note'], ['az', 'A à Z']].map(([k, l]) => (
                <button key={k} className={sort === k ? 'on' : ''} onClick={() => setSort(k)}>{l}</button>
              ))}
            </div>
            <div className="pills">
              {[0, 2020, 2010, 2000, 1990, 1980].map((d) => (
                <button key={d} className={'pill' + (decade === d ? ' on' : '')} onClick={() => setDecade(d)}>{d ? `${d}s` : 'Toutes années'}</button>
              ))}
            </div>
            <span className="muted" style={{ fontSize: 14 }}>{list.length} titres</span>
            <div className="seg" role="group" aria-label="Vue" style={{ marginLeft: 'auto' }}>
              {VIEWS.map((v) => (
                <button key={v.id} className={view === v.id ? 'on' : ''} onClick={() => updateSettings({ catalogView: v.id })}>{v.name}</button>
              ))}
            </div>
          </div>
          )}
          <CatalogView view={view} items={list.slice(0, limit)} onOpen={(it) => navigate({ name: 'fiche', item: it })} />
          {list.length === 0 && (
            cat === '__reco' && reco === null ? <p className="empty">Recherche de recommandations…</p>
              : cat === '__fav' && !q && !decade ? <p className="empty">Aucun favori pour l'instant : passe la souris sur une affiche et clique sur le +.</p>
                : cat === '__reco' && !q && !decade ? <p className="empty">Regarde quelques {isSeries ? 'séries' : 'films'} : les recommandations se baseront dessus.</p>
                  : cat === '__mine' && !q && !decade ? <p className="empty">Les séries que tu regardes apparaîtront ici.</p>
                    : <p className="empty">Aucun titre ne correspond.</p>
          )}
          {limit < list.length && <div ref={sentinel} style={{ height: 40 }} />}
        </div>
      </div>
    </div>
  );
}

