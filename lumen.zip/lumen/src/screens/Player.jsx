import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { attachSource, fmtTime, hhmm } from '../lib/player.js';
import { liveRef, replayRef, nextEpisodeRef } from '../lib/play.js';
import { loadJSON, saveJSON } from '../lib/store.js';
import { pickVariant, rememberVariant, variantLabel } from '../lib/live.js';
import { getEpg, nowNext, timeshiftUrl } from '../lib/epg.js';
import { searchSubs, downloadSub, vttUrl } from '../lib/subs.js';
import { img } from '../lib/tmdb.js';
import { applyEq, EQ_MODES } from '../lib/audio.js';
import { Icon, Spinner } from '../components/ui.jsx';

function resLabel(h) {
  if (!h) return '';
  if (h >= 4000) return '8K';
  if (h >= 2000) return '4K';
  if (h >= 1400) return '2K';
  if (h >= 1000) return 'FHD';
  if (h >= 700) return 'HD';
  return 'SD';
}

const DAY = 86400000;

export default function Player({ route }) {
  const app = useApp();
  const { xtOf, mpvExe, back, replace, saveProgress, settings, updateSettings, catalog, progress, tmdb, addReminder, reminders, trakt } = app;
  const ref = route.ref;
  const isLive = ref.kind === 'live';
  const isReplay = ref.kind === 'replay';
  const isVod = ref.kind === 'movie' || ref.kind === 'episode';
  const video = useRef(null);
  const wrap = useRef(null);

  // En quittant la lecture : la synchro maison envoie la progression à la TV
  useEffect(() => () => window.dispatchEvent(new Event('lumen:played')), []);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [pos, setPos] = useState(0);
  const [dur, setDur] = useState(0);
  const [buf, setBuf] = useState(0);
  const [vol, setVol] = useState(() => loadJSON('volume', 1));
  const [muted, setMuted] = useState(false);
  const [idle, setIdle] = useState(false);
  const [hover, setHover] = useState(null);
  const [size, setSize] = useState('');
  const [nextIn, setNextIn] = useState(null);
  const [zap, setZap] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [tick, setTick] = useState(0);
  const [offset, setOffset] = useState(0); // replay : secondes depuis le début du programme
  const [liveProg, setLiveProg] = useState(null);
  const [pausedAt, setPausedAt] = useState(null);
  const [entracte, setEntracte] = useState(false);
  const [panel, setPanel] = useState(false);
  const [audioTracks, setAudioTracks] = useState([]);
  const [subs, setSubs] = useState([]);
  const [subId, setSubId] = useState(null);
  const [subOffset, setSubOffset] = useState(0);
  const [found, setFound] = useState(null);
  const [subMsg, setSubMsg] = useState('');
  const [seasonEnd, setSeasonEnd] = useState(null);
  const [introDone, setIntroDone] = useState(false);
  const idleT = useRef(null);
  const skipLearn = useRef(0);
  const ringOff = useRef(false);

  const channel = isLive || isReplay ? catalog.byKey.get(isReplay ? ref.chKey : ref.key) : null;
  const group = ref.groupKey ? catalog.byKey.get(ref.groupKey) : null;
  const progDur = isReplay ? Math.max(60, (ref.end - ref.start) / 1000) : 0;
  const skips = ref.seriesKey ? (loadJSON('skips', {})[ref.seriesKey] || {}) : {};

  const xt = xtOf(ref.acc);
  const url = useMemo(() => {
    const ext = attempt === 0 ? 'ts' : 'm3u8';
    if (isLive) return xt.liveUrl(ref.id, ext);
    if (isReplay) return timeshiftUrl(xt, ref.id, ref.start + offset * 1000, (progDur - offset) / 60 + 2, catalog.serverTz, ext);
    return ref.kind === 'movie' ? xt.movieUrl(ref.id, ref.ext) : xt.episodeUrl(ref.id, ref.ext);
  }, [ref.key, ref.acc, ref.id, attempt, offset]);

  // Bascule sur une autre source (autre serveur, autre qualité) quand le flux ne passe pas
  const [switching, setSwitching] = useState('');
  const failover = async () => {
    const tried = ref.tried || [ref.acc + ':' + ref.id];
    const go = (patch, label) => {
      setSwitching(label);
      setTimeout(() => setSwitching(''), 3500);
      replace({ ...route, startAt: video.current && video.current.currentTime > 5 ? video.current.currentTime : route.startAt, ref: { ...ref, ...patch, tried: [...tried, patch.acc + ':' + patch.id] } });
      return true;
    };
    if (ref.kind === 'movie' && ref.alts) {
      const alt = ref.alts.find((a) => !tried.includes(a.acc + ':' + a.id));
      if (alt) return go({ acc: alt.acc, id: alt.id, ext: alt.ext }, 'Source de secours : ' + (alt.accName || 'autre serveur'));
    }
    if (ref.kind === 'episode' && ref.altSeries) {
      for (const a of ref.altSeries) {
        try {
          const si = await xtOf(a.acc).seriesInfo(a.id);
          const eps = si && si.episodes ? (Array.isArray(si.episodes) ? si.episodes.flat() : Object.values(si.episodes).flat()) : [];
          const e = eps.find((x) => Number(x.season) === ref.season && Number(x.episode_num) === ref.num);
          if (e && !tried.includes(a.acc + ':' + e.id)) return go({ acc: a.acc, id: e.id, ext: e.container_extension || 'mp4' }, 'Source de secours : ' + (a.accName || 'autre serveur'));
        } catch { /* serveur suivant */ }
      }
    }
    if (isLive && group && group.variants.length > 1) {
      const v = group.variants.find((x) => !tried.includes(x.ch.acc + ':' + x.ch.id) && x.ch.key !== ref.key);
      if (v) return go({ key: v.ch.key, id: v.ch.id, acc: v.ch.acc }, `Bascule sur ${group.name} ${v.q || ''}${v.ch.accName && v.ch.accName !== '' ? ' · ' + v.ch.accName : ''}`.trim());
    }
    return false;
  };

  // Branchement de la source
  useEffect(() => {
    const v = video.current;
    setLoading(true);
    setError('');
    const fail = async (msg) => {
      if ((isLive || isReplay) && attempt === 0) { setAttempt(1); return; }
      if (await failover()) return;
      // Format refusé par le lecteur intégré : mpv prend le relais s'il est installé
      if (window.lumen && mpvExe && (settings.engine || 'auto') === 'auto') {
        replace({ ...route, engine: 'mpv', startAt: video.current && video.current.currentTime > 5 ? video.current.currentTime : route.startAt });
        return;
      }
      setLoading(false);
      setError(msg);
    };
    const src = attachSource(v, url, { live: isLive, onFatal: () => fail(isReplay ? 'Ce replay n\'est pas disponible sur le serveur.' : 'Le flux ne peut pas être lu.') });
    const onErr = () => {
      const code = v.error && v.error.code;
      fail(code === 4
        ? 'Ce format (souvent MKV, HEVC ou audio AC3/DTS) n\'est pas pris en charge par le lecteur intégré.'
        : 'Le flux ne peut pas être lu. Le serveur est peut-être saturé ou le lien a expiré.');
    };
    const onMeta = () => {
      if (isVod && route.startAt > 5 && route.startAt < v.duration - 10) v.currentTime = route.startAt;
      setSize(v.videoHeight ? `${v.videoWidth}×${v.videoHeight}` : '');
      readAudio();
    };
    v.addEventListener('error', onErr);
    v.addEventListener('loadedmetadata', onMeta);
    v.volume = vol;
    v.play().catch(() => {});
    return () => {
      v.removeEventListener('error', onErr);
      v.removeEventListener('loadedmetadata', onMeta);
      src.destroy();
    };
  }, [url, tick]);

  // Trakt : ce que tu regardes est envoyé en direct (scrobble)
  const scrobbleOn = isVod && trakt && trakt.connected && settings.traktScrobble !== false && ref.tmdbId;
  useEffect(() => {
    if (!scrobbleOn || !dur) return;
    const pct = (video.current.currentTime / dur) * 100;
    trakt.scrobble(playing ? 'start' : 'pause', ref, pct);
  }, [playing, scrobbleOn, !!dur]);
  useEffect(() => () => {
    const v = video.current;
    if (scrobbleOn && v && Number.isFinite(v.duration) && v.duration > 0) trakt.scrobble('stop', ref, (v.currentTime / v.duration) * 100);
  }, [scrobbleOn]);

  // Égaliseur
  const [eqOk, setEqOk] = useState(true);
  useEffect(() => { if (playing) setEqOk(applyEq(video.current, settings.eq || 'normal')); }, [settings.eq, playing]);

  // Programme en cours (direct)
  useEffect(() => {
    if (!isLive || !channel) return;
    let off = false;
    const load = () => getEpg(xt, channel).then((l) => !off && setLiveProg(nowNext(l).now)).catch(() => {});
    load();
    const t = setInterval(load, 60000);
    return () => { off = true; clearInterval(t); };
  }, [ref.key]);

  // Progression (films et épisodes)
  const save = useCallback(() => {
    const v = video.current;
    if (!v || !isVod || !Number.isFinite(v.duration) || v.duration < 60 || v.currentTime < 5) return;
    saveProgress(ref.key, { hidden: false, watched: v.currentTime / v.duration >= 0.95, pos: v.currentTime, dur: v.duration, ref: { ...ref, queue: (ref.queue || []).slice(0, 30) } });
  }, [ref, isVod, saveProgress]);
  useEffect(() => {
    const t = setInterval(save, 5000);
    return () => { clearInterval(t); save(); };
  }, [save]);

  // Épisode suivant, générique
  const nextEp = ref.queue && ref.queue[0];
  const isSeasonLast = ref.kind === 'episode' && (!nextEp || nextEp.season !== ref.season);
  const creditsLen = skips.credits || 40;

  const goEpisode = useCallback((n, queue) => {
    save();
    const v = video.current;
    // Passer à la suite pendant le générique compte l'épisode comme vu
    if (v && Number.isFinite(v.duration) && v.duration - v.currentTime < 480 && v.currentTime / v.duration > 0.8) {
      saveProgress(ref.key, { hidden: false, watched: true, pos: v.currentTime, dur: v.duration, ref: { ...ref, queue: (ref.queue || []).slice(0, 30) } });
    }
    const pv = progress['e:' + n.id];
    replace({ name: 'player', startAt: pv && !pv.watched && pv.pos / pv.dur < 0.95 ? pv.pos : 0, ref: { ...nextEpisodeRef(ref, n), queue } });
  }, [ref, replace, save, progress, saveProgress]);

  const goNext = useCallback(() => {
    if (!nextEp) return;
    const v = video.current;
    const left = v && Number.isFinite(v.duration) ? v.duration - v.currentTime : 0;
    if (ref.seriesKey && left > 15 && left < 480) {
      const all = loadJSON('skips', {});
      all[ref.seriesKey] = { ...(all[ref.seriesKey] || {}), credits: Math.round(left) };
      saveJSON('skips', all);
    }
    goEpisode(nextEp, ref.queue.slice(1));
  }, [nextEp, ref, goEpisode]);

  useEffect(() => {
    if (ref.kind !== 'episode' || !dur) return;
    const left = dur - pos;
    if (left > creditsLen || left <= 0) return;
    if (isSeasonLast) { if (!seasonEnd) openSeasonEnd(); }
    else if (nextIn === null && !ringOff.current) setNextIn(10);
  }, [pos, dur]);

  useEffect(() => {
    if (nextIn === null) return;
    if (nextIn <= 0) { if (settings.autoNext) goNext(); return; }
    const t = setTimeout(() => setNextIn((n) => (n === null ? null : n - 1)), 1000);
    return () => clearTimeout(t);
  }, [nextIn]);

  // Carton de fin de saison
  const openSeasonEnd = async () => {
    const entries = Object.values(progress).filter((p) => p.ref && p.ref.seriesKey === ref.seriesKey && p.ref.season === ref.season);
    const firstT = Math.min(Date.now(), ...entries.map((p) => p.first || p.t));
    const total = entries.reduce((a, p) => a + (p.dur || 0), 0) + (dur || 0);
    const card = {
      count: Math.max(entries.length, ref.num || 0),
      seasonCount: ref.seasonCount || ref.num,
      hours: total / 3600,
      days: Math.max(1, Math.ceil((Date.now() - firstT) / DAY)),
      started: firstT,
      next: nextEp && nextEp.season === ref.season + 1 ? nextEp : null,
      upcoming: null
    };
    setSeasonEnd(card);
    if (!card.next && tmdb.enabled && ref.tmdbId) {
      try {
        const d = await tmdb.req(`/tv/${ref.tmdbId}`, {}, 12 * 3600 * 1000);
        const ne = d.next_episode_to_air;
        if (ne && ne.air_date) setSeasonEnd((c) => ({ ...c, upcoming: { date: Date.parse(ne.air_date + 'T10:00:00'), season: ne.season_number, num: ne.episode_number, name: ne.name, still: img(ne.still_path, 'w500') } }));
        else setSeasonEnd((c) => ({ ...c, upcoming: d.status === 'Ended' || d.status === 'Canceled' ? 'ended' : 'unknown' }));
      } catch { /* pas d'info */ }
    }
  };

  // Intro : bouton, apprentissage par série, saut automatique
  const introEnd = skips.intro || 0;
  const showIntro = ref.kind === 'episode' && !introDone && pos > 3 && pos < (introEnd || 300) && !(introEnd && pos >= introEnd - 1);
  useEffect(() => {
    if (ref.kind === 'episode' && settings.autoSkipIntro && introEnd && !introDone && pos > 1 && pos < introEnd - 2) {
      video.current.currentTime = introEnd;
      setIntroDone(true);
    }
  }, [pos]);
  const skipIntro = () => {
    const v = video.current;
    const target = introEnd && introEnd > v.currentTime ? introEnd : v.currentTime + 85;
    v.currentTime = target;
    setIntroDone(true);
    skipLearn.current = Date.now();
    if (!introEnd) {
      const all = loadJSON('skips', {});
      all[ref.seriesKey] = { ...(all[ref.seriesKey] || {}), intro: Math.round(target) };
      saveJSON('skips', all);
    }
  };
  const onSeeked = () => {
    // Juste après "Passer l'intro", un réglage fin de l'utilisateur devient la nouvelle fin d'intro
    if (ref.seriesKey && Date.now() - skipLearn.current < 20000 && video.current.currentTime < 600) {
      const all = loadJSON('skips', {});
      all[ref.seriesKey] = { ...(all[ref.seriesKey] || {}), intro: Math.round(video.current.currentTime) };
      saveJSON('skips', all);
    }
  };

  // Direct : zapping et qualité
  const zapBy = useCallback((dir) => {
    if (!isLive || !ref.list || ref.list.length < 2) return;
    const cur = ref.groupKey || ref.key;
    const i = ref.list.indexOf(cur);
    const k = ref.list[(i + dir + ref.list.length) % ref.list.length];
    const it = catalog.byKey.get(k);
    if (!it) return;
    if (it.kind === 'group') replace({ name: 'player', ref: liveRef(pickVariant(it, settings.liveQuality), ref.list, it) });
    else replace({ name: 'player', ref: liveRef(it, ref.list) });
  }, [isLive, ref, catalog, replace, settings.liveQuality]);

  useEffect(() => {
    if (!isLive) return;
    setZap(ref.title);
    const t = setTimeout(() => setZap(''), 2500);
    return () => clearTimeout(t);
  }, [ref.key]);

  const toLive = () => {
    const g = group;
    const ch = channel;
    if (!ch) return;
    replace({ name: 'player', ref: liveRef(g ? pickVariant(g, settings.liveQuality) : ch, ref.list || [], g) });
  };
  const fromStart = () => {
    if (!channel || !liveProg) return;
    replace({ name: 'player', ref: { ...replayRef(channel, liveProg, group), list: ref.list } });
  };

  // Commandes
  const wake = useCallback(() => {
    setIdle(false);
    clearTimeout(idleT.current);
    idleT.current = setTimeout(() => setIdle(true), 3000);
  }, []);
  useEffect(() => { wake(); return () => clearTimeout(idleT.current); }, []);

  const resumeFromEntracte = () => {
    const v = video.current;
    setEntracte(false);
    if (isVod) v.currentTime = Math.max(0, v.currentTime - 5);
    v.play().catch(() => {});
  };

  const toggle = () => {
    const v = video.current;
    if (entracte) return resumeFromEntracte();
    if (v.paused) {
      // Pause du direct : on reprend en différé là où on s'était arrêté
      if (isLive && pausedAt && Date.now() - pausedAt > 8000 && channel && channel.archive) {
        const start = Math.floor(pausedAt / 60000) * 60000;
        replace({ name: 'player', ref: { ...replayRef(channel, { title: ref.title, start, end: (liveProg && liveProg.end > start + 600000 ? liveProg.end : start + 3 * 3600000) }, group), sub: 'En différé', list: ref.list, timeshift: true } });
        return;
      }
      v.play().catch(() => {});
    } else {
      v.pause();
      if (isLive) setPausedAt(Date.now());
    }
  };
  const seekTo = (abs) => {
    const v = video.current;
    if (isReplay) {
      const o = Math.max(0, Math.min(progDur - 60, Math.floor(abs / 60) * 60));
      setOffset(o);
      return;
    }
    if (Number.isFinite(v.duration)) v.currentTime = Math.max(0, Math.min(v.duration - 1, abs));
  };
  const absPos = isReplay ? offset + pos : pos;
  const total = isReplay ? progDur : dur;
  const seekBy = (s) => { if (!isLive) seekTo(absPos + (isReplay ? Math.sign(s) * Math.max(60, Math.abs(s)) : s)); };

  const setVolume = (x) => {
    const v = video.current;
    const n = Math.max(0, Math.min(1, x));
    v.volume = n; v.muted = false;
    setVol(n); setMuted(false);
    saveJSON('volume', n);
  };
  const fullscreen = () => {
    if (window.lumen) window.lumen.toggleFullscreen();
    else if (document.fullscreenElement) document.exitFullscreen();
    else wrap.current.requestFullscreen().catch(() => {});
  };
  const leave = () => {
    save();
    if (window.lumen) window.lumen.toggleFullscreen(false);
    else if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    back();
  };
  const external = async () => {
    video.current.pause();
    if (!window.lumen) { window.open(url); return; }
    const r = await window.lumen.externalPlay({ url, title: ref.title + (ref.sub && !isLive ? ' · ' + ref.sub : ''), playerPath: settings.playerPath });
    if (!r.ok) setError(r.error);
  };

  // Entracte : pause de plus de 5 secondes
  useEffect(() => {
    if (playing || isLive || !settings.entracte || loading || error || seasonEnd) { setEntracte(false); return; }
    const t = setTimeout(() => setEntracte(true), 5000);
    return () => clearTimeout(t);
  }, [playing, loading, error, seasonEnd]);

  // Pistes audio
  const readAudio = () => {
    const at = video.current && video.current.audioTracks;
    if (!at) return setAudioTracks([]);
    const list = [];
    for (let i = 0; i < at.length; i++) list.push({ i, label: at[i].label || at[i].language || `Piste ${i + 1}`, lang: at[i].language, on: at[i].enabled });
    setAudioTracks(list);
  };
  const pickAudio = (i) => {
    const at = video.current.audioTracks;
    for (let k = 0; k < at.length; k++) at[k].enabled = k === i;
    readAudio();
  };

  // Sous-titres
  const activeSub = subs.find((s) => s.id === subId);
  const subUrl = useMemo(() => (activeSub ? vttUrl(activeSub.text, subOffset) : ''), [subId, subOffset, subs.length]);
  useEffect(() => {
    const v = video.current;
    if (!v) return;
    const t = setTimeout(() => { for (const tr of v.textTracks) tr.mode = subUrl ? 'showing' : 'disabled'; }, 50);
    return () => { clearTimeout(t); if (subUrl) URL.revokeObjectURL(subUrl); };
  }, [subUrl]);
  const addSub = (label, text) => {
    const id = 's' + Date.now();
    setSubs((l) => [...l, { id, label, text }]);
    setSubId(id);
    setSubOffset(0);
  };
  const onSubFile = (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    f.text().then((t) => addSub(f.name.replace(/\.(srt|vtt)$/i, ''), t));
  };
  const findSubs = async () => {
    setSubMsg('Recherche…');
    setFound(null);
    try {
      const q = ref.kind === 'episode' && ref.tmdbId
        ? { parentTmdbId: ref.tmdbId, season: ref.season, episode: ref.num }
        : ref.tmdbId ? { tmdbId: ref.tmdbId } : { query: ref.title };
      const list = await searchSubs(settings, q);
      setFound(list);
      setSubMsg(list.length ? '' : 'Aucun sous-titre trouvé.');
    } catch (e) { setSubMsg(e.message); }
  };
  const getSub = async (s) => {
    setSubMsg('Téléchargement…');
    try { addSub(`${s.lang.toUpperCase()} · ${s.name}`, await downloadSub(settings, s.id)); setSubMsg(''); setFound(null); }
    catch (e) { setSubMsg(e.message); }
  };

  // Clavier
  useEffect(() => {
    const onKey = (e) => {
      if (e.target && e.target.tagName === 'INPUT') return;
      wake();
      const k = e.key;
      if (entracte && k !== 'Escape') { e.preventDefault(); resumeFromEntracte(); return; }
      if (k === ' ' || k === 'k' || k === 'Enter') { e.preventDefault(); if (nextIn !== null && k === 'Enter') goNext(); else toggle(); }
      else if (k === 'ArrowRight') seekBy(10);
      else if (k === 'ArrowLeft') seekBy(-10);
      else if (k === 'ArrowUp') { e.preventDefault(); if (isLive) zapBy(-1); else setVolume(video.current.volume + 0.1); }
      else if (k === 'ArrowDown') { e.preventDefault(); if (isLive) zapBy(1); else setVolume(video.current.volume - 0.1); }
      else if (k === 'PageUp') zapBy(-1);
      else if (k === 'PageDown') zapBy(1);
      else if (k === 'f' || k === 'F') fullscreen();
      else if (k === 'm' || k === 'M') { video.current.muted = !video.current.muted; setMuted(video.current.muted); }
      else if (k === 'n' || k === 'N') goNext();
      else if (k === 's' || k === 'S') { if (showIntro) skipIntro(); }
      else if (k === 'Escape' || k === 'Backspace') { if (panel) setPanel(false); else leave(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const onSeekClick = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    seekTo(((e.clientX - r.left) / r.width) * total);
  };
  const onSeekHover = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    setHover({ x, t: x * total });
  };

  const pct = total ? (absPos / total) * 100 : 0;
  const bpct = total ? ((isReplay ? offset + buf : buf) / total) * 100 : 0;
  const vh = video.current ? video.current.videoHeight : 0;
  const remaining = Math.max(0, total - absPos);
  const subSize = { s: '26px', m: '34px', l: '44px' }[settings.subSize] || '34px';
  const upcomingBell = seasonEnd && seasonEnd.upcoming && typeof seasonEnd.upcoming === 'object'
    ? reminders.find((r) => r.type === 'episode' && r.seriesKey === ref.seriesKey && r.start === seasonEnd.upcoming.date) : null;

  return (
    <div ref={wrap} className={'player' + (idle && playing && !panel ? ' idle' : '')} style={{ '--subsize': subSize }} onMouseMove={wake}>
      <video ref={video} playsInline crossOrigin="anonymous" onDoubleClick={fullscreen} onClick={toggle} onSeeked={onSeeked}
        onPlaying={() => { setPlaying(true); setLoading(false); }}
        onPause={() => setPlaying(false)}
        onWaiting={() => setLoading(true)}
        onCanPlay={() => setLoading(false)}
        onTimeUpdate={(e) => {
          const v = e.currentTarget;
          setPos(v.currentTime);
          if (Number.isFinite(v.duration)) setDur(v.duration);
          if (v.buffered.length) setBuf(v.buffered.end(v.buffered.length - 1));
          if (v.videoHeight && !size) setSize(`${v.videoWidth}×${v.videoHeight}`);
        }}
        onEnded={() => { save(); if (nextEp && !isSeasonLast) goNext(); else if (isSeasonLast && !seasonEnd) openSeasonEnd(); }}>
        {subUrl && <track key={subUrl} kind="subtitles" src={subUrl} srcLang="fr" label="Sous-titres" default />}
      </video>

      {loading && !error && <Spinner center />}
      {zap && <div className="zap">{ref.title}</div>}
      {switching && <div className="zap" style={{ top: 170, fontSize: 15 }}>{switching}</div>}

      {error && (
        <div className="p-msg">
          <b style={{ fontSize: 18 }}>Lecture impossible</b>
          <p className="muted" style={{ lineHeight: 1.5 }}>{error}</p>
          <div className="actions" style={{ justifyContent: 'center' }}>
            {window.lumen && mpvExe && <button className="btn btn-primary" onClick={() => replace({ ...route, engine: 'mpv' })}><Icon name="play" size={18} />Lire avec mpv</button>}
            <button className={'btn ' + (mpvExe ? 'btn-ghost' : 'btn-primary')} onClick={external}><Icon name="external" size={18} />Lecteur externe</button>
            <button className="btn btn-ghost" onClick={() => { setAttempt(0); setError(''); setTick((t) => t + 1); }}>Réessayer</button>
            {isReplay && <button className="btn btn-ghost" onClick={toLive}>Revenir au direct</button>}
            <button className="btn btn-ghost" onClick={leave}>Retour</button>
          </div>
        </div>
      )}

      <div className="p-top">
        <button className="icon-btn" onClick={leave} aria-label="Retour"><Icon name="back" size={26} /></button>
        <div style={{ flex: '1 1 auto', minWidth: 0 }}>
          <div className="p-title">{ref.title}</div>
          <div className="p-sub">{isLive && liveProg ? `En direct · ${liveProg.title} · ${hhmm(liveProg.start)} – ${hhmm(liveProg.end)}` : ref.sub}</div>
        </div>
        {isLive && group && group.variants.length > 1 && (
          <div className="qpills" role="group" aria-label="Qualité">
            {group.variants.map((v) => (
              <button key={v.ch.key} className={v.ch.key === ref.key ? 'on' : ''} title={v.ch.name}
                onClick={() => { rememberVariant(group, v.ch); replace({ name: 'player', ref: liveRef(v.ch, ref.list, group) }); }}>{variantLabel(group, v)}</button>
            ))}
          </div>
        )}
        {vh > 0 && <span className="chip" title={size}>{resLabel(vh)} · {size}</span>}
      </div>

      {showIntro && !error && (
        <button className="skip-btn" onClick={skipIntro}>Passer l'intro<small>S</small></button>
      )}

      {nextIn !== null && nextEp && !seasonEnd && (
        <div className="ring-card">
          <button className="ring" onClick={goNext} aria-label="Lancer l'épisode suivant">
            <svg viewBox="0 0 120 120" aria-hidden="true">
              <circle cx="60" cy="60" r="56" fill="none" stroke="rgba(255,255,255,.18)" strokeWidth="5" />
              <circle cx="60" cy="60" r="56" fill="none" stroke="var(--accent)" strokeWidth="5" strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 56} strokeDashoffset={2 * Math.PI * 56 * (Math.max(0, nextIn) / 10)}
                style={{ transition: 'stroke-dashoffset 1s linear', transform: 'rotate(-90deg)', transformOrigin: 'center' }} />
            </svg>
            <span className="disc">{nextEp.still ? <img src={nextEp.still} alt="" /> : <Icon name="play" size={34} />}</span>
          </button>
          <div className="ring-txt">
            <span className="kicker">Épisode suivant{settings.autoNext ? ` · ${Math.max(0, nextIn)} s` : ''}</span>
            <b>{nextEp.title || `Épisode ${nextEp.num}`}</b>
            <span className="muted">Saison {nextEp.season} · Épisode {nextEp.num}</span>
            <div className="actions" style={{ marginTop: 4 }}>
              <button className="btn btn-primary btn-sm" onClick={goNext}>OK, on enchaîne</button>
              <button className="btn btn-ghost btn-sm" onClick={() => { ringOff.current = true; setNextIn(null); }}>Rester</button>
            </div>
          </div>
        </div>
      )}

      {seasonEnd && (
        <div className="season-end" style={{ backgroundImage: ref.poster || ref.image ? `url("${ref.image}")` : undefined }}>
          <div className="se-veil" />
          <div className="se-body">
            <span className="kicker">Fin de la saison {ref.season}</span>
            <h1 className="big-title" style={{ fontSize: 'clamp(44px, 6vw, 84px)' }}>{ref.title}</h1>
            <div className="se-stats">
              <div><b>{seasonEnd.seasonCount || seasonEnd.count}</b><span>épisodes</span></div>
              <div><b>{seasonEnd.hours >= 1 ? Math.round(seasonEnd.hours) + ' h' : Math.round(seasonEnd.hours * 60) + ' min'}</b><span>de visionnage</span></div>
              <div><b>{seasonEnd.days}</b><span>jour{seasonEnd.days > 1 ? 's' : ''} pour la voir</span></div>
              <div><b>{new Date(seasonEnd.started).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</b><span>commencée le</span></div>
            </div>
            {seasonEnd.next && (
              <div className="actions">
                <button className="btn btn-primary" autoFocus onClick={() => goEpisode(seasonEnd.next, ref.queue.slice(1))}>
                  <Icon name="play" size={18} />Saison {seasonEnd.next.season} · Épisode {seasonEnd.next.num}
                </button>
                <button className="btn btn-ghost" onClick={leave}>Plus tard</button>
              </div>
            )}
            {!seasonEnd.next && seasonEnd.upcoming && typeof seasonEnd.upcoming === 'object' && (
              <>
                <p className="synopsis">La suite, saison {seasonEnd.upcoming.season} épisode {seasonEnd.upcoming.num}, arrive le {new Date(seasonEnd.upcoming.date).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}, dans {Math.max(0, Math.ceil((seasonEnd.upcoming.date - Date.now()) / DAY))} jours.</p>
                <div className="actions">
                  <button className={'btn ' + (upcomingBell ? 'btn-ghost' : 'btn-primary')} disabled={!!upcomingBell}
                    onClick={() => addReminder({ type: 'episode', key: ref.seriesKey, seriesKey: ref.seriesKey, title: ref.title, sub: `S${seasonEnd.upcoming.season} · É${seasonEnd.upcoming.num}`, start: seasonEnd.upcoming.date })}>
                    <Icon name="bell" size={18} />{upcomingBell ? 'Rappel posé' : 'Me prévenir le jour J'}
                  </button>
                  <button className="btn btn-ghost" onClick={leave}>Retour</button>
                </div>
              </>
            )}
            {!seasonEnd.next && seasonEnd.upcoming === 'ended' && <><p className="synopsis">C'était la dernière saison. Série terminée.</p><div className="actions"><button className="btn btn-primary" onClick={leave}>Retour</button></div></>}
            {!seasonEnd.next && (!seasonEnd.upcoming || seasonEnd.upcoming === 'unknown') && <><p className="synopsis">Pas encore de date pour la suite.</p><div className="actions"><button className="btn btn-primary" onClick={leave}>Retour</button></div></>}
          </div>
        </div>
      )}

      {entracte && (
        <button className="entracte" onClick={resumeFromEntracte} aria-label="Reprendre la lecture">
          <span className="kicker">Entracte</span>
          <span className="ent-clock">{hhmm(Date.now())}</span>
          <span className="ent-line">Reste {fmtTime(remaining)} · Fin à {hhmm(Date.now() + remaining * 1000)}</span>
          <span className="ent-title">{ref.title}{ref.sub && ref.kind === 'episode' ? ' · ' + ref.sub : ''}</span>
          {nextEp && <span className="muted">Ensuite : S{nextEp.season} · É{nextEp.num}{nextEp.title ? ' · ' + nextEp.title : ''}</span>}
          <span className="ent-hint">Appuie sur une touche pour reprendre, 5 secondes avant</span>
        </button>
      )}

      {panel && (
        <div className="tracks" onClick={(e) => e.stopPropagation()}>
          <div className="tr-col">
            <b>Audio</b>
            {audioTracks.length <= 1 && <span className="muted">{audioTracks.length ? audioTracks[0].label : 'Piste unique'}{isLive || isReplay ? ' (direct : piste du flux)' : ''}</span>}
            {audioTracks.length > 1 && audioTracks.map((t) => (
              <button key={t.i} className={'tr-opt' + (t.on ? ' on' : '')} onClick={() => pickAudio(t.i)}>{t.label}{t.lang && t.label !== t.lang ? ` (${t.lang})` : ''}</button>
            ))}
          </div>
          <div className="tr-col">
            <b>Son</b>
            {EQ_MODES.map((m) => (
              <button key={m.id} className={'tr-opt' + ((settings.eq || 'normal') === m.id ? ' on' : '')} onClick={() => updateSettings({ eq: m.id })}>
                {m.name}<small> · {m.desc}</small>
              </button>
            ))}
            {!eqOk && <span className="muted" style={{ fontSize: 12 }}>Égaliseur indisponible sur ce flux.</span>}
          </div>
          <div className="tr-col">
            <b>Sous-titres</b>
            <button className={'tr-opt' + (!subId ? ' on' : '')} onClick={() => setSubId(null)}>Désactivés</button>
            {subs.map((s) => <button key={s.id} className={'tr-opt' + (s.id === subId ? ' on' : '')} onClick={() => setSubId(s.id)}>{s.label}</button>)}
            <label className="tr-opt" style={{ cursor: 'pointer' }}>Charger un fichier (.srt, .vtt)…<input type="file" accept=".srt,.vtt" onChange={onSubFile} style={{ display: 'none' }} /></label>
            {settings.osKey
              ? <button className="tr-opt" onClick={findSubs}>Chercher sur OpenSubtitles…</button>
              : <span className="muted" style={{ fontSize: 12, lineHeight: 1.5 }}>Ajoute une clé OpenSubtitles dans les Réglages pour chercher des sous-titres en ligne.</span>}
            {subMsg && <span className="muted">{subMsg}</span>}
            {found && found.map((s) => (
              <button key={s.id} className="tr-opt small" onClick={() => getSub(s)}>{s.lang.toUpperCase()} · {s.name}<small> · {s.downloads} téléch.</small></button>
            ))}
            {subId && (
              <div className="tr-adj">
                <span>Décalage {subOffset > 0 ? '+' : ''}{subOffset.toFixed(1)} s</span>
                <button className="btn btn-ghost btn-sm" onClick={() => setSubOffset((o) => o - 0.5)}>−0,5</button>
                <button className="btn btn-ghost btn-sm" onClick={() => setSubOffset((o) => o + 0.5)}>+0,5</button>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="p-bottom">
        {!isLive && (
          <div className="seek" onClick={onSeekClick} onMouseMove={onSeekHover} onMouseLeave={() => setHover(null)}
            role="slider" aria-label="Position" aria-valuemin={0} aria-valuemax={Math.round(total)} aria-valuenow={Math.round(absPos)} tabIndex={0}>
            <div className="tr" />
            <div className="bf" style={{ width: Math.min(100, bpct) + '%' }} />
            <div className="pl" style={{ width: Math.min(100, pct) + '%' }} />
            <div className="kn" style={{ left: Math.min(100, pct) + '%' }} />
            {hover && <div className="bubble" style={{ left: hover.x * 100 + '%' }}>{fmtTime(hover.t)}{isReplay ? ' · ' + hhmm(ref.start + hover.t * 1000) : ''}</div>}
          </div>
        )}
        <div className="p-ctrl">
          <button className="icon-btn" onClick={toggle} aria-label={playing ? 'Pause' : 'Lecture'}><Icon name={playing ? 'pause' : 'play'} size={26} /></button>
          {!isLive && <button className="icon-btn" onClick={() => seekBy(-10)} aria-label="Reculer"><Icon name="rewind" /></button>}
          {!isLive && <button className="icon-btn" onClick={() => seekBy(10)} aria-label="Avancer"><Icon name="forward" /></button>}
          {isLive && <button className="icon-btn" onClick={() => zapBy(-1)} aria-label="Chaîne précédente"><Icon name="back" /></button>}
          {isLive && <button className="icon-btn" onClick={() => zapBy(1)} aria-label="Chaîne suivante"><Icon name="next" /></button>}
          <button className="icon-btn" onClick={() => { video.current.muted = !video.current.muted; setMuted(video.current.muted); }} aria-label={muted ? 'Activer le son' : 'Couper le son'}>
            <Icon name={muted || vol === 0 ? 'mute' : 'volume'} />
          </button>
          <input type="range" min="0" max="1" step="0.05" value={muted ? 0 : vol} onChange={(e) => setVolume(Number(e.target.value))} aria-label="Volume" style={{ width: 110 }} />
          <span className="time">
            {isLive ? (pausedAt && !playing && channel && channel.archive ? 'EN PAUSE · reprise en différé' : 'EN DIRECT') : `${fmtTime(absPos)} / ${fmtTime(total)}`}
            {isReplay && <span className="muted"> · {hhmm(ref.start + absPos * 1000)}</span>}
          </span>
          <span className="grow" />
          {isLive && channel && channel.archive && liveProg && <button className="btn btn-ghost btn-sm" onClick={fromStart} title="Relancer le programme depuis le début">⟲ Depuis le début</button>}
          {isReplay && <button className="btn btn-primary btn-sm live-btn" onClick={toLive}>● Direct</button>}
          {nextEp && <button className="btn btn-ghost btn-sm" onClick={goNext}>Épisode suivant</button>}
          <button className={'icon-btn' + (subId ? ' on' : '')} onClick={() => setPanel((v) => !v)} aria-label="Audio et sous-titres" title="Audio et sous-titres"><Icon name="subs" /></button>
          <button className="icon-btn" onClick={external} aria-label="Ouvrir dans un lecteur externe" title="Lecteur externe (VLC, mpv)"><Icon name="external" /></button>
          <button className="icon-btn" onClick={fullscreen} aria-label="Plein écran"><Icon name="full" /></button>
        </div>
      </div>
    </div>
  );
}
