// TV : un seul bouton « Options » qui regroupe tris, filtres et vues d'un écran
import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Icon } from '../components/ui.jsx';

// sections : [{ label, value, choices: [[clé, libellé]], onChange }]
export default function TvOptions({ sections }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!open) return;
    const on = (e) => { e.preventDefault(); setOpen(false); };
    window.addEventListener('tv-back', on);
    return () => window.removeEventListener('tv-back', on);
  }, [open]);
  const summary = sections.map((s) => (s.choices.find(([k]) => k === s.value) || [])[1]).filter(Boolean).join(' · ');
  return (
    <>
      <button className="btn btn-ghost btn-sm tv-opt-btn" onClick={() => setOpen(true)}>
        <Icon name="gear" size={16} />Options{summary ? <span className="muted" style={{ fontWeight: 400 }}> · {summary}</span> : null}
      </button>
      {open && createPortal(
        <div className="modal tv-quick" data-tv-layer role="dialog" aria-label="Options" onClick={() => setOpen(false)}>
          <div className="modal-inner tv-opts" onClick={(e) => e.stopPropagation()}>
            <h2 className="page-title" style={{ fontSize: 34 }}>Options</h2>
            {sections.map((s, si) => (
              <div key={s.label} className="tv-opt-sec">
                <span className="kicker">{s.label}</span>
                <div className="tv-opt-row">
                  {s.choices.map(([k, l], i) => (
                    <button key={String(k)} className={'pill' + (s.value === k ? ' on' : '')}
                      {...(si === 0 && (s.value === k || (i === 0 && !s.choices.some(([kk]) => kk === s.value))) ? { 'data-tv-autofocus': true } : {})}
                      onClick={() => s.onChange(k)}>{l}</button>
                  ))}
                </div>
              </div>
            ))}
            <button className="btn btn-primary" style={{ alignSelf: 'flex-start', marginTop: 8 }} onClick={() => setOpen(false)}>Fermer</button>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}
