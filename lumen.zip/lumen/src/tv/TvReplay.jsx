// TV : revoir un programme passé d'une chaîne (replay Xtream), jour par jour
import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { getEpg, canReplay, dayLabel } from '../lib/epg.js';
import { hhmm } from '../lib/player.js';
import { pickVariant } from '../lib/live.js';
import { replayRef } from '../lib/play.js';
import { Spinner } from '../components/ui.jsx';
import { focusEl } from './spatial.js';

export default function TvReplay({ group, onClose }) {
  const { xtOf, navigate, settings } = useApp();
  const ch = pickVariant(group, settings.liveQuality);
  const [progs, setProgs] = useState(null);
  const [day, setDay] = useState(null);

  useEffect(() => {
    let off = false;
    getEpg(xtOf(ch.acc), ch).then((l) => !off && setProgs(l)).catch(() => !off && setProgs([]));
    return () => { off = true; };
  }, [ch.key]);

  useEffect(() => {
    const on = (e) => { e.preventDefault(); onClose(); };
    window.addEventListener('tv-back', on);
    return () => window.removeEventListener('tv-back', on);
  }, [onClose]);

  const now = Date.now();
  const past = useMemo(() => (progs || []).filter((p) => canReplay(ch, p, now)).sort((a, b) => b.start - a.start), [progs]);
  const days = useMemo(() => [...new Set(past.map((p) => new Date(p.start).toDateString()))], [past]);
  const curDay = day ?? days[0];
  const shown = past.filter((p) => new Date(p.start).toDateString() === curDay);

  // Gauche/droite : jour précédent/suivant
  const onKeys = (e) => {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    e.preventDefault();
    const i = days.indexOf(curDay);
    const n = days[i + (e.key === 'ArrowLeft' ? 1 : -1)];
    if (!n) return;
    setDay(n);
    setTimeout(() => focusEl(document.querySelector('.tv-replay .epg-item')), 60);
  };

  const play = (p) => { onClose(); navigate({ name: 'player', ref: replayRef(ch, p, group) }); };

  return (
    <div className="modal tv-quick tv-replay" data-tv-layer role="dialog" aria-label={'Replay ' + group.name} onClick={onClose}>
      <div className="modal-inner" onClick={(e) => e.stopPropagation()} style={{ width: 'min(860px, 100%)', maxHeight: '86vh' }}>
        <span className="kicker">Revoir un programme</span>
        <h2 className="page-title" style={{ fontSize: 34 }}>{group.name}</h2>
        {!progs && <div style={{ position: 'relative', height: 120 }}><Spinner center /></div>}
        {progs && past.length === 0 && <p className="muted">Aucun programme à revoir sur cette chaîne pour l'instant.</p>}
        {curDay && (
          <div className="tv-replay-day">
            <span className={days.indexOf(curDay) < days.length - 1 ? '' : 'off'}>‹</span>
            <b>{dayLabel(new Date(curDay).getTime())}</b>
            <span className={days.indexOf(curDay) > 0 ? '' : 'off'}>›</span>
            <small className="muted">gauche et droite pour changer de jour</small>
          </div>
        )}
        <div className="tv-replay-list" data-tv-keys="lr" onKeyDown={onKeys}>
          {shown.map((p, i) => (
            <button key={p.start} className="epg-item" onClick={() => play(p)} {...(i === 0 ? { 'data-tv-autofocus': true } : {})}>
              <div className="tm">{p.end > now ? 'EN COURS · DEPUIS LE DÉBUT · ' : ''}{hhmm(p.start)} – {hhmm(p.end)}</div>
              <b>{p.title}</b>
              {p.desc && <p>{p.desc}</p>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
