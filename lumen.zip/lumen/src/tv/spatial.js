// Navigation à la télécommande : les flèches déplacent le focus vers l'élément le plus proche dans la direction choisie.
// Fonctionne sur tous les écrans sans configuration : tout bouton, lien ou champ visible est atteignable.

const SELECTOR = 'button:not([disabled]):not([tabindex="-1"]), a[href], input:not([type="hidden"]):not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])';
const DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };

function visible(el) {
  if (!el.isConnected) return false;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return false;
  if (r.bottom < -innerHeight * 1.5 || r.top > innerHeight * 2.5) return false;
  if (el.checkVisibility) return el.checkVisibility({ visibilityProperty: true, opacityProperty: true });
  const st = getComputedStyle(el);
  if (st.visibility === 'hidden' || st.display === 'none' || Number(st.opacity) === 0) return false;
  for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
    const ps = getComputedStyle(p);
    if (ps.visibility === 'hidden' || ps.display === 'none') return false;
  }
  return true;
}

// Zone active : la fenêtre la plus au-dessus (fiche, lecteur, menu ouvert) sinon toute la page
function scope() {
  const layers = [...document.querySelectorAll('[data-tv-layer], .overlay, .modal, .player, .tv-player, .intro')]
    .filter((l) => l.getBoundingClientRect().height > 0 && getComputedStyle(l).visibility !== 'hidden' && getComputedStyle(l).display !== 'none');
  return layers.length ? layers[layers.length - 1] : document.body;
}

function candidates(root) {
  return [...root.querySelectorAll(SELECTOR)].filter(visible);
}

function center(r) { return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }

// Colonne retenue pendant les déplacements verticaux (rangées alignées)
let anchorX = null;

// Haut/bas : rangée la plus proche, puis l'élément le plus proche de la colonne de départ
function bestVertical(from, list, dir) {
  const a = from.getBoundingClientRect();
  const ca = center(a);
  const x = anchorX == null ? ca.x : anchorX;
  const cands = [];
  for (const el of list) {
    if (el === from || from.contains(el) || el.contains(from)) continue;
    const b = el.getBoundingClientRect();
    const cb = center(b);
    if (dir === 'down' ? cb.y <= ca.y + 4 || b.top < a.top + 4 : cb.y >= ca.y - 4 || b.bottom > a.bottom - 4) continue;
    const gap = dir === 'down' ? b.top - a.bottom : a.top - b.bottom;
    cands.push({ el, b, gap: Math.max(gap, -a.height / 2) });
  }
  if (!cands.length) return null;
  // D'abord la même colonne (liste des chaînes, groupes, réglages…), sinon la rangée la plus proche
  const left = Math.min(a.left, x - 1);
  const right = Math.max(a.right, x + 1);
  // v43 : la colonne ne l'emporte que si elle n'oblige pas à sauter loin (sinon on sautait des blocs entiers)
  const nearest = Math.min(...cands.map((c) => c.gap));
  const col = cands.filter((c) => Math.min(right, c.b.right) - Math.max(left, c.b.left) > 8 && c.gap <= nearest + 140);
  const pool = col.length ? col : cands;
  const min = Math.min(...pool.map((c) => c.gap));
  const row = pool.filter((c) => c.gap <= min + 24);
  let pick = null;
  let d = Infinity;
  for (const c of row) {
    const dx = x < c.b.left ? c.b.left - x : x > c.b.right ? x - c.b.right : 0;
    if (dx < d) { d = dx; pick = c.el; }
  }
  return pick;
}

// v43 : écrans en liste (Réglages) : haut/bas suivent l'ordre de lecture, ligne par ligne,
// sans jamais sauter un bouton ni rester bloqué
function listVertical(cur, list, dir) {
  const i = list.indexOf(cur);
  if (i < 0) return null;
  const a = cur.getBoundingClientRect();
  const step = dir === 'down' ? 1 : -1;
  let row = null;
  let rowTop = 0;
  for (let j = i + step; j >= 0 && j < list.length; j += step) {
    const b = list[j].getBoundingClientRect();
    const mid = b.top + b.height / 2;
    if (!row) {
      if (dir === 'down' ? mid <= a.bottom - 2 && b.top < a.bottom - 2 : mid >= a.top + 2 && b.bottom > a.top + 2) continue;
      row = [list[j]];
      rowTop = mid;
    } else if (Math.abs(mid - rowTop) < 12) row.push(list[j]);
    else break;
  }
  if (!row) return null;
  // Toujours le premier élément de la ligne (à gauche), comme dans une liste de réglages
  return row.reduce((p, el) => (el.getBoundingClientRect().left < p.getBoundingClientRect().left ? el : p));
}

// Score : distance dans l'axe + pénalité pour l'écart sur l'axe perpendiculaire
function best(from, list, dir) {
  if (dir === 'up' || dir === 'down') return bestVertical(from, list, dir);
  // v49 : guide des programmes : à gauche de la chaîne, on sort du guide (groupes, puis menu)
  if (dir === 'left' && from.classList.contains('ge-ch')) return null;
  const a = from.getBoundingClientRect();
  const ca = center(a);
  let pick = null;
  let score = Infinity;
  for (const el of list) {
    if (el === from || from.contains(el) || el.contains(from)) continue;
    const b = el.getBoundingClientRect();
    const cb = center(b);
    let main, cross, overlap;
    if (dir === 'left' || dir === 'right') {
      main = dir === 'right' ? b.left - a.right : a.left - b.right;
      if (dir === 'right' ? cb.x <= ca.x + 1 : cb.x >= ca.x - 1) continue;
      // v49 : vraiment à gauche ou à droite (le guide avait des programmes qui commencent au même bord que la chaîne)
      if (dir === 'left' ? b.left >= a.left - 2 : b.right <= a.right + 2) continue;
      overlap = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
      // Gauche/droite restent sur la même ligne
      if (overlap <= Math.min(a.height, b.height) * 0.2) continue;
      cross = Math.abs(cb.y - ca.y);
    } else {
      main = dir === 'down' ? b.top - a.bottom : a.top - b.bottom;
      if (dir === 'down' ? cb.y <= ca.y + 1 : cb.y >= ca.y - 1) continue;
      overlap = Math.min(a.right, b.right) - Math.max(a.left, b.left);
      cross = overlap > 0 ? Math.abs(cb.x - ca.x) * 0.15 : Math.abs(cb.x - ca.x);
    }
    const s = Math.max(main, -a.width) + cross * 2.2;
    if (s < score) { score = s; pick = el; }
  }
  return pick;
}

// v50 : défilement glissé (180 ms) au lieu de sauts : la page et les rangées suivent la sélection en douceur.
// Une touche maintenue redirige l'animation en cours vers la nouvelle cible, sans à-coups.
const anims = new WeakMap();
function pendingOf(el, prop) {
  const a = anims.get(el);
  return a && a[prop] ? a[prop].target - el[prop] : 0;
}
function glide(el, prop, target) {
  const max = prop === 'scrollTop' ? el.scrollHeight - el.clientHeight : el.scrollWidth - el.clientWidth;
  target = Math.max(0, Math.min(max, Math.round(target)));
  let a = anims.get(el);
  if (!a) { a = {}; anims.set(el, a); }
  if (a[prop]) cancelAnimationFrame(a[prop].raf);
  const from = el[prop];
  if (Math.abs(target - from) < 2) { el[prop] = target; delete a[prop]; return; }
  const t0 = performance.now();
  const job = { target, raf: 0 };
  a[prop] = job;
  const step = (t) => {
    const p = Math.min(1, (t - t0) / 180);
    el[prop] = from + (target - from) * (1 - Math.pow(1 - p, 3));
    if (p < 1 && a[prop] === job) job.raf = requestAnimationFrame(step);
    else if (a[prop] === job) delete a[prop];
  };
  job.raf = requestAnimationFrame(step);
}

// Conteneur défilant intermédiaire (colonne des groupes, guide, listes internes) : on garde le comportement direct
function nestedScroller(el, main) {
  for (let p = el.parentElement; p && p !== main; p = p.parentElement) {
    if (p.classList.contains('row-track')) continue;
    const v = p.scrollHeight > p.clientHeight + 2;
    const h = p.scrollWidth > p.clientWidth + 2;
    if (!v && !h) continue;
    const st = getComputedStyle(p);
    if ((v && /(auto|scroll)/.test(st.overflowY)) || (h && /(auto|scroll)/.test(st.overflowX))) return true;
  }
  return false;
}

export function focusEl(el) {
  if (!el) return;
  el.focus({ preventScroll: true });
  const main = el.closest('.overlay, .modal, .scroll');
  if (!main || el.closest('.header, .tv-rail') || nestedScroller(el, main)) {
    el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    // v49 : guide des programmes : un programme ne reste jamais caché sous la colonne des chaînes
    if (el.classList.contains('ge-prog')) {
      const ge = el.closest('.grid-epg');
      const chCell = el.closest('.ge-row') && el.closest('.ge-row').querySelector('.ge-ch');
      if (ge && chCell) {
        const r = el.getBoundingClientRect();
        const cr = chCell.getBoundingClientRect();
        if (r.left < cr.right + 8) ge.scrollLeft -= cr.right + 8 - r.left;
      }
    }
    return;
  }
  // Rangée horizontale : de la marge pour voir la carte voisine
  const row = el.closest('.row-track');
  if (row) {
    const pend = pendingOf(row, 'scrollLeft');
    const r = el.getBoundingClientRect();
    const rr = row.getBoundingClientRect();
    const left = r.left - pend;
    const right = r.right - pend;
    const cur = row.scrollLeft + pend;
    if (left < rr.left + 50) glide(row, 'scrollLeft', cur + left - rr.left - 60);
    else if (right > rr.right - 50) glide(row, 'scrollLeft', cur + right - rr.right + 60);
  }
  // Vertical : jamais caché en haut, jamais collé en bas ; en haut de page, on remonte tout en haut (v47)
  const pend = pendingOf(main, 'scrollTop');
  const r = el.getBoundingClientRect();
  const top = r.top - pend;
  const bottom = r.bottom - pend;
  const cur = main.scrollTop + pend;
  const topGap = document.querySelector('.tv-rail') ? 40 : 110;
  const inPage = top - main.getBoundingClientRect().top + cur;
  if ((main.classList.contains('scroll') || main.classList.contains('overlay')) && inPage + r.height < innerHeight - 30) glide(main, 'scrollTop', 0);
  else if (top < topGap) glide(main, 'scrollTop', cur + top - topGap - 20);
  else if (bottom > innerHeight - 30) glide(main, 'scrollTop', cur + bottom - innerHeight + 50);
}

// Dernier élément sélectionné dans chaque couche : on y revient quand la couche du dessus se ferme
const memory = new WeakMap();
// v43 : le menu latéral n'est jamais retenu comme « dernier endroit » du contenu
let lastContent = null;
function remember(el) {
  if (el.closest('.tv-rail')) return;
  const root = el.closest('[data-tv-layer], .overlay, .modal, .player, .tv-player') || document.body;
  memory.set(root, el);
  if (root === document.body) lastContent = el;
}
const inRail = (el) => !!(el && el.closest && el.closest('.tv-rail'));
const inChrome = (el) => !!el.closest('.header, .tv-rail');

// v43 : entrer dans le menu latéral, sur la rubrique en cours
export function focusRail() {
  const rail = document.querySelector('.tv-rail');
  if (!rail) return false;
  const on = rail.querySelector('[data-rail-on]') || rail.querySelector('.tr-item:not(.tr-profile)');
  if (!on) return false;
  on.focus({ preventScroll: true });
  return true;
}
export const railFocused = () => inRail(document.activeElement);

// v43 : revenir au contenu. Même écran : là où on était. Nouvel écran : son premier élément, dès qu'il est affiché.
let contentTimer = null;
export function focusContentSoon(changed) {
  clearTimeout(contentTimer);
  if (!changed && lastContent && lastContent.isConnected && visible(lastContent)) { focusEl(lastContent); return; }
  let tries = 0;
  const tick = () => {
    const sc = document.querySelector('.scroll');
    const pref = sc && sc.querySelector('[data-tv-autofocus]:not([disabled])');
    const first = pref && visible(pref) ? pref : sc && [...sc.querySelectorAll(SELECTOR)].find(visible);
    // On laisse l'écran se monter (l'ancien contenu disparaît d'abord)
    if (first && (tries > 1 || !changed)) { focusEl(first); return; }
    if (++tries < 40) contentTimer = setTimeout(tick, 70);
  };
  contentTimer = setTimeout(tick, changed ? 70 : 0);
}

// Premier élément à sélectionner quand un écran s'ouvre
export function focusFirst() {
  const root = scope();
  const back = memory.get(root);
  if (back && back.isConnected && root.contains(back) && visible(back)) { focusEl(back); return; }
  const pref = root.querySelector('[data-tv-autofocus]:not([disabled])');
  if (pref && visible(pref)) { focusEl(pref); return; }
  const list = candidates(root);
  // Évite l'en-tête : on démarre dans le contenu
  const inContent = list.find((el) => !inChrome(el) && el.getBoundingClientRect().top > (document.querySelector('.tv-rail') ? 0 : 80));
  focusEl(inContent || list[0]);
}

// Remonte en haut de l'écran et sélectionne le premier élément du contenu
export function focusTop() {
  const sc = document.querySelector('.scroll');
  if (sc) { const a = anims.get(sc); if (a && a.scrollTop) { cancelAnimationFrame(a.scrollTop.raf); delete a.scrollTop; } sc.scrollTop = 0; }
  const list = candidates(document.body).filter((el) => !inChrome(el));
  const first = list.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top || a.getBoundingClientRect().left - b.getBoundingClientRect().left)[0];
  if (first) focusEl(first);
}

export function installSpatialNav() {
  document.addEventListener('keydown', (e) => {
    const dir = DIRS[e.key];
    if (!dir) return;
    const cur = document.activeElement;
    // Dans un champ texte, gauche/droite déplacent le curseur
    if (cur && (cur.tagName === 'INPUT' || cur.tagName === 'TEXTAREA') && (dir === 'left' || dir === 'right') && cur.type !== 'checkbox' && cur.type !== 'range') {
      const v = cur.value || '';
      const atStart = cur.selectionStart === 0 && cur.selectionEnd === 0;
      const atEnd = cur.selectionStart === v.length;
      if (!(dir === 'left' ? atStart : atEnd)) return;
    }
    if (cur && cur.type === 'range' && (dir === 'left' || dir === 'right')) return;
    // Zone qui gère elle-même gauche/droite (saisons d'une série…)
    if (cur && (dir === 'left' || dir === 'right') && cur.closest && cur.closest('[data-tv-keys="lr"]')) return;
    const root = scope();
    // v43 : menu latéral. Haut/bas d'une rubrique à l'autre, droite revient au contenu
    if (root === document.body && inRail(cur)) {
      e.preventDefault();
      if (dir === 'right') { focusContentSoon(false); return; }
      if (dir === 'left') return;
      const items = [...document.querySelectorAll('.tv-rail .tr-item')];
      const i = items.indexOf(cur);
      const n = items[i + (dir === 'down' ? 1 : -1)];
      if (n) n.focus({ preventScroll: true });
      return;
    }
    // v43 : gauche/droite dans une rangée : on cherche d'abord dans la rangée seule (rapide)
    if ((dir === 'left' || dir === 'right') && cur && root.contains(cur)) {
      const track = cur.closest('.row-track');
      if (track) {
        const near = best(cur, [...track.querySelectorAll(SELECTOR)].filter(visible), dir);
        if (near) { e.preventDefault(); anchorX = null; focusEl(near); return; }
      }
    }
    const list = candidates(root).filter((el) => !inRail(el));
    if (!list.length) return;
    e.preventDefault();
    if (!cur || cur === document.body || !root.contains(cur) || !visible(cur)) { focusFirst(); return; }
    const isHead = (el) => !!el.closest('.header');
    let next = null;
    if (isHead(cur)) {
      // Dans l'en-tête : gauche/droite dans le menu, bas vers le contenu
      if (dir === 'left' || dir === 'right') next = best(cur, list.filter(isHead), dir);
      else if (dir === 'down') next = best(cur, list.filter((el) => !isHead(el) && el.getBoundingClientRect().top > cur.getBoundingClientRect().bottom), dir);
    } else {
      // Les colonnes latérales (groupes, catégories) forment une zone à part :
      // haut/bas restent dans leur zone, gauche/droite passent de l'une à l'autre
      const side = (el) => !!el.closest('.side');
      const content = list.filter((el) => !isHead(el));
      const listZone = cur.closest('[data-tv-nav="list"]');
      if ((dir === 'up' || dir === 'down') && listZone) next = listVertical(cur, [...listZone.querySelectorAll(SELECTOR)].filter(visible), dir);
      else if (dir === 'up' || dir === 'down') next = best(cur, content.filter((el) => side(el) === side(cur)), dir);
      else {
        next = best(cur, content, dir);
        if (!next && ((side(cur) && dir === 'right') || (!side(cur) && dir === 'left'))) {
          // Pas d'élément à la même hauteur : on va au plus proche de l'autre zone
          // (vers la colonne de gauche : directement sur le groupe sélectionné)
          const zone = content.filter((el) => side(el) !== side(cur));
          const on = dir === 'left' && zone.find((el) => el.classList.contains('on'));
          if (on) next = on;
          else {
            const a = cur.getBoundingClientRect();
            let d = Infinity;
            for (const el of zone) {
              const b = el.getBoundingClientRect();
              if (dir === 'right' ? b.left < a.right - 2 : b.right > a.left + 2) continue;
              const dd = Math.abs(b.left - a.right) + Math.abs(b.top - a.top) * 1.5;
              if (dd < d) { d = dd; next = el; }
            }
          }
        }
      }
      // v43 : rien à gauche : on ouvre le menu latéral
      if (!next && dir === 'left' && root === document.body && focusRail()) { anchorX = null; return; }
      // Tout en haut du contenu : on remonte dans l'en-tête, sur l'onglet de l'écran en cours
      if (!next && dir === 'up' && list.some(isHead)) {
        const active = list.find((el) => isHead(el) && el.closest('.nav') && el.classList.contains('on'));
        next = active || best(cur, list.filter(isHead), dir);
      }
    }
    if (dir === 'left' || dir === 'right') anchorX = null;
    else if (anchorX == null) anchorX = center(cur.getBoundingClientRect()).x;
    if (next) {
      focusEl(next);
      if (dir === 'left' || dir === 'right') anchorX = null;
    }
  }, true);

  document.addEventListener('focusin', (e) => { if (e.target && e.target.closest) remember(e.target); }, true);

  // OK : clic au relâchement, appui long (0,6 s) = menu rapide de l'élément
  let okTimer = null;
  let okEl = null;
  let okLong = false;
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const el = document.activeElement;
    if (!el || el === document.body || el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') return;
    e.preventDefault();
    e.stopPropagation();
    if (e.repeat || okEl) return;
    okEl = el;
    okLong = false;
    okTimer = setTimeout(() => {
      okLong = true;
      const ev = new CustomEvent('tv-longpress', { bubbles: true, cancelable: true });
      // Rien n'écoute l'appui long ici : on fait un clic normal
      if (el.dispatchEvent(ev)) { okLong = false; el.click(); okLong = true; }
    }, 600);
  }, true);
  document.addEventListener('keyup', (e) => {
    if (e.key !== 'Enter' || !okEl) return;
    e.preventDefault();
    clearTimeout(okTimer);
    const el = okEl;
    okEl = null;
    if (!okLong && el.isConnected) el.click();
  }, true);

  // Après un changement d'écran, si le focus est perdu, on le remet dans le contenu
  let t = null;
  const obs = new MutationObserver(() => {
    clearTimeout(t);
    t = setTimeout(() => {
      const cur = document.activeElement;
      const root = scope();
      if (!cur || cur === document.body || !root.contains(cur) || !visible(cur)) focusFirst();
    }, 180);
  });
  obs.observe(document.body, { childList: true, subtree: true });
}
