// Navigation à la télécommande : les flèches déplacent le focus vers l'élément le plus proche dans la direction choisie.
// Fonctionne sur tous les écrans sans configuration : tout bouton, lien ou champ visible est atteignable.

const SELECTOR = 'button:not([disabled]), a[href], input:not([type="hidden"]):not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])';
const DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };

function visible(el) {
  if (!el.isConnected) return false;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return false;
  if (r.bottom < -innerHeight * 1.5 || r.top > innerHeight * 2.5) return false;
  if (el.checkVisibility) return el.checkVisibility({ visibilityProperty: true, opacityProperty: true });
  const st = getComputedStyle(el);
  if (st.visibility === 'hidden' || st.display === 'none' || Number(st.opacity) === 0) return false;
  for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
    const ps = getComputedStyle(p);
    if (ps.visibility === 'hidden' || ps.display === 'none') return false;
  }
  return true;
}

// Zone active : la fenêtre la plus au-dessus (fiche, lecteur, menu ouvert) sinon toute la page
function scope() {
  const layers = [...document.querySelectorAll('[data-tv-layer], .overlay, .modal, .player, .tv-player, .intro')]
    .filter((l) => l.getBoundingClientRect().height > 0 && getComputedStyle(l).visibility !== 'hidden' && getComputedStyle(l).display !== 'none');
  return layers.length ? layers[layers.length - 1] : document.body;
}

function candidates(root) {
  return [...root.querySelectorAll(SELECTOR)].filter(visible);
}

function center(r) { return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }

// Score : distance dans l'axe + pénalité pour l'écart sur l'axe perpendiculaire
function best(from, list, dir) {
  const a = from.getBoundingClientRect();
  const ca = center(a);
  let pick = null;
  let score = Infinity;
  for (const el of list) {
    if (el === from || from.contains(el) || el.contains(from)) continue;
    const b = el.getBoundingClientRect();
    const cb = center(b);
    let main, cross, overlap;
    if (dir === 'left' || dir === 'right') {
      main = dir === 'right' ? b.left - a.right : a.left - b.right;
      if (dir === 'right' ? cb.x <= ca.x + 1 : cb.x >= ca.x - 1) continue;
      overlap = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
      // Gauche/droite restent sur la même ligne
      if (overlap <= Math.min(a.height, b.height) * 0.2) continue;
      cross = Math.abs(cb.y - ca.y);
    } else {
      main = dir === 'down' ? b.top - a.bottom : a.top - b.bottom;
      if (dir === 'down' ? cb.y <= ca.y + 1 : cb.y >= ca.y - 1) continue;
      overlap = Math.min(a.right, b.right) - Math.max(a.left, b.left);
      cross = overlap > 0 ? Math.abs(cb.x - ca.x) * 0.15 : Math.abs(cb.x - ca.x);
    }
    const s = Math.max(main, -a.width) + cross * 2.2;
    if (s < score) { score = s; pick = el; }
  }
  return pick;
}

export function focusEl(el) {
  if (!el) return;
  el.focus({ preventScroll: true });
  // Défilement immédiat (les positions doivent être justes pour la touche suivante)
  el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  // Les lignes horizontales gardent de la marge pour voir la carte voisine
  const row = el.closest('.row-track');
  if (row) {
    const r = el.getBoundingClientRect();
    const rr = row.getBoundingClientRect();
    if (r.left < rr.left + 50) row.scrollLeft += r.left - rr.left - 60;
    else if (r.right > rr.right - 50) row.scrollLeft += r.right - rr.right + 60;
  }
  // Jamais caché sous l'en-tête, jamais collé au bas de l'écran
  if (!el.closest('.header')) {
    const sc = el.closest('.scroll, .overlay, .modal');
    if (sc) {
      const r = el.getBoundingClientRect();
      if (r.top < 110) sc.scrollTop += r.top - 130;
      else if (r.bottom > innerHeight - 30) sc.scrollTop += r.bottom - innerHeight + 50;
    }
  }
}

// Premier élément à sélectionner quand un écran s'ouvre
export function focusFirst() {
  const root = scope();
  const pref = root.querySelector('[data-tv-autofocus]:not([disabled])');
  if (pref && visible(pref)) { focusEl(pref); return; }
  const list = candidates(root);
  // Évite l'en-tête : on démarre dans le contenu
  const inContent = list.find((el) => !el.closest('.header') && el.getBoundingClientRect().top > 80);
  focusEl(inContent || list[0]);
}

export function installSpatialNav() {
  document.addEventListener('keydown', (e) => {
    const dir = DIRS[e.key];
    if (!dir) return;
    const cur = document.activeElement;
    // Dans un champ texte, gauche/droite déplacent le curseur
    if (cur && (cur.tagName === 'INPUT' || cur.tagName === 'TEXTAREA') && (dir === 'left' || dir === 'right') && cur.type !== 'checkbox' && cur.type !== 'range') {
      const v = cur.value || '';
      const atStart = cur.selectionStart === 0 && cur.selectionEnd === 0;
      const atEnd = cur.selectionStart === v.length;
      if (!(dir === 'left' ? atStart : atEnd)) return;
    }
    if (cur && cur.type === 'range' && (dir === 'left' || dir === 'right')) return;
    const root = scope();
    const list = candidates(root);
    if (!list.length) return;
    e.preventDefault();
    if (!cur || cur === document.body || !root.contains(cur) || !visible(cur)) { focusFirst(); return; }
    const isHead = (el) => !!el.closest('.header');
    let next = null;
    if (isHead(cur)) {
      // Dans l'en-tête : gauche/droite dans le menu, bas vers le contenu
      if (dir === 'left' || dir === 'right') next = best(cur, list.filter(isHead), dir);
      else if (dir === 'down') next = best(cur, list.filter((el) => !isHead(el) && el.getBoundingClientRect().top > cur.getBoundingClientRect().bottom), dir);
    } else {
      next = best(cur, list.filter((el) => !isHead(el)), dir);
      // Tout en haut du contenu : on remonte dans l'en-tête
      if (!next && dir === 'up') next = best(cur, list.filter(isHead), dir);
    }
    if (next) focusEl(next);
  }, true);

  // Après un changement d'écran, si le focus est perdu, on le remet dans le contenu
  let t = null;
  const obs = new MutationObserver(() => {
    clearTimeout(t);
    t = setTimeout(() => {
      const cur = document.activeElement;
      const root = scope();
      if (!cur || cur === document.body || !root.contains(cur) || !visible(cur)) focusFirst();
    }, 180);
  });
  obs.observe(document.body, { childList: true, subtree: true });
}
