// Navigation à la télécommande : les flèches déplacent le focus vers l'élément le plus proche dans la direction choisie.
// Fonctionne sur tous les écrans sans configuration : tout bouton, lien ou champ visible est atteignable.

const SELECTOR = 'button:not([disabled]):not([tabindex="-1"]), a[href], input:not([type="hidden"]):not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])';
const DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };

function visible(el) {
  if (!el.isConnected) return false;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return false;
  if (r.bottom < -innerHeight * 1.5 || r.top > innerHeight * 2.5) return false;
  if (el.checkVisibility) return el.checkVisibility({ visibilityProperty: true, opacityProperty: true });
  const st = getComputedStyle(el);
  if (st.visibility === 'hidden' || st.display === 'none' || Number(st.opacity) === 0) return false;
  for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
    const ps = getComputedStyle(p);
    if (ps.visibility === 'hidden' || ps.display === 'none') return false;
  }
  return true;
}

// Zone active : la fenêtre la plus au-dessus (fiche, lecteur, menu ouvert) sinon toute la page
function scope() {
  const layers = [...document.querySelectorAll('[data-tv-layer], .overlay, .modal, .player, .tv-player, .intro')]
    .filter((l) => l.getBoundingClientRect().height > 0 && getComputedStyle(l).visibility !== 'hidden' && getComputedStyle(l).display !== 'none');
  return layers.length ? layers[layers.length - 1] : document.body;
}

function candidates(root) {
  return [...root.querySelectorAll(SELECTOR)].filter(visible);
}

function center(r) { return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }

// Colonne retenue pendant les déplacements verticaux (rangées alignées)
let anchorX = null;

// Haut/bas : rangée la plus proche, puis l'élément le plus proche de la colonne de départ
function bestVertical(from, list, dir) {
  const a = from.getBoundingClientRect();
  const ca = center(a);
  const x = anchorX == null ? ca.x : anchorX;
  const cands = [];
  for (const el of list) {
    if (el === from || from.contains(el) || el.contains(from)) continue;
    const b = el.getBoundingClientRect();
    const cb = center(b);
    if (dir === 'down' ? cb.y <= ca.y + 4 || b.top < a.top + 4 : cb.y >= ca.y - 4 || b.bottom > a.bottom - 4) continue;
    const gap = dir === 'down' ? b.top - a.bottom : a.top - b.bottom;
    cands.push({ el, b, gap: Math.max(gap, -a.height / 2) });
  }
  if (!cands.length) return null;
  // D'abord la même colonne (liste des chaînes, groupes, réglages…), sinon la rangée la plus proche
  const left = Math.min(a.left, x - 1);
  const right = Math.max(a.right, x + 1);
  const col = cands.filter((c) => Math.min(right, c.b.right) - Math.max(left, c.b.left) > 8);
  const pool = col.length ? col : cands;
  const min = Math.min(...pool.map((c) => c.gap));
  const row = pool.filter((c) => c.gap <= min + 24);
  let pick = null;
  let d = Infinity;
  for (const c of row) {
    const dx = x < c.b.left ? c.b.left - x : x > c.b.right ? x - c.b.right : 0;
    if (dx < d) { d = dx; pick = c.el; }
  }
  return pick;
}

// Score : distance dans l'axe + pénalité pour l'écart sur l'axe perpendiculaire
function best(from, list, dir) {
  if (dir === 'up' || dir === 'down') return bestVertical(from, list, dir);
  const a = from.getBoundingClientRect();
  const ca = center(a);
  let pick = null;
  let score = Infinity;
  for (const el of list) {
    if (el === from || from.contains(el) || el.contains(from)) continue;
    const b = el.getBoundingClientRect();
    const cb = center(b);
    let main, cross, overlap;
    if (dir === 'left' || dir === 'right') {
      main = dir === 'right' ? b.left - a.right : a.left - b.right;
      if (dir === 'right' ? cb.x <= ca.x + 1 : cb.x >= ca.x - 1) continue;
      overlap = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
      // Gauche/droite restent sur la même ligne
      if (overlap <= Math.min(a.height, b.height) * 0.2) continue;
      cross = Math.abs(cb.y - ca.y);
    } else {
      main = dir === 'down' ? b.top - a.bottom : a.top - b.bottom;
      if (dir === 'down' ? cb.y <= ca.y + 1 : cb.y >= ca.y - 1) continue;
      overlap = Math.min(a.right, b.right) - Math.max(a.left, b.left);
      cross = overlap > 0 ? Math.abs(cb.x - ca.x) * 0.15 : Math.abs(cb.x - ca.x);
    }
    const s = Math.max(main, -a.width) + cross * 2.2;
    if (s < score) { score = s; pick = el; }
  }
  return pick;
}

export function focusEl(el) {
  if (!el) return;
  el.focus({ preventScroll: true });
  // Défilement immédiat (les positions doivent être justes pour la touche suivante)
  el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  // Les lignes horizontales gardent de la marge pour voir la carte voisine
  const row = el.closest('.row-track');
  if (row) {
    const r = el.getBoundingClientRect();
    const rr = row.getBoundingClientRect();
    if (r.left < rr.left + 50) row.scrollLeft += r.left - rr.left - 60;
    else if (r.right > rr.right - 50) row.scrollLeft += r.right - rr.right + 60;
  }
  // Jamais caché sous l'en-tête, jamais collé au bas de l'écran
  if (!el.closest('.header')) {
    const sc = el.closest('.scroll, .overlay, .modal');
    if (sc) {
      const r = el.getBoundingClientRect();
      if (r.top < 110) sc.scrollTop += r.top - 130;
      else if (r.bottom > innerHeight - 30) sc.scrollTop += r.bottom - innerHeight + 50;
    }
  }
}

// Dernier élément sélectionné dans chaque couche : on y revient quand la couche du dessus se ferme
const memory = new WeakMap();
function remember(el) {
  const root = el.closest('[data-tv-layer], .overlay, .modal, .player, .tv-player') || document.body;
  memory.set(root, el);
}

// Premier élément à sélectionner quand un écran s'ouvre
export function focusFirst() {
  const root = scope();
  const back = memory.get(root);
  if (back && back.isConnected && root.contains(back) && visible(back)) { focusEl(back); return; }
  const pref = root.querySelector('[data-tv-autofocus]:not([disabled])');
  if (pref && visible(pref)) { focusEl(pref); return; }
  const list = candidates(root);
  // Évite l'en-tête : on démarre dans le contenu
  const inContent = list.find((el) => !el.closest('.header') && el.getBoundingClientRect().top > 80);
  focusEl(inContent || list[0]);
}

// Remonte en haut de l'écran et sélectionne le premier élément du contenu
export function focusTop() {
  const sc = document.querySelector('.scroll');
  if (sc) sc.scrollTop = 0;
  const list = candidates(document.body).filter((el) => !el.closest('.header'));
  const first = list.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top || a.getBoundingClientRect().left - b.getBoundingClientRect().left)[0];
  if (first) focusEl(first);
}

export function installSpatialNav() {
  document.addEventListener('keydown', (e) => {
    const dir = DIRS[e.key];
    if (!dir) return;
    const cur = document.activeElement;
    // Dans un champ texte, gauche/droite déplacent le curseur
    if (cur && (cur.tagName === 'INPUT' || cur.tagName === 'TEXTAREA') && (dir === 'left' || dir === 'right') && cur.type !== 'checkbox' && cur.type !== 'range') {
      const v = cur.value || '';
      const atStart = cur.selectionStart === 0 && cur.selectionEnd === 0;
      const atEnd = cur.selectionStart === v.length;
      if (!(dir === 'left' ? atStart : atEnd)) return;
    }
    if (cur && cur.type === 'range' && (dir === 'left' || dir === 'right')) return;
    // Zone qui gère elle-même gauche/droite (saisons d'une série…)
    if (cur && (dir === 'left' || dir === 'right') && cur.closest && cur.closest('[data-tv-keys="lr"]')) return;
    const root = scope();
    const list = candidates(root);
    if (!list.length) return;
    e.preventDefault();
    if (!cur || cur === document.body || !root.contains(cur) || !visible(cur)) { focusFirst(); return; }
    const isHead = (el) => !!el.closest('.header');
    let next = null;
    if (isHead(cur)) {
      // Dans l'en-tête : gauche/droite dans le menu, bas vers le contenu
      if (dir === 'left' || dir === 'right') next = best(cur, list.filter(isHead), dir);
      else if (dir === 'down') next = best(cur, list.filter((el) => !isHead(el) && el.getBoundingClientRect().top > cur.getBoundingClientRect().bottom), dir);
    } else {
      // Les colonnes latérales (groupes, catégories) forment une zone à part :
      // haut/bas restent dans leur zone, gauche/droite passent de l'une à l'autre
      const side = (el) => !!el.closest('.side');
      const content = list.filter((el) => !isHead(el));
      if (dir === 'up' || dir === 'down') next = best(cur, content.filter((el) => side(el) === side(cur)), dir);
      else {
        next = best(cur, content, dir);
        if (!next && ((side(cur) && dir === 'right') || (!side(cur) && dir === 'left'))) {
          // Pas d'élément à la même hauteur : on va au plus proche de l'autre zone
          // (vers la colonne de gauche : directement sur le groupe sélectionné)
          const zone = content.filter((el) => side(el) !== side(cur));
          const on = dir === 'left' && zone.find((el) => el.classList.contains('on'));
          if (on) next = on;
          else {
            const a = cur.getBoundingClientRect();
            let d = Infinity;
            for (const el of zone) {
              const b = el.getBoundingClientRect();
              if (dir === 'right' ? b.left < a.right - 2 : b.right > a.left + 2) continue;
              const dd = Math.abs(b.left - a.right) + Math.abs(b.top - a.top) * 1.5;
              if (dd < d) { d = dd; next = el; }
            }
          }
        }
      }
      // Tout en haut du contenu : on remonte dans l'en-tête
      if (!next && dir === 'up') next = best(cur, list.filter(isHead), dir);
    }
    if (dir === 'left' || dir === 'right') anchorX = null;
    else if (anchorX == null) anchorX = center(cur.getBoundingClientRect()).x;
    if (next) {
      focusEl(next);
      if (dir === 'left' || dir === 'right') anchorX = null;
    }
  }, true);

  document.addEventListener('focusin', (e) => { if (e.target && e.target.closest) remember(e.target); }, true);

  // OK : clic au relâchement, appui long (0,6 s) = menu rapide de l'élément
  let okTimer = null;
  let okEl = null;
  let okLong = false;
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const el = document.activeElement;
    if (!el || el === document.body || el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') return;
    e.preventDefault();
    e.stopPropagation();
    if (e.repeat || okEl) return;
    okEl = el;
    okLong = false;
    okTimer = setTimeout(() => {
      okLong = true;
      const ev = new CustomEvent('tv-longpress', { bubbles: true, cancelable: true });
      // Rien n'écoute l'appui long ici : on fait un clic normal
      if (el.dispatchEvent(ev)) { okLong = false; el.click(); okLong = true; }
    }, 600);
  }, true);
  document.addEventListener('keyup', (e) => {
    if (e.key !== 'Enter' || !okEl) return;
    e.preventDefault();
    clearTimeout(okTimer);
    const el = okEl;
    okEl = null;
    if (!okLong && el.isConnected) el.click();
  }, true);

  // Après un changement d'écran, si le focus est perdu, on le remet dans le contenu
  let t = null;
  const obs = new MutationObserver(() => {
    clearTimeout(t);
    t = setTimeout(() => {
      const cur = document.activeElement;
      const root = scope();
      if (!cur || cur === document.body || !root.contains(cur) || !visible(cur)) focusFirst();
    }, 180);
  });
  obs.observe(document.body, { childList: true, subtree: true });
}
