// Clavier à l'écran pour la télécommande, avec recherche vocale (micro de la Shield)
import React, { useEffect, useRef, useState } from 'react';
import { focusEl } from './spatial.js';
import { LumenTv, native } from './native.js';
import { Icon } from '../components/ui.jsx';

const ROWS = ['ABCDEFGHI', 'JKLMNOPQR', 'STUVWXYZ', '1234567890'];

export default function TvKeyboard({ value, onChange }) {
  const [msg, setMsg] = useState('');
  const box = useRef(null);
  // À l'ouverture de la recherche, le focus va sur « Parler » (ou la première lettre)
  useEffect(() => {
    const t = setTimeout(() => focusEl(box.current && box.current.querySelector('[data-tv-autofocus]')), 60);
    return () => clearTimeout(t);
  }, []);
  const type = (c) => onChange((value + c).replace(/^\s+/, ''));
  const voice = async () => {
    setMsg('');
    try {
      const r = await LumenTv.voice();
      if (r.text) onChange(r.text);
    } catch (e) {
      setMsg(e.message || 'Recherche vocale indisponible');
    }
  };
  return (
    <div className="tv-kb" ref={box}>
      <div className="tv-kb-q">
        <Icon name="search" size={26} />
        <span className={value ? '' : 'muted'}>{value || 'Films, séries, chaînes…'}</span>
        <i className="tv-kb-caret" />
      </div>
      <div className="tv-kb-keys">
        {native && (
          <button className="tv-kb-voice" data-tv-autofocus onClick={voice} aria-label="Recherche vocale">
            <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></svg>
            Parler
          </button>
        )}
        {ROWS.map((r, i) => (
          <div key={i} className="tv-kb-row">
            {[...r].map((c) => <button key={c} onClick={() => type(c.toLowerCase())} {...(!native && i === 0 && c === 'A' ? { 'data-tv-autofocus': true } : {})}>{c}</button>)}
            {i === 2 && <button className="wide" onClick={() => type(' ')}>Espace</button>}
          </div>
        ))}
        <div className="tv-kb-row">
          <button className="wide" onClick={() => onChange(value.slice(0, -1))} aria-label="Effacer une lettre">⌫ Effacer</button>
          <button className="wide" onClick={() => onChange('')}>Tout effacer</button>
        </div>
      </div>
      {msg && <p className="err">{msg}</p>}
    </div>
  );
}
