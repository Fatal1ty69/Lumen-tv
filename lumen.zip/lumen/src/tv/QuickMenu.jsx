// TV : appui long sur OK = menu rapide de l'élément (affiche, chaîne, « Continuer à regarder »)
import React, { useEffect, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { movieRef, isWatched } from '../lib/play.js';
import { pickVariant } from '../lib/live.js';
import TvReplay from './TvReplay.jsx';

export default function QuickMenu() {
  const app = useApp();
  const { catalog, favorites, toggleFav, navigate, progress, setWatched } = app;
  const [menu, setMenu] = useState(null);
  const [replay, setReplay] = useState(null);

  // Le lecteur demande la liste des programmes passés d'une chaîne
  useEffect(() => {
    const on = (e) => { const g = catalog.byKey.get(e.detail && e.detail.key); if (g) setReplay(g); };
    window.addEventListener('lumen:replays', on);
    return () => window.removeEventListener('lumen:replays', on);
  }, [catalog]);

  useEffect(() => {
    const on = (e) => {
      const el = e.target;
      const item = el.closest && el.closest('[data-item-key]');
      const chan = el.closest && el.closest('.chan[data-key], [data-chan-key]');
      const land = el.closest && el.closest('.land-wrap');
      let m = null;
      if (item) {
        const it = catalog.byKey.get(item.getAttribute('data-item-key'));
        if (it) m = { kind: 'item', it, el: item };
      } else if (chan) {
        const g = catalog.byKey.get(chan.getAttribute('data-key') || chan.getAttribute('data-chan-key'));
        if (g) m = { kind: 'chan', it: g, el: chan };
      } else if (land) {
        m = { kind: 'land', el: land, title: (land.querySelector('.ptitle') || {}).textContent || '' };
      }
      if (!m) return;
      e.preventDefault();
      setMenu(m);
    };
    document.addEventListener('tv-longpress', on);
    return () => document.removeEventListener('tv-longpress', on);
  }, [catalog]);

  // Retour ferme le menu rapide
  useEffect(() => {
    if (!menu) return;
    const on = (e) => { e.preventDefault(); setMenu(null); setTimeout(() => menu.el && menu.el.isConnected && menu.el.focus(), 30); };
    window.addEventListener('tv-back', on);
    return () => window.removeEventListener('tv-back', on);
  }, [menu]);

  if (replay) return <TvReplay group={replay} onClose={() => setReplay(null)} />;
  if (!menu) return null;
  const close = () => {
    const back = menu.el;
    setMenu(null);
    setTimeout(() => back && back.isConnected && back.focus(), 30);
  };
  const act = (fn) => () => { fn(); close(); };
  const actions = [];
  if (menu.kind === 'item') {
    const it = menu.it;
    actions.push(['Voir la fiche', () => navigate({ name: 'fiche', item: it })]);
    actions.push([favorites[it.key] ? 'Retirer de Ma liste' : 'Ajouter à Ma liste', () => toggleFav(it)]);
    if (it.kind === 'movie') {
      const seen = isWatched(progress[it.key]);
      actions.push([seen ? 'Marquer comme non vu' : 'Marquer comme vu', () => setWatched([{ ref: { ...movieRef(it), tmdbId: it.tmdb || null } }], !seen)]);
    }
  } else if (menu.kind === 'chan') {
    const g = menu.it;
    actions.push(['Regarder en direct', () => menu.el.click()]);
    const ch = pickVariant(g, app.settings.liveQuality);
    if (ch && ch.archive) actions.push(['Revoir un programme', () => setReplay(g)]);
    actions.push([favorites[g.key] ? 'Retirer des favoris' : 'Ajouter aux favoris', () => toggleFav({ key: g.key, kind: 'group', id: g.key, title: g.name, poster: g.logo })]);
  } else {
    actions.push(['Reprendre', () => { const b = menu.el.querySelector('.card'); if (b) b.click(); }]);
    actions.push(['Retirer de « Continuer à regarder »', () => { const b = menu.el.querySelector('.rm-btn'); if (b) b.click(); }]);
  }
  const title = menu.kind === 'land' ? menu.title : menu.it.title || menu.it.name;

  return (
    <div className="modal tv-quick" data-tv-layer role="dialog" aria-label={title} onClick={close}>
      <div className="modal-inner" onClick={(e) => e.stopPropagation()}>
        <h2 className="page-title" style={{ fontSize: 34, marginBottom: 8 }}>{title}</h2>
        {actions.map(([label, fn], i) => (
          <button key={label} className="btn btn-ghost tv-quick-btn" {...(i === 0 ? { 'data-tv-autofocus': true } : {})} onClick={act(fn)}>{label}</button>
        ))}
        <button className="btn btn-ghost tv-quick-btn" onClick={close}>Fermer</button>
      </div>
    </div>
  );
}
