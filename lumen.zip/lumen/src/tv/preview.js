// Miniature du direct (TV) : un petit lecteur natif posé sur l'emplacement de l'aperçu
import { LumenTv, native } from './native.js';

let current = null;      // { key, url, alt, el }
let shown = false;
let blocked = false;     // une fenêtre (fiche, menu, lecteur) recouvre l'écran
let obs = null;
let raf = 0;

const BLOCKERS = '.overlay, .modal, .tv-player, .intro, [data-tv-layer]';

function rect() {
  if (!current || !current.el || !current.el.isConnected) return null;
  const r = current.el.getBoundingClientRect();
  if (r.width < 10 || r.bottom < 0 || r.top > innerHeight) return null;
  return { x: r.left, y: r.top, w: r.width, h: r.height, vw: innerWidth };
}

function sync() {
  if (!native || !current) return;
  const r = rect();
  const want = !blocked && !!r;
  if (want) {
    LumenTv.previewStart({ key: current.key, url: current.url, alt: current.alt, ...r }).catch(() => {});
    shown = true;
  } else if (shown) {
    LumenTv.previewHide().catch(() => {});
    shown = false;
  }
}

function watch() {
  if (obs) return;
  obs = new MutationObserver(() => {
    const b = !!document.querySelector(BLOCKERS);
    if (b !== blocked) { blocked = b; sync(); }
  });
  obs.observe(document.body, { childList: true, subtree: true });
  blocked = !!document.querySelector(BLOCKERS);
  const onMove = () => {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(() => {
      const r = rect();
      if (shown && r && !blocked) LumenTv.previewMove(r).catch(() => {});
      else sync();
    });
  };
  document.addEventListener('scroll', onMove, true);
  window.addEventListener('resize', onMove);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { shown = false; sync(); } });
}

export function previewShow(key, url, alt, el) {
  if (!native) return;
  watch();
  current = { key, url, alt, el };
  sync();
}

export function previewKey() {
  return current && shown ? current.key : null;
}

export function previewStop() {
  if (!native) return;
  current = null;
  shown = false;
  LumenTv.previewStop().catch(() => {});
}
