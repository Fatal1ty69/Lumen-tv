// Mise à jour de Lumen TV depuis les versions publiées sur GitHub
import React, { useEffect, useState } from 'react';
import { LumenTv, native } from './native.js';
import { loadJSON, saveJSON } from '../lib/store.js';

export const TV_REPO = import.meta.env.VITE_TV_REPO || 'Fatal1ty69/Lumen-tv';

// { current, latest, name, url } ou null si pas de version plus récente
export async function checkUpdate() {
  if (!native) return null;
  const info = await LumenTv.appInfo();
  const r = await window.lumen.httpGet(`https://api.github.com/repos/${TV_REPO}/releases/latest`, 15000);
  if (!r.ok || r.status !== 200) throw new Error('GitHub ne répond pas' + (r.status ? ' (' + r.status + ')' : ''));
  const rel = JSON.parse(r.text);
  const latest = Number(String(rel.tag_name || '').replace(/\D+/g, '')) || 0;
  const asset = (rel.assets || []).find((a) => /\.apk$/i.test(a.name));
  const res = { current: Number(info.versionCode) || 0, currentName: info.versionName, latest, name: rel.name || rel.tag_name, url: asset && asset.browser_download_url };
  return { ...res, newer: !!(asset && latest > res.current) };
}

export function UpdatePanel({ upd, onClose }) {
  const [state, setState] = useState('idle');
  useEffect(() => {
    const on = (e) => { e.preventDefault(); onClose(); };
    window.addEventListener('tv-back', on);
    return () => window.removeEventListener('tv-back', on);
  }, [onClose]);
  const [pct, setPct] = useState(0);
  const [msg, setMsg] = useState('');

  const go = async () => {
    setMsg('');
    setState('download');
    setPct(0);
    const sub = await LumenTv.addListener('updateProgress', (e) => setPct(e.percent));
    try {
      const r = await LumenTv.installUpdate({ url: upd.url });
      if (r && r.needPermission) {
        setState('idle');
        setMsg('Android a ouvert l\'écran d\'autorisation : active « Lumen », reviens ici avec Retour, puis appuie de nouveau sur « Mettre à jour ».');
      } else {
        setState('install');
      }
    } catch (e) {
      setState('idle');
      setMsg(e.message || 'Téléchargement impossible');
    } finally {
      sub.remove();
    }
  };

  return (
    <div className="modal tv-update" data-tv-layer role="dialog" aria-label="Mise à jour">
      <div className="modal-inner" style={{ maxWidth: 720, padding: 34 }}>
        <span className="kicker">Mise à jour disponible</span>
        <h2 className="page-title" style={{ fontSize: 42, margin: '6px 0 10px' }}>{upd.name}</h2>
        <p className="muted" style={{ fontSize: 17, lineHeight: 1.5 }}>Tu as la version {upd.currentName || upd.current}. La nouvelle version s'installe par-dessus : tes réglages, Ma liste et ta progression sont conservés.</p>
        {state === 'download' && <div className="dl-bar" style={{ marginTop: 18 }}><i style={{ width: Math.max(2, pct) + '%' }} /><span>Téléchargement {pct >= 0 ? pct + ' %' : ''}</span></div>}
        {state === 'install' && <p className="ok" style={{ fontSize: 17, marginTop: 16 }}>Android te demande de confirmer : choisis « Installer » (ou « Mettre à jour »).</p>}
        {msg && <p className="err" style={{ fontSize: 16, marginTop: 16 }}>{msg}</p>}
        <div className="actions" style={{ marginTop: 22 }}>
          {state !== 'install' && <button className="btn btn-primary" data-tv-autofocus disabled={state === 'download'} onClick={go}>{state === 'download' ? 'Téléchargement…' : 'Mettre à jour'}</button>}
          <button className="btn btn-ghost" onClick={onClose}>{state === 'install' ? 'Fermer' : 'Plus tard'}</button>
        </div>
      </div>
    </div>
  );
}

// Vérification discrète au démarrage (une fois par jour au plus, sauf version déjà refusée)
export default function UpdateCheck() {
  const [upd, setUpd] = useState(null);
  useEffect(() => {
    const last = loadJSON('tvUpdateCheck', 0);
    if (Date.now() - last < 6 * 3600 * 1000) return;
    const t = setTimeout(async () => {
      try {
        const u = await checkUpdate();
        saveJSON('tvUpdateCheck', Date.now());
        if (u && u.newer && loadJSON('tvUpdateSkip', 0) !== u.latest) setUpd(u);
      } catch { /* hors ligne */ }
    }, 6000);
    return () => clearTimeout(t);
  }, []);
  if (!upd) return null;
  return <UpdatePanel upd={upd} onClose={() => { saveJSON('tvUpdateSkip', upd.latest); setUpd(null); }} />;
}
