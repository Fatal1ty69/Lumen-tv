// Lecture sur Android TV : la vidéo s'ouvre dans le lecteur natif (ExoPlayer), Lumen garde la progression
import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { liveRef, nextEpisodeRef } from '../lib/play.js';
import { pickVariant } from '../lib/live.js';
import { timeshiftUrl } from '../lib/epg.js';
import { loadJSON } from '../lib/store.js';
import { Spinner } from '../components/ui.jsx';
import { LumenTv } from './native.js';

function buildPlaylist(ref, { xtOf, catalog, settings }) {
  const xt = xtOf(ref.acc);
  if (ref.kind === 'live') {
    const keys = ref.list && ref.list.length ? ref.list : [ref.groupKey || ref.key];
    const refs = [];
    for (const k of keys) {
      const it = catalog.byKey.get(k);
      if (!it) continue;
      refs.push(it.kind === 'group' ? liveRef(pickVariant(it, settings.liveQuality), keys, it) : liveRef(it, keys));
    }
    let index = refs.findIndex((r) => r.key === ref.key || (ref.groupKey && r.groupKey === ref.groupKey));
    if (index < 0) { refs.unshift(ref); index = 0; }
    refs[index] = ref;
    const items = refs.map((r) => {
      const x = xtOf(r.acc);
      return { url: x.liveUrl(r.id, 'ts'), alt: x.liveUrl(r.id, 'm3u8'), title: r.title, sub: 'En direct', key: r.key };
    });
    return { live: true, refs, items, index };
  }
  if (ref.kind === 'replay') {
    const dur = (ref.end - ref.start) / 60000 + 2;
    return {
      live: false, refs: [ref], index: 0,
      items: [{ url: timeshiftUrl(xt, ref.id, ref.start, dur, catalog.serverTz, 'ts'), alt: timeshiftUrl(xt, ref.id, ref.start, dur, catalog.serverTz, 'm3u8'), title: ref.title, sub: ref.sub || 'Replay', key: ref.key }]
    };
  }
  if (ref.kind === 'movie') {
    const alt = ref.alts && ref.alts[0];
    return {
      live: false, refs: [ref], index: 0,
      items: [{ url: xt.movieUrl(ref.id, ref.ext), alt: alt ? xtOf(alt.acc).movieUrl(alt.id, alt.ext) : '', title: ref.title, sub: ref.sub || '', key: ref.key }]
    };
  }
  // Épisode : celui-ci puis la suite de la saison (et des suivantes)
  const refs = [ref];
  let cur = ref;
  for (let i = 0; i < 30 && cur.queue && cur.queue[0]; i++) {
    cur = nextEpisodeRef(cur, cur.queue[0]);
    refs.push(cur);
  }
  const items = refs.map((r) => ({ url: xt.episodeUrl(r.id, r.ext), alt: '', title: r.title, sub: r.sub, key: r.key }));
  return { live: false, refs, items, index: 0 };
}

export default function TvPlayer({ route }) {
  const app = useApp();
  const { back, saveProgress, settings, trakt } = app;
  const ref = route.ref;
  const [state, setState] = useState('playing');
  const [error, setError] = useState('');
  const started = useRef(false);
  const plRef = useRef(null);

  const launch = async () => {
    setState('playing');
    setError('');
    const pl = buildPlaylist(ref, app);
    plRef.current = pl;
    const credits = ref.seriesKey ? ((loadJSON('skips', {})[ref.seriesKey] || {}).credits || 40) : 40;
    if (trakt && trakt.connected && settings.traktScrobble !== false && (ref.kind === 'movie' || ref.kind === 'episode')) trakt.scrobble('start', ref, 0);
    let r;
    try {
      r = await LumenTv.play({
        items: pl.items, index: pl.index, live: pl.live, startAt: route.startAt || 0,
        autoNext: settings.autoNext !== false, credits, audioLang: 'fr', subLang: settings.subLang || 'fr'
      });
    } catch (e) {
      r = { error: e.message || String(e) };
    }
    // Progression de chaque épisode regardé
    for (const it of r.items || []) {
      const rr = pl.refs[it.index];
      if (!rr || !(rr.kind === 'movie' || rr.kind === 'episode') || !it.dur || it.dur < 60 || it.pos < 5) continue;
      const watched = !!it.ended || it.pos / it.dur >= 0.95;
      saveProgress(rr.key, { hidden: false, watched, pos: it.pos, dur: it.dur, ref: { ...rr, queue: (rr.queue || []).slice(0, 30) } });
      if (watched && trakt && trakt.connected && settings.traktScrobble !== false) trakt.scrobble('stop', rr, 100);
    }
    if (r.error) {
      setError(r.error);
      setState('error');
      return;
    }
    back();
  };

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    launch();
  }, []);

  const pl = plRef.current;
  const cur = pl ? pl.items[pl.index] : null;

  return (
    <div className="tv-player" data-tv-layer style={{ backgroundImage: ref.image ? `url("${ref.image}")` : undefined }}>
      <div className="tv-player-veil" />
      <div className="tv-player-body">
        <span className="kicker">{ref.kind === 'live' ? 'En direct' : ref.kind === 'episode' ? ref.sub : 'Film'}</span>
        <h1 className="big-title">{ref.title}</h1>
        {state === 'playing' && <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}><Spinner /><span className="muted">Lecture en cours…</span></div>}
        {state === 'error' && (
          <>
            <p className="err" style={{ fontSize: 18 }}>{error}</p>
            <div className="actions">
              <button className="btn btn-primary" data-tv-autofocus onClick={launch}>Réessayer</button>
              {cur && <button className="btn btn-ghost" onClick={() => LumenTv.openExternal({ url: cur.url, title: ref.title, video: true }).catch(() => {})}>Ouvrir avec une autre appli</button>}
              <button className="btn btn-ghost" onClick={back}>Retour</button>
            </div>
            <p className="muted" style={{ fontSize: 15, maxWidth: 720 }}>« Ouvrir avec une autre appli » propose VLC, Just Player ou MX Player s'ils sont installés sur la Shield : ils lisent certains formats que le lecteur intégré refuse.</p>
          </>
        )}
      </div>
    </div>
  );
}
