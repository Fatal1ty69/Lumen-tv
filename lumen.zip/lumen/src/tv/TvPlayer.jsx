// Lecture sur Android TV : la vidéo s'ouvre dans le lecteur natif (ExoPlayer), Lumen garde la progression
import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { liveRef, nextEpisodeRef, replayRef } from '../lib/play.js';
import { getEpg } from '../lib/epg.js';
import { pickVariant } from '../lib/live.js';
import { timeshiftUrl } from '../lib/epg.js';
import { loadJSON, saveJSON } from '../lib/store.js';
import { Spinner } from '../components/ui.jsx';
import { LumenTv } from './native.js';

const enc = encodeURIComponent;

// ---------- Direct : toutes les chaînes et leurs groupes, envoyés une fois au lecteur ----------

let sent = { version: null };
let ids = new WeakMap();
let idSeq = 0;

function catalogId(catalog) {
  if (!ids.has(catalog)) ids.set(catalog, ++idSeq);
  return ids.get(catalog);
}

export function buildLiveData(catalog, xtOf, settings, favorites) {
  const accs = [];
  const bases = [];
  const epg = [];
  const accIndex = (acc) => {
    const k = acc || '';
    let i = accs.indexOf(k);
    if (i < 0) {
      const x = xtOf(acc);
      i = accs.push(k) - 1;
      if (x && x.kind === 'm3u') { bases.push(''); epg.push(''); }
      else {
        bases.push(`${x.server}/live/${enc(x.username)}/${enc(x.password)}/`);
        epg.push(`${x.server}/player_api.php?username=${enc(x.username)}&password=${enc(x.password)}&action=get_short_epg&limit=4&stream_id=`);
      }
    }
    return i;
  };
  const channels = [];
  const at = new Map();
  for (const g of catalog.liveGroups) {
    const ch = pickVariant(g, settings.liveQuality);
    if (!ch) continue;
    at.set(g.key, channels.length);
    const x = xtOf(ch.acc);
    // Playlist M3U : la chaîne porte son adresse complète (pas de base identifiant/mot de passe)
    const url = x && x.kind === 'm3u' ? x.liveUrl(ch.id) : '';
    channels.push({ id: String(ch.id), n: g.name, num: String(g.num || ''), logo: g.logo || '', a: accIndex(ch.acc), key: g.key, arch: !!ch.archive, ...(url ? { url } : {}) });
  }
  const groups = [];
  const fav = catalog.liveGroups.filter((g) => favorites[g.key] && at.has(g.key)).map((g) => at.get(g.key));
  if (fav.length) groups.push({ name: 'Favoris', ch: fav, id: '__fav' });
  for (const c of catalog.liveCats) {
    const l = catalog.liveGroups.filter((g) => g.cat === c.id && at.has(g.key)).map((g) => at.get(g.key));
    if (l.length) groups.push({ name: c.name, ch: l, id: c.id });
  }
  const version = [catalogId(catalog), settings.liveQuality, fav.join('.'), JSON.stringify(loadJSON('livePick', {}))].join(':');
  return { version, bases, epg, channels, groups };
}

async function ensureLiveData(app) {
  const d = buildLiveData(app.catalog, app.xtOf, app.settings, app.favorites);
  if (sent.version !== d.version) {
    await LumenTv.setLiveData(d);
    sent = { version: d.version, data: d };
  }
  return sent.data;
}

// ---------- Films, séries, replay ----------

function vodPlaylist(ref, { xtOf, catalog }) {
  const xt = xtOf(ref.acc);
  const skips = loadJSON('skips', {});
  const item = (r, url, alt = '') => ({
    url, alt, title: r.title, sub: r.sub || '', key: r.key, kind: r.kind,
    introEnd: r.seriesKey ? ((skips[r.seriesKey] || {}).intro || 0) : 0,
    tmdbId: r.kind === 'movie' ? r.tmdbId || 0 : 0,
    parentTmdbId: r.kind === 'episode' ? r.tmdbId || 0 : 0,
    season: r.season || 0, episode: r.num || 0, query: r.title
  });
  if (ref.kind === 'replay') {
    const dur = (ref.end - ref.start) / 60000 + 2;
    return { refs: [ref], items: [item(ref, timeshiftUrl(xt, ref.id, ref.start, dur, catalog.serverTz, 'ts'), timeshiftUrl(xt, ref.id, ref.start, dur, catalog.serverTz, 'm3u8'))] };
  }
  if (ref.kind === 'movie') {
    const alt = ref.alts && ref.alts[0];
    return { refs: [ref], items: [item(ref, xt.movieUrl(ref.id, ref.ext), alt ? xtOf(alt.acc).movieUrl(alt.id, alt.ext) : '')] };
  }
  // Épisode : celui-ci puis la suite
  const refs = [ref];
  let cur = ref;
  for (let i = 0; i < 30 && cur.queue && cur.queue[0]; i++) {
    cur = nextEpisodeRef(cur, cur.queue[0]);
    refs.push(cur);
  }
  return { refs, items: refs.map((r) => item(r, xt.episodeUrl(r.id, r.ext))) };
}

export default function TvPlayer({ route }) {
  const app = useApp();
  const { back, saveProgress, settings, trakt } = app;
  const ref = route.ref;
  const [state, setState] = useState('playing');
  const [error, setError] = useState('');
  const [extUrl, setExtUrl] = useState('');
  const started = useRef(false);

  const langKey = ref.seriesKey || '_';
  const langs = () => {
    const m = loadJSON('tvLangs', {});
    return m[langKey] || m._ || { audioLang: 'fr', subLang: settings.subLang || 'fr', subOn: false };
  };
  const saveLangs = (r) => {
    if (r.audioLang === undefined) return;
    const m = loadJSON('tvLangs', {});
    const v = { audioLang: r.audioLang, subLang: r.subLang, subOn: !!r.subOn };
    m[langKey] = v;
    m._ = v;
    saveJSON('tvLangs', m);
  };

  const launchLive = async () => {
    const d = await ensureLiveData(app);
    // Groupe d'où l'on vient : Favoris si la liste en vient, sinon le groupe de la chaîne
    const chIndex = d.channels.findIndex((c) => c.key === (ref.groupKey || ref.key));
    const g0 = app.catalog.byKey.get(ref.groupKey || ref.key);
    const favList = ref.list && d.groups[0] && d.groups[0].id === '__fav' && ref.list.length === d.groups[0].ch.length;
    let group = favList ? 0 : d.groups.findIndex((g) => g0 && g.id === g0.cat);
    if (group < 0) group = Math.max(0, d.groups.findIndex((g) => g.ch.includes(chIndex)));
    const pos = Math.max(0, d.groups[group] ? d.groups[group].ch.indexOf(chIndex) : 0);
    const r = await LumenTv.play({
      mode: 'live', group, pos, prevKey: loadJSON('prevLive', ''),
      reuse: !!route.reuse, keepPreview: !!route.keepPreview, startKey: ref.groupKey || ref.key,
      liveExt: loadJSON('liveExt', {})[ref.acc || ''] || 'ts', resize: loadJSON('tvResize', 0), ...langs()
    });
    if (r.channelKey) {
      saveJSON('lastLive', r.channelKey);
      // Chaînes récentes (rangée de l'accueil)
      saveJSON('recentLive', [r.channelKey, ...loadJSON('recentLive', []).filter((k) => k !== r.channelKey)].slice(0, 12));
    }
    // Favoris modifiés depuis la liste des chaînes du lecteur
    for (const k of r.favAdd || []) { const g = app.catalog.byKey.get(k); if (g && !app.favorites[k]) app.toggleFav({ key: k, kind: 'group', id: k, title: g.name, poster: g.logo }); }
    for (const k of r.favRemove || []) { const g = app.catalog.byKey.get(k); if (g && app.favorites[k]) app.toggleFav({ key: k, kind: 'group', id: k, title: g.name, poster: g.logo }); }
    if (r.prevKey) saveJSON('prevLive', r.prevKey);
    if (r.liveExt) { const m = loadJSON('liveExt', {}); m[ref.acc || ''] = r.liveExt; saveJSON('liveExt', m); }
    if (r.resize !== undefined) saveJSON('tvResize', r.resize);
    saveLangs(r);
    return r;
  };

  const launchVod = async () => {
    const pl = vodPlaylist(ref, app);
    setExtUrl(pl.items[0] ? pl.items[0].url : '');
    const credits = ref.seriesKey ? ((loadJSON('skips', {})[ref.seriesKey] || {}).credits || 40) : 40;
    if (trakt && trakt.connected && settings.traktScrobble !== false && (ref.kind === 'movie' || ref.kind === 'episode')) trakt.scrobble('start', ref, 0);
    const r = await LumenTv.play({
      mode: 'vod', items: pl.items, index: 0, startAt: route.startAt || 0,
      autoNext: settings.autoNext !== false, autoSkipIntro: !!settings.autoSkipIntro, credits,
      os: settings.osKey ? { key: settings.osKey, user: settings.osUser || '', pass: settings.osPass || '' } : null,
      resize: loadJSON('tvResize', 0), ...langs()
    });
    // Progression de chaque épisode regardé
    for (const it of r.items || []) {
      const rr = pl.refs[it.index];
      if (!rr || !(rr.kind === 'movie' || rr.kind === 'episode') || !it.dur || it.dur < 60 || it.pos < 5) continue;
      const watched = !!it.ended || it.pos / it.dur >= 0.9;
      saveProgress(rr.key, { hidden: false, watched, pos: it.pos, dur: it.dur, ref: { ...rr, queue: (rr.queue || []).slice(0, 30) } });
      if (trakt && trakt.connected && settings.traktScrobble !== false) trakt.scrobble(watched ? 'stop' : 'pause', rr, watched ? 100 : (it.pos / it.dur) * 100);
    }
    // Fin d'intro apprise (premier « Passer l'intro » sur une série)
    if (r.intro) {
      const all = loadJSON('skips', {});
      for (const [i, sec] of Object.entries(r.intro)) {
        const rr = pl.refs[Number(i)];
        if (rr && rr.seriesKey && !(all[rr.seriesKey] || {}).intro) all[rr.seriesKey] = { ...(all[rr.seriesKey] || {}), intro: Math.round(sec) };
      }
      saveJSON('skips', all);
    }
    if (r.resize !== undefined) saveJSON('tvResize', r.resize);
    saveLangs(r);
    return r;
  };

  const launch = async () => {
    setState('playing');
    setError('');
    let r;
    try {
      r = ref.kind === 'live' ? await launchLive() : await launchVod();
    } catch (e) {
      r = { error: e.message || String(e) };
    }
    // Temps passé sur chaque chaîne (récap « Ton année », dans les Réglages)
    if (r.liveSeconds) {
      const y = String(new Date().getFullYear());
      const st = loadJSON('liveStats', {});
      const cur = { ...(st[y] || {}) };
      for (const [k, sec] of Object.entries(r.liveSeconds)) cur[k] = (cur[k] || 0) + Number(sec || 0);
      saveJSON('liveStats', { ...st, [y]: cur });
    }
    // Rappel validé avec OK pendant un film ou une série : on ouvre la chaîne
    if (r.gotoKey) {
      const g = app.catalog.byKey.get(r.gotoKey);
      const ch = g && (g.kind === 'group' ? pickVariant(g, settings.liveQuality) : g);
      if (ch) { app.replace({ name: 'player', ref: liveRef(ch, app.catalog.liveGroups.filter((x) => x.cat === g.cat).map((x) => x.key), g.kind === 'group' ? g : null) }); return; }
    }
    if (r.error) {
      setError(r.error);
      setState('error');
      return;
    }
    // Depuis le menu du direct : reprendre le programme depuis le début, ou choisir un programme passé
    if (r.action === 'startover' && r.channelKey) {
      const g = app.catalog.byKey.get(r.channelKey);
      const ch = g && pickVariant(g, settings.liveQuality);
      if (ch) {
        const progs = await getEpg(app.xtOf(ch.acc), ch).catch(() => []);
        const now = Date.now();
        const cur = progs.find((p) => p.start <= now && p.end > now);
        if (cur) { app.replace({ name: 'player', ref: replayRef(ch, cur, g) }); return; }
      }
      setError('Le début de ce programme n\'est pas disponible sur le serveur.');
      setState('error');
      return;
    }
    back();
    if (r.channelKey) setTimeout(() => window.dispatchEvent(new CustomEvent('lumen:live-return', { detail: { key: r.channelKey } })), 80);
    if (r.action === 'replays' && r.channelKey) setTimeout(() => window.dispatchEvent(new CustomEvent('lumen:replays', { detail: { key: r.channelKey } })), 160);
  };

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    launch();
  }, []);

  return (
    <div className="tv-player" data-tv-layer style={{ backgroundImage: ref.image ? `url("${ref.image}")` : undefined }}>
      <div className="tv-player-veil" />
      <div className="tv-player-body">
        <span className="kicker">{ref.kind === 'live' ? 'En direct' : ref.kind === 'episode' ? ref.sub : 'Film'}</span>
        <h1 className="big-title">{ref.title}</h1>
        {state === 'playing' && <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}><Spinner /><span className="muted">Lecture en cours…</span></div>}
        {state === 'error' && (
          <>
            <p className="err" style={{ fontSize: 18 }}>{error}</p>
            <div className="actions">
              <button className="btn btn-primary" data-tv-autofocus onClick={launch}>Réessayer</button>
              {extUrl && <button className="btn btn-ghost" onClick={() => LumenTv.openExternal({ url: extUrl, title: ref.title, video: true }).catch(() => {})}>Ouvrir avec une autre appli</button>}
              <button className="btn btn-ghost" onClick={back}>Retour</button>
            </div>
            <p className="muted" style={{ fontSize: 15, maxWidth: 720 }}>« Ouvrir avec une autre appli » propose VLC, Just Player ou MX Player s'ils sont installés sur la Shield : ils lisent certains formats que le lecteur intégré refuse.</p>
          </>
        )}
      </div>
    </div>
  );
}
