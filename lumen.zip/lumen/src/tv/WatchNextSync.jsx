// Android TV : la rangée « Continuer à regarder » de l'écran d'accueil de la Shield suit celle de Lumen,
// et un clic dessus ouvre Lumen directement sur le bon épisode, à la bonne minute.
import { useEffect } from 'react';
import { App as CapApp } from '@capacitor/app';
import { useApp } from '../lib/app.jsx';
import { useResume } from '../lib/upnext.js';
import { loadJSON, saveJSON } from '../lib/store.js';
import { LumenTv } from './native.js';

let launchHandled = false;

export default function WatchNextSync() {
  const { navigate, catalog } = useApp();
  const resume = useResume(10);

  // Mise à jour de la rangée (quelques secondes après le dernier changement)
  const sig = resume.map((p) => p.ref.key + ':' + Math.round((p.pos || 0) / 30)).join(',');
  useEffect(() => {
    const t = setTimeout(() => {
      const items = resume.slice(0, 8).map((p) => ({
        key: p.ref.key, kind: p.ref.kind, title: p.ref.title, sub: p.ref.sub || '',
        image: p.ref.image || p.ref.poster || '', pos: Math.round(p.pos || 0), dur: Math.round(p.dur || 0),
        t: p.t || Date.now(), next: !!p.next
      }));
      saveJSON('watchNextRefs', Object.fromEntries(resume.slice(0, 8).map((p) => [p.ref.key, { ref: p.ref, pos: p.next ? 0 : p.pos || 0 }])));
      LumenTv.syncWatchNext({ items }).catch(() => {});
    }, 4000);
    return () => clearTimeout(t);
  }, [sig]);

  // Ouverture depuis l'écran d'accueil : lumen://play?key=…
  useEffect(() => {
    const open = (url) => {
      const m = String(url || '').match(/^lumen:\/\/play\?key=([^&]+)/);
      if (!m) return;
      const e = loadJSON('watchNextRefs', {})[decodeURIComponent(m[1])];
      if (e && e.ref) navigate({ name: 'player', ref: e.ref, startAt: e.pos || 0 });
    };
    if (!launchHandled) {
      launchHandled = true;
      CapApp.getLaunchUrl().then((r) => r && open(r.url)).catch(() => {});
    }
    let sub = null;
    CapApp.addListener('appUrlOpen', (ev) => open(ev.url)).then((h) => { sub = h; });
    return () => { if (sub) sub.remove(); };
  }, [catalog]);

  return null;
}
