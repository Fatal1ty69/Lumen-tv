// Réception des réglages sur la TV : depuis un téléphone (page web servie par la TV) ou depuis Lumen PC
import React, { useEffect, useState } from 'react';
import qrcode from 'qrcode-generator';
import { LumenTv, native } from './native.js';
import { loadJSON, saveJSON } from '../lib/store.js';
import { normalizeServer } from '../lib/xtream.js';
import { MODELS, normalizeMac, normalizeStalkerPortal } from '../lib/stalker.js';
import { handleTvSync } from '../lib/sync.js';

// Réglages propres au PC qu'on ne recopie pas sur la TV
const PC_ONLY = ['mpvPath', 'playerPath', 'engine'];

export function applyConfig(d) {
  if (d.kind === 'clone' && d.storage) {
    const tvSettings = loadJSON('settings', {});
    for (const [k, v] of Object.entries(d.storage)) {
      if (!k.startsWith('lumen:') || typeof v !== 'string') continue;
      // Les données des profils déjà présentes sur la TV ne sont pas écrasées : la synchro maison les fusionne ensuite
      if (['lumen:meta', 'lumen:profile', 'lumen:syncState', 'lumen:tvLink'].includes(k)) continue;
      if ((k.startsWith('lumen:p:') || k === 'lumen:profiles') && localStorage.getItem(k) != null) continue;
      if (k === 'lumen:settings') {
        try {
          const s = JSON.parse(v);
          for (const p of PC_ONLY) { if (p in tvSettings) s[p] = tvSettings[p]; else delete s[p]; }
          localStorage.setItem(k, JSON.stringify(s));
        } catch { /* réglages illisibles */ }
        continue;
      }
      try { localStorage.setItem(k, v); } catch { /* quota */ }
    }
  } else if (d.account) {
    const a = d.account;
    const id = 'acc' + Date.now().toString(36);
    const accounts = loadJSON('accounts', []);
    if (a.kind === 'm3u') {
      // Playlist M3U (direct) : on l'ajoute à côté des serveurs existants, sans changer le serveur principal
      let url = String(a.server || '').trim();
      if (url && !/^https?:\/\//i.test(url)) url = 'http://' + url;
      accounts.push({ id, kind: 'm3u', name: (a.name || '').trim() || 'Playlist M3U', server: url, epgUrl: (a.epgUrl || '').trim(), ua: (a.ua || '').trim() });
      saveJSON('accounts', accounts);
      if (accounts.length === 1) saveJSON('activeId', id);
    } else if (a.kind === 'stalker') {
      const portal = normalizeStalkerPortal(a.portal || a.server || '');
      const mac = normalizeMac(a.mac);
      const model = MODELS[a.model] ? a.model : 'MAG254';
      // Le spread conserve aussi les futures options MAG sans les rabattre sur le
      // schéma Xtream. Les alias historiques restent disponibles au client commun.
      accounts.push({
        ...a, id, kind: 'stalker', name: String(a.name || '').trim() || 'Stalker / MAG',
        server: portal, portal, mac, model,
        serial: String(a.serial || a.sn || '').trim(), sn: String(a.sn || a.serial || '').trim(),
        deviceId: String(a.deviceId || a.device || '').trim(), device: String(a.device || a.deviceId || '').trim(),
        deviceId2: String(a.deviceId2 || a.device2 || '').trim(), device2: String(a.device2 || a.deviceId2 || '').trim(),
        signature: String(a.signature || a.sig || '').trim(), sig: String(a.sig || a.signature || '').trim(),
        epgUrl: String(a.epgUrl || '').trim(), tz: String(a.tz || '').trim()
      });
      saveJSON('accounts', accounts);
      saveJSON('activeId', id);
    } else {
      accounts.push({ id, name: (a.name || '').trim() || 'Serveur principal', server: normalizeServer(a.server || ''), username: (a.username || '').trim(), password: (a.password || '').trim() });
      saveJSON('accounts', accounts);
      saveJSON('activeId', id);
    }
    const s = loadJSON('settings', {});
    if (d.tmdbKey) s.tmdbKey = d.tmdbKey;
    if (d.omdbKey) s.omdbKey = d.omdbKey;
    saveJSON('settings', s);
  }
  saveJSON('tvReceived', Date.now());
  location.reload();
}

// Démarre l'écoute dès l'ouverture de l'appli sur la TV
let infoPromise = null;
export function startReceiver() {
  if (!native) return Promise.resolve(null);
  if (!infoPromise) {
    LumenTv.addListener('config', applyConfig);
    LumenTv.addListener('syncRequest', (e) => {
      let out;
      try { out = handleTvSync(e.body); } catch (err) { out = { ok: false, error: err.message || String(err) }; }
      LumenTv.syncReply({ id: e.id, body: JSON.stringify(out) }).catch(() => {});
    });
    infoPromise = LumenTv.startServer().catch(() => null);
  }
  return infoPromise;
}

export function useReceiverInfo() {
  const [info, setInfo] = useState(null);
  useEffect(() => {
    let off = false;
    if (native) startReceiver().then((i) => !off && setInfo(i));
    else setInfo({ ip: '192.168.1.42', port: 47820, code: '1234', demo: true });
    return () => { off = true; };
  }, []);
  return info;
}

export default function TvReceive({ compact = false }) {
  const info = useReceiverInfo();
  if (!info) return <p className="muted">Préparation…</p>;
  if (!info.ip) return <p className="err">La TV n'est pas connectée au réseau : vérifie le Wi-Fi ou le câble Ethernet de la Shield.</p>;
  const url = `http://${info.ip}:${info.port}`;
  const qr = qrcode(0, 'M');
  qr.addData(url);
  qr.make();
  return (
    <div className={'tv-recv' + (compact ? ' compact' : '')}>
      <div className="tv-recv-qr" dangerouslySetInnerHTML={{ __html: qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true }) }} />
      <div className="tv-recv-tx">
        <div className="tv-recv-step"><b>Avec ton téléphone</b><span>Scanne le QR code (ou ouvre <code>{url}</code>) et saisis ton serveur Xtream, Stalker/MAG ou ta playlist M3U. Pratique pour coller une longue adresse sans la télécommande.</span></div>
        <div className="tv-recv-step"><b>Ou depuis Lumen sur ton PC</b><span>Réglages, carte « Envoyer vers ma TV », puis indique l'adresse <code>{info.ip}</code>. Tout est recopié, puis le PC reste synchronisé avec la TV tout seul.</span></div>
        <div className="tv-recv-code"><span>Code à saisir</span><b>{info.code}</b></div>
      </div>
    </div>
  );
}
