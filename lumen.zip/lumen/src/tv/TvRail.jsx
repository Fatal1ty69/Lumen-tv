// v43 : menu latéral de la TV, façon TiviMate.
// Replié : une colonne d'icônes, la rubrique en cours marquée d'un trait ambre.
// Déplié (dès que le focus y entre) : les libellés apparaissent par-dessus le contenu, assombri.
// On y entre avec la flèche gauche au début d'une rangée, ou avec Retour. OK ouvre la rubrique
// et renvoie le focus dans le contenu ; droite revient là où on était.
import React, { useEffect, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { getProfiles, activeProfile } from '../lib/store.js';
import { switchProfile } from '../components/ProfilePicker.jsx';
import { focusContentSoon } from './spatial.js';

const P = {
  home: <><path d="M3 11.5 12 4l9 7.5" /><path d="M5.5 10v9.5h13V10" /></>,
  live: <><rect x="3" y="6" width="18" height="13" rx="2" /><path d="M8 3l4 3 4-3" /></>,
  film: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4" /></>,
  series: <><rect x="3" y="5" width="18" height="12" rx="2" /><path d="M8 21h8M12 17v4" /></>,
  discover: <><circle cx="12" cy="12" r="9" /><path d="m15.5 8.5-2 5-5 2 2-5z" /></>,
  mine: <path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" />,
  search: <><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4.5 4.5" /></>,
  gear: <><circle cx="12" cy="12" r="3" /><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1" /></>
};

const ITEMS = [
  { id: 'home', label: 'Accueil', route: { name: 'home' } },
  { id: 'live', label: 'Direct', route: { name: 'live' } },
  { id: 'film', label: 'Films', route: { name: 'browse', kind: 'movie' } },
  { id: 'series', label: 'Séries', route: { name: 'browse', kind: 'series' } },
  { id: 'discover', label: 'Découvrir', route: { name: 'decouvrir' }, also: ['vitrine'] },
  { id: 'mine', label: 'Mon espace', route: { name: 'monespace' }, also: ['mylist', 'messeries', 'agenda'] },
  { id: 'search', label: 'Recherche', route: { name: 'search', q: '' }, sep: true },
  { id: 'gear', label: 'Réglages', route: { name: 'settings' } }
];

function isOn(it, base) {
  if (it.route.name === 'browse') return base.name === 'browse' && base.kind === it.route.kind;
  return base.name === it.route.name || !!(it.also && it.also.includes(base.name));
}

function Clock() {
  const [d, setD] = useState(() => new Date());
  useEffect(() => { const t = setInterval(() => setD(new Date()), 20000); return () => clearInterval(t); }, []);
  return <div className="tr-clock">{String(d.getHours()).padStart(2, '0')}:{String(d.getMinutes()).padStart(2, '0')}</div>;
}

export default function TvRail({ base }) {
  const { goRoot } = useApp();
  const [open, setOpen] = useState(false);
  const me = getProfiles().find((p) => p.id === activeProfile()) || { name: 'Alex', color: '#F2A93B' };
  const go = (it) => {
    if (!isOn(it, base)) goRoot(it.route);
    focusContentSoon(!isOn(it, base));
  };
  return (
    <>
      <nav className={'tv-rail' + (open ? ' open' : '')} aria-label="Menu principal"
        onFocus={() => setOpen(true)}
        onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setOpen(false); }}>
        <div className="tr-logo" aria-hidden="true">{open ? 'LUMEN' : 'L'}</div>
        <button className="tr-item tr-profile" onClick={switchProfile} aria-label={'Profil ' + me.name + ', changer de profil'}>
          <span className="tr-av" style={{ background: me.color }}>{(me.name || 'A')[0].toUpperCase()}</span>
          <span className="tr-lab"><b>{me.name}</b><small>Changer de profil</small></span>
        </button>
        <div className="tr-list">
          {ITEMS.map((it) => (
            <React.Fragment key={it.id}>
              {it.sep && <div className="tr-sep" />}
              <button className={'tr-item' + (isOn(it, base) ? ' on' : '')} data-rail-on={isOn(it, base) ? '1' : undefined}
                onClick={() => go(it)} aria-label={it.label} aria-current={isOn(it, base) ? 'page' : undefined}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{P[it.id]}</svg>
                <span className="tr-lab">{it.label}</span>
              </button>
            </React.Fragment>
          ))}
        </div>
        <Clock />
      </nav>
      {open && <div className="tv-rail-dim" aria-hidden="true" />}
    </>
  );
}
