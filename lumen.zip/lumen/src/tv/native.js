// Lumen TV : détection d'Android TV et pont vers le code natif.
// Sur la TV, window.lumen imite l'API du PC (requêtes réseau sans CORS, etc.) pour que le reste de l'appli marche tel quel.
import { Capacitor, registerPlugin } from '@capacitor/core';

export const native = Capacitor.isNativePlatform();
// ?tv=1 dans le navigateur : interface TV sans le natif (pour tester)
export const isTV = native || /[?&]tv=1/.test(location.search);

export const LumenTv = native ? registerPlugin('LumenTv') : null;

const UA = 'VLC/3.0.20 LibVLC/3.0.20';

if (native) {
  const req = async (opts) => {
    try {
      return await LumenTv.http(opts);
    } catch (e) {
      return { ok: false, error: e.message || String(e) };
    }
  };
  window.lumen = {
    tv: true,
    httpGet: (url, timeout) => req({ url, timeout: timeout || 30000, headers: { 'User-Agent': UA } }),
    httpReq: ({ url, method = 'GET', headers = {}, body = null, timeout = 30000 }) => req({ url, method, headers, body, timeout }),
    openExternal: (url) => LumenTv.openExternal({ url }).catch(() => {}),
    externalPlay: ({ url, title }) => LumenTv.openExternal({ url, title, video: true }).then(() => ({ ok: true }), (e) => ({ ok: false, error: e.message })),
    toggleFullscreen: () => {},
    onFullscreen: () => () => {},
    mpvFind: async () => null,
    pickPlayer: async () => null
  };
}

if (isTV) document.documentElement.classList.add('tv');

// La Shield affiche la page en 960 px de large (écran 1080p, densité 2) : on fixe une largeur de 1280 px
// pour garder la mise en page du PC avec des textes lisibles à 3 mètres
if (native) {
  const m = document.querySelector('meta[name="viewport"]');
  if (m) m.setAttribute('content', 'width=1280, user-scalable=no');
}
