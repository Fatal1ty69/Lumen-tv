import { isTV, native } from './tv/native.js';
import { installSpatialNav } from './tv/spatial.js';
import { startReceiver } from './tv/TvReceive.jsx';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { AppProvider } from './lib/app.jsx';
import ProfilePicker from './components/ProfilePicker.jsx';
import { getProfiles, setActiveProfile } from './lib/store.js';
import App from './App.jsx';
import { tvLink, syncNow, startSyncLoop } from './lib/sync.js';
import '@fontsource/anton/400.css';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import './styles.css';

if (isTV) installSpatialNav();
if (native) startReceiver();

// Le choix du profil se fait avant de charger l'appli : chaque profil a ses propres données
// Sur le PC : on récupère d'abord ce qui a été fait sur la TV (4 s au plus), avant l'accueil
const pcSync = !native && !!(window.lumen && !window.lumen.tv && tvLink());
const firstSync = pcSync ? Promise.race([syncNow('démarrage'), new Promise((r) => setTimeout(r, 4000))]) : Promise.resolve();
if (pcSync || (!native && window.lumen)) firstSync.then(startSyncLoop);

function Root() {
  const [ready, setReady] = React.useState(!pcSync);
  React.useEffect(() => { if (!ready) firstSync.then(() => setReady(true)); }, []);
  const [picked, setPicked] = React.useState(() => {
    try { return getProfiles().length < 2 || sessionStorage.getItem('lumen:picked') === '1'; } catch { return true; }
  });
  if (!ready) return <div className="sync-boot"><span className="spinner" /><p>Synchronisation avec la TV…</p></div>;
  if (!picked) {
    return <ProfilePicker onPick={(id) => {
      setActiveProfile(id);
      try { sessionStorage.setItem('lumen:picked', '1'); } catch { /* rien */ }
      window.__skipIntro = true;
      setPicked(true);
    }} />;
  }
  return (
    <AppProvider>
      <App />
    </AppProvider>
  );
}

createRoot(document.getElementById('root')).render(<Root />);
