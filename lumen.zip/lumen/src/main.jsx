import { isTV, native } from './tv/native.js';
import { installSpatialNav } from './tv/spatial.js';
import { startReceiver } from './tv/TvReceive.jsx';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { AppProvider } from './lib/app.jsx';
import App from './App.jsx';
import '@fontsource/anton/400.css';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import './styles.css';

if (isTV) installSpatialNav();
if (native) startReceiver();

createRoot(document.getElementById('root')).render(
  <AppProvider>
    <App />
  </AppProvider>
);
