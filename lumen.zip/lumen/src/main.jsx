import { isTV, native } from './tv/native.js';
import { installSpatialNav } from './tv/spatial.js';
import { startReceiver } from './tv/TvReceive.jsx';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { AppProvider } from './lib/app.jsx';
import ProfilePicker from './components/ProfilePicker.jsx';
import { getProfiles, setActiveProfile } from './lib/store.js';
import App from './App.jsx';
import { tvLink, syncNow, startSyncLoop } from './lib/sync.js';
import '@fontsource/anton/400.css';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import './styles.css';

if (isTV) installSpatialNav();
if (native) startReceiver();

// Synchro maison en arrière-plan : on n'attend jamais pour afficher l'accueil (le catalogue vient du cache).
// Quand la synchro aboutit, la progression, les favoris et les rappels se mettent à jour en place
// (évènement « lumen:storage » écouté dans app.jsx). Démarrage perçu instantané, même si la TV est lente ou absente.
if (!native && window.lumen && !window.lumen.tv) {
  startSyncLoop();
  if (tvLink()) syncNow('démarrage');
}

// Le choix du profil se fait avant de charger l'appli : chaque profil a ses propres données
function Root() {
  const [picked, setPicked] = React.useState(() => {
    try { return getProfiles().length < 2 || sessionStorage.getItem('lumen:picked') === '1'; } catch { return true; }
  });
  if (!picked) {
    return <ProfilePicker onPick={(id) => {
      setActiveProfile(id);
      try { sessionStorage.setItem('lumen:picked', '1'); } catch { /* rien */ }
      window.__skipIntro = true;
      setPicked(true);
    }} />;
  }
  return (
    <AppProvider>
      <App />
    </AppProvider>
  );
}

createRoot(document.getElementById('root')).render(<Root />);
