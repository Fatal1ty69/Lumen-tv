import React, { useEffect, useState } from 'react';
import { useApp } from './lib/app.jsx';
import Header from './components/Header.jsx';
import { Spinner } from './components/ui.jsx';
import Login from './screens/Login.jsx';
import Home from './screens/Home.jsx';
import Browse from './screens/Browse.jsx';
import Vitrine from './screens/Vitrine.jsx';
import Fiche from './screens/Fiche.jsx';
import Live from './screens/Live.jsx';
import Search from './screens/Search.jsx';
import MyList from './screens/MyList.jsx';
import Settings from './screens/Settings.jsx';
import Player from './screens/Player.jsx';
import MpvPlayer from './screens/MpvPlayer.jsx';
import Agenda from './screens/Agenda.jsx';
import Decouvrir from './screens/Decouvrir.jsx';
import MesSeries from './screens/MesSeries.jsx';
import { ReminderCenter } from './lib/reminders.jsx';
import { loadJSON } from './lib/store.js';
import { native, isTV } from './tv/native.js';
import { focusTop } from './tv/spatial.js';
import QuickMenu from './tv/QuickMenu.jsx';
import WatchNextSync from './tv/WatchNextSync.jsx';
import TvPlayer from './tv/TvPlayer.jsx';
import { liveRef } from './lib/play.js';
import { pickVariant } from './lib/live.js';
import UpdateCheck from './tv/UpdateCheck.jsx';
import { App as CapApp } from '@capacitor/app';

// Intro du logo, une fois par lancement
function Intro({ onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 3100); return () => clearTimeout(t); }, []);
  return (
    <div className="intro" onClick={onDone} role="presentation">
      <div className="beam" />
      <div className="word" aria-label="Lumen">
        {'LUMEN'.split('').map((c, i) => <span key={i} style={{ animationDelay: 0.25 + i * 0.12 + 's' }}>{c}</span>)}
      </div>
      <div className="intro-tag">Toute ta télé, en grand</div>
    </div>
  );
}

const OVERLAYS = new Set(['fiche', 'player']);

const SCREENS = { home: Home, browse: Browse, vitrine: Vitrine, live: Live, search: Search, mylist: MyList, settings: Settings, agenda: Agenda, decouvrir: Decouvrir, messeries: MesSeries };

function AppBody() {
  const { account, catalog, catState, refreshCatalog, stack, route, back, settings, mpvExe, navigate, goRoot } = useApp();

  // TV : démarrage direct sur la dernière chaîne regardée
  const startedLive = React.useRef(false);
  useEffect(() => {
    if (!native || !catalog || startedLive.current) return;
    startedLive.current = true;
    if (!settings.tvStartLive) return;
    const g = catalog.byKey.get(loadJSON('lastLive', ''));
    if (!g || g.kind !== 'group') return;
    const list = catalog.liveGroups.filter((x) => x.cat === g.cat).map((x) => x.key);
    const ch = pickVariant(g, settings.liveQuality);
    if (ch) navigate({ name: 'player', ref: liveRef(ch, list, g) });
  }, [catalog]);
  const [solid, setSolid] = useState(false);

  // Touche Retour, TV : fenêtre ouverte > écran du dessus > haut de page > accueil > « Quitter Lumen ? »
  const [exitAsk, setExitAsk] = useState(false);
  const tvBack = React.useCallback(() => {
    if (document.querySelector('.intro')) return;
    if (!account) { if (native) CapApp.minimizeApp(); return; }
    if (!window.dispatchEvent(new CustomEvent('tv-back', { cancelable: true }))) return;
    if (exitAsk) { setExitAsk(false); return; }
    if (stack.length > 1) { back(); return; }
    const sc = document.querySelector('.scroll');
    if (sc && sc.scrollTop > 150) { focusTop(); return; }
    const base0 = stack[0] || { name: 'home' };
    if (base0.name !== 'home') { goRoot({ name: 'home' }); return; }
    setExitAsk(true);
  }, [exitAsk, stack, back, goRoot, account]);

  useEffect(() => {
    const onKey = (e) => {
      if (isTV && (e.key === 'Escape' || e.key === 'BrowserBack' || e.key === 'GoBack')) { e.preventDefault(); tvBack(); return; }
      if (e.key === 'Escape' && route.name !== 'player' && stack.length > 1) back();
      if (e.key === 'BrowserBack' || (e.altKey && e.key === 'ArrowLeft')) back();
    };
    window.addEventListener('keydown', onKey);
    let sub = null;
    if (native) CapApp.addListener('backButton', tvBack).then((h) => { sub = h; });
    return () => { window.removeEventListener('keydown', onKey); if (sub) sub.remove(); };
  }, [route, stack.length, back, tvBack]);

  if (!account) return <Login />;

  if (!catalog) {
    if (catState.error) {
      return (
        <div className="loading-screen">
          <div className="logo">LUMEN</div>
          <p className="err" style={{ maxWidth: 520, textAlign: 'center' }}>{catState.error}</p>
          <div className="actions">
            <button className="btn btn-primary" onClick={() => refreshCatalog(true)}>Réessayer</button>
            <Login.SwitchButton />
          </div>
        </div>
      );
    }
    return (
      <div className="loading-screen">
        <div className="logo">LUMEN</div>
        <Spinner />
        <p className="muted">{catState.step || 'Chargement'}…</p>
      </div>
    );
  }

  const baseIdx = stack.map((r) => !OVERLAYS.has(r.name)).lastIndexOf(true);
  const base = stack[baseIdx] || { name: 'home' };
  const overlays = stack.slice(baseIdx + 1);
  const Base = SCREENS[base.name] || Home;
  const top = overlays[overlays.length - 1];

  return (
    <div className="app">
      <div className="scroll" key={baseIdx + base.name + (base.kind || '') + (base.provider || '')}
        onScroll={(e) => setSolid(e.currentTarget.scrollTop > 40)}
        style={top && top.name === 'player' ? { visibility: 'hidden' } : undefined}>
        <Base route={base} active={!top} />
      </div>
      {!(top && top.name === 'player') && <Header solid={solid || !['home', 'vitrine', 'decouvrir'].includes(base.name)} base={base} />}
      {overlays.map((r, i) => {
        if (r.name === 'fiche') {
          const lastFiche = overlays.map((o) => o.name).lastIndexOf('fiche');
          return <Fiche key={i + ':' + (r.item ? r.item.key : r.tmdb && r.tmdb.id)} route={r} hidden={i !== lastFiche || top.name === 'player'} />;
        }
        if (r.name === 'player' && i === overlays.length - 1) {
          if (native) return <TvPlayer key={i + ':tv:' + (r.ref && r.ref.key)} route={r} />;
          const useMpv = window.lumen && mpvExe && r.engine !== 'chromium' && (r.engine === 'mpv' || settings.engine === 'mpv');
          return useMpv ? <MpvPlayer key={i + ':mpv:' + (r.ref && r.ref.key)} route={r} /> : <Player key={i + ':' + (r.ref && r.ref.key)} route={r} />;
        }
        return null;
      })}
      <ReminderCenter />
      {native && <UpdateCheck />}
      {isTV && <QuickMenu />}
      {native && <WatchNextSync />}
      {exitAsk && (
        <div className="modal tv-exit" data-tv-layer role="dialog" aria-label="Quitter Lumen">
          <div className="modal-inner">
            <h2 className="page-title" style={{ fontSize: 38 }}>Quitter Lumen ?</h2>
            <div className="actions">
              <button className="btn btn-primary" data-tv-autofocus onClick={() => setExitAsk(false)}>Rester</button>
              <button className="btn btn-ghost" onClick={() => { setExitAsk(false); if (native) CapApp.exitApp(); }}>Quitter</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [intro, setIntro] = useState(() => loadJSON('settings', {}).intro !== false);
  return (
    <>
      <AppBody />
      {intro && <Intro onDone={() => setIntro(false)} />}
    </>
  );
}
