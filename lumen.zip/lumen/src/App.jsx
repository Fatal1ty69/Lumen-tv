import React, { lazy, useEffect, useState } from 'react';
import { useApp } from './lib/app.jsx';
import Header from './components/Header.jsx';
import { Spinner, Icon } from './components/ui.jsx';
import Login from './screens/Login.jsx';
import Home from './screens/Home.jsx';
import Browse from './screens/Browse.jsx';
import Fiche from './screens/Fiche.jsx';
import ScreenGuard, { prefetchScreens } from './components/ScreenGuard.jsx';
import { ConfirmHost } from './components/Confirm.jsx';
import { ReminderCenter } from './lib/reminders.jsx';
import { loadJSON, saveJSON } from './lib/store.js';
import { native, isTV } from './tv/native.js';
import { focusTop, focusRail, railFocused } from './tv/spatial.js';
import TvRail from './tv/TvRail.jsx';
import QuickMenu from './tv/QuickMenu.jsx';
import WatchNextSync from './tv/WatchNextSync.jsx';
import { liveRef } from './lib/play.js';
import { pickVariant } from './lib/live.js';
import { warmEpg } from './lib/epgWarm.js';
import UpdateCheck from './tv/UpdateCheck.jsx';
import { App as CapApp } from '@capacitor/app';

// Intro du logo, une fois par lancement
function Intro({ onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 3100); return () => clearTimeout(t); }, []);
  return (
    <div className="intro" onClick={onDone} role="presentation">
      <div className="beam" />
      <div className="word" aria-label="Lumen">
        {'LUMEN'.split('').map((c, i) => <span key={i} style={{ animationDelay: 0.25 + i * 0.12 + 's' }}>{c}</span>)}
      </div>
      <div className="intro-tag">Toute ta télé, en grand</div>
    </div>
  );
}

const OVERLAYS = new Set(['fiche', 'player']);

// v28 : écrans chargés à la demande. L'accueil, la grille et la fiche restent dans le paquet principal ;
// le reste (dont le lecteur et ses moteurs hls.js / mpegts.js) arrive à la première ouverture,
// et il est préchargé en tâche de fond quelques secondes après le démarrage.
const LOADERS = {
  live: () => import('./screens/Live.jsx'),
  player: () => import('./screens/Player.jsx'),
  monespace: () => import('./screens/MonEspace.jsx'),
  search: () => import('./screens/Search.jsx'),
  decouvrir: () => import('./screens/Decouvrir.jsx'),
  vitrine: () => import('./screens/Vitrine.jsx'),
  messeries: () => import('./screens/MesSeries.jsx'),
  agenda: () => import('./screens/Agenda.jsx'),
  settings: () => import('./screens/Settings.jsx'),
  mpv: () => import('./screens/MpvPlayer.jsx'),
  tvplayer: () => import('./tv/TvPlayer.jsx')
};
const Live = lazy(LOADERS.live);
const Player = lazy(LOADERS.player);
const MonEspace = lazy(LOADERS.monespace);
const Search = lazy(LOADERS.search);
const Decouvrir = lazy(LOADERS.decouvrir);
const Vitrine = lazy(LOADERS.vitrine);
const MesSeries = lazy(LOADERS.messeries);
const Agenda = lazy(LOADERS.agenda);
const Settings = lazy(LOADERS.settings);
const MpvPlayer = lazy(LOADERS.mpv);
const TvPlayer = lazy(LOADERS.tvplayer);

const SCREENS = { home: Home, browse: Browse, vitrine: Vitrine, live: Live, search: Search, mylist: MonEspace, settings: Settings, agenda: Agenda, decouvrir: Decouvrir, messeries: MesSeries, monespace: MonEspace };

// Bandeau non bloquant : une source active n'a pas pu etre chargee (ex. playlist bloquee),
    // mais le reste du catalogue s'affiche normalement. On peut relancer ou masquer.
    function SourceBanner() {
      const { accounts, catalog, refreshCatalog } = useApp();
      const [hidden, setHidden] = useState('');
      if (!catalog || !catalog.mergedFrom) return null;
      const ok = new Set(catalog.mergedFrom);
      const missing = accounts.filter((a) => (a.use || 'all') !== 'off' && !ok.has(a.name));
      if (!missing.length) return null;
      const sig = missing.map((m) => m.id).join(',');
      if (hidden === sig) return null;
      return (
        <div className="src-banner" role="status">
          <Icon name="refresh" size={18} />
          <span>{missing.length > 1 ? "Des sources n'ont pas pu etre chargees" : "Une source n'a pas pu etre chargee"} : {missing.map((m) => m.name).join(', ')}.</span>
          <button className="btn btn-sm btn-ghost" onClick={() => refreshCatalog(true)}>Reessayer</button>
          <button className="src-x" aria-label="Masquer" onClick={() => setHidden(sig)}><Icon name="close" size={14} /></button>
        </div>
      );
    }

// LUMEN_V25_HISTORY_SETTINGS — gestion non destructive de Continuer / historique
function HistorySettingsCard() {
  const { progress, saveProgress } = useApp();
  const [history, setHistory] = useState(() => loadJSON('mediaHistory', []));

  const commit = (next) => {
    setHistory(next);
    saveJSON('mediaHistory', next);
  };
  const without = (key) => commit(history.filter((entry) => entry.key !== key));
  const hideFromContinue = (entry) => {
    const current = progress[entry.key] || {};
    saveProgress(entry.key, { ...current, hidden: true, ref: current.ref || entry.ref });
  };
  const markWatched = (entry) => {
    const current = progress[entry.key] || {};
    const duration = Number(current.dur) || 1;
    saveProgress(entry.key, { ...current, hidden: true, watched: true, pos: duration, dur: duration, ref: current.ref || entry.ref });
  };

  return (
    <section className="card settings-history-v25" style={{ margin: '22px clamp(18px, 4vw, 64px) 48px', padding: 22 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
        <div style={{ flex: '1 1 320px' }}>
          <span className="kicker">Historique</span>
          <h2 style={{ margin: '4px 0 6px' }}>Continuer à regarder</h2>
          <p className="muted" style={{ margin: 0 }}>Retirer ou marquer un contenu comme vu ne supprime jamais le média du catalogue.</p>
        </div>
        <button className="btn btn-ghost" disabled={!history.length} onClick={() => commit([])}>Effacer l’historique</button>
      </div>
      {!history.length && <p className="muted" style={{ marginTop: 18 }}>L’historique est vide.</p>}
      {!!history.length && (
        <div style={{ display: 'grid', gap: 10, marginTop: 18 }}>
          {history.map((entry) => {
            const item = progress[entry.key] || {};
            const title = (entry.ref && entry.ref.title) || (item.ref && item.ref.title) || entry.key;
            const sub = (entry.ref && entry.ref.sub) || (item.ref && item.ref.sub) || '';
            return (
              <div key={entry.key} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 12, background: 'rgba(255,255,255,.045)', flexWrap: 'wrap' }}>
                <div style={{ flex: '1 1 240px', minWidth: 0 }}><b>{title}</b>{sub && <div className="muted" style={{ fontSize: 13 }}>{sub}</div>}</div>
                <button className="btn btn-ghost btn-sm" onClick={() => hideFromContinue(entry)}>Retirer de Continuer</button>
                <button className="btn btn-ghost btn-sm" onClick={() => markWatched(entry)}>Marquer comme vu</button>
                <button className="btn btn-ghost btn-sm" onClick={() => without(entry.key)}>Retirer de l’historique</button>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

function AppBody() {
  const { account, catalog, catState, refreshCatalog, stack, route, back, settings, mpvExe, navigate, goRoot, xtOf, favorites } = useApp();

  // Guide des programmes préchargé en arrière-plan au lancement. Un court délai
  // laisse au contrôle léger du Direct Stalker la priorité ; il évite que les
  // nombreuses requêtes EPG concurrencent le handshake au moment critique.
  useEffect(() => {
    if (!catalog) return undefined;
    const timer = setTimeout(() => {
      warmEpg({ catalog, xtOf, favorites, liveQuality: settings.liveQuality });
    }, 3500);
    return () => clearTimeout(timer);
  }, [catalog]);

  // Écrans différés préchargés une fois le catalogue affiché (aucun impact sur le démarrage)
  const prefetched = React.useRef(false);
  useEffect(() => {
    if (!catalog || prefetched.current) return;
    prefetched.current = true;
    const order = native ? ['tvplayer', 'live', 'search'] : ['player', 'live', 'monespace', 'search', 'decouvrir', 'vitrine', 'messeries', 'agenda', 'settings', 'mpv'];
    prefetchScreens(order.map((k) => LOADERS[k]));
  }, [catalog]);

  // TV : démarrage direct sur la dernière chaîne regardée
  const startedLive = React.useRef(false);
  useEffect(() => {
    if (!native || !catalog || startedLive.current) return;
    startedLive.current = true;
    if (!settings.tvStartLive) return;
    const g = catalog.byKey.get(loadJSON('lastLive', ''));
    if (!g || g.kind !== 'group') return;
    const list = catalog.liveGroups.filter((x) => x.cat === g.cat).map((x) => x.key);
    const ch = pickVariant(g, settings.liveQuality);
    if (ch) navigate({ name: 'player', ref: liveRef(ch, list, g) });
  }, [catalog]);
  const [solid, setSolid] = useState(false);

  // Touche Retour, TV : fenêtre ouverte > écran du dessus > haut de page > accueil > « Quitter Lumen ? »
  const [exitAsk, setExitAsk] = useState(false);
  const tvBack = React.useCallback(() => {
    if (document.querySelector('.intro')) return;
    if (!account) { if (native) CapApp.minimizeApp(); return; }
    if (!window.dispatchEvent(new CustomEvent('tv-back', { cancelable: true }))) return;
    if (exitAsk) { setExitAsk(false); return; }
    if (stack.length > 1) { back(); return; }
    const sc = document.querySelector('.scroll');
    if (sc && sc.scrollTop > 150 && !railFocused()) { focusTop(); return; }
    // v43 : Retour ouvre le menu latéral ; depuis le menu, on revient à l'accueil puis on propose de quitter
    if (!railFocused() && focusRail()) return;
    const base0 = stack[0] || { name: 'home' };
    if (base0.name !== 'home') { goRoot({ name: 'home' }); return; }
    setExitAsk(true);
  }, [exitAsk, stack, back, goRoot, account]);

  useEffect(() => {
    const onKey = (e) => {
      if (isTV && (e.key === 'Escape' || e.key === 'BrowserBack' || e.key === 'GoBack')) { e.preventDefault(); tvBack(); return; }
      if (e.key === 'Escape' && route.name !== 'player' && stack.length > 1) back();
      if (e.key === 'BrowserBack' || (e.altKey && e.key === 'ArrowLeft')) back();
    };
    window.addEventListener('keydown', onKey);
    let sub = null;
    if (native) CapApp.addListener('backButton', tvBack).then((h) => { sub = h; });
    return () => { window.removeEventListener('keydown', onKey); if (sub) sub.remove(); };
  }, [route, stack.length, back, tvBack]);

  if (!account) return <Login />;

  if (!catalog) {
    if (catState.error) {
      return (
        <div className="loading-screen">
          <div className="logo">LUMEN</div>
          <p className="err" style={{ maxWidth: 520, textAlign: 'center' }}>{catState.error}</p>
          <div className="actions">
            <button className="btn btn-primary" onClick={() => refreshCatalog(true)}>Réessayer</button>
            <Login.SwitchButton />
          </div>
        </div>
      );
    }
    return (
      <div className="loading-screen">
        <div className="logo">LUMEN</div>
        <Spinner />
        <p className="muted">{catState.step || 'Chargement'}…</p>
      </div>
    );
  }

  const baseIdx = stack.map((r) => !OVERLAYS.has(r.name)).lastIndexOf(true);
  const base = stack[baseIdx] || { name: 'home' };
  const overlays = stack.slice(baseIdx + 1);
  const Base = SCREENS[base.name] || Home;
  const top = overlays[overlays.length - 1];

  return (
    <div className="app">
      <div className="scroll" key={baseIdx + base.name + (base.kind || '') + (base.provider || '')}
        onScroll={(e) => setSolid(e.currentTarget.scrollTop > 40)}
        style={top && top.name === 'player' ? { visibility: 'hidden' } : undefined}>
        <ScreenGuard name={base.name} resetKey={baseIdx + base.name} onHome={() => goRoot({ name: 'home' })}>
          <Base route={base} active={!top} />
          {base.name === 'settings' && !top && <HistorySettingsCard />}
        </ScreenGuard>
      </div>
 {!(top && top.name === 'player') && (isTV ? <TvRail base={base} /> : <Header solid={solid || !['home', 'vitrine', 'decouvrir'].includes(base.name)} base={base} />)}
      {!native && !(top && top.name === 'player') && <SourceBanner />}
      {overlays.map((r, i) => {
        if (r.name === 'fiche') {
          const lastFiche = overlays.map((o) => o.name).lastIndexOf('fiche');
          const fk = i + ':' + (r.item ? r.item.key : r.tmdb && r.tmdb.id);
          return (
            <ScreenGuard key={fk} name="fiche" resetKey={fk} overlay onHome={back}>
              <Fiche route={r} hidden={i !== lastFiche || top.name === 'player'} />
            </ScreenGuard>
          );
        }
        if (r.name === 'player' && i === overlays.length - 1) {
          const useMpv = !native && window.lumen && mpvExe && r.engine !== 'chromium' && (r.engine === 'mpv' || settings.engine === 'mpv');
          const pk = i + (native ? ':tv:' : useMpv ? ':mpv:' : ':') + (r.ref && r.ref.key);
          return (
            <ScreenGuard key={pk} name="player" resetKey={pk} overlay onHome={back}>
              {native ? <TvPlayer route={r} /> : useMpv ? <MpvPlayer route={r} /> : <Player route={r} />}
            </ScreenGuard>
          );
        }
        return null;
      })}
      <ReminderCenter />
      <ConfirmHost />
      {native && <UpdateCheck />}
      {isTV && <QuickMenu />}
      {native && <WatchNextSync />}
      {exitAsk && (
        <div className="modal tv-exit" data-tv-layer role="dialog" aria-label="Quitter Lumen">
          <div className="modal-inner">
            <h2 className="page-title" style={{ fontSize: 38 }}>Quitter Lumen ?</h2>
            <div className="actions">
              <button className="btn btn-primary" data-tv-autofocus onClick={() => setExitAsk(false)}>Rester</button>
              <button className="btn btn-ghost" onClick={() => { setExitAsk(false); if (native) CapApp.exitApp(); }}>Quitter</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  // v43 : pas d'intro sur la TV, on arrive tout de suite sur l'accueil
  const [intro, setIntro] = useState(() => !isTV && !window.__skipIntro && loadJSON('settings', {}).intro !== false);
  return (
    <>
      <AppBody />
      {intro && <Intro onDone={() => setIntro(false)} />}
    </>
  );
}
