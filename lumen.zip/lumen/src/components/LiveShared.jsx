import React, { useEffect, useState } from 'react';
import { hhmm } from '../lib/fmt.js';
import { norm } from '../lib/titles.js';
import { getEpg, getCachedEpg, nowNext } from '../lib/epg.js';
import { cached } from '../lib/store.js';
import { img } from '../lib/tmdb.js';
import { Img } from './ui.jsx';

// Outils du Direct partagés avec l'accueil (guide, horloge, carte image).
// Séparés de Live.jsx en v28 : l'accueil ne charge plus tout l'écran Direct ni le moteur de lecture.

export function useEpgs(xtOf, chans, network = true) {
  const [map, setMap] = useState({});
  const keys = (network ? 'net:' : 'cache:') + chans.map((c) => c.key).join(',');
  useEffect(() => {
    let off = false;
    chans.forEach((c) => {
      const load = network ? getEpg : getCachedEpg;
      load(xtOf(c.acc), c).then((list) => {
        if (off || list === undefined) return;
        setMap((m) => (m[c.key] === list ? m : { ...m, [c.key]: list }));
      }).catch(() => {});
    });
    return () => { off = true; };
  }, [keys]);
  return map;
}

export function useNow(ms = 30000) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), ms); return () => clearInterval(t); }, [ms]);
  return now;
}

// Image d'un programme (films et séries reconnus sur TMDB)
function cleanProg(t) {
  return String(t || '').replace(/^(film|série|serie|téléfilm|telefilm|documentaire)\s*:\s*/i, '').replace(/\(?S\d+\s*E\d+\)?/i, '').replace(/\s*-\s*épisode.*$/i, '').trim();
}
function useProgImage(tmdb, title) {
  const [src, setSrc] = useState('');
  useEffect(() => {
    setSrc('');
    const q = cleanProg(title);
    if (!tmdb || !tmdb.enabled || q.length < 3) return;
    let off = false;
    cached('progimg2:' + norm(q), 7 * 24 * 3600 * 1000, async () => {
      const d = await tmdb.req('/search/multi', { query: q, language: 'fr-FR' }, 7 * 24 * 3600 * 1000);
      const res = (d.results || []).filter((r) => r.backdrop_path && r.media_type !== 'person');
      const n = norm(q);
      // Titre identique d'abord, sinon un titre proche (« Le Grand Bain » / « Le Grand Bain, saison 2 »)
      const hit = res.find((r) => norm(r.title || r.name) === n)
        || res.find((r) => { const t = norm(r.title || r.name); return t.length > 3 && (t.startsWith(n) || n.startsWith(t)); });
      return hit ? img(hit.backdrop_path, 'w780') : '';
    }).then((u) => !off && setSrc(u)).catch(() => {});
    return () => { off = true; };
  }, [title, tmdb]);
  return src;
}

export function ImageCard({ g, ch, progs, now, onPlay, tmdb }) {
  const nn = nowNext(Array.isArray(progs) ? progs : [], now);
  const pic = useProgImage(tmdb, nn.now && nn.now.title);
  if (!g || !ch) return null;
  return (
    <button className="card img-card" onClick={() => onPlay(g)} data-chan-key={g.key} aria-label={`${g.name}${nn.now ? ', ' + nn.now.title : ''}`}>
      <div className="frame">
        {pic ? <img className="cover" src={pic} alt="" /> : <div className="img-logo"><Img src={g.logo} fit="contain" /></div>}
        <div className="shade" />
        <span className="img-ch"><Img src={g.logo} fit="contain" /></span>
        {ch.archive && <span className="badge home" style={{ top: 10 }}>REPLAY</span>}
        <div className="img-txt">
          <span className="kicker" style={{ fontSize: 11 }}>{g.name}</span>
          <b>{nn.now ? nn.now.title : 'Programme inconnu'}</b>
          {nn.now && <span className="muted">{hhmm(nn.now.start)} – {hhmm(nn.now.end)}</span>}
        </div>
        {nn.now && <div className="bar"><i style={{ width: ((now - nn.now.start) / (nn.now.end - nn.now.start)) * 100 + '%' }} /></div>}
      </div>
      <div className="card-sub">{nn.next ? `Ensuite ${hhmm(nn.next.start)} · ${nn.next.title}` : ' '}</div>
    </button>
  );
}

// v42 : « Guide en images » en liste compacte : vignette 16/9 à gauche, programme à droite
function leftText(ms) {
  const m = Math.ceil(ms / 60000);
  if (!(m > 0)) return '';
  return 'encore ' + (m >= 60 ? Math.floor(m / 60) + 'h' + String(m % 60).padStart(2, '0') : m + ' min');
}

export function ImageRow({ g, ch, progs, now, onPlay, tmdb }) {
  const nn = nowNext(Array.isArray(progs) ? progs : [], now);
  const pic = useProgImage(tmdb, nn.now && nn.now.title);
  if (!g || !ch) return null;
  const pct = nn.now ? Math.max(0, Math.min(100, ((now - nn.now.start) / (nn.now.end - nn.now.start)) * 100)) : 0;
  return (
    <button className="img-row" onClick={() => onPlay(g)} data-chan-key={g.key} aria-label={`${g.name}${nn.now ? ', ' + nn.now.title : ''}`}>
      <span className="ir-thumb">
        {pic ? <img src={pic} alt="" /> : <span className="ir-logo"><Img src={g.logo} fit="contain" /></span>}
        {nn.now && <i className="ir-bar"><em style={{ width: pct + '%' }} /></i>}
      </span>
      <span className="ir-txt">
        <span className="ir-ch">
          <span className="ir-chlogo"><Img src={g.logo} fit="contain" /></span>
          <span className="ir-chname">{g.name}</span>
          {ch.archive && <span className="ir-rep">REPLAY</span>}
        </span>
        <b>{nn.now ? nn.now.title : 'Programme inconnu'}</b>
        {nn.now && <span className="ir-time">{hhmm(nn.now.start)} – {hhmm(nn.now.end)}<span className="ir-left">{leftText(nn.now.end - now)}</span></span>}
        {nn.next && <span className="ir-next">Ensuite {hhmm(nn.next.start)} · {nn.next.title}</span>}
      </span>
    </button>
  );
}
