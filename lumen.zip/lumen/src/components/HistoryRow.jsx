import React, { useMemo, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { loadJSON, saveJSON } from '../lib/store.js';
import { Row, LandCard } from './ui.jsx';
import { askConfirm } from './Confirm.jsx';
import { epSub } from '../lib/fmt.js';

// v31 : l'historique films et séries quitte l'accueil (il doublait « Continuer à regarder »)
// et vit dans Mon espace, onglet Reprendre. Même comportement qu'avant : relecture, retrait, effacement.
export default function HistoryRow() {
  const { progress, navigate, catalog } = useApp();
  const [tick, setTick] = useState(0);
  const history = useMemo(() => loadJSON('mediaHistory', [])
    .filter((h) => h && h.ref && (h.ref.kind === 'movie' || h.ref.kind === 'episode'))
    .slice(0, 30), [tick]);
  const remove = (key) => { saveJSON('mediaHistory', loadJSON('mediaHistory', []).filter((x) => x.key !== key)); setTick((t) => t + 1); };
  const clear = async () => {
    if (await askConfirm({ title: 'Effacer tout l\'historique films et séries ?', text: 'Les titres restent dans le catalogue, seule la liste est vidée.', ok: 'Tout effacer', danger: true })) {
      saveJSON('mediaHistory', []);
      setTick((t) => t + 1);
    }
  };
  if (!history.length) return null;
  return (
    <Row title="Historique films et séries" action={{ label: 'Tout effacer', onClick: clear }}>
      {history.map((h) => {
        const p = progress[h.key];
        return <LandCard key={h.key} item={catalog.byKey.get(h.ref.kind === 'episode' ? h.ref.seriesKey : h.ref.key)} title={h.ref.title} image={h.ref.image || h.ref.poster} pct={p && p.dur ? (p.pos / p.dur) * 100 : 0}
          sub={[h.ref.kind === 'episode' ? epSub(h.ref) : 'Film', new Date(h.t).toLocaleDateString('fr-FR')].filter(Boolean).join(' · ')}
          onOpen={() => navigate({ name: 'player', ref: h.ref, startAt: p && !p.watched ? p.pos : 0 })}
          onRemove={() => remove(h.key)} removeLabel="l'historique" />;
      })}
    </Row>
  );
}
