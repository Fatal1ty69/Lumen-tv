// « Je ne sais pas quoi regarder » : tire un titre au hasard parmi ce qui est sur ton serveur,
// avec des filtres d'envie (type, note, durée, décennie, genre, jamais commencé) et un effet de roue.
import React, { useMemo, useState, useRef, useEffect } from 'react';
import { useApp } from '../lib/app.jsx';
import { cached, loadJSON, saveJSON } from '../lib/store.js';
import { movieRef, isWatched } from '../lib/play.js';
import { Icon, Img } from './ui.jsx';
import { useModalFocus } from '../lib/useModalFocus.js';

const TYPES = [['all', 'Tout'], ['movie', 'Films'], ['series', 'Séries']];
const NOTES = [[0, 'Toutes'], [6, '6+'], [7, '7+'], [8, '8+']];
const DURATIONS = [['all', 'Toutes'], ['short', '− 1h30'], ['mid', '1h30-2h'], ['long', '+ 2h']];
const DECADES = [[2020, '2020s'], [2010, '2010s'], [2000, '2000s'], [1990, '90s'], [1980, '80s']];
const GENRES = [
  ['Action', 'action'], ['Aventure', 'aventure|adventure'], ['Comédie', 'comedie|comedy'],
  ['Drame', 'drame|drama'], ['Thriller', 'thriller|suspense'], ['Horreur', 'horreur|epouvante|horror'],
  ['Science-fiction', 'science.?fiction|sci.?fi|\\bsf\\b'], ['Fantastique', 'fantastique|fantasy|fantas'],
  ['Animation', 'animation|anime|dessin anime'], ['Romance', 'romance|romantique'],
  ['Policier', 'policier|\\bcrime\\b|polar|mafia'], ['Famille', 'famille|family|enfant|kids|jeunesse'],
  ['Documentaire', 'documentaire|\\bdocu'], ['Guerre', 'guerre|\\bwar\\b'], ['Western', 'western']
];
const deacc = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const inRange = (min, dur) => dur === 'short' ? min <= 90 : dur === 'mid' ? (min > 90 && min <= 120) : dur === 'long' ? min > 120 : true;

export function SurpriseBar() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button className="surprise-bar" onClick={() => setOpen(true)}>
        <span className="surprise-ic"><Icon name="refresh" size={19} /></span>
        <span className="surprise-txt"><b>Je ne sais pas quoi regarder</b></span>
        <span className="surprise-go"><Icon name="next" size={18} /></span>
      </button>
      {open && <SurpriseModal onClose={() => setOpen(false)} />}
    </>
  );
}

function SurpriseModal({ onClose }) {
  const { catalog, progress, navigate, xtOf, watchlist, toggleWatch } = useApp();
  // Les derniers filtres choisis sont retrouvés à la prochaine ouverture
  const saved = useMemo(() => loadJSON('surpriseFilters', {}), []);
  const [type, setType] = useState(saved.type || 'all');
  const [genre, setGenre] = useState(saved.genre || '');
  const [minNote, setMinNote] = useState(saved.minNote || 0);
  const [dur, setDur] = useState(saved.dur || 'all');
  const [decade, setDecade] = useState(saved.decade || 0);
  const [unseen, setUnseen] = useState(saved.unseen !== undefined ? !!saved.unseen : true);
  useEffect(() => { saveJSON('surpriseFilters', { type, genre, minNote, dur, decade, unseen }); }, [type, genre, minNote, dur, decade, unseen]);
  const [spinning, setSpinning] = useState(false);
  const [face, setFace] = useState(null);
  const [result, setResult] = useState(null);
  const [resultMin, setResultMin] = useState(null);
  const [noMatch, setNoMatch] = useState('');
  const timer = useRef(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; clearTimeout(timer.current); }, []);
  // v28 : Échap ferme seulement cette fenêtre (plus de retour arrière dans l'écran derrière), focus piégé puis rendu
  const box = useRef(null);
  useModalFocus(box, { onClose });
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== 'Backspace' || /^(INPUT|TEXTAREA|SELECT)$/.test((e.target && e.target.tagName) || '')) return;
      e.preventDefault(); e.stopImmediatePropagation(); onClose();
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [onClose]);

  const durActive = dur !== 'all';
  const catName = useMemo(() => Object.fromEntries(catalog.vodCats.map((c) => [c.id, c.name])), [catalog]);
  const hay = (it) => deacc(it.kind === 'movie' ? (catName[it.cat] || '') : (it.genre || ''));

  const typePool = useMemo(() => {
    let l = [];
    if (type !== 'series') l = l.concat(catalog.vod);
    if (type !== 'movie' && !durActive) l = l.concat(catalog.series);
    return l.filter((it) => it.poster);
  }, [catalog, type, durActive]);

  const genres = useMemo(() => GENRES.map(([label, re]) => {
    const rx = new RegExp(re, 'i');
    const n = typePool.reduce((a, it) => a + (rx.test(hay(it)) ? 1 : 0), 0);
    return { label, rx, n };
  }).filter((g) => g.n > 0), [typePool, catName]);
  useEffect(() => { if (genre && !genres.some((g) => g.label === genre)) setGenre(''); }, [genres]);

  const decadesAvail = useMemo(() => DECADES.filter(([d]) => typePool.some((it) => it.year >= d && it.year < d + 10)), [typePool]);
  useEffect(() => { if (decade && !decadesAvail.some(([d]) => d === decade)) setDecade(0); }, [decadesAvail]);

  const basePool = useMemo(() => {
    const g = genre ? genres.find((x) => x.label === genre) : null;
    return typePool.filter((it) => {
      if (minNote && !(it.rating >= minNote)) return false;
      if (decade && !(it.year >= decade && it.year < decade + 10)) return false;
      if (unseen && progress[it.key]) return false;
      if (g && !g.rx.test(hay(it))) return false;
      return true;
    });
  }, [typePool, minNote, decade, unseen, genre, genres, progress, catName]);

  const runtimeOf = async (it) => {
    try {
      const x = xtOf(it.acc);
      if (!x || !x.vodInfo) return null;
      const vi = await cached('vi:' + x.server + ':' + it.id, 24 * 3600 * 1000, () => x.vodInfo(it.id));
      const secs = vi && vi.info && Number(vi.info.duration_secs);
      return secs ? Math.round(secs / 60) : null;
    } catch { return null; }
  };

  const choosePick = async () => {
    if (!basePool.length) return null;
    if (!durActive) return { pick: basePool[Math.floor(Math.random() * basePool.length)], min: null };
    const movies = basePool.filter((x) => x.kind === 'movie');
    const shuffled = [...movies].sort(() => Math.random() - 0.5).slice(0, 24);
    for (const c of shuffled) {
      if (!alive.current) return null;
      const min = await runtimeOf(c);
      if (min != null && inRange(min, dur)) return { pick: c, min };
    }
    return null;
  };

  const spin = async () => {
    if (!basePool.length || spinning) return;
    setResult(null); setResultMin(null); setNoMatch('');
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    setSpinning(true);
    const chosen = await choosePick();
    if (!alive.current) return;
    if (!chosen) { setSpinning(false); setNoMatch(durActive ? 'Aucun film trouvé pour cette durée.' : 'Aucun titre ne correspond.'); return; }
    const { pick, min } = chosen;
    if (reduce) { setFace(pick); setResult(pick); setResultMin(min); setSpinning(false); return; }
    let n = 0;
    const total = 18 + Math.floor(Math.random() * 7);
    const tick = () => {
      if (!alive.current) return;
      n += 1;
      if (n >= total) { setFace(pick); setResult(pick); setResultMin(min); setSpinning(false); return; }
      setFace(basePool[Math.floor(Math.random() * basePool.length)]);
      timer.current = setTimeout(tick, Math.min(430, 40 + n * n * 1.15));
    };
    tick();
  };

  const openFiche = () => { if (result) { navigate({ name: 'fiche', item: result }); onClose(); } };
  const resumeAt = result && result.kind === 'movie' && progress[result.key] && !isWatched(progress[result.key]) && progress[result.key].pos > 60
    ? progress[result.key].pos : 0;
  // Film : lecture directe. Série : la fiche, pour choisir l'épisode.
  const playResult = () => {
    if (!result) return;
    if (result.kind !== 'movie') { openFiche(); return; }
    navigate({ name: 'player', ref: movieRef(result), startAt: resumeAt });
    onClose();
  };
  const inWatch = !!(result && watchlist && watchlist[result.key]);
  const fmtMin = (m) => m ? (m >= 60 ? Math.floor(m / 60) + 'h' + (m % 60 ? String(m % 60).padStart(2, '0') : '') : m + ' min') : '';

  return (
    <div className="modal surprise-modal" onClick={onClose} role="dialog" aria-label="Je ne sais pas quoi regarder">
      <div className="modal-inner surprise-inner" ref={box} tabIndex={-1} onClick={(e) => e.stopPropagation()}>
        <div className="modal-top">
          <span className="kicker">Je ne sais pas quoi regarder</span>
          <button className="btn btn-ghost btn-sm" onClick={onClose}><Icon name="close" size={16} />Fermer</button>
        </div>

        <div className="surprise-body">
          <div className="surprise-filters">
            <div className="sf-line">
              <span className="sf-label">Type</span>
              <div className="sf-group">{TYPES.map(([v, l]) => <button key={v} className={type === v ? 'on' : ''} onClick={() => setType(v)}>{l}</button>)}</div>
            </div>
            <div className="sf-line">
              <span className="sf-label">Note</span>
              <div className="sf-group">{NOTES.map(([v, l]) => <button key={v} className={minNote === v ? 'on' : ''} onClick={() => setMinNote(v)}>{l}</button>)}</div>
            </div>
            <div className="sf-line">
              <span className="sf-label">Durée</span>
              <div className="sf-group">{DURATIONS.map(([v, l]) => <button key={v} className={dur === v ? 'on' : ''} onClick={() => setDur(v)}>{l}</button>)}</div>
            </div>
            {decadesAvail.length > 0 && (
              <div className="sf-line">
                <span className="sf-label">Décennie</span>
                <div className="sf-group">
                  <button className={!decade ? 'on' : ''} onClick={() => setDecade(0)}>Toutes</button>
                  {decadesAvail.map(([d, l]) => <button key={d} className={decade === d ? 'on' : ''} onClick={() => setDecade(d)}>{l}</button>)}
                </div>
              </div>
            )}
            {genres.length > 0 && (
              <div className="sf-line genres">
                <span className="sf-label">Genre</span>
                <div className="sf-chips">
                  <button className={!genre ? 'on' : ''} onClick={() => setGenre('')}>Tous</button>
                  {genres.map((g) => <button key={g.label} className={genre === g.label ? 'on' : ''} onClick={() => setGenre(g.label)}>{g.label}</button>)}
                </div>
              </div>
            )}
            <button className={'sf-toggle' + (unseen ? ' on' : '')} onClick={() => setUnseen((u) => !u)} aria-pressed={unseen}>
              <Icon name={unseen ? 'check' : 'plus'} size={15} />Jamais commencé
            </button>
          </div>

          <div className={'surprise-stage' + (spinning ? ' spin' : '') + (result ? ' done' : '')}>
            <div className="ss-thumb">
              {face ? <Img src={face.poster} className="ss-poster" title={face.title} /> : <div className="ss-ph"><Icon name="play" size={26} /></div>}
            </div>
            <div className="ss-side">
              {result ? (
                <>
                  <b className="ss-title">{result.title}</b>
                  <span className="ss-meta">{[result.kind === 'series' ? 'Série' : 'Film', result.year, resultMin ? fmtMin(resultMin) : '', result.rating ? '★ ' + result.rating.toFixed(1) : ''].filter(Boolean).join('  ·  ')}</span>
                  {genre && <span className="ss-tag">{genre}</span>}
                </>
              ) : spinning ? <span className="ss-wait">Tirage en cours…</span>
                : noMatch ? <span className="ss-wait">{noMatch}</span>
                  : <span className="ss-wait">{basePool.length ? 'Lance le tirage.' : 'Aucun titre. Élargis les filtres.'}</span>}
            </div>
          </div>
        </div>

        <div className="surprise-actions">
          {result ? (
            <>
              <button className="btn btn-primary" onClick={playResult}>
                <Icon name="play" size={18} />{result.kind === 'movie' ? (resumeAt ? 'Reprendre' : 'Lecture') : 'Voir les épisodes'}
              </button>
              <button className={'btn btn-ghost btn-toggle' + (inWatch ? ' on' : '')} onClick={() => toggleWatch(result)} aria-pressed={inWatch}
                title={inWatch ? 'Retirer de À voir plus tard' : 'Ajouter à À voir plus tard'}>
                <Icon name={inWatch ? 'check' : 'calendar'} size={17} />Plus tard
              </button>
              {result.kind === 'movie' && <button className="btn btn-ghost" onClick={openFiche}><Icon name="info" size={18} />Fiche</button>}
              <button className="btn btn-ghost" onClick={spin}><Icon name="refresh" size={18} />Relancer</button>
            </>
          ) : (
            <button className="btn btn-primary" onClick={spin} disabled={!basePool.length || spinning}>
              <Icon name="refresh" size={18} />{spinning ? 'Tirage…' : 'Lancer'}
            </button>
          )}
          <span className="muted ss-count">{basePool.length} titre{basePool.length > 1 ? 's' : ''}{durActive ? ' (durée vérifiée au tirage)' : ''}</span>
        </div>
      </div>
    </div>
  );
}
