// Réglages (PC) : recopie tout Lumen vers Lumen TV sur le réseau local
import React, { useState } from 'react';
import { loadJSON, saveJSON } from '../lib/store.js';
import { Spinner } from './ui.jsx';
import { setTvLink, syncNow } from '../lib/sync.js';

async function req(opts) {
  const r = await window.lumen.httpReq({ timeout: 5000, ...opts });
  if (!r.ok) throw new Error(r.error || 'injoignable');
  return r;
}

// Trouve le port de Lumen TV (47820 par défaut, jusqu'à 47825 s'il était pris)
async function findTv(addr) {
  const [host, port] = addr.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '').split(':');
  const ports = port ? [Number(port)] : [47820, 47821, 47822, 47823, 47824, 47825];
  for (const p of ports) {
    try {
      const r = await req({ url: `http://${host}:${p}/ping`, timeout: 2500 });
      if (r.status === 200 && /Lumen TV/.test(r.text)) return `http://${host}:${p}`;
    } catch { /* port suivant */ }
  }
  return null;
}

export default function SendToTv() {
  const [addr, setAddr] = useState(() => loadJSON('tvAddress', ''));
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  const send = async () => {
    setMsg(null);
    if (!addr.trim() || !/^\d{4}$/.test(code.trim())) { setMsg({ ok: false, t: 'Indique l\'adresse et le code à 4 chiffres affichés sur la TV.' }); return; }
    setBusy(true);
    try {
      const base = await findTv(addr);
      if (!base) throw new Error('Lumen TV ne répond pas à cette adresse. Vérifie que l\'appli est ouverte sur la TV et que le PC et la TV sont sur le même réseau.');
      saveJSON('tvAddress', addr.trim());
      const storage = {};
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('lumen:') && !['lumen:tvAddress', 'lumen:tvLink', 'lumen:syncState', 'lumen:meta'].includes(k) && !k.endsWith(':del')) storage[k] = localStorage.getItem(k);
      }
      const r = await req({ url: base + '/config', method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: code.trim(), kind: 'clone', from: 'Lumen PC', storage }), timeout: 20000 });
      let d = {};
      try { d = JSON.parse(r.text); } catch { /* réponse vide */ }
      if (r.status === 200 && d.ok) {
        const u = new URL(base);
        setTvLink({ host: u.hostname, port: Number(u.port) || 47820, code: code.trim(), paired: Date.now() });
        setTimeout(() => syncNow('association'), 6000);
        setMsg({ ok: true, t: 'C\'est envoyé : la TV redémarre Lumen avec tes réglages. La synchronisation maison est activée.' });
      }
      else throw new Error(d.error || 'La TV a refusé l\'envoi (' + r.status + ').');
    } catch (e) {
      setMsg({ ok: false, t: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card-box">
      <h2>Envoyer vers ma TV</h2>
      <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>
        Ouvre Lumen sur ta TV (Android TV, Nvidia Shield) : l'écran d'accueil ou ses Réglages affichent une adresse et un code. Saisis-les ici pour recopier sur la TV tes serveurs, tes clés TMDB et OMDb, ta connexion Trakt, Ma liste, tes groupes masqués et ta progression. Le PC et la TV doivent être sur le même réseau.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr auto', gap: 10, alignItems: 'end' }}>
        <label className="lbl">Adresse de la TV
          <input value={addr} onChange={(e) => setAddr(e.target.value)} placeholder="192.168.1.42" autoComplete="off" />
        </label>
        <label className="lbl">Code
          <input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="0000" inputMode="numeric" autoComplete="off" />
        </label>
        <button className="btn btn-primary btn-sm" onClick={send} disabled={busy}>{busy ? <><Spinner /> Envoi…</> : 'Envoyer'}</button>
      </div>
      {msg && <p className={msg.ok ? 'ok' : 'err'}>{msg.t}</p>}
    </section>
  );
}
