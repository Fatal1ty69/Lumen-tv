import React, { Suspense } from 'react';
import { Spinner } from './ui.jsx';

// Filet de sécurité par écran : une erreur dans un écran n'éteint plus toute l'application.
// L'écran fautif affiche un message avec « Réessayer » et « Accueil » ; le reste (menu, lecteur) continue.
// resetKey : quand il change (navigation), l'erreur est oubliée et l'écran est retenté.
class Boundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null, key: props.resetKey };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  static getDerivedStateFromProps(props, state) {
    if (props.resetKey !== state.key) return { error: null, key: props.resetKey };
    return null;
  }

  componentDidCatch(error, info) {
    try { console.error('[Lumen] écran en erreur :', this.props.name, error, info && info.componentStack); } catch { /* rien */ }
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    const { onHome, overlay } = this.props;
    // Un fichier d'écran introuvable après une mise à jour : un rechargement suffit
    const chunk = /dynamically imported module|Failed to fetch|Loading chunk/i.test(String(error && error.message));
    return (
      <div className={overlay ? 'guard guard-overlay' : 'guard'} role="alert">
        <div className="guard-card">
          <span className="kicker">Oups</span>
          <h2>{chunk ? 'Cet écran doit être rechargé' : 'Cet écran a rencontré un problème'}</h2>
          <p className="muted">{chunk ? 'Lumen a été mis à jour pendant son utilisation.' : 'Le reste de Lumen fonctionne toujours.'}</p>
          <div className="actions">
            <button className="btn btn-primary" onClick={() => (chunk ? window.location.reload() : this.setState({ error: null }))}>Réessayer</button>
            {onHome && <button className="btn btn-ghost" onClick={() => { this.setState({ error: null }); onHome(); }}>Accueil</button>}
          </div>
          <details className="guard-detail">
            <summary>Détail technique</summary>
            <code>{String((error && error.message) || error)}</code>
          </details>
        </div>
      </div>
    );
  }
}

function Waiting({ overlay }) {
  if (overlay) return <div className="guard-wait guard-overlay"><Spinner /></div>;
  return <div className="guard-wait"><Spinner /></div>;
}

export default function ScreenGuard({ name, resetKey, onHome, overlay = false, children }) {
  return (
    <Boundary name={name} resetKey={resetKey} onHome={onHome} overlay={overlay}>
      <Suspense fallback={<Waiting overlay={overlay} />}>{children}</Suspense>
    </Boundary>
  );
}

// Précharge en tâche de fond les écrans différés, pour qu'ils s'ouvrent sans attente
export function prefetchScreens(loaders) {
  const run = () => loaders.forEach((load, i) => setTimeout(() => { load().catch(() => {}); }, i * 120));
  if ('requestIdleCallback' in window) window.requestIdleCallback(run, { timeout: 4000 });
  else setTimeout(run, 1500);
}
