// Mosaïque des chaînes : aperçus rafraîchis l'un après l'autre (une seule connexion),
// direct au survol, et en option quelques chaînes en direct permanent
import React, { useEffect, useRef, useState } from 'react';
import { attachSource, hhmm } from '../lib/player.js';
import { nowNext } from '../lib/epg.js';
import { Img } from './ui.jsx';

const frames = new Map(); // images gardées entre deux visites de la mosaïque

function grab(video) {
  try {
    const c = document.createElement('canvas');
    c.width = 384; c.height = 216;
    c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.72);
  } catch { return null; }
}

function LiveTile({ xtOf, ch }) {
  const v = useRef(null);
  useEffect(() => {
    const el = v.current;
    el.muted = true;
    const src = attachSource(el, xtOf(ch.acc).liveUrl(ch.id, 'ts'), { live: true });
    el.play().catch(() => {});
    return () => src.destroy();
  }, [ch.key]);
  return <video ref={v} className="mo-video" playsInline muted />;
}

export default function Mosaic({ xtOf, groups, chosen, epgs, now, onPlay, liveCount = 0, maxConn }) {
  const tiles = groups.slice(0, 24);
  const [, setTick] = useState(0);
  const [hover, setHover] = useState(null);
  const cycler = useRef(null);
  const idx = useRef(0);

  // Rafraîchissement tour à tour des images
  useEffect(() => {
    if (hover) return;
    const rest = tiles.slice(liveCount);
    if (!rest.length) return;
    let alive = true;
    let src = null;
    let timer = null;
    const el = cycler.current;
    el.muted = true;
    const next = () => {
      if (!alive) return;
      if (src) { src.destroy(); src = null; }
      const g = rest[idx.current % rest.length];
      idx.current++;
      const ch = chosen[g.key];
      let done = false;
      const finish = () => {
        if (done || !alive) return;
        done = true;
        const img = grab(el);
        if (img) { frames.set(g.key, img); setTick((t) => t + 1); }
        timer = setTimeout(next, 300);
      };
      const onPlaying = () => setTimeout(finish, 1200);
      el.addEventListener('playing', onPlaying, { once: true });
      src = attachSource(el, xtOf(ch.acc).liveUrl(ch.id, 'ts'), { live: true, onFatal: () => { done = true; timer = setTimeout(next, 300); } });
      el.play().catch(() => {});
      timer = setTimeout(() => { if (!done) { done = true; next(); } }, 8000);
    };
    next();
    return () => { alive = false; clearTimeout(timer); if (src) src.destroy(); };
  }, [tiles.map((g) => g.key).join(','), hover, liveCount]);

  const used = liveCount + 1;
  return (
    <div>
      <p className="muted" style={{ fontSize: 13, marginBottom: 12 }}>
        Les images se rafraîchissent une chaîne après l'autre. Survole une chaîne pour la voir en direct, clique pour le plein écran.
        {maxConn ? ` Connexions utilisées : ${used} sur ${maxConn}.` : ''}
      </p>
      <video ref={cycler} style={{ display: 'none' }} playsInline muted />
      <div className="mosaic">
        {tiles.map((g, i) => {
          const ch = chosen[g.key];
          const nn = nowNext(epgs[ch.key] || [], now);
          const isLive = i < liveCount || hover === g.key;
          const frame = frames.get(g.key);
          return (
            <button key={g.key} className={'mo-tile' + (hover === g.key ? ' on' : '')} onClick={() => onPlay(g)}
              onMouseEnter={() => setHover(g.key)} onMouseLeave={() => setHover((h) => (h === g.key ? null : h))}
              onFocus={() => setHover(g.key)} onBlur={() => setHover((h) => (h === g.key ? null : h))} aria-label={`${g.name}${nn.now ? ', ' + nn.now.title : ''}`}>
              {frame ? <img className="mo-frame" src={frame} alt="" /> : <span className="mo-logo"><Img src={g.logo} fit="contain" title={g.name} /></span>}
              {isLive && <LiveTile xtOf={xtOf} ch={ch} />}
              {isLive && <span className="mo-live">EN DIRECT</span>}
              <span className="mo-cap">
                <b>{g.num} · {g.name}</b>
                {nn.now && <small>{nn.now.title} · jusqu'à {hhmm(nn.now.end)}</small>}
              </span>
              {nn.now && <span className="bar"><i style={{ width: ((now - nn.now.start) / (nn.now.end - nn.now.start)) * 100 + '%' }} /></span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}
