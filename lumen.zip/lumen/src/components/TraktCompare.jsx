// Fiche d'une série : comparaison épisode par épisode entre le serveur, Lumen et Trakt (pour comprendre un écart)
import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useApp } from '../lib/app.jsx';
import { isWatched } from '../lib/play.js';
import { buildMap, tmdbSeasons, toTmdb } from '../lib/numbering.js';

const fmt = (list) => (list && list.length ? list.map(([s, n]) => `S${s} : ${n}`).join(' · ') : 'inconnue');

export default function TraktCompare({ d, onClose }) {
  const { traktWatched, progress, tmdb } = useApp();
  const [seasons, setSeasons] = useState(undefined);
  useEffect(() => { tmdbSeasons(tmdb, d.tmdbId).then(setSeasons); }, [d.tmdbId]);
  useEffect(() => {
    const on = (e) => { e.preventDefault(); onClose(); };
    const key = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('tv-back', on);
    window.addEventListener('keydown', key);
    return () => { window.removeEventListener('tv-back', on); window.removeEventListener('keydown', key); };
  }, [onClose]);

  const all = d.seasons.flatMap((n) => (d.episodes[n] || []).map((e) => ({ e, s: Number(n) })));
  const srv = [];
  for (const x of all) if (x.s > 0) { const last = srv[srv.length - 1]; if (last && last[0] === x.s) last[1] = Math.max(last[1], x.e.num); else srv.push([x.s, x.e.num]); }
  const map = seasons ? buildMap(all.map((x) => ({ season: x.s, num: Number(x.e.num) })), seasons) : null;
  const tw = (traktWatched && traktWatched.shows && traktWatched.shows[d.tmdbId]) || null;
  const info = (traktWatched && traktWatched.showInfo && traktWatched.showInfo[d.tmdbId]) || null;
  const rows = all.map((x) => {
    const t = toTmdb(map, x.s, x.e.num);
    const onTrakt = !!(tw && tw[t.season + ':' + t.number]);
    const inLumen = isWatched(progress['e:' + x.e.id]);
    return { ...x, t, onTrakt, inLumen };
  });
  const diff = rows.filter((r) => r.onTrakt !== r.inLumen).length;
  const traktOnly = tw ? Object.keys(tw).filter((k) => !rows.some((r) => r.t.season + ':' + r.t.number === k)) : [];

  return createPortal(
    <div className="modal tc" data-tv-layer role="dialog" aria-label="Comparer avec Trakt" onClick={onClose}>
      <div className="modal-inner tc-inner" onClick={(e) => e.stopPropagation()}>
        <div className="tc-head">
          <div>
            <span className="kicker">Comparer avec Trakt</span>
            <h2 style={{ margin: '4px 0 0', fontSize: 26 }}>{d.view ? d.view.title : ''}</h2>
          </div>
          <button className="btn btn-ghost btn-sm" data-tv-autofocus onClick={onClose}>Fermer</button>
        </div>
        <div className="tc-facts">
          <div><span>Série Trakt reliée</span><b>{tw ? `${(info && info.title) || 'oui'}${info && info.year ? ' (' + info.year + ')' : ''} · TMDB ${d.tmdbId}` : `Aucune (TMDB ${d.tmdbId || '?'} absent de ton historique Trakt)`}</b></div>
          <div><span>Découpe du serveur</span><b>{fmt(srv)}</b></div>
          <div><span>Découpe Trakt / TMDB</span><b>{seasons === undefined ? 'chargement…' : fmt(seasons)}</b></div>
          <div><span>Correspondance</span><b>{map ? 'par rang dans la série (découpes différentes)' : 'saison et numéro identiques'}</b></div>
          <div><span>Écarts</span><b className={diff ? 'err' : 'ok'}>{diff ? `${diff} épisode${diff > 1 ? 's' : ''} vu${diff > 1 ? 's' : ''} d'un côté seulement` : 'aucun'}</b></div>
        </div>
        <div className="tc-table-wrap">
          <table className="tc-table">
            <thead><tr><th>Serveur</th><th>Titre</th><th>Trakt</th><th>Vu sur Trakt</th><th>Vu dans Lumen</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.e.id} className={r.onTrakt !== r.inLumen ? 'bad' : ''}>
                  <td>S{r.s} · É{r.e.num}</td>
                  <td>{r.e.title}</td>
                  <td>S{r.t.season} · É{r.t.number}</td>
                  <td>{r.onTrakt ? '✓' : '·'}</td>
                  <td>{r.inLumen ? '✓' : '·'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {traktOnly.length > 0 && <p className="muted" style={{ fontSize: 14, margin: 0 }}>Vus sur Trakt mais absents du serveur : {traktOnly.map((k) => 'S' + k.replace(':', ' · É')).join(', ')}</p>}
      </div>
    </div>,
    document.body
  );
}
