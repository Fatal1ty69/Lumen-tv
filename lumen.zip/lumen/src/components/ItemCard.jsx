// Affiche d'un film ou d'une série avec des actions directes au survol (PC) :
// Lecture (films), À voir plus tard, Ma liste. Un clic sur l'affiche ouvre toujours la fiche.
import React from 'react';
import { useApp } from '../lib/app.jsx';
import { movieRef, isWatched } from '../lib/play.js';
import { isTV } from '../tv/native.js';
import { Icon, PosterCard } from './ui.jsx';

export default function ItemCard({ item, poster, sub, badge, home, onOpen, showTitle }) {
  const { navigate, progress, favorites, toggleFav, watchlist, toggleWatch } = useApp();
  const open = onOpen || (() => navigate({ name: 'fiche', item }));
  const card = (
    <PosterCard itemKey={item.key} item={item} title={item.title} poster={poster || item.poster} sub={sub} badge={badge} home={home} showTitle={showTitle} onOpen={open} />
  );
  // Télécommande : la carte reste simple, les actions sont dans la fiche (appui long)
  if (isTV) return card;

  const p = progress[item.key];
  const resumeAt = item.kind === 'movie' && p && !isWatched(p) && p.pos > 60 ? p.pos : 0;
  const inFav = !!favorites[item.key];
  const inWatch = !!(watchlist && watchlist[item.key]);
  return (
    <div className="poster-wrap has-acts">
      {card}
      <div className="card-acts">
        {item.kind === 'movie' && (
          <button className="ca play" onClick={() => navigate({ name: 'player', ref: movieRef(item), startAt: resumeAt })}
            aria-label={(resumeAt ? 'Reprendre ' : 'Lire ') + item.title} title={resumeAt ? 'Reprendre' : 'Lecture'}>
            <Icon name="play" size={15} />
          </button>
        )}
        <button className={'ca' + (inWatch ? ' on' : '')} onClick={() => toggleWatch(item)} aria-pressed={inWatch}
          aria-label={(inWatch ? 'Retirer de À voir plus tard : ' : 'À voir plus tard : ') + item.title} title={inWatch ? 'Retirer de À voir plus tard' : 'À voir plus tard'}>
          <Icon name={inWatch ? 'check' : 'calendar'} size={15} />
        </button>
        <button className={'ca' + (inFav ? ' on' : '')} onClick={() => toggleFav(item)} aria-pressed={inFav}
          aria-label={(inFav ? 'Retirer de Ma liste : ' : 'Ajouter à Ma liste : ') + item.title} title={inFav ? 'Retirer de Ma liste' : 'Ajouter à Ma liste'}>
          <Icon name={inFav ? 'check' : 'plus'} size={15} />
        </button>
      </div>
    </div>
  );
}
