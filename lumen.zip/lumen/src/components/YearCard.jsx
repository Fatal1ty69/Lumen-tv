// Réglages : « Ton année », le récap de ce que le profil a regardé (films, épisodes, séries, direct)
import React, { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { useApp } from '../lib/app.jsx';
import { getProfiles, activeProfile, loadJSON } from '../lib/store.js';
import { Img } from './ui.jsx';

const SHORT = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
const MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

export function yearStats(progress, catalog, year) {
  const from = new Date(year, 0, 1).getTime();
  const to = new Date(year + 1, 0, 1).getTime();
  let secs = 0, films = 0, episodes = 0;
  const series = new Map();
  const genres = new Map();
  const months = new Array(12).fill(0);
  const days = new Set();
  const movies = [];
  for (const p of Object.values(progress || {})) {
    if (!p || !p.ref || !p.t || p.t < from || p.t >= to) continue;
    const kind = p.ref.kind;
    if (kind !== 'movie' && kind !== 'episode') continue;
    const s = Math.max(0, Math.min(Number(p.watched ? p.dur : p.pos) || 0, 4 * 3600));
    if (s < 60 && !p.watched) continue;
    secs += s;
    const d = new Date(p.t);
    months[d.getMonth()] += s;
    days.add(d.toDateString());
    const item = catalog && catalog.byKey.get(kind === 'episode' ? p.ref.seriesKey : p.ref.key);
    if (kind === 'movie' && p.watched) { films++; movies.push({ key: p.ref.key, title: p.ref.title, poster: p.ref.poster || (item && item.poster) || p.ref.image, t: p.t }); }
    if (kind === 'episode') {
      if (p.watched) episodes++;
      const k = p.ref.seriesKey || p.ref.title;
      const cur = series.get(k) || { key: k, title: p.ref.title, poster: p.ref.poster || (item && item.poster) || '', n: 0, secs: 0 };
      cur.n += p.watched ? 1 : 0;
      cur.secs += s;
      series.set(k, cur);
    }
    const g = item && item.genre;
    if (g) for (const one of String(g).split(/[,/&|]+/).map((x) => x.trim()).filter(Boolean).slice(0, 3)) genres.set(one, (genres.get(one) || 0) + s);
  }
  const live = (loadJSON('liveStats', {})[String(year)]) || {};
  const liveSecs = Object.values(live).reduce((a, b) => a + b, 0);
  const channels = Object.entries(live).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, v]) => {
    const g = catalog && catalog.byKey.get(k);
    return { key: k, name: g ? g.name : k, logo: g ? g.logo : '', secs: v };
  });
  const best = months.indexOf(Math.max(...months));
  return {
    year, secs, films, episodes, liveSecs, days: days.size,
    series: [...series.values()].sort((a, b) => b.secs - a.secs),
    genres: [...genres.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name]) => name),
    months, bestMonth: months[best] > 0 ? best : -1, channels,
    movies: movies.sort((a, b) => b.t - a.t).slice(0, 8)
  };
}

const hours = (s) => Math.round(s / 3600);

function Recap({ stats, name, onClose, years, setYear }) {
  useEffect(() => {
    const on = (e) => { e.preventDefault(); onClose(); };
    const key = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('tv-back', on);
    window.addEventListener('keydown', key);
    return () => { window.removeEventListener('tv-back', on); window.removeEventListener('keydown', key); };
  }, [onClose]);
  const max = Math.max(1, ...stats.months);
  const empty = !stats.secs && !stats.liveSecs;
  return createPortal(
    <div className="yr" data-tv-layer role="dialog" aria-label={'Ton année ' + stats.year}>
      <div className="yr-inner">
        <div className="yr-head">
          <div>
            <span className="kicker">{name}</span>
            <h2 className="yr-title">Ton année {stats.year}</h2>
          </div>
          <div className="actions">
            {years.map((y) => <button key={y} className={'btn btn-sm ' + (y === stats.year ? 'btn-primary' : 'btn-ghost')} onClick={() => setYear(y)}>{y}</button>)}
            <button className="btn btn-ghost btn-sm" data-tv-autofocus onClick={onClose}>Fermer</button>
          </div>
        </div>
        {empty ? <p className="muted" style={{ fontSize: 18 }}>Rien de regardé cette année pour l'instant. Reviens après quelques soirées devant Lumen.</p> : (
          <>
            <div className="yr-big">
              <div><b>{hours(stats.secs + stats.liveSecs)}</b><span>heures devant Lumen</span></div>
              {stats.films > 0 && <div><b>{stats.films}</b><span>film{stats.films > 1 ? 's' : ''}</span></div>}
              {stats.episodes > 0 && <div><b>{stats.episodes}</b><span>épisode{stats.episodes > 1 ? 's' : ''}</span></div>}
              {stats.series.length > 0 && <div><b>{stats.series.length}</b><span>série{stats.series.length > 1 ? 's' : ''}</span></div>}
              <div><b>{stats.days}</b><span>jour{stats.days > 1 ? 's' : ''} de visionnage</span></div>
              {stats.liveSecs > 0 && <div><b>{hours(stats.liveSecs)}</b><span>heures de direct</span></div>}
            </div>
            <div className="yr-months" aria-label="Heures par mois">
              {stats.months.map((m, i) => (
                <div key={i} className={'yr-month' + (i === stats.bestMonth ? ' best' : '')}>
                  <i style={{ height: Math.max(3, (m / max) * 100) + '%' }} title={hours(m) + ' h'} />
                  <span>{SHORT[i]}</span>
                </div>
              ))}
            </div>
            {stats.bestMonth >= 0 && <p className="muted" style={{ fontSize: 16, margin: 0 }}>Ton plus gros mois : <b style={{ color: '#fff' }}>{MONTHS[stats.bestMonth]}</b>, avec {hours(stats.months[stats.bestMonth])} heures.{stats.genres.length ? ' Genres préférés : ' + stats.genres.slice(0, 3).join(', ') + '.' : ''}</p>}
            {stats.series.length > 0 && (
              <section>
                <h3 className="yr-h">Tes séries de l'année</h3>
                <div className="yr-row">
                  {stats.series.slice(0, 6).map((s, i) => (
                    <div key={s.key} className="yr-tile">
                      <div className="yr-poster">{s.poster ? <Img src={s.poster} alt={s.title} /> : <span>{s.title}</span>}</div>
                      <em>{i + 1}</em>
                      <b>{s.title}</b>
                      <span>{s.n} épisode{s.n > 1 ? 's' : ''} · {Math.max(1, hours(s.secs))} h</span>
                    </div>
                  ))}
                </div>
              </section>
            )}
            {stats.movies.length > 0 && (
              <section>
                <h3 className="yr-h">Derniers films vus</h3>
                <div className="yr-row">
                  {stats.movies.slice(0, 6).map((m) => (
                    <div key={m.key} className="yr-tile"><div className="yr-poster">{m.poster ? <Img src={m.poster} alt={m.title} /> : <span>{m.title}</span>}</div><b>{m.title}</b></div>
                  ))}
                </div>
              </section>
            )}
            {stats.channels.length > 0 && (
              <section>
                <h3 className="yr-h">Tes chaînes</h3>
                <div className="yr-chans">
                  {stats.channels.map((c) => (
                    <div key={c.key} className="yr-chan">{c.logo ? <Img src={c.logo} alt="" fit="contain" /> : <i />}<b>{c.name}</b><span>{Math.max(1, hours(c.secs))} h</span></div>
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </div>,
    document.body
  );
}

export default function YearCard() {
  const { progress, catalog } = useApp();
  const [open, setOpen] = useState(false);
  const now = new Date().getFullYear();
  const [year, setYear] = useState(now);
  const me = getProfiles().find((p) => p.id === activeProfile());
  const stats = useMemo(() => yearStats(progress, catalog, year), [progress, catalog, year]);
  const quick = useMemo(() => yearStats(progress, catalog, now), [progress, catalog]);
  const years = useMemo(() => {
    const prev = yearStats(progress, catalog, now - 1);
    return prev.secs || prev.liveSecs ? [now - 1, now] : [now];
  }, [progress, catalog]);
  return (
    <section className="card-box">
      <h2>Ton année {now}</h2>
      <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>
        {quick.secs || quick.liveSecs
          ? `${me ? me.name + ', tu' : 'Tu'} as passé ${hours(quick.secs + quick.liveSecs)} heures devant Lumen cette année : ${quick.films} film${quick.films > 1 ? 's' : ''} et ${quick.episodes} épisode${quick.episodes > 1 ? 's' : ''}.`
          : 'Le récap de ce que tu regardes sur ce profil : heures, films, séries préférées, chaînes.'}
      </p>
      <div className="actions"><button className="btn btn-primary btn-sm" onClick={() => { setYear(now); setOpen(true); }}>Voir mon année</button></div>
      {open && <Recap stats={stats} name={me ? me.name : ''} years={years} setYear={setYear} onClose={() => setOpen(false)} />}
    </section>
  );
}
