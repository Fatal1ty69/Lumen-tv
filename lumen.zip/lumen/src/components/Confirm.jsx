import React, { useEffect, useRef, useState } from 'react';
import { useModalFocus } from '../lib/useModalFocus.js';

// Confirmation intégrée à Lumen, à la place de window.confirm (fenêtre système grise sur PC,
// parfois invisible ou bloquante dans la WebView de la TV).
// Usage : if (await askConfirm({ title, text, ok: 'Effacer', danger: true })) { ... }
let push = null;
let seq = 0;

export function askConfirm(opts) {
  const o = typeof opts === 'string' ? { title: opts } : opts || {};
  if (!push) return Promise.resolve(window.confirm(o.title || o.text || 'Confirmer ?'));
  return new Promise((resolve) => push({ ...o, id: ++seq, resolve }));
}

function Dialog({ req, onDone }) {
  const box = useRef(null);
  const close = (v) => onDone(v);
  useModalFocus(box, { onClose: () => close(false) });

  // Touche Retour de la télécommande : annule
  useEffect(() => {
    const onBack = (e) => { e.preventDefault(); close(false); };
    window.addEventListener('tv-back', onBack);
    return () => window.removeEventListener('tv-back', onBack);
  }, []);

  return (
    <div className="modal confirm-modal" data-tv-layer role="alertdialog" aria-modal="true" aria-labelledby="lumen-confirm-t" onClick={() => close(false)}>
      <div className="confirm-box" ref={box} tabIndex={-1} onClick={(e) => e.stopPropagation()}>
        <h2 id="lumen-confirm-t">{req.title}</h2>
        {req.text && <p className="muted">{req.text}</p>}
        <div className="actions">
          {/* Le bouton sûr a le focus : Entrée par réflexe n'efface rien */}
          <button className="btn btn-ghost" data-autofocus data-tv-autofocus onClick={() => close(false)}>{req.cancel || 'Annuler'}</button>
          <button className={req.danger ? 'btn btn-danger' : 'btn btn-primary'} onClick={() => close(true)}>{req.ok || 'Confirmer'}</button>
        </div>
      </div>
    </div>
  );
}

// À monter une fois dans l'application
export function ConfirmHost() {
  const [queue, setQueue] = useState([]);
  useEffect(() => {
    push = (req) => setQueue((q) => [...q, req]);
    return () => { push = null; };
  }, []);
  const req = queue[0];
  if (!req) return null;
  return (
    <Dialog key={req.id} req={req} onDone={(v) => {
      req.resolve(v);
      setQueue((q) => q.slice(1));
    }} />
  );
}
