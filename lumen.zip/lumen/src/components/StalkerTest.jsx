// Réglages (PC) : test d'un portail Stalker avant de l'ajouter à Lumen
import React, { useState } from 'react';
import { loadJSON, saveJSON } from '../lib/store.js';
import { testPortal, MODELS } from '../lib/stalker.js';
import { Spinner } from './ui.jsx';

export default function StalkerTest() {
  const saved = loadJSON('stalkerTest', {});
  const [portal, setPortal] = useState(saved.portal || '');
  const [mac, setMac] = useState(saved.mac || '');
  const [adv, setAdv] = useState(() => ({ model: '', sn: '', device: '', device2: '', sig: '', ...(saved.adv || {}) }));
  const [showAdv, setShowAdv] = useState(() => !!(saved.adv && Object.values(saved.adv).some(Boolean)));
  const setA = (k) => (e) => setAdv((a) => ({ ...a, [k]: e.target.value }));
  const [steps, setSteps] = useState(null);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState('');

  const run = async () => {
    saveJSON('stalkerTest', { portal: portal.trim(), mac: mac.trim(), adv });
    setBusy(true);
    setSteps([]);
    setCopied('');
    try { await testPortal({ portal, mac, ...adv }, setSteps); } catch (e) { setSteps((s) => [...(s || []), { label: 'Erreur', ok: false, detail: e.message }]); }
    setBusy(false);
  };

  const report = () => ['Test portail Stalker · Lumen', ...(steps || []).map((s) => `${s.ok ? 'OK ' : 'KO '} ${s.label} : ${s.detail || ''}`)].join('\n');
  const copy = async () => {
    try { await navigator.clipboard.writeText(report()); setCopied('Rapport copié : colle-le dans la conversation avec Claude.'); } catch { setCopied('Copie impossible : fais une capture de la carte.'); }
  };

  return (
    <section className="card-box">
      <h2>Portail Stalker (test)</h2>
      <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>
        Vérifie qu'un portail Stalker (adresse du portail et adresse MAC) répond comme Lumen l'attend : connexion, chaînes, guide, films, séries et lecture. Rien n'est ajouté à tes serveurs.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr auto', gap: 10, alignItems: 'end' }}>
        <label className="lbl">Adresse du portail
          <input id="stalker-portal" value={portal} onChange={(e) => setPortal(e.target.value)} placeholder="http://exemple.com/c/" autoComplete="off" />
        </label>
        <label className="lbl">Adresse MAC
          <input id="stalker-mac" value={mac} onChange={(e) => setMac(e.target.value)} placeholder="00:1A:79:00:00:00" autoComplete="off" />
        </label>
        <button className="btn btn-primary btn-sm" onClick={run} disabled={busy || !portal.trim() || !mac.trim()}>{busy ? <><Spinner /> Test…</> : 'Tester'}</button>
      </div>
      <button className="btn btn-ghost btn-sm" style={{ alignSelf: 'flex-start' }} onClick={() => setShowAdv((v) => !v)}>{showAdv ? 'Masquer' : 'Afficher'} les identifiants du boîtier (facultatif)</button>
      {showAdv && (
        <div className="stk-adv">
          <p className="muted" style={{ fontSize: 13, margin: 0, gridColumn: '1 / -1', lineHeight: 1.5 }}>Si une autre appli lit ce portail (STBEmu par exemple), recopie ici les identifiants de son profil : certains portails n'acceptent la MAC qu'avec le même numéro de série et les mêmes identifiants d'appareil. Laisse vide pour que Lumen les calcule.</p>
          <label className="lbl">Modèle
            <select id="stalker-model" value={adv.model} onChange={setA('model')}>
              <option value="">Essayer tous</option>
              {Object.keys(MODELS).map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </label>
          <label className="lbl">Numéro de série<input id="stalker-sn" value={adv.sn} onChange={setA('sn')} placeholder="ex. 0123456789ABC" autoComplete="off" /></label>
          <label className="lbl">Device ID<input id="stalker-dev" value={adv.device} onChange={setA('device')} placeholder="64 caractères" autoComplete="off" /></label>
          <label className="lbl">Device ID 2<input id="stalker-dev2" value={adv.device2} onChange={setA('device2')} placeholder="souvent identique" autoComplete="off" /></label>
          <label className="lbl">Signature<input id="stalker-sig" value={adv.sig} onChange={setA('sig')} placeholder="64 caractères" autoComplete="off" /></label>
        </div>
      )}
      {steps && steps.length > 0 && (
        <div className="stk-steps">
          {steps.map((s, i) => (
            <div key={i} className={'stk-step ' + (s.ok ? 'ok' : 'ko')}>
              <i>{s.ok ? '✓' : '✕'}</i>
              <div><b>{s.label}</b><span>{s.detail}</span></div>
            </div>
          ))}
          {busy && <div className="stk-step"><Spinner /><div><span>Étape suivante…</span></div></div>}
        </div>
      )}
      {steps && steps.length > 0 && !busy && (
        <div className="actions" style={{ marginTop: 0 }}>
          <button className="btn btn-ghost btn-sm" onClick={copy}>Copier le rapport</button>
          {copied && <span className="muted" style={{ fontSize: 13, alignSelf: 'center' }}>{copied}</span>}
        </div>
      )}
    </section>
  );
}
