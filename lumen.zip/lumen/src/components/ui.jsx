// Composants visuels partagés
import React, { useEffect, useRef, useState } from 'react';
import { useModalFocus } from '../lib/useModalFocus.js';
import { useCardMeta, fmtLen } from '../lib/cardMeta.js';
import { endAt, lenMinutes } from '../lib/fmt.js';
import { isTV } from '../tv/native.js';

// v43 : sur la TV, les vignettes TMDB venues du serveur sont ramenées à une taille de carte
const tvSized = (u) => (isTV && typeof u === 'string' && u.includes('image.tmdb.org/t/p/')
  ? u.replace(/\/t\/p\/(original|w1280)\//, '/t/p/w780/').replace(/\/t\/p\/w(500|600|780)[^/]*\/(?=[^/]+\.(jpe?g|png|webp)$)/i, (m) => (/w780/.test(m) ? m : '/t/p/w342/'))
  : u);

const PATHS = {
  play: <path d="M6 4l14 8-14 8z" fill="currentColor" stroke="none" />,
  pause: <g fill="currentColor" stroke="none"><rect x="6" y="4" width="4" height="16" rx="1" /><rect x="14" y="4" width="4" height="16" rx="1" /></g>,
  info: <g><circle cx="12" cy="12" r="9" /><path d="M12 11v6M12 7.5v.5" /></g>,
  search: <g><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></g>,
  bell: <g><path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8" /><path d="M10.3 20a1.9 1.9 0 0 0 3.4 0" /></g>,
  plus: <path d="M12 5v14M5 12h14" />,
  check: <path d="M5 12.5l4.5 4.5L19 7" />,
  clock: <g><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></g>,
  spark: <path d="M12 3l1.9 5.6L19.5 10l-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.4z" fill="currentColor" stroke="none" />,
  star: <path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z" fill="currentColor" stroke="none" />,
  back: <path d="M15 5l-7 7 7 7" />,
  next: <path d="M9 5l7 7-7 7" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  gear: <g><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" /></g>,
  volume: <g><path d="M11 5L6 9H2v6h4l5 4z" fill="currentColor" /><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14" /></g>,
  mute: <g><path d="M11 5L6 9H2v6h4l5 4z" fill="currentColor" /><path d="M23 9l-6 6M17 9l6 6" /></g>,
  full: <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />,
  rewind: <g><path d="M11 17l-5-5 5-5" /><path d="M18 17l-5-5 5-5" /></g>,
  forward: <g><path d="M13 17l5-5-5-5" /><path d="M6 17l5-5-5-5" /></g>,
  external: <g><path d="M14 4h6v6" /><path d="M20 4l-9 9" /><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5" /></g>,
  refresh: <g><path d="M20 11a8 8 0 1 0-2.3 5.7" /><path d="M20 5v6h-6" /></g>,
  calendar: <g><rect x="3.5" y="5" width="17" height="15" rx="2" /><path d="M3.5 10h17M8 3v4M16 3v4" /></g>,
  subs: <g><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M7 13h4M13 13h4M7 16h7" /></g>,
  tv: <g><rect x="3" y="5" width="18" height="12" rx="2" /><path d="M8 21h8M12 17v4" /></g>
};

export function Icon({ name, size = 22, stroke = 2, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke}
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {PATHS[name]}
    </svg>
  );
}

// Couleur stable dérivée du titre pour les affiches de secours
const FALLBACK_COLORS = ['#3B2A1E', '#1E2B3B', '#2B1E3B', '#1E3B2E', '#3B1E25', '#2E2E1E', '#1E333B', '#33231A'];
function colorFor(s) {
  let h = 0;
  for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return FALLBACK_COLORS[h % FALLBACK_COLORS.length];
}

export function Img({ src, alt = '', className, title, style, fit, fallback }) {
  const [bad, setBad] = useState(false);
  const [useFb, setUseFb] = useState(false);
  // Image de secours si la première ne charge pas
  if ((!src || bad) && fallback && !useFb) { setUseFb(true); setBad(false); }
  if (useFb && fallback) src = fallback;
  src = tvSized(src);
  if (!src || bad) {
    return title
      ? <div className="fallback" style={{ background: colorFor(title) }} aria-hidden="true">{title}</div>
      : <div style={{ position: 'absolute', inset: 0, background: '#17171B' }} aria-hidden="true" />;
  }
  return <img src={src} alt={alt} className={className} style={{ ...(fit ? { objectFit: fit } : {}), ...style }}
    loading="lazy" decoding="async" onError={() => setBad(true)} />;
}

export function Spinner({ center }) {
  return <div className={'spinner' + (center ? ' center-spin' : '')} role="status" aria-label="Chargement" />;
}

// État affiché quand une liste est vide, en cours de chargement, ou en erreur.
// variant : 'empty' | 'error' | 'info' ; action : { label, onClick } optionnel
export function EmptyState({ icon = 'tv', title, hint, action, variant = 'empty' }) {
  return (
    <div className={'empty-state ' + variant} role="status">
      <div className="empty-ico" aria-hidden="true"><Icon name={icon} size={30} /></div>
      {title && <p className="empty-title">{title}</p>}
      {hint && <p className="empty-hint">{hint}</p>}
      {action && <button className="btn btn-primary btn-sm" onClick={action.onClick}>{action.label}</button>}
    </div>
  );
}

// Fausse rangée de cartes pendant le chargement, pour éviter l'écran qui saute
export function SkeletonRow({ cards = 7, land = false }) {
  return (
    <section className="skel-section" aria-hidden="true">
      <div className="row-head"><div className="skel skel-h2" /></div>
      <div className="row-wrap">
        <div className="row-track">
          {Array.from({ length: cards }).map((_, i) => (
            <div key={i} className={'skel skel-card' + (land ? ' land' : '')} />
          ))}
        </div>
      </div>
    </section>
  );
}

// Squelette du bandeau « à la une » (s'insère dans la section .hero existante)
export function HeroSkel() {
  return (
    <>
      <div className="scrim-bottom" />
      <div className="hero-body hero-skel" aria-hidden="true">
        <div className="skel skel-line" style={{ width: 160, height: 16 }} />
        <div className="skel skel-line" style={{ width: '46%', height: 52, marginTop: 16 }} />
        <div className="skel skel-line" style={{ width: '38%', height: 14, marginTop: 18 }} />
        <div className="skel skel-line" style={{ width: '60%', height: 13, marginTop: 10 }} />
        <div className="skel skel-line" style={{ width: '52%', height: 13, marginTop: 6 }} />
        <div className="skel-actions">
          <div className="skel skel-btn" />
          <div className="skel skel-btn ghost" />
        </div>
      </div>
    </>
  );
}

// v43 : sur la TV, « Tout voir » et les bascules deviennent des cartes en fin de rangée,
// au lieu de petits boutons dans le titre qu'on attrape par erreur en descendant
function EndCard({ label, icon = 'next', onClick, reset }) {
  return (
    <button className="card end-card" onClick={(e) => {
      const tr = e.currentTarget.closest('.row-track');
      onClick();
      if (reset && tr) setTimeout(() => { tr.scrollLeft = 0; const f = tr.querySelector('.card'); if (f) f.focus({ preventScroll: true }); }, 60);
    }}>
      <span className="ec-ic"><Icon name={icon} size={26} stroke={2.4} /></span>
      <span className="ec-lab">{label}</span>
    </button>
  );
}

export function Row({ title, onSeeAll, action, extra, children, tvSwitch }) {
  const track = useRef(null);
  if (isTV) {
    return (
      <section>
        <div className="row-head">
          <h2 className="row-title">{title}</h2>
          {extra}
        </div>
        <div className="row-wrap">
          <div className="row-track" ref={track}>
            {children}
            {tvSwitch && <EndCard label={tvSwitch.label} icon="refresh" onClick={tvSwitch.onClick} reset />}
            {onSeeAll && <EndCard label="Tout voir" onClick={onSeeAll} />}
            {action && <EndCard label={action.label} onClick={action.onClick} />}
          </div>
        </div>
      </section>
    );
  }
  const scroll = (dir) => {
    const el = track.current;
    if (el) el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: 'smooth' });
  };
  return (
    <section>
      <div className="row-head">
        <h2 className="row-title">{title}</h2>
        {extra}
        {onSeeAll && <button className="see-all" onClick={onSeeAll}>Tout voir</button>}
        {action && <button className="see-all" onClick={action.onClick}>{action.label}</button>}
      </div>
      <div className="row-wrap">
        <button className="row-arrow l" onClick={() => scroll(-1)} aria-label="Défiler à gauche"><Icon name="back" size={28} /></button>
        <div className="row-track" ref={track}>{children}</div>
        <button className="row-arrow r" onClick={() => scroll(1)} aria-label="Défiler à droite"><Icon name="next" size={28} /></button>
      </div>
    </section>
  );
}

// v33 : étiquette d'infos en bas de l'affiche (note, année, durée ou saisons)
function CardMeta({ item, meta, compact = false, top = false }) {
  const m = useCardMeta(item, meta);
  const r = Number(m.rating) || 0;
  const tone = r >= 7.5 ? ' good' : r >= 6.5 ? ' mid' : '';
  // Série en cours : les épisodes vus parlent plus que le nombre de saisons
  const third = m.kind === 'series'
    ? (!compact && m.epCount ? m.epCount + ' ép.' : m.seasons ? m.seasons + (m.seasons > 1 ? ' saisons' : ' saison') : 'Série')
    : (compact ? '' : fmtLen(m.len));
  const end = !compact && m.kind === 'movie' && m.left ? endAt(m.left) : '';
  return (
    <>
      <div className={'card-meta' + (top ? ' top' : '')} ref={m.ref}>
        {r > 0 && <span className={'cm-note' + tone}><Icon name="star" size={11} />{r.toFixed(1)}</span>}
        {m.year > 0 && <span className="cm-chip">{m.year}</span>}
        {third && <span className={'cm-chip' + (end ? ' cm-len' : '')}>{third}</span>}
        {end && <span className="cm-chip cm-end">Fin {end}</span>}
        {!compact && m.quality && <span className="cm-chip cm-q">{m.quality}</span>}
      </div>
      {m.seen && !top && <span className={'cm-seen-dot' + (m.seen === 'Vu' ? '' : ' soft')} title={m.seen === 'Vu' ? 'Déjà vu' : 'À jour : tous les épisodes disponibles sont vus'} aria-label={m.seen === 'Vu' ? 'Déjà vu' : 'À jour'}><Icon name="check" size={14} stroke={3} /></span>}
      {!compact && m.pct > 0 && <div className="card-prog" aria-hidden="true"><i style={{ width: Math.max(3, m.pct) + '%' }} /></div>}
    </>
  );
}

// v38 : bandeau de Découvrir et des Plateformes, mêmes pastilles que l'accueil
export function HeroChips({ x, fv }) {
  if (!x) return null;
  const len = (fv && fv.len) || '';
  const isMovie = x.type !== 'tv';
  return (
    <>
      <MetaChips score={x.score} year={String(x.date || '').slice(0, 4)} len={len} end={isMovie && len ? endAt(lenMinutes(len)) : ''} />
      {fv && fv.genres && fv.genres.length > 0 && <div className="hero-genres">{fv.genres.slice(0, 3).join(' · ')}</div>}
    </>
  );
}

// v35 : pastilles du bandeau « à la une », dans le même style que les tuiles
export function MetaChips({ score, year, len, extra, end }) {
  const r = Number(score) || 0;
  const tone = r >= 7.5 ? ' good' : r >= 6.5 ? ' mid' : '';
  return (
    <div className="meta-chips">
      {r > 0 && <span className={'cm-note' + tone}><Icon name="star" size={13} />{r.toFixed(1)}</span>}
      {year && <span className="cm-chip">{year}</span>}
      {len && <span className="cm-chip">{len}</span>}
      {extra && <span className="cm-chip soft">{extra}</span>}
      {end && <span className="cm-chip">Fin à {end}</span>}
    </div>
  );
}

export function PosterCard({ title, poster, sub, badge, home, onOpen, onFocus, focused, showTitle = false, itemKey, onRemove, removeLabel = 'cette liste', item, meta }) {
  const card = (
    <button className={'card poster' + (focused ? ' focused' : '')} onClick={onOpen} data-item-key={itemKey || undefined}
      onMouseEnter={onFocus} onFocus={onFocus} aria-label={title}>
      <div className="frame">
        <Img src={poster} className="cover" title={title} />
        {showTitle && poster && <><div className="shade" /><div className="ptitle">{title}</div></>}
        {badge && <div className="badge">{badge}</div>}
        {home && <div className="badge home">CHEZ TOI</div>}
        {(item || meta) && <CardMeta item={item} meta={meta} />}
      </div>
      {sub !== undefined && <div className="card-sub">{sub}</div>}
    </button>
  );
  if (!onRemove) return card;
  return (
    <div className="poster-wrap">
      {card}
      <button className="rm-btn" onClick={(e) => { e.stopPropagation(); onRemove(); }}
        aria-label={'Retirer ' + title + ' de ' + removeLabel} title={'Retirer de ' + removeLabel}>
        <Icon name="close" size={16} />
      </button>
    </div>
  );
}

export function LandCard({ title, image, fallback, sub, pct, onOpen, onRemove, badge, removeLabel = 'Continuer à regarder', item }) {
  return (
    <div className="land-wrap">
      <button className="card land" onClick={onOpen} aria-label={'Reprendre ' + title}>
        <div className="frame">
          <Img src={image} fallback={fallback} className="cover" title={title} />
          <div className="shade" />
          <div className="ptitle">{title}</div>
          {badge && <div className="badge">{badge}</div>}
          {!badge && <div className="bar"><i style={{ width: Math.min(100, Math.max(2, pct)) + '%' }} /></div>}
          {item && <CardMeta item={item} compact top />}
        </div>
        <div className="card-sub">{sub}</div>
      </button>
      {onRemove && (
        <button className="rm-btn" onClick={onRemove} aria-label={'Retirer ' + title + ' de ' + removeLabel} title={'Retirer de ' + removeLabel}>
          <Icon name="close" size={16} />
        </button>
      )}
    </div>
  );
}

export function Top10Card({ rank, title, poster, onOpen }) {
  return (
    <button className="card top10" onClick={onOpen} aria-label={`Numéro ${rank}, ${title}`}>
      <span className="num" aria-hidden="true">{rank}</span>
      <div className="frame"><Img src={poster} className="cover" title={title} /></div>
    </button>
  );
}

export function Tile({ name, sub, onOpen, logo }) {
  return (
    <button className="card tile" onClick={onOpen} aria-label={name}>
      {logo ? <img className="tile-logo" src={logo} alt="" /> : null}
      <b>{name}</b>{sub && <span>{sub}</span>}
    </button>
  );
}

export function CatTile({ name, image, onOpen }) {
  return (
    <button className="card cat-tile" onClick={onOpen} aria-label={name}>
      <div className="frame">
        <Img src={image} className="cover" />
        <div className="veil" />
        <div className="cname">{name}</div>
      </div>
    </button>
  );
}

export function TrailerModal({ ytKey, onClose }) {
  const box = useRef(null);
  useModalFocus(box, { enabled: !!ytKey });
  useEffect(() => {
    if (!ytKey) return;
    // Échap ferme seulement la bande-annonce, pas la fiche derrière
    const onKey = (e) => {
      if (e.key === 'Escape' || e.key === 'Backspace') { e.stopImmediatePropagation(); e.preventDefault(); onClose(); }
    };
    // Touche Retour de la télécommande
    const onBack = (e) => { e.preventDefault(); onClose(); };
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('tv-back', onBack);
    return () => { window.removeEventListener('keydown', onKey, true); window.removeEventListener('tv-back', onBack); };
  }, [ytKey, onClose]);
  if (!ytKey) return null;
  return (
    <div className="modal" onClick={(e) => { e.stopPropagation(); onClose(); }} role="dialog" aria-label="Bande-annonce">
      <div className="modal-inner" ref={box} onClick={(e) => e.stopPropagation()}>
        <div className="modal-top">
          <span className="kicker">Bande-annonce</span>
          <button className="btn btn-ghost btn-sm" onClick={onClose} autoFocus><Icon name="close" size={16} />Fermer</button>
        </div>
        <div className="box">
          <iframe title="Bande-annonce" allow="autoplay; fullscreen; encrypted-media" allowFullScreen
            src={`https://www.youtube-nocookie.com/embed/${ytKey}?autoplay=1&rel=0&hl=fr&cc_lang_pref=fr`} />
        </div>
      </div>
    </div>
  );
}
