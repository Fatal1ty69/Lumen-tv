// Réglages : synchronisation maison entre Lumen PC et Lumen TV (même réseau)
import React, { useEffect, useState } from 'react';
import { isTV, native } from '../tv/native.js';
import { syncState, syncNow, tvLink, setTvLink } from '../lib/sync.js';
import { useReceiverInfo } from '../tv/TvReceive.jsx';
import { Spinner } from './ui.jsx';

function when(t) {
  if (!t) return 'jamais';
  const d = new Date(t);
  const today = new Date().toDateString() === d.toDateString();
  const hm = d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  return today ? `aujourd'hui à ${hm}` : d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' }) + ' à ' + hm;
}

function useSyncState() {
  const [s, setS] = useState(syncState);
  useEffect(() => {
    const on = (e) => setS(e.detail || syncState());
    const st = () => setS(syncState());
    window.addEventListener('lumen:sync', on);
    window.addEventListener('lumen:storage', st);
    const t = setInterval(st, 15000);
    return () => { window.removeEventListener('lumen:sync', on); window.removeEventListener('lumen:storage', st); clearInterval(t); };
  }, []);
  return s;
}

const INTRO = 'Ta progression, Ma liste, Mes séries, tes chaînes favorites et tes rappels passent tout seuls d\'un appareil à l\'autre, pour chaque profil. La TV fait référence : le PC vient la voir à son ouverture, après chaque lecture et toutes les 90 secondes.';

// Sur la TV : rien à faire, on affiche juste l'état et le code
function TvSide() {
  const s = useSyncState();
  const info = useReceiverInfo();
  return (
    <section className="card-box">
      <h2>Synchronisation</h2>
      <p className="muted" style={{ fontSize: 15, lineHeight: 1.6 }}>{INTRO}</p>
      <div className="sync-status">
        <i className={'sync-dot' + (s.last ? ' ok' : '')} />
        <span>{s.last ? `Dernière synchro avec le PC : ${when(s.last)}` : 'Pas encore de synchro avec le PC'}</span>
      </div>
      {info && info.ip && <p className="muted" style={{ fontSize: 15 }}>Pour associer le PC : adresse <b>{info.ip}</b>, code <b>{info.code}</b> (Réglages de Lumen PC, carte « Synchronisation »).</p>}
    </section>
  );
}

function PcSide() {
  const s = useSyncState();
  const [link, setLink] = useState(tvLink);
  const [addr, setAddr] = useState(() => (tvLink() && tvLink().host) || '');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  const pair = async () => {
    setMsg('');
    const host = addr.trim().replace(/^https?:\/\//, '').replace(/[:/].*$/, '');
    if (!host || !/^\d{4}$/.test(code.trim())) { setMsg('Indique l\'adresse et le code à 4 chiffres affichés sur la TV.'); return; }
    setBusy(true);
    const l = { host, port: 47820, code: code.trim(), paired: Date.now() };
    setTvLink(l);
    const r = await syncNow('association');
    setBusy(false);
    if (r && r.ok) { setLink(l); setCode(''); }
    else { setTvLink(null); setMsg((r && r.error) || 'La TV ne répond pas.'); }
  };

  if (!link) {
    return (
      <section className="card-box">
        <h2>Synchronisation</h2>
        <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>{INTRO} Il suffit de l'associer une fois : ouvre Lumen sur la TV, Réglages, carte « Synchronisation », et recopie l'adresse et le code.</p>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr auto', gap: 10, alignItems: 'end' }}>
          <label className="lbl">Adresse de la TV
            <input value={addr} onChange={(e) => setAddr(e.target.value)} placeholder="192.168.1.42" autoComplete="off" />
          </label>
          <label className="lbl">Code
            <input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="0000" inputMode="numeric" autoComplete="off" />
          </label>
          <button className="btn btn-primary btn-sm" onClick={pair} disabled={busy}>{busy ? <><Spinner /> Association…</> : 'Associer'}</button>
        </div>
        {msg && <p className="err">{msg}</p>}
      </section>
    );
  }

  const dot = s.busy ? 'busy' : s.ok === false ? 'err' : s.last ? 'ok' : '';
  return (
    <section className="card-box">
      <h2>Synchronisation</h2>
      <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>{INTRO}</p>
      <div className="sync-status">
        <i className={'sync-dot ' + dot} />
        <span>
          {s.busy ? 'Synchronisation en cours…' : `Dernière synchro : ${when(s.last)}`}
          {!s.busy && s.ok === false && s.error && <span className="muted"> · {s.error}</span>}
        </span>
      </div>
      <p className="muted" style={{ fontSize: 13 }}>TV associée : {link.host}{s.changed ? ` · ${s.changed} rubrique${s.changed > 1 ? 's' : ''} mise${s.changed > 1 ? 's' : ''} à jour la dernière fois` : ''}</p>
      <div className="actions" style={{ marginTop: 10 }}>
        <button className="btn btn-primary btn-sm" disabled={s.busy} onClick={() => syncNow('manuel')}>Synchroniser maintenant</button>
        <button className="btn btn-ghost btn-sm" onClick={() => { if (window.confirm('Ne plus synchroniser avec cette TV ?')) { setTvLink(null); setLink(null); } }}>Dissocier</button>
      </div>
    </section>
  );
}

export default function SyncCard() {
  if (isTV) return native || /[?&]tv=1/.test(location.search) ? <TvSide /> : null;
  if (!window.lumen) return null;
  return <PcSide />;
}
