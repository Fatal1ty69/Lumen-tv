// Réglages : afficher ou masquer les groupes du serveur
import React, { useMemo, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { norm } from '../lib/titles.js';
import { Icon } from './ui.jsx';

const TYPES = [
  { k: 'live', label: 'Direct', cats: 'liveCats', items: 'live' },
  { k: 'vod', label: 'Films', cats: 'vodCats', items: 'vod' },
  { k: 'series', label: 'Séries', cats: 'seriesCats', items: 'series' }
];

export default function Categories() {
  const { rawCatalog, hiddenCats, setHidden } = useApp();
  const [type, setType] = useState('live');
  const [q, setQ] = useState('');
  const [show, setShow] = useState('all');
  const t = TYPES.find((x) => x.k === type);

  const counts = useMemo(() => {
    const m = new Map();
    if (rawCatalog) for (const it of rawCatalog[t.items]) m.set(it.cat, (m.get(it.cat) || 0) + 1);
    return m;
  }, [rawCatalog, type]);

  if (!rawCatalog) return <p className="muted">Le catalogue n'est pas encore chargé.</p>;

  const hidden = new Set(hiddenCats[type] || []);
  const all = rawCatalog[t.cats];
  const n = norm(q);
  const list = all.filter((c) => (!n || norm(c.name).includes(n)) && (show === 'all' || (show === 'on' ? !hidden.has(c.id) : hidden.has(c.id))));
  const ids = list.map((c) => c.id);
  const visibleCount = all.filter((c) => !hidden.has(c.id)).length;

  return (
    <div className="cats-mgr">
      <div className="toolbar" style={{ marginBottom: 0 }}>
        <div className="seg" role="tablist" aria-label="Type de groupes">
          {TYPES.map((x) => {
            const h = (hiddenCats[x.k] || []).length;
            return (
              <button key={x.k} role="tab" aria-selected={type === x.k} className={type === x.k ? 'on' : ''} onClick={() => { setType(x.k); setQ(''); setShow('all'); }}>
                {x.label}{h ? ` · ${h} masqué${h > 1 ? 's' : ''}` : ''}
              </button>
            );
          })}
        </div>
      </div>
      <div className="toolbar" style={{ marginBottom: 0 }}>
        <div className="field" style={{ flex: '1 1 260px' }}>
          <Icon name="search" size={18} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filtrer, par exemple « FR » ou « AR | »" aria-label="Filtrer les groupes" style={{ minWidth: 0, width: '100%' }} />
        </div>
        <div className="seg" role="group" aria-label="Afficher">
          {[['all', 'Tous'], ['on', 'Affichés'], ['off', 'Masqués']].map(([k, l]) => (
            <button key={k} className={show === k ? 'on' : ''} onClick={() => setShow(k)}>{l}</button>
          ))}
        </div>
      </div>
      <div className="toolbar" style={{ marginBottom: 0 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => setHidden(type, ids, false)} disabled={!ids.length}>
          <Icon name="check" size={16} />{q || show !== 'all' ? `Afficher ces ${ids.length}` : 'Tout afficher'}
        </button>
        <button className="btn btn-ghost btn-sm" onClick={() => setHidden(type, ids, true)} disabled={!ids.length}>
          <Icon name="close" size={16} />{q || show !== 'all' ? `Masquer ces ${ids.length}` : 'Tout masquer'}
        </button>
        <span className="muted" style={{ fontSize: 14 }}>{visibleCount} sur {all.length} affichés</span>
      </div>
      <div className="cats-list" role="group" aria-label={'Groupes ' + t.label}>
        {list.map((c) => {
          const on = !hidden.has(c.id);
          return (
            <label key={c.id} className={'cat-row' + (on ? '' : ' off')}>
              <input type="checkbox" checked={on} onChange={() => setHidden(type, [c.id], on)} />
              <span className="cat-name">{c.name || 'Sans nom'}</span>
              <span className="cat-count">{counts.get(c.id) || 0}</span>
            </label>
          );
        })}
        {list.length === 0 && <p className="muted" style={{ padding: 12 }}>Aucun groupe ne correspond.</p>}
      </div>
    </div>
  );
}
