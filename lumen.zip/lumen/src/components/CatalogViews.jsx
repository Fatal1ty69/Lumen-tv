// Façons de parcourir un catalogue de films ou de séries
import React from 'react';
import { Img, PosterCard } from './ui.jsx';

export const VIEWS = [
  { id: 'grille', name: 'Grille' },
  { id: 'mur', name: "Mur d'affiches" },
  { id: 'chrono', name: 'Chronologie' },
  { id: 'videoclub', name: 'Vidéoclub' },
  { id: 'liste', name: 'Liste' }
];

const sub = (it) => [it.year, it.rating ? '★ ' + it.rating.toFixed(1) : ''].filter(Boolean).join(' · ');

// Couleur de tranche VHS stable pour un titre
const SPINES = ['#1F3A5F', '#5F1F2A', '#2F4F2F', '#4A3A1A', '#3A2A5A', '#1A4A4A', '#5A3A1A', '#2A2A2A', '#6A1A1A', '#1A3A2A'];
function spineColor(s) {
  let h = 0;
  for (const c of String(s)) h = (h * 33 + c.charCodeAt(0)) >>> 0;
  return SPINES[h % SPINES.length];
}

export function CatalogView({ view, items, onOpen }) {
  if (view === 'mur') {
    return (
      <div className="wall">
        {items.map((it) => (
          <button key={it.key} data-item-key={it.key} className="wall-item" onClick={() => onOpen(it)} aria-label={it.title}>
            <Img src={it.poster} className="cover" title={it.title} />
            <span className="wall-cap"><b>{it.title}</b><small>{sub(it)}</small></span>
          </button>
        ))}
      </div>
    );
  }

  if (view === 'chrono') {
    const byYear = new Map();
    for (const it of items) {
      const y = it.year || 'Sans date';
      if (!byYear.has(y)) byYear.set(y, []);
      byYear.get(y).push(it);
    }
    const years = [...byYear.keys()].sort((a, b) => (b === 'Sans date' ? -1 : a === 'Sans date' ? 1 : b - a));
    return (
      <div className="chrono">
        {years.map((y) => (
          <section key={y} className="chrono-year">
            <div className="chrono-mark"><span>{y}</span><small>{byYear.get(y).length} titre{byYear.get(y).length > 1 ? 's' : ''}</small></div>
            <div className="chrono-items">
              {byYear.get(y).map((it) => (
                <PosterCard key={it.key} itemKey={it.key} title={it.title} poster={it.poster} sub={it.rating ? '★ ' + it.rating.toFixed(1) : ''} onOpen={() => onOpen(it)} />
              ))}
            </div>
          </section>
        ))}
      </div>
    );
  }

  if (view === 'videoclub') {
    const shelves = [];
    for (let i = 0; i < items.length; i += 18) shelves.push(items.slice(i, i + 18));
    return (
      <div className="vclub">
        {shelves.map((sh, i) => (
          <div key={i} className="shelf">
            {sh.map((it) => (
              <button key={it.key} data-item-key={it.key} className="vhs" onClick={() => onOpen(it)} aria-label={it.title} style={{ '--spine': spineColor(it.title) }}>
                <span className="vhs-spine">
                  <span className="vhs-brand">LUMEN</span>
                  <span className="vhs-title">{it.title}</span>
                  <span className="vhs-year">{it.year || ''}</span>
                </span>
                <span className="vhs-cover"><Img src={it.poster} className="cover" title={it.title} /></span>
              </button>
            ))}
          </div>
        ))}
      </div>
    );
  }

  if (view === 'liste') {
    return (
      <div className="lview">
        {items.map((it) => (
          <button key={it.key} data-item-key={it.key} className="lview-row" onClick={() => onOpen(it)}>
            <span className="lview-th"><Img src={it.backdrop || it.poster} className="cover" title={it.title} /></span>
            <span className="lview-tx">
              <b>{it.title}</b>
              <span className="muted">{[it.year, it.genre && it.genre.split(/[,/]/)[0], it.rating ? '★ ' + it.rating.toFixed(1) : ''].filter(Boolean).join(' · ')}</span>
              {it.plot && <span className="lview-plot">{it.plot}</span>}
            </span>
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className="grid">
      {items.map((it) => <PosterCard key={it.key} itemKey={it.key} title={it.title} poster={it.poster} sub={sub(it)} onOpen={() => onOpen(it)} />)}
    </div>
  );
}
