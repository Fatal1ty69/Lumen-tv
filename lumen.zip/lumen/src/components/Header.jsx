import { isTV } from '../tv/native.js';
import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { Icon } from './ui.jsx';
import { RemindersPanel } from '../lib/reminders.jsx';

const LINKS = [
  { label: 'Accueil', route: { name: 'home' } },
  { label: 'Direct', route: { name: 'live' } },
  { label: 'Films', route: { name: 'browse', kind: 'movie' } },
  { label: 'Séries', route: { name: 'browse', kind: 'series' } },
  { label: 'Mes séries', route: { name: 'messeries' } },
  { label: 'Plateformes', route: { name: 'vitrine' } },
  { label: 'Découvrir', route: { name: 'decouvrir' } },
  { label: 'Agenda', route: { name: 'agenda' } },
  { label: 'Ma liste', route: { name: 'mylist' } }
];

function same(a, b) {
  return a.name === b.name && (a.kind || null) === (b.kind || null);
}

export default function Header({ solid, base }) {
  const { goRoot, navigate, account, reminders, searchHistory, addSearch, removeSearch, clearSearch } = useApp();
  const [focused, setFocused] = useState(false);
  const [panel, setPanel] = useState(false);
  const [clock, setClock] = useState(() => new Date());
  useEffect(() => { const t = setInterval(() => setClock(new Date()), 15000); return () => clearInterval(t); }, []);
  const pending = reminders.filter((r) => (r.end || r.start + 3600000) > Date.now()).length;
  const [open, setOpen] = useState(base.name === 'search');
  const [q, setQ] = useState(base.name === 'search' ? base.q || '' : '');
  const input = useRef(null);

  useEffect(() => {
    if (base.name !== 'search') { setOpen(false); setQ(''); }
    else { setOpen(true); setQ(base.q || ''); }
  }, [base.name, base.q]);

  const onSearch = (v) => {
    setQ(v);
    if (base.name === 'search') goRoot({ name: 'search', q: v });
    else if (v.trim().length >= 2) navigate({ name: 'search', q: v });
  };

  return (
    <header className={'header' + (solid ? ' solid' : '')}>
      <button className="logo" onClick={() => goRoot({ name: 'home' })} aria-label="Lumen, accueil">LUMEN</button>
      <nav className="nav" aria-label="Navigation principale">
        {LINKS.map((l) => (
          <button key={l.label} className={same(base, l.route) || (l.route.name === 'browse' && base.name === 'browse' && base.kind === l.route.kind) ? 'on' : ''}
            onClick={() => goRoot(l.route)}>{l.label}</button>
        ))}
      </nav>
      <div className="head-right">
        <div className={'search-box' + (open ? ' open' : '')}>
          <button className="icon-btn" style={{ width: 32, height: 32 }} aria-label="Rechercher"
            onClick={() => { if (isTV) { goRoot({ name: 'search', q: '' }); return; } setOpen(true); if (input.current) input.current.focus(); }}>
            <Icon name="search" />
          </button>
          <input ref={input} value={q} placeholder="Films, séries, chaînes" aria-label="Rechercher"
            onChange={(e) => onSearch(e.target.value)}
            onFocus={() => setFocused(true)}
            onKeyDown={(e) => { if (e.key === 'Enter') { addSearch(q); if (base.name !== 'search' && q.trim().length >= 2) navigate({ name: 'search', q }); } }}
            onBlur={() => { setFocused(false); if (!q) setOpen(false); }} />
          {focused && !q && searchHistory.length > 0 && (
            <div className="search-hist" onMouseDown={(e) => e.preventDefault()}>
              <div className="sh-head"><span>Recherches récentes</span><button onClick={clearSearch}>Effacer</button></div>
              {searchHistory.map((h) => (
                <div key={h} className="sh-row">
                  <button className="sh-q" onClick={() => { setOpen(true); onSearch(h); }}>
                    <Icon name="refresh" size={15} />{h}
                  </button>
                  <button className="sh-x" onClick={() => removeSearch(h)} aria-label={'Retirer ' + h}><Icon name="close" size={14} /></button>
                </div>
              ))}
            </div>
          )}
        </div>
        <button className="clock" onClick={() => goRoot({ name: 'agenda' })} title="Agenda">
          {String(clock.getHours()).padStart(2, '0')}:{String(clock.getMinutes()).padStart(2, '0')}
        </button>
        <button className="icon-btn" style={{ position: 'relative' }} aria-label={`Rappels (${pending})`} onClick={() => setPanel((v) => !v)}>
          <Icon name="bell" />
          {pending > 0 && <span className="bell-count">{pending}</span>}
        </button>
        <button className="icon-btn" aria-label="Réglages" onClick={() => goRoot({ name: 'settings' })}><Icon name="gear" /></button>
        <button className="avatar" aria-label={'Profil ' + (account ? account.name : '')} onClick={() => goRoot({ name: 'settings' })}>
          {(account && account.name ? account.name[0] : 'A').toUpperCase()}
        </button>
      </div>
      {panel && <RemindersPanel onClose={() => setPanel(false)} />}
    </header>
  );
}
