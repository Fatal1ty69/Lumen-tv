import React, { useMemo, useState } from 'react';
import { inspectXmltv, xmltvChannelKey, xmltvNorm } from '../lib/xmltv.js';
import { Icon, Spinner } from './ui.jsx';

export default function XmltvSettings({ account, catalog, updateAccount }) {
  const [url, setUrl] = useState(account.epgUrl || '');
  const [report, setReport] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState('');
  const [channelQuery, setChannelQuery] = useState('');
  const [xmlQuery, setXmlQuery] = useState('');

  const channels = useMemo(() => {
    const all = catalog && catalog.live ? catalog.live : [];
    const own = all.filter((ch) => !ch.acc || ch.acc === account.id);
    return own.length ? own : all;
  }, [catalog, account.id]);

  const saveUrl = () => {
    const value = url.trim();
    if (value !== (account.epgUrl || '')) {
      updateAccount(account.id, { epgUrl: value });
      setReport(null);
    }
    return value;
  };

  const test = async (force = false) => {
    const value = saveUrl();
    if (!value) { setError('Renseigne d’abord l’adresse du guide XMLTV.'); return; }
    setBusy(true); setError('');
    try {
      const next = await inspectXmltv({ ...account, epgUrl: value }, channels, force);
      setReport(next);
      const first = next.matches.find((x) => !x.match) || next.matches[0];
      if (first && !selected) setSelected(first.key);
    } catch (e) { setError(e.message || String(e)); }
    finally { setBusy(false); }
  };

  const selectedRow = report && report.matches.find((x) => x.key === selected);
  const cq = xmltvNorm(channelQuery);
  const xq = xmltvNorm(xmlQuery);
  const xmlChoices = report ? report.xmlChannels
    .filter((x) => !xq || xmltvNorm(`${x.name} ${x.id}`).includes(xq))
    .slice(0, 80) : [];

  const setMap = (xmlId) => {
    if (!selectedRow) return;
    const map = { ...(account.epgMap || {}) };
    if (xmlId) map[selectedRow.key] = xmlId; else delete map[selectedRow.key];
    updateAccount(account.id, { epgMap: map });
    inspectXmltv({ ...account, epgUrl: url.trim(), epgMap: map }, channels, false).then(setReport).catch(() => {});
  };

  return (
    <div className="xmltv-box">
      <div className="xmltv-head">
        <div>
          <b>Guide XMLTV externe</b>
          <span>Prioritaire pour le Direct Stalker, avec correspondance automatique et cache local.</span>
        </div>
        {report && <span className="xmltv-score">{report.matched}/{report.matches.length} chaînes associées</span>}
      </div>
      <div className="xmltv-url">
        <input value={url} onChange={(e) => setUrl(e.target.value)} onBlur={saveUrl}
          placeholder="https://exemple.com/guide.xml ou guide.xml.gz" autoComplete="off" spellCheck={false} />
        <button className="btn btn-ghost btn-sm" onClick={() => test(false)} disabled={busy || !channels.length}>
          {busy ? <Spinner /> : <Icon name="refresh" size={15} />}{report ? 'Vérifier' : 'Tester et associer'}
        </button>
        {report && <button className="btn btn-ghost btn-sm" onClick={() => test(true)} disabled={busy}>Actualiser le cache</button>}
      </div>
      {!channels.length && <span className="muted" style={{ fontSize: 12 }}>Le catalogue doit être chargé pour vérifier les associations.</span>}
      {error && <span className="err" style={{ fontSize: 13 }}>{error}</span>}
      {report && (
        <>
          <div className="xmltv-stats">
            <span><b>{report.totalChannels}</b> chaînes dans le XMLTV</span>
            <span><b>{report.totalProgrammes}</b> programmes utiles</span>
            <span className={report.unmatched ? 'warn' : 'ok'}><b>{report.unmatched}</b> sans correspondance</span>
            <span>{report.meta && report.meta.cached ? 'Cache local utilisé' : 'Guide téléchargé'}</span>
          </div>
          <details className="xmltv-map" open={report.unmatched > 0}>
            <summary>Corriger une correspondance manuellement</summary>
            <div className="xmltv-grid">
              <div className="xmltv-list">
                <input value={channelQuery} onChange={(e) => setChannelQuery(e.target.value)} placeholder="Filtrer les chaînes…" />
                <div>
                  {report.matches.filter((x) => !cq || xmltvNorm(x.ch.name).includes(cq)).slice(0, 250).map((x) => (
                    <button key={x.key} className={(selected === x.key ? 'on ' : '') + (x.match ? 'matched' : 'missing')} onClick={() => { setSelected(x.key); setXmlQuery(''); }}>
                      <span>{x.ch.name}</span><small>{x.match ? `→ ${x.match.channel.name}${x.match.via === 'manual' ? ' · manuel' : ''}` : 'Non associée'}</small>
                    </button>
                  ))}
                </div>
              </div>
              <div className="xmltv-picker">
                {selectedRow ? <>
                  <b>{selectedRow.ch.name}</b>
                  <span className="muted">Association actuelle : {selectedRow.match ? selectedRow.match.channel.name : 'aucune'}</span>
                  <input value={xmlQuery} onChange={(e) => setXmlQuery(e.target.value)} placeholder="Chercher dans le XMLTV…" autoFocus />
                  <div>
                    {xmlChoices.map((x) => <button key={x.id} className={selectedRow.match && selectedRow.match.channel.id === x.id ? 'on' : ''} onClick={() => setMap(x.id)}><span>{x.name}</span><small>{x.id}</small></button>)}
                  </div>
                  <button className="btn btn-ghost btn-sm" onClick={() => setMap('')}>Revenir à l’association automatique</button>
                </> : <span className="muted">Choisis une chaîne à gauche.</span>}
              </div>
            </div>
          </details>
        </>
      )}
    </div>
  );
}
