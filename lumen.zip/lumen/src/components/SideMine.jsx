import React, { useState } from 'react';
import { loadJSON, saveJSON } from '../lib/store.js';
import { Icon } from './ui.jsx';

// v40 : bloc « Pour toi » de la colonne de gauche, repliable (replié par défaut, choix mémorisé).
// Replié, il tient sur une ligne ; si une de ses listes est ouverte, elle reste visible.
export default function SideMine({ active, children }) {
  const [open, setOpen] = useState(() => loadJSON('sideMineOpen', false));
  const toggle = () => { const v = !open; setOpen(v); saveJSON('sideMineOpen', v); };
  const items = React.Children.toArray(children).filter(Boolean);
  const shown = open ? items : items.filter((c) => c.props && String(c.props.className || '').includes('on'));
  return (
    <div className={'side-group side-mine' + (open ? ' open' : '')}>
      <button className="side-mine-head" onClick={toggle} aria-expanded={open}>
        <span>Pour toi</span>
        <Icon name="next" size={14} />
      </button>
      {shown}
    </div>
  );
}
