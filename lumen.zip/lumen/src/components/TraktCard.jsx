// Réglages : connexion et synchronisation Trakt
import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../lib/app.jsx';
import { Icon } from './ui.jsx';
import { TRAKT_REDIRECT } from '../lib/trakt.js';
import { isTV } from '../tv/native.js';

export default function TraktCard() {
  const { settings, updateSettings, trakt, traktState, traktSync, traktWatched, traktImport } = useApp();
  const [code, setCode] = useState(null);
  const [msg, setMsg] = useState('');
  const [, force] = useState(0);
  const timer = useRef(null);

  useEffect(() => () => clearTimeout(timer.current), []);

  const [waiting, setWaiting] = useState(false);
  const connect = async () => {
    setMsg('');
    if (trakt.usesPkce) {
      setWaiting(true);
      try { await trakt.pkceLogin(); setMsg('Connecté à Trakt.'); force((n) => n + 1); traktSync(); }
      catch (e) { setMsg(e.message); }
      finally { setWaiting(false); }
      return;
    }
    try {
      const c = await trakt.deviceCode();
      setCode(c);
      const started = Date.now();
      const poll = async () => {
        if (Date.now() - started > c.expires_in * 1000) { setCode(null); setMsg('Le code a expiré, recommence.'); return; }
        const r = await trakt.pollToken(c.device_code).catch(() => 'error');
        if (r === 'ok') { setCode(null); setMsg('Connecté à Trakt.'); force((n) => n + 1); traktSync(); return; }
        if (r === 'denied') { setCode(null); setMsg('Connexion refusée sur Trakt.'); return; }
        if (r === 'expired') { setCode(null); setMsg('Le code a expiré, recommence.'); return; }
        timer.current = setTimeout(poll, (c.interval + (r === 'slow' ? 2 : 0)) * 1000);
      };
      timer.current = setTimeout(poll, c.interval * 1000);
    } catch (e) { setMsg(e.message); }
  };

  const shows = Object.keys((traktWatched && traktWatched.shows) || {}).length;
  const movies = Object.keys((traktWatched && traktWatched.movies) || {}).length;

  if (isTV && !trakt.connected) {
    return <p className="muted" style={{ fontSize: 15, lineHeight: 1.6 }}>Pour connecter Trakt à la TV : connecte-le d'abord dans Lumen sur ton PC, puis utilise « Envoyer vers ma TV » dans les Réglages du PC. La connexion Trakt est recopiée avec le reste.</p>;
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <p className="muted" style={{ fontSize: 14, lineHeight: 1.6 }}>
        Trakt garde la liste de tout ce que tu as vu et la partage avec tes autres applis. Pour connecter Lumen : sur trakt.tv, va dans Paramètres, « Your API Apps », crée une application (nom : Lumen, Redirect URIs : <code>{TRAKT_REDIRECT}</code>, Allowed origins : vide), puis colle ici le Client ID. Le Client Secret est facultatif : les applications récentes n'en ont plus.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <label className="lbl">Client ID
          <input value={settings.traktId} onChange={(e) => updateSettings({ traktId: e.target.value.trim() })} autoComplete="off" />
        </label>
        <label className="lbl">Client Secret (facultatif)
          <input type="password" value={settings.traktSecret} onChange={(e) => updateSettings({ traktSecret: e.target.value.trim() })} autoComplete="off" />
        </label>
      </div>

      {trakt.configured && !trakt.connected && !code && !waiting && (
        <button className="btn btn-primary btn-sm" style={{ alignSelf: 'flex-start' }} onClick={connect}>Connecter mon compte Trakt</button>
      )}
      {waiting && (
        <div className="trakt-code">
          <span>Ton navigateur s'est ouvert sur Trakt : connecte-toi et clique sur « Yes » pour autoriser Lumen.</span>
          <span className="muted">En attente de ta validation…</span>
        </div>
      )}
      {code && (
        <div className="trakt-code">
          <span>Ouvre <button className="see-all" onClick={() => (window.lumen ? window.lumen.openExternal(code.verification_url) : window.open(code.verification_url))}>{code.verification_url}</button> et saisis ce code :</span>
          <b>{code.user_code}</b>
          <span className="muted">En attente de ta validation…</span>
        </div>
      )}
      {trakt.connected && (
        <>
          <div className="server-row">
            <span>Connecté{traktState.user ? ' en tant que ' + traktState.user : ''}</span>
            <span className="muted" style={{ fontWeight: 400, fontSize: 13 }}>{shows} séries · {movies} films vus{traktState.last ? ' · synchro ' + new Date(traktState.last).toLocaleString('fr-FR') : ''}</span>
          </div>
          {traktImport && (traktImport.running || traktImport.t) && (
            <span className="muted" style={{ fontSize: 13 }}>
              {traktImport.running ? 'Import de ton historique Trakt…' : `Importé dans Lumen : ${traktImport.shows} séries trouvées sur ton serveur, ${traktImport.eps} épisodes vus, ${traktImport.paused} lecture${traktImport.paused > 1 ? 's' : ''} en pause.`}
            </span>
          )}
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
            <input type="checkbox" checked={settings.traktScrobble !== false} onChange={(e) => updateSettings({ traktScrobble: e.target.checked })} />
            Envoyer à Trakt ce que je regarde, en direct (scrobble)
          </label>
          <div className="actions" style={{ marginTop: 0 }}>
            <button className="btn btn-ghost btn-sm" onClick={traktSync} disabled={traktState.syncing}><Icon name="refresh" size={16} />{traktState.syncing ? 'Synchronisation…' : 'Synchroniser maintenant'}</button>
            <button className="btn btn-ghost btn-sm" onClick={() => { trakt.disconnect(); force((n) => n + 1); setMsg('Déconnecté de Trakt.'); }}>Déconnecter</button>
          </div>
          <span className="muted" style={{ fontSize: 13, lineHeight: 1.5 }}>Ton historique Trakt (épisodes vus et lectures en pause) est importé dans Lumen à chaque synchro : il alimente « Continuer à regarder » et « Mes séries ». Ce que tu coches dans Lumen est envoyé à Trakt.</span>
        </>
      )}
      {traktState.error && <p className="err">{traktState.error}</p>}
      {msg && <p className={/refus|expir|refusé|Client/.test(msg) ? 'err' : 'ok'}>{msg}</p>}
    </div>
  );
}
