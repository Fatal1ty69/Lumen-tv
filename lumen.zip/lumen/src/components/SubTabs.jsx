// Onglets de second niveau (PC) : regroupent sous « Mon espace » et « Découvrir » les écrans
// qui avaient chacun leur entrée dans le menu. Sur la TV, le menu complet est conservé.
import React from 'react';
import { useApp } from '../lib/app.jsx';
import { isTV } from '../tv/native.js';

const ESPACE = [
  ['plus', 'À voir plus tard', { name: 'monespace', tab: 'plus' }],
  ['liste', 'Ma liste', { name: 'monespace', tab: 'liste' }],
  ['reprendre', 'À reprendre', { name: 'monespace', tab: 'reprendre' }],
  ['chaines', 'Chaînes', { name: 'monespace', tab: 'chaines' }],
  ['messeries', 'Mes séries', { name: 'messeries' }],
  ['agenda', 'Agenda', { name: 'agenda' }]
];

export function EspaceTabs({ current, counts = {}, style }) {
  const { goRoot } = useApp();
  if (isTV) return null;
  return (
    <div className="subtabs" role="tablist" aria-label="Mon espace" style={style}>
      {ESPACE.map(([id, label, route]) => (
        <button key={id} role="tab" aria-selected={current === id} className={current === id ? 'on' : ''} onClick={() => goRoot(route)}>
          {label}{counts[id] !== undefined && <span>{counts[id]}</span>}
        </button>
      ))}
    </div>
  );
}

export function DecouvrirTabs({ current }) {
  const { goRoot } = useApp();
  if (isTV) return null;
  return (
    <div className="seg subseg" role="tablist" aria-label="Découvrir">
      <button role="tab" aria-selected={current === 'decouvrir'} className={current === 'decouvrir' ? 'on' : ''} onClick={() => goRoot({ name: 'decouvrir' })}>Explorer</button>
      <button role="tab" aria-selected={current === 'vitrine'} className={current === 'vitrine' ? 'on' : ''} onClick={() => goRoot({ name: 'vitrine' })}>Plateformes</button>
    </div>
  );
}
