// « Qui regarde ? » : choix du profil au lancement
import React, { useEffect, useRef } from 'react';
import { getProfiles, activeProfile } from '../lib/store.js';

export function switchProfile() {
  try { sessionStorage.removeItem('lumen:picked'); } catch { /* rien */ }
  location.reload();
}

export function ProfileAvatar({ profile, size = 40 }) {
  return (
    <span className="pf-av" style={{ width: size, height: size, fontSize: size * 0.46, background: profile.color }}>
      {(profile.name || '?')[0].toUpperCase()}
    </span>
  );
}

export default function ProfilePicker({ onPick }) {
  const list = getProfiles();
  const last = activeProfile();
  const box = useRef(null);
  useEffect(() => {
    const el = box.current && (box.current.querySelector(`[data-pid="${last}"]`) || box.current.querySelector('button'));
    if (el) el.focus();
  }, []);
  return (
    <div className="pf-screen">
      <div className="logo" style={{ fontSize: 48 }}>LUMEN</div>
      <h1 className="pf-title">Qui regarde ?</h1>
      <div className="pf-list" ref={box}>
        {list.map((p) => (
          <button key={p.id} data-pid={p.id} className="pf-card" onClick={() => onPick(p.id)} aria-label={p.name}>
            <ProfileAvatar profile={p} size={150} />
            <span className="pf-name">{p.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
