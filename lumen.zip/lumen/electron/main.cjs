// Lumen, process principal Electron
const { app, BrowserWindow, ipcMain, session, shell, dialog, net, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, execFile } = require('child_process');
const net2 = require('net');
const os = require('os');

const isDev = process.env.LUMEN_DEV === '1';
const IPTV_UA = 'VLC/3.0.20 LibVLC/3.0.20';
let win;

// Choix des pistes audio dans le lecteur intégré
app.commandLine.appendSwitch('enable-blink-features', 'AudioVideoTracks');

// Hôtes pour lesquels on garde le User-Agent normal (TMDB, YouTube, Google Fonts)
const KEEP_UA = /(themoviedb\.org|tmdb\.org|youtube|ytimg|googlevideo|google|gstatic)/i;

function setupNetwork() {
  const ses = session.defaultSession;

  // Les serveurs Xtream refusent souvent le User-Agent d'Electron
  ses.webRequest.onBeforeSendHeaders((details, cb) => {
    const headers = details.requestHeaders;
    // Les intégrations YouTube exigent un Referer web (absent depuis file://)
    if (/youtube(-nocookie)?\.com\/embed\//i.test(details.url) && !headers['Referer']) {
      headers['Referer'] = 'https://lumen-player.app/';
    }
    if (!KEEP_UA.test(details.url)) {
      headers['User-Agent'] = IPTV_UA;
      delete headers['Origin'];
      delete headers['Referer'];
    }
    cb({ requestHeaders: headers });
  });

  // Les serveurs IPTV n'envoient pas d'en-têtes CORS : on les ajoute
  ses.webRequest.onHeadersReceived((details, cb) => {
    if (KEEP_UA.test(details.url)) return cb({});
    const h = details.responseHeaders || {};
    for (const k of Object.keys(h)) {
      if (k.toLowerCase().startsWith('access-control-')) delete h[k];
    }
    h['Access-Control-Allow-Origin'] = ['*'];
    h['Access-Control-Allow-Headers'] = ['*'];
    h['Access-Control-Allow-Methods'] = ['GET, HEAD, OPTIONS'];
    h['Access-Control-Expose-Headers'] = ['*'];
    const res = { responseHeaders: h };
    if (details.method === 'OPTIONS') res.statusLine = 'HTTP/1.1 200 OK';
    cb(res);
  });
}

// v28 : seules les adresses web (et e-mail) partent vers le navigateur du système.
// Une adresse file://, un protocole d'application ou un lien forgé dans une donnée distante
// (guide, fiche, playlist) ne peut plus déclencher l'ouverture d'un programme local.
function safeExternal(url) {
  try {
    const u = new URL(String(url));
    if (u.protocol === 'https:' || u.protocol === 'http:' || u.protocol === 'mailto:') {
      shell.openExternal(u.toString());
      return true;
    }
  } catch { /* adresse invalide */ }
  return false;
}

// La fenêtre ne quitte jamais l'application : une page externe hériterait sinon du pont window.lumen
function isAppUrl(url) {
  return isDev ? String(url).startsWith('http://localhost:5173') : String(url).startsWith('file://');
}

function createWindow() {
  win = new BrowserWindow({
    width: 1600,
    height: 940,
    minWidth: 1100,
    minHeight: 680,
    backgroundColor: '#09090B',
    autoHideMenuBar: true,
    title: 'Lumen',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      autoplayPolicy: 'no-user-gesture-required'
    }
  });
  win.setMenuBarVisibility(false);

  if (isDev) {
    win.loadURL('http://localhost:5173');
    win.webContents.openDevTools({ mode: 'detach' });
  } else {
    win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }

  // Les liens externes s'ouvrent dans le navigateur
  win.webContents.setWindowOpenHandler(({ url }) => {
    safeExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (isAppUrl(url)) return;
    e.preventDefault();
    safeExternal(url);
  });
  win.webContents.on('will-attach-webview', (e) => e.preventDefault());
  win.on('enter-full-screen', () => win.webContents.send('fullscreen', true));
  win.on('leave-full-screen', () => win.webContents.send('fullscreen', false));
}

// Lecteurs externes connus sous Windows
const KNOWN_PLAYERS = [
  'C:\\Program Files\\VideoLAN\\VLC\\vlc.exe',
  'C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe',
  'C:\\Program Files\\mpv\\mpv.exe',
  'C:\\Program Files\\MPC-HC\\mpc-hc64.exe'
];

ipcMain.handle('external-play', async (_e, { url, title, playerPath }) => {
  const candidates = [playerPath, ...KNOWN_PLAYERS].filter(Boolean);
  const exe = candidates.find((p) => { try { return fs.existsSync(p); } catch { return false; } });
  if (!exe) return { ok: false, error: 'Aucun lecteur externe trouvé. Indique le chemin de VLC ou mpv dans les Réglages.' };
  const args = [];
  const name = path.basename(exe).toLowerCase();
  if (name.includes('vlc')) args.push(`--meta-title=${title || 'Lumen'}`, `--http-user-agent=${IPTV_UA}`, url);
  else if (name.includes('mpv')) args.push(`--title=${title || 'Lumen'}`, `--user-agent=${IPTV_UA}`, url);
  else args.push(url);
  spawn(exe, args, { detached: true, stdio: 'ignore' }).unref();
  return { ok: true };
});

ipcMain.handle('pick-player', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Choisir le lecteur externe',
    properties: ['openFile'],
    filters: [{ name: 'Programmes', extensions: ['exe'] }]
  });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('toggle-fullscreen', (_e, value) => {
  if (!win) return false;
  const next = typeof value === 'boolean' ? value : !win.isFullScreen();
  win.setFullScreen(next);
  return next;
});

ipcMain.handle('open-external', (_e, url) => safeExternal(url));

// Requêtes vers les serveurs IPTV faites depuis le process principal : pas de CORS, vraies erreurs réseau
const NET_ERRORS = {
  ERR_NAME_NOT_RESOLVED: 'Adresse introuvable : vérifie l\'orthographe du serveur.',
  ERR_NAME_RESOLUTION_FAILED: 'Adresse introuvable : vérifie l\'orthographe du serveur.',
  ERR_CONNECTION_REFUSED: 'Le serveur refuse la connexion : vérifie le port (le nombre après les deux-points).',
  ERR_CONNECTION_TIMED_OUT: 'Le serveur ne répond pas (délai dépassé).',
  ERR_TIMED_OUT: 'Le serveur ne répond pas (délai dépassé).',
  ERR_CONNECTION_RESET: 'La connexion a été coupée par le serveur ou par le réseau.',
  ERR_CONNECTION_CLOSED: 'La connexion a été coupée par le serveur ou par le réseau.',
  ERR_EMPTY_RESPONSE: 'Le serveur a répondu vide : essaie avec http:// au lieu de https:// (ou l\'inverse).',
  ERR_SSL_PROTOCOL_ERROR: 'Erreur de connexion sécurisée : essaie avec http:// au lieu de https://.',
  ERR_INTERNET_DISCONNECTED: 'Pas de connexion internet.',
  ERR_ADDRESS_UNREACHABLE: 'Serveur injoignable depuis ce réseau.',
  ERR_TOO_MANY_REDIRECTS: 'Le serveur redirige en boucle.'
};

// Requête générique (API OpenSubtitles, etc.)
ipcMain.handle('http-req', async (_e, { url, method = 'GET', headers = {}, body = null, timeout = 30000 }) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await net.fetch(url, { method, headers, body, signal: ctrl.signal });
    const pages = res.headers.get('x-pagination-page-count');
    return { ok: true, status: res.status, text: await res.text(), pageCount: pages ? Number(pages) : null };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  } finally {
    clearTimeout(timer);
  }
});

ipcMain.handle('http-get', async (_e, { url, timeout = 30000 }) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await net.fetch(url, { signal: ctrl.signal, headers: { 'User-Agent': IPTV_UA }, cache: 'no-store' });
    const text = await res.text();
    return { ok: true, status: res.status, text };
  } catch (err) {
    const raw = String((err && err.message) || err);
    const code = (raw.match(/ERR_[A-Z_]+/) || [])[0] || '';
    let message = NET_ERRORS[code];
    if (!message && /abort/i.test(raw)) message = 'Le serveur ne répond pas (délai dépassé).';
    if (!message && code.startsWith('ERR_CERT')) message = 'Certificat de sécurité invalide : essaie avec http:// au lieu de https://.';
    return { ok: false, error: (message || 'Impossible de joindre le serveur.') + (code ? ` (${code})` : '') };
  } finally {
    clearTimeout(timer);
  }
});

// ---------------------------------------------------------------------------
// Moteur mpv : lecture de tous les formats, pilotée par Lumen via l'IPC JSON de mpv
// ---------------------------------------------------------------------------
let mpv = null;

function mpvLocal() {
  return path.join(app.getPath('userData'), 'mpv', process.platform === 'win32' ? 'mpv.exe' : 'mpv');
}

function findMpv(custom) {
  const home = os.homedir();
  const list = [
    custom, mpvLocal(),
    'C:\\Program Files\\mpv\\mpv.exe', 'C:\\Program Files (x86)\\mpv\\mpv.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'mpv', 'mpv.exe'),
    path.join(home, 'scoop', 'apps', 'mpv', 'current', 'mpv.exe'),
    'C:\\ProgramData\\chocolatey\\bin\\mpv.exe',
    '/usr/bin/mpv', '/usr/local/bin/mpv', '/opt/homebrew/bin/mpv'
  ].filter(Boolean);
  for (const p of list) { try { if (fs.existsSync(p)) return p; } catch { /* suivant */ } }
  // Dans le PATH (winget, installation manuelle)
  try {
    const r = require('child_process').execSync(process.platform === 'win32' ? 'where mpv.exe' : 'which mpv', { stdio: ['ignore', 'pipe', 'ignore'], timeout: 3000 }).toString().split(/\r?\n/)[0].trim();
    if (r && fs.existsSync(r)) return r;
  } catch { /* absent */ }
  return null;
}

function mpvSend(cmd) {
  if (mpv && mpv.sock && !mpv.sock.destroyed) { mpv.sock.write(JSON.stringify({ command: cmd }) + '\n'); return true; }
  return false;
}

function stopMpv() {
  if (!mpv) return;
  const m = mpv;
  mpv = null;
  try { m.sock && m.sock.destroy(); } catch { /* déjà fermé */ }
  try { m.proc.kill(); } catch { /* déjà arrêté */ }
}

const OBSERVE = ['time-pos', 'duration', 'pause', 'track-list', 'eof-reached', 'volume', 'media-title', 'video-params', 'estimated-vf-fps', 'container-fps', 'video-codec', 'audio-codec', 'video-bitrate', 'file-format'];

ipcMain.handle('mpv-find', (_e, custom) => findMpv(custom));

ipcMain.handle('mpv-play', async (_e, o) => {
  stopMpv();
  const exe = findMpv(o.path);
  if (!exe) return { ok: false, error: 'mpv est introuvable. Installe-le depuis les Réglages.' };
  const pipe = process.platform === 'win32' ? `\\\\.\\pipe\\lumen-mpv-${Date.now()}` : path.join(os.tmpdir(), `lumen-mpv-${Date.now()}.sock`);
  const args = [
    `--input-ipc-server=${pipe}`, '--force-window=immediate', '--keep-open=yes', '--idle=no',
    `--title=${o.title || 'Lumen'}`, `--force-media-title=${o.title || 'Lumen'}`, `--user-agent=${IPTV_UA}`,
    '--slang=fr,fre,fra,fr-FR', '--alang=fr,fre,fra,fr-FR,en,eng', '--sub-auto=fuzzy', '--hwdec=auto-safe',
    '--osd-font-size=38', '--osd-bar=yes', '--cache=yes', '--demuxer-max-bytes=200MiB'
  ];
  if (o.fullscreen !== false) args.push('--fs');
  if (o.start > 5) args.push(`--start=${Math.floor(o.start)}`);
  if (o.af) args.push(`--af=${o.af}`);
  if (o.volume != null) args.push(`--volume=${Math.round(o.volume * 100)}`);
  if (o.live) args.push('--cache-secs=8');
  if (o.extraArgs) args.push(...o.extraArgs);
  args.push('--', o.url);
  const proc = spawn(exe, args, { stdio: 'ignore', windowsHide: false });
  const me = { proc, pipe, sock: null, buf: '' };
  mpv = me;
  const send = (ev) => { if (win && !win.isDestroyed()) win.webContents.send('mpv-event', ev); };
  proc.on('exit', (code) => { if (mpv === me) mpv = null; send({ type: 'exit', code }); });
  proc.on('error', (err) => send({ type: 'error', error: String(err.message || err) }));
  // Connexion à l'IPC de mpv (le temps qu'il démarre)
  for (let i = 0; i < 50 && mpv === me; i++) {
    const ok = await new Promise((resolve) => {
      const sock = net2.connect(pipe);
      sock.once('connect', () => { me.sock = sock; resolve(true); });
      sock.once('error', () => resolve(false));
    });
    if (ok) break;
    await new Promise((r) => setTimeout(r, 120));
  }
  if (!me.sock) { stopMpv(); return { ok: false, error: 'mpv a démarré mais ne répond pas.' }; }
  me.sock.setEncoding('utf8');
  me.sock.on('data', (chunk) => {
    me.buf += chunk;
    let i;
    while ((i = me.buf.indexOf('\n')) >= 0) {
      const line = me.buf.slice(0, i);
      me.buf = me.buf.slice(i + 1);
      let msg;
      try { msg = JSON.parse(line); } catch { continue; }
      if (msg.event === 'property-change') send({ type: 'prop', name: msg.name, data: msg.data });
      else if (msg.event === 'client-message') send({ type: 'msg', args: msg.args || [] });
      else if (msg.event === 'end-file') send({ type: 'end', reason: msg.reason });
      else if (msg.event === 'file-loaded') send({ type: 'loaded' });
    }
  });
  me.sock.on('close', () => send({ type: 'closed' }));
  OBSERVE.forEach((name, n) => mpvSend(['observe_property', n + 1, name]));
  // Raccourcis propres à Lumen dans la fenêtre mpv
  mpvSend(['keybind', 'n', 'script-message lumen-next']);
  mpvSend(['keybind', 'N', 'script-message lumen-next']);
  mpvSend(['keybind', 'PGUP', 'script-message lumen-prev-channel']);
  mpvSend(['keybind', 'PGDWN', 'script-message lumen-next-channel']);
  return { ok: true, exe };
});

ipcMain.handle('mpv-cmd', (_e, cmd) => mpvSend(cmd));
ipcMain.handle('mpv-stop', () => { stopMpv(); return true; });

// Téléchargement automatique de mpv pour Windows (versions officielles shinchiro)
ipcMain.handle('mpv-download', async () => {
  const progress = (p, step) => { if (win && !win.isDestroyed()) win.webContents.send('mpv-dl', { p, step }); };
  try {
    if (process.platform !== 'win32') return { ok: false, error: 'Le téléchargement automatique est prévu pour Windows. Installe mpv avec le gestionnaire de paquets.' };
    progress(0, 'Recherche de la dernière version');
    const rel = await net.fetch('https://api.github.com/repos/shinchiro/mpv-winbuild-cmake/releases/latest', { headers: { 'User-Agent': 'Lumen', Accept: 'application/vnd.github+json' } }).then((r) => r.json());
    const assets = (rel && rel.assets) || [];
    const asset = assets.find((a) => /^mpv-x86_64-\d{8}-git-[0-9a-f]+\.7z$/i.test(a.name)) || assets.find((a) => /^mpv-x86_64-v3-.*\.7z$/i.test(a.name));
    if (!asset) return { ok: false, error: 'Version de mpv introuvable sur GitHub. Installe mpv manuellement depuis mpv.io.' };
    const dir = path.dirname(mpvLocal());
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, 'mpv.7z');
    const res = await net.fetch(asset.browser_download_url);
    if (!res.ok) return { ok: false, error: 'Téléchargement refusé (' + res.status + ').' };
    const total = Number(res.headers.get('content-length')) || asset.size || 0;
    const out = fs.createWriteStream(file);
    const reader = res.body.getReader();
    let got = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      got += value.length;
      out.write(Buffer.from(value));
      if (total) progress(Math.round((got / total) * 90), 'Téléchargement');
    }
    await new Promise((r) => out.end(r));
    progress(92, 'Décompression');
    let sz;
    try { sz = require('7zip-bin'); } catch { sz = require(path.join(process.env.LUMEN_RUNTIME || '', 'node_modules', '7zip-bin')); }
    let z = sz.path7za.replace('app.asar', 'app.asar.unpacked');
    await new Promise((resolve, reject) => execFile(z, ['x', file, '-o' + dir, '-y'], (err) => (err ? reject(err) : resolve())));
    fs.unlinkSync(file);
    progress(100, 'Terminé');
    return fs.existsSync(mpvLocal()) ? { ok: true, path: mpvLocal() } : { ok: false, error: 'Décompression incomplète.' };
  } catch (e) {
    return { ok: false, error: 'Échec : ' + (e.message || e) };
  }
});

app.on('before-quit', stopMpv);

// ---------------------------------------------------------------------------
// Connexion Trakt par le navigateur (PKCE) : pas de Client Secret nécessaire
// ---------------------------------------------------------------------------
const http = require('http');
const crypto = require('crypto');
const TRAKT_PORT = 47811;
const TRAKT_REDIRECT = `http://localhost:${TRAKT_PORT}/callback`;
const TRAKT_API = process.env.TRAKT_API || 'https://api.trakt.tv';
const TRAKT_WEB = process.env.TRAKT_WEB || 'https://trakt.tv';
const b64url = (buf) => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

const PAGE = (title, text) => `<!doctype html><meta charset="utf-8"><title>Lumen</title><body style="margin:0;background:#09090B;color:#EDEDF0;font:16px system-ui;display:flex;align-items:center;justify-content:center;height:100vh"><div style="text-align:center"><div style="font:700 48px Impact,sans-serif;letter-spacing:4px;color:#F2A93B">LUMEN</div><h1 style="font-size:24px">${title}</h1><p style="color:#A1A1AA">${text}</p></div>`;

ipcMain.handle('trakt-pkce', async (_e, { clientId }) => {
  const verifier = b64url(crypto.randomBytes(48));
  const challenge = b64url(crypto.createHash('sha256').update(verifier).digest());
  const state = b64url(crypto.randomBytes(16));
  let server;
  try {
    const code = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Délai dépassé : la connexion n\'a pas été validée dans le navigateur.')), 5 * 60 * 1000);
      server = http.createServer((req, res) => {
        const u = new URL(req.url, TRAKT_REDIRECT);
        if (u.pathname !== '/callback') { res.writeHead(404); res.end(); return; }
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        if (u.searchParams.get('state') !== state || !u.searchParams.get('code')) {
          res.end(PAGE('Connexion refusée', 'Tu peux fermer cet onglet et réessayer depuis Lumen.'));
          clearTimeout(timer);
          reject(new Error(u.searchParams.get('error') === 'access_denied' ? 'Connexion refusée sur Trakt.' : 'Réponse de Trakt invalide.'));
          return;
        }
        res.end(PAGE('Lumen est connecté à Trakt', 'Tu peux fermer cet onglet et revenir dans Lumen.'));
        clearTimeout(timer);
        resolve(u.searchParams.get('code'));
      });
      server.on('error', (err) => { clearTimeout(timer); reject(new Error(err.code === 'EADDRINUSE' ? `Le port ${TRAKT_PORT} est déjà utilisé sur ce PC.` : String(err.message || err))); });
      server.listen(TRAKT_PORT, '127.0.0.1', () => {
        const q = new URLSearchParams({ response_type: 'code', client_id: clientId, redirect_uri: TRAKT_REDIRECT, state, code_challenge: challenge, code_challenge_method: 'S256' });
        const url = `${TRAKT_WEB}/oauth/authorize?${q}`;
        if (process.env.LUMEN_NO_BROWSER) console.log('TRAKT_AUTH_URL ' + url);
        else shell.openExternal(url);
      });
    });
    const r = await net.fetch(TRAKT_API + '/oauth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': clientId },
      body: JSON.stringify({ code, client_id: clientId, redirect_uri: TRAKT_REDIRECT, grant_type: 'authorization_code', code_verifier: verifier })
    });
    const text = await r.text();
    if (r.status !== 200) return { ok: false, error: `Trakt a refusé l'échange du code (${r.status}). Vérifie l'adresse de retour de ton application Trakt : ${TRAKT_REDIRECT}` };
    return { ok: true, tokens: JSON.parse(text) };
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  } finally {
    try { server && server.close(); } catch { /* déjà fermé */ }
  }
});

// v30 : une seule fenêtre Lumen à la fois. Deux instances se disputent le stockage de Chromium,
// ce qui peut le faire repartir vide. Un second lancement ramène simplement la fenêtre existante.
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.exit(0);
} else {
  app.on('second-instance', () => {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.show();
    win.focus();
  });
}

// v30 : copie de sécurité des comptes, hors du stockage de Chromium (userData/lumen-comptes.bak).
// Chiffrée par Windows (DPAPI, liée à ta session) quand c'est possible. Jamais écrasée par une liste vide ;
// la version précédente est gardée en .bak.1.
const BACKUP = () => path.join(app.getPath('userData'), 'lumen-comptes.bak');
function encode(text) {
  if (safeStorage && safeStorage.isEncryptionAvailable()) return Buffer.concat([Buffer.from('LMN1'), safeStorage.encryptString(text)]);
  return Buffer.concat([Buffer.from('LMN0'), Buffer.from(text, 'utf8')]);
}
function decode(buf) {
  const tag = buf.subarray(0, 4).toString('latin1');
  if (tag === 'LMN1') return safeStorage.decryptString(buf.subarray(4));
  if (tag === 'LMN0') return buf.subarray(4).toString('utf8');
  throw new Error('format inconnu');
}
ipcMain.handle('backup-save', (_e, data) => {
  try {
    if (!data || !Array.isArray(data.accounts) || !data.accounts.length) return { ok: false, reason: 'vide' };
    const text = JSON.stringify({ ...data, savedAt: Date.now() });
    const file = BACKUP();
    try {
      const prev = decode(fs.readFileSync(file));
      if (JSON.stringify({ ...JSON.parse(prev), savedAt: 0 }) === JSON.stringify({ ...data, savedAt: 0 })) return { ok: true, same: true };
      fs.copyFileSync(file, file + '.1');
    } catch { /* pas encore de sauvegarde */ }
    fs.writeFileSync(file + '.tmp', encode(text));
    fs.renameSync(file + '.tmp', file);
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: String(e && e.message || e) };
  }
});
ipcMain.handle('backup-load', () => {
  for (const f of [BACKUP(), BACKUP() + '.1']) {
    try {
      const data = JSON.parse(decode(fs.readFileSync(f)));
      if (Array.isArray(data.accounts) && data.accounts.length) return data;
    } catch { /* suivante */ }
  }
  return null;
});

app.whenReady().then(() => {
  if (!gotLock) return;
  setupNetwork();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// Synchro maison : retrouve Lumen TV sur le réseau local (connexions sortantes uniquement, rien à autoriser dans le pare-feu)
function probe(host, port, ms) {
  return new Promise((resolve) => {
    const s = net2.connect({ host, port });
    const done = (ok) => { s.destroy(); resolve(ok); };
    s.setTimeout(ms, () => done(false));
    s.once('connect', () => done(true));
    s.once('error', () => done(false));
  });
}
ipcMain.handle('lan-scan', async (_e, ports = [47820]) => {
  const bases = new Set();
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family !== 'IPv4' || a.internal) continue;
      if (!/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address)) continue;
      bases.add(a.address.split('.').slice(0, 3).join('.'));
    }
  }
  const targets = [];
  for (const b of bases) for (let i = 1; i < 255; i++) for (const p of ports) targets.push([b + '.' + i, p]);
  const open = [];
  let next = 0;
  await Promise.all(Array.from({ length: 96 }, async () => {
    while (next < targets.length) {
      const [h, p] = targets[next++];
      if (await probe(h, p, 450)) open.push({ host: h, port: p });
    }
  }));
  const found = [];
  for (const t of open) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 1500);
      const res = await net.fetch(`http://${t.host}:${t.port}/ping`, { signal: ctrl.signal, cache: 'no-store' });
      clearTimeout(timer);
      if (/Lumen TV/.test(await res.text())) found.push(t);
    } catch { /* pas Lumen */ }
  }
  return found;
});

// Portails Stalker (MAG) : requêtes avec en-têtes exacts (User-Agent, Cookie, Authorization), redirections suivies
ipcMain.handle('stalker-req', async (_e, { url, headers = {}, timeout = 12000, maxBytes = 8 * 1024 * 1024 }) => {
  const httpMod = require('http');
  const httpsMod = require('https');
  const once = (u, left) => new Promise((resolve) => {
    let target;
    try { target = new URL(u); } catch { resolve({ ok: false, error: 'Adresse invalide' }); return; }
    const mod = target.protocol === 'https:' ? httpsMod : httpMod;
    const req = mod.request(target, { method: 'GET', headers, timeout, rejectUnauthorized: false }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && left > 0) {
        res.resume();
        resolve(once(new URL(res.headers.location, target).toString(), left - 1));
        return;
      }
      const chunks = [];
      let size = 0;
      let cut = false;
      let finished = false;
      res.on('data', (c) => {
        size += c.length;
        if (size > maxBytes) { cut = true; chunks.push(c.slice(0, Math.max(0, c.length - (size - maxBytes)))); res.destroy(); return; }
        chunks.push(c);
      });
      const end = (streamError) => {
        if (finished) return;
        finished = true;
        let buf = Buffer.concat(chunks);
        const ce = String(res.headers['content-encoding'] || '').toLowerCase();
        try {
          const zlib = require('zlib');
          if (ce.includes('gzip')) buf = zlib.gunzipSync(buf, { finishFlush: zlib.constants.Z_SYNC_FLUSH });
          else if (ce.includes('deflate')) buf = zlib.inflateSync(buf, { finishFlush: zlib.constants.Z_SYNC_FLUSH });
        } catch { /* contenu tronqué : on garde tel quel */ }
        const status = res.statusCode || 0;
        resolve({
          ok: status >= 200 && status < 400 && !streamError,
          status,
          type: res.headers['content-type'] || '',
          finalUrl: u,
          text: buf.toString('utf8'),
          bytes: Math.min(size, maxBytes),
          cut,
          error: streamError ? String((streamError && streamError.message) || streamError) : (status >= 400 ? `HTTP ${status}` : '')
        });
      };
      res.once('end', () => end());
      res.once('close', () => end());
      res.once('error', end);
    });
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'Le portail ne répond pas (délai dépassé)' }); });
    req.on('error', (err) => resolve({ ok: false, error: String((err && err.message) || err) }));
    req.end();
  });
  return once(url, 5);
});
ipcMain.handle('hash', (_e, { algo, text }) => require('crypto').createHash(algo).update(String(text)).digest('hex'));

// Cache XMLTV persistant : lecture instantanée, validation ETag/Last-Modified et
// repli sur la dernière copie en cas de coupure réseau.
ipcMain.handle('fetch-xml-cache', async (_e, { url, timeout = 90000, ua, force = false, maxAge = 6 * 3600 * 1000 }) => {
  const crypto = require('crypto');
  const zlib = require('zlib');
  const dir = path.join(app.getPath('userData'), 'cache', 'xmltv');
  const key = crypto.createHash('sha256').update(String(url)).digest('hex');
  const xmlFile = path.join(dir, key + '.xml');
  const metaFile = path.join(dir, key + '.json');
  let meta = null;
  let cachedText = null;
  try { meta = JSON.parse(fs.readFileSync(metaFile, 'utf8')); } catch { /* premier chargement */ }
  try { cachedText = fs.readFileSync(xmlFile, 'utf8'); } catch { /* premier chargement */ }
  const age = meta && meta.fetchedAt ? Date.now() - meta.fetchedAt : Infinity;
  if (!force && cachedText && age < Math.max(60000, Number(maxAge) || 0)) {
    return { ok: true, text: cachedText, finalUrl: meta.finalUrl || url, cached: true, fetchedAt: meta.fetchedAt };
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const headers = { 'Accept-Encoding': 'gzip', Accept: 'application/xml,text/xml,*/*', 'User-Agent': ua || IPTV_UA };
    if (meta && meta.etag) headers['If-None-Match'] = meta.etag;
    if (meta && meta.lastModified) headers['If-Modified-Since'] = meta.lastModified;
    const res = await net.fetch(url, { signal: ctrl.signal, cache: 'no-store', headers });
    if (res.status === 304 && cachedText) {
      meta = { ...meta, fetchedAt: Date.now() };
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(metaFile, JSON.stringify(meta));
      return { ok: true, text: cachedText, finalUrl: meta.finalUrl || url, cached: true, fetchedAt: meta.fetchedAt };
    }
    if (!res.ok) throw new Error('Le serveur a répondu ' + res.status);
    const buf = Buffer.from(await res.arrayBuffer());
    let text;
    if (buf.length > 1 && buf[0] === 0x1f && buf[1] === 0x8b) text = zlib.gunzipSync(buf).toString('utf8');
    else text = buf.toString('utf8');
    if (!/<tv[\s>]/i.test(text)) throw new Error('Le fichier reçu ne ressemble pas à un guide XMLTV.');
    meta = {
      url, finalUrl: res.url || url, fetchedAt: Date.now(),
      etag: res.headers.get('etag') || '', lastModified: res.headers.get('last-modified') || '', bytes: Buffer.byteLength(text)
    };
    fs.mkdirSync(dir, { recursive: true });
    const tmp = xmlFile + '.tmp';
    fs.writeFileSync(tmp, text, 'utf8');
    fs.renameSync(tmp, xmlFile);
    fs.writeFileSync(metaFile, JSON.stringify(meta));
    return { ok: true, text, finalUrl: meta.finalUrl, cached: false, fetchedAt: meta.fetchedAt };
  } catch (err) {
    if (cachedText) return { ok: true, text: cachedText, finalUrl: meta && meta.finalUrl || url, cached: true, stale: true, fetchedAt: meta && meta.fetchedAt };
    const raw = String((err && err.message) || err);
    return { ok: false, error: /abort/i.test(raw) ? 'Le serveur XMLTV ne répond pas (délai dépassé).' : raw };
  } finally { clearTimeout(timer); }
});

// Guide XMLTV : récupère le fichier (texte ou .gz) et le décompresse si besoin
ipcMain.handle('fetch-xml', async (_e, { url, timeout = 60000, ua }) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await net.fetch(url, { signal: ctrl.signal, cache: 'no-store', headers: { 'Accept-Encoding': 'gzip', Accept: '*/*', 'User-Agent': ua || IPTV_UA } });
    const finalUrl = res.url || url;
    if (!res.ok) return { ok: false, error: 'Le serveur a répondu ' + res.status, status: res.status, finalUrl };
    const buf = Buffer.from(await res.arrayBuffer());
    let text;
    if (buf.length > 1 && buf[0] === 0x1f && buf[1] === 0x8b) {
      try { text = require('zlib').gunzipSync(buf).toString('utf8'); }
      catch { text = buf.toString('utf8'); }
    } else {
      text = buf.toString('utf8');
    }
    return { ok: true, status: res.status, text, finalUrl };
  } catch (err) {
    const raw = String((err && err.message) || err);
    return { ok: false, error: /abort/i.test(raw) ? 'Le serveur ne répond pas (délai dépassé).' : raw };
  } finally {
    clearTimeout(timer);
  }
});
