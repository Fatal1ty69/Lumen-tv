const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lumen', {
  externalPlay: (opts) => ipcRenderer.invoke('external-play', opts),
  pickPlayer: () => ipcRenderer.invoke('pick-player'),
  toggleFullscreen: (value) => ipcRenderer.invoke('toggle-fullscreen', value),
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  httpGet: (url, timeout) => ipcRenderer.invoke('http-get', { url, timeout }),
  httpReq: (opts) => ipcRenderer.invoke('http-req', opts),
  lanScan: (ports) => ipcRenderer.invoke('lan-scan', ports),
  traktPkce: (clientId) => ipcRenderer.invoke('trakt-pkce', { clientId }),
  mpvFind: (custom) => ipcRenderer.invoke('mpv-find', custom),
  mpvPlay: (opts) => ipcRenderer.invoke('mpv-play', opts),
  mpvCmd: (cmd) => ipcRenderer.invoke('mpv-cmd', cmd),
  mpvStop: () => ipcRenderer.invoke('mpv-stop'),
  mpvDownload: () => ipcRenderer.invoke('mpv-download'),
  onMpv: (cb) => {
    const fn = (_e, v) => cb(v);
    ipcRenderer.on('mpv-event', fn);
    return () => ipcRenderer.removeListener('mpv-event', fn);
  },
  onMpvDl: (cb) => {
    const fn = (_e, v) => cb(v);
    ipcRenderer.on('mpv-dl', fn);
    return () => ipcRenderer.removeListener('mpv-dl', fn);
  },
  onFullscreen: (cb) => {
    const fn = (_e, v) => cb(v);
    ipcRenderer.on('fullscreen', fn);
    return () => ipcRenderer.removeListener('fullscreen', fn);
  }
});
