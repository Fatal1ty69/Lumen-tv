const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lumen', {
  externalPlay: (opts) => ipcRenderer.invoke('external-play', opts),
  pickPlayer: () => ipcRenderer.invoke('pick-player'),
  toggleFullscreen: (value) => ipcRenderer.invoke('toggle-fullscreen', value),
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  httpGet: (url, timeout) => ipcRenderer.invoke('http-get', { url, timeout }),
  httpReq: (opts) => ipcRenderer.invoke('http-req', opts),
  stalkerReq: (opts) => ipcRenderer.invoke('stalker-req', opts),
  hash: (algo, text) => ipcRenderer.invoke('hash', { algo, text }),
  backupSave: (data) => ipcRenderer.invoke('backup-save', data),
  backupLoad: () => ipcRenderer.invoke('backup-load'),
  fetchXml: (url, timeout, ua) => ipcRenderer.invoke('fetch-xml', { url, timeout, ua }),
  fetchXmlCache: (url, opts = {}) => ipcRenderer.invoke('fetch-xml-cache', { url, ...opts }),
  lanScan: (ports) => ipcRenderer.invoke('lan-scan', ports),
  traktPkce: (clientId) => ipcRenderer.invoke('trakt-pkce', { clientId }),
  mpvFind: (custom) => ipcRenderer.invoke('mpv-find', custom),
  mpvPlay: (opts) => ipcRenderer.invoke('mpv-play', opts),
  mpvCmd: (cmd) => ipcRenderer.invoke('mpv-cmd', cmd),
  mpvStop: () => ipcRenderer.invoke('mpv-stop'),
  mpvDownload: () => ipcRenderer.invoke('mpv-download'),
  onMpv: (cb) => {
    const fn = (_e, v) => cb(v);
    ipcRenderer.on('mpv-event', fn);
    return () => ipcRenderer.removeListener('mpv-event', fn);
  },
  onMpvDl: (cb) => {
    const fn = (_e, v) => cb(v);
    ipcRenderer.on('mpv-dl', fn);
    return () => ipcRenderer.removeListener('mpv-dl', fn);
  },
  onFullscreen: (cb) => {
    const fn = (_e, v) => cb(v);
    ipcRenderer.on('fullscreen', fn);
    return () => ipcRenderer.removeListener('fullscreen', fn);
  }
});
