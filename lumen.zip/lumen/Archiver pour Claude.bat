@echo off
chcp 65001 >nul
setlocal
title Lumen - Archive pour Claude
cd /d "%~dp0"
if not exist "%~dp0package.json" (
  echo.
  echo  Place ce fichier a la racine de Lumen, a cote de package.json, puis relance.
  echo.
  pause
  exit /b 1
)
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HHmm"') do set "D=%%i"
set "OUT=%~dp0..\Lumen-sources-%D%.zip"
echo.
echo  Creation de l'archive des sources (sans node_modules, dist ni sauvegardes)...
tar -a -c -f "%OUT%" --exclude=node_modules --exclude=dist --exclude=dist.previous --exclude=.lumen-backups --exclude=release --exclude=android/app/build --exclude=android/build --exclude=android/.gradle --exclude="Lumen-v*" .
if errorlevel 1 (
  echo.
  echo  La creation de l'archive a echoue.
  pause
  exit /b 1
)
echo.
echo  Archive prete, a cote du dossier Lumen :
echo  %OUT%
echo.
explorer /select,"%OUT%"
pause
